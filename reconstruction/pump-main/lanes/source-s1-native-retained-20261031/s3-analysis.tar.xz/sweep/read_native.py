"""Prepared bounded S3 native reader. Do not run before root admission.

Only stdlib and the existing sealed logical decoder are used. Binding JSON is
reviewed input: function roles, fee ABI roots and semantic choice PCs are never
guessed from old frame offsets, 7/9 geometry, or physical block placement.
"""
from pathlib import Path
import argparse
import importlib.util
import json
import re

PARSER = Path('/dev/shm/pump-cto-option-c1/work/carrier/native_compare.py')
PARSER_SHA = '2033142ac919d226a4539cc0f25b80066428794d198263dd0a73919c71af81e9'
spec = importlib.util.spec_from_file_location('sealed_logical_reader', PARSER)
nc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(nc)
assert nc.sha(PARSER.read_bytes()) == PARSER_SHA


def graph(rows, size):
    blocks = nc.cfg(rows, size)
    by = {r['offset']: r for r in rows}
    pred = {p: [] for p in by}
    succ = {}
    for p, r in by.items():
        n = p + r['bytes']
        q = ([r['jump']] + ([n] if r['opcode'] & 0xf0 and n in by else [])) if 'jump' in r else [] if r['opcode'] == 0x95 else [n] if n in by else []
        succ[p] = q
        for t in q:
            pred[t].append(p)
    return blocks, by, pred, succ


def overlaps(r, lo, hi):
    return r.get('memoryKind') == 'write' and r.get('memoryBase') == 10 and r['displacement'] < hi and lo < r['displacement'] + r['memoryWidth']


def entry_fee_spills(rows, blocks, fee_input):
    """Derive actual first-block FP destinations from a reviewed fee ABI root.

    Register root or r5 argument-frame root may be supplied. Only explicit MOV,
    frame-root LDX, and direct FP stores are followed; unsupported transport is
    UNKNOWN and must not be replaced with an old expected FP displacement.
    """
    if not fee_input:
        return {'status': 'UNBOUND_ABI_ROOT', 'spills': []}
    aliases = {fee_input['register']} if 'register' in fee_input else set()
    frame_aliases = {5} if 'argumentFrameOffset' in fee_input else set()
    spills = []
    for r in rows:
        if r['offset'] >= blocks[0]['end']:
            break
        op, d, s = r['opcode'], r['dst'], r['src']
        if op == 0xbf:
            if s in aliases: aliases.add(d)
            else: aliases.discard(d)
            if s in frame_aliases: frame_aliases.add(d)
            else: frame_aliases.discard(d)
        elif r.get('memoryKind') == 'write':
            if r.get('memoryBase') == 10 and op & 7 == 3 and s in aliases:
                spills.append(r)
        elif r.get('memoryKind') == 'read':
            rooted = s in frame_aliases and r['displacement'] == fee_input.get('argumentFrameOffset')
            aliases.discard(d)
            frame_aliases.discard(d)
            if rooted: aliases.add(d)
        elif op in (0x85, 0x8d):
            aliases -= set(range(6)); frame_aliases -= set(range(6))
        elif op & 7 in (0, 4, 7):
            aliases.discard(d); frame_aliases.discard(d)
    return {'status': 'DIRECT_FIRST_BLOCK_SPILLS' if spills else 'UNKNOWN_NO_DIRECT_ENTRY_SPILL', 'spills': spills}


def fee_reads(rows, blocks, by, pred, spills):
    def last_writes(pc, lo, hi):
        found, seen, todo = set(), set(), list(pred[pc])
        entry_reached = False
        while todo:
            p = todo.pop()
            if p in seen: continue
            seen.add(p)
            if overlaps(by[p], lo, hi): found.add(p)
            elif not pred[p]: entry_reached = True
            else: todo.extend(pred[p])
        return sorted(found), entry_reached
    result = []
    starts = {r['offset'] for r in spills}
    for r in rows:
        if r.get('memoryKind') != 'read' or r.get('memoryBase') != 10: continue
        lo, hi = r['displacement'], r['displacement'] + r['memoryWidth']
        covers = [s for s in spills if s['displacement'] <= lo and hi <= s['displacement'] + s['memoryWidth']]
        if not covers: continue
        defs, entry = last_writes(r['offset'], lo, hi)
        if entry or not defs or not set(defs) <= starts: continue
        block = next(b for b in blocks if b['start'] <= r['offset'] < b['end'])
        aliases, transforms, tests = {r['dst']}, [], []
        for q in rows:
            if not r['offset'] < q['offset'] < block['end']: continue
            op, d, s = q['opcode'], q['dst'], q['src']
            if 'jump' in q:
                if op & 0xf0 and (d in aliases or op & 8 and s in aliases): tests.append(q)
            elif op == 0xbf:
                if s in aliases: aliases.add(d)
                else: aliases.discard(d)
            elif op in (0x57, 0x54, 0xa7, 0xa4) and d in aliases:
                transforms.append(q)
            elif op in (0x85, 0x8d): aliases -= set(range(6))
            elif q.get('memoryKind') == 'read' or op & 7 in (0, 4, 7): aliases.discard(d)
        result.append({'read': r, 'lastDirectFpWrites': [by[p] for p in defs], 'transforms': transforms, 'sameBlockConditionalTestCandidates': tests})
    return result


def direct_copies(rows, blocks):
    pairs = []
    for a, b in zip(rows, rows[1:]):
        if a.get('memoryKind') == 'read' and a.get('memoryBase') == 10 and b.get('memoryKind') == 'write' and b.get('memoryBase') == 10 and b['opcode'] & 7 == 3 and a['dst'] == b['src'] and a['memoryWidth'] == b['memoryWidth']:
            block = next(x for x in blocks if x['start'] <= a['offset'] < x['end'])
            if b['offset'] < block['end']: pairs.append({'block': block['start'], 'width': a['memoryWidth'], 'load': a, 'store': b})
    return pairs


def contiguous_copy_groups(pairs):
    groups = []
    for a, b in zip(pairs, pairs[1:]):
        if a['block'] != b['block'] or a['store']['offset'] + 8 != b['load']['offset']: continue
        sa, sb = a['load']['displacement'], b['load']['displacement']
        da, db = a['store']['displacement'], b['store']['displacement']
        if sb-sa != db-da: continue
        wa, wb = a['width'], b['width']
        n = 7 if wa == wb == 4 and abs(sb-sa) == 3 else 9 if (wa, wb, sb-sa) in ((8, 1, 8), (1, 8, -8)) else 16 if wa == wb == 8 and abs(sb-sa) == 8 else None
        if n:
            groups.append({'block': a['block'], 'width': n, 'geometryOnly': True,
                           'load': a['load'], 'store': b['store'], 'pairs': [a, b],
                           'sourceFpRange': [min(sa, sb), min(sa, sb)+n],
                           'destinationFpRange': [min(da, db), min(da, db)+n]})
    return groups


def choice_views(rows, blocks, by, choices, copies):
    def reach(start):
        seen, todo = {start}, [start]
        table = {b['start']: b for b in blocks}
        while todo:
            for q in table[todo.pop()]['successors']:
                if q not in seen: seen.add(q); todo.append(q)
        return seen
    reachable = reach(0)
    dom = {b['start']: ({0} if b['start'] == 0 else set(reachable)) for b in blocks if b['start'] in reachable}
    changed = True
    while changed:
        changed = False
        for b in blocks:
            p = b['start']
            if p == 0 or p not in reachable: continue
            predecessors = [dom[q] for q in b['predecessors'] if q in reachable]
            new = {p} | (set.intersection(*predecessors) if predecessors else set())
            if new != dom[p]: dom[p] = new; changed = True
    views = {}
    for label, value in choices.items():
        pc = int(value, 0) if isinstance(value, str) else value
        assert pc in by
        block = next(b for b in blocks if b['start'] <= pc < b['end'])
        p = block['start']
        views[label] = {'boundInstruction': by[pc], 'block': block, 'instructions': [r for r in rows if p <= r['offset'] < block['end']],
                        'directCopiesCompletedBeforeAndDominatingChoice': [c for c in copies if c['block'] in dom.get(p, set()) and (c['block'] != p or c['store']['offset'] < pc)],
                        'directCopiesAfterAndDominatedByChoice': [c for c in copies if p in dom.get(c['block'], set()) and (c['block'] != p or pc < c['load']['offset'])]}
    return views


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--elf', type=Path, required=True)
    p.add_argument('--sha256', required=True)
    p.add_argument('--bindings', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    assert not a.out.exists(), 'preserve prior receipts'
    bindings = json.loads(a.bindings.read_text())
    assert bindings.get('rootAdmitted') is True
    assert bindings.get('sourceIrRoleReviewComplete') is True or bindings.get('sourceAbiRoleReviewComplete') is True
    assert bindings.get('elfSha256') == a.sha256
    blob, text, symbols = nc.elf(a.elf, a.sha256)
    output = {'schema': 'settings-s3-bounded-native-v1', 'elf': str(a.elf), 'sha256': a.sha256, 'bindingSha256': nc.sha(a.bindings.read_bytes()), 'decoderSha256': PARSER_SHA, 'functions': {}}
    for role, binding in bindings['functions'].items():
        picks = [s for s in symbols if re.search(binding['symbolRegex'], s['name'])]
        assert len(picks) <= 1, (role, picks)
        if not picks:
            output['functions'][role] = {'status': 'NO_NONZERO_STT_FUNC_WITNESS', 'inlineProven': False}
            continue
        fn = picks[0]; start = text[4] + fn['address'] - text[3]
        raw = blob[start:start+fn['bytes']]
        rows = nc.decode(raw, fn['address'], symbols)
        blocks, by, pred, succ = graph(rows, len(raw))
        spills = entry_fee_spills(rows, blocks, binding.get('feeInput'))
        copies = direct_copies(rows, blocks)
        groups = contiguous_copy_groups(copies)
        calls = [{'instruction': r, 'precedingLogicalRows': rows[max(0, i-16):i]} for i, r in enumerate(rows) if 'callTarget' in r]
        output['functions'][role] = {'status': 'ACTUAL_NONZERO_STT_FUNC', 'symbol': fn, 'bodySha256': nc.sha(raw), 'logicalInstructions': len(rows), 'logicalRows': rows, 'entryFeeSpills': spills, 'directFeeReadCandidates': fee_reads(rows, blocks, by, pred, spills['spills']), 'calls': calls, 'blocks': blocks, 'directFpCopyPairs': copies, 'contiguousCopyGeometryGroups': groups, 'reviewedChoiceViews': choice_views(rows, blocks, by, binding.get('choices', {}), copies+groups)}
    output['limits'] = ['Fee input and semantic choices are reviewed external role bindings; output cannot authenticate its own role labels.', 'Fee flow uses entry pure copies and last direct-FP writes only. Later/indirect/interprocedural transport unsupported here remains UNKNOWN.', 'No arbitrary opaque-callee alias closure; calls return normally for this CFG and standard SBF callee-saved rules apply only when separately invoked.', 'Copy pairs describe native geometry, not Rust Result/Try/tuple types or unique source lifetimes.', 'No absence of a symbol alone proves inlining; no physical code placement proves private-source coldness.', 'No scorer, compiler, SDK, VM, or source mutation is performed.']
    a.out.write_text(json.dumps(output, indent=2)+'\n')


if __name__ == '__main__': main()
