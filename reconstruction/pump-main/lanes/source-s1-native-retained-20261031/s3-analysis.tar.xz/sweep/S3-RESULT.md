S3 has a real structural success and a large target-byte regression. It does
not qualify as byte progress over the frozen13fe reference. No runtime,
source acceptance, PR, retry, or followup source form is proposed here.

Root's exact source/archive/native admission is preserved: source65f0162a…,
operationald95abdd9…, run41172052790, unstripped ELF
100d222047a2281a4409d8f732266955368504479d3d4076b4f6e3af08ef37e4.
The native no-loss guard SUCCESS and independent1035-row score PASS are real:
1034raw/normalized, no changed membership rows. CTO remains unmatched.
Unchanged Boolean membership for an already-unmatched window does not measure
similarity within that body.

Actual function/call layout:

- execute is0x22a10/27,400B/3337 logical instructions, body SHA256
  a8bf685d74da8226d39a8fc9f17eb0100b84a56db69415f241bb2a2b3f75e570.
- There is no nonzero validate/settings or nested sweep STT_FUNC witness and
  no corresponding direct outline call in execute. No CALLX occurs. Reviewed
  creator/fee and sweep operations remain within execute. These observations
  do not identify an inliner threshold/reason or prove source coldness.
- The source helper is still named validate, now returning the full settings
  six tuple. Its exact source leaf is
  32d4d71065f96e0d24f65ead880974a4e4cc95919ec2ef0bc113a0d536e3d7b9.
  No newly captured S3 IR is claimed; native role review uses exact source and
  the public ABI. The premeasurement reader is retained unchanged as
  read_native.prepared.py; the executed reader additionally permits an explicit
  source/ABI-review flag rather than falsely asserting a new IR capture.

The fee/shared prediction survived native code:

- Incoming fee tag R4 is actually stored at+0008 toFP-2296. This slot was
  derived from the input copy, not supplied as an old frame anchor. Direct
  backward reaching-write checks bind its validation reads to that spill.
- Before prepare+1a98 there are three such reads/tests:
  +9f8/+a00, +1480/+1488, +14d8/+14e0. Each test is JEQ0; feeNone successors
  are+e18,+1818,+18d8. Later+4f40/+5198 incoming-tag reads are outside this
  validation prefix and are not counted as validation fee tests.
- Shared is data_is_empty+188→MOV R7,R0+190→XOR1+198→delayed STX+3c8 to
  FP-2304. R7's only explicit definitions before that spill are+100/+190/+198;
  intervening calls preserve it under the standard SBF R6–R9 ABI.
- The successful range branch+1618 reaches private block+17c0. That block has
  sole predecessor+1608 and exactly four rows: store a flag+17c0, retained
  holder-byte read+17c8, shared reload+17d0, shared JNE0+17d8. It has no7/9
  payload projection. All three feeSome fallthrough entries can reach this
  head; none of the three feeNone entries can reach it in the direct CFG.
  Holder feeNone instead has shared reload/test+e40/+e48. Thus this private
  valid-fee shared gate is distinct from the common gate in rejected S1/S2.

Success-copy phase is also concrete, without inferring Rust types from width:

- The three selected32 scratch arms complete four8B stores before their fee
  read/tests: +9c0..9f0, +1440..1470, and+14a0..14d0. Nonholder source choice
  +1420 occurs before its two corresponding fee tests.
- After flag join+1960, four8B transports+1968..19a0 copy32B, and adjacent
  overlapping8B pairs+19a8..19c0 cover13B. memcpy+19f0 copies their contiguous
 45B carrier region. These are native transport facts, not a claim that45B
  uniquely identifies a Rust tuple or Result layout. Context owns the true
  target32 versus new-sharing payload roles and their real curve/pool/Fees
  consumers, as well as Error284.
- Exact raw rows, CFG sets, absence-of-feeNone reachability and choice/copy
  relations are in S3-BOUNDARY.json, derived only from the initial cached
  S3-ACTUAL logical rows. No ELF was reopened for that supplement.

The exact maintained target similarity method was independently reproduced:

| Original→candidate CTO comparison | Frozen13fe | S3 | S3−13fe |
| --- | ---: | ---: | ---: |
| win.py normalized logical matchesM |2245|1279|−966|
| win.py normalized ratio |0.6725584182144997|0.38316357100059917|−0.2893948472139005|
| clearly local exact-raw matchesM |2076|1166|−910|
| clearly local exact-raw ratio |0.621929298981426|0.34931096464949074|−0.2726183343319353|

Both candidates are27,400B/3337 logical instructions; original has3339 logical
instructions. The maintained ratio is exactly win.insns(score.normalize) plus
Cand.tokens and difflib.SequenceMatcher(None,orig,cand,autojunk=False), with
ratio2M/(3339+3337). Normalization masks internal direct-call immediates and
section-pointer LDDW values only; it does not mask registers, FP offsets or
jump displacements. This independently reproduces the author's rounded13fe
0.67256. TARGET-METRIC.json retains full method-file hashes, candidate/body
hashes, actualM and raw diagnostics. No Cand.memberships, cmd_list, full score,
objdump, compiler, IR, SDK or VM was invoked for this metric.

The one native reader read S3's admitted image. The separately authorized
target metric uses Cand byte snapshots of S3 and frozen13fe, and the maintained
module's original section metadata; it verifies the reconstructed cached
original body against the admitted original bytes. That bounded metric read
does not repeat native source/CFG analysis or the official scorer. Earlier
original/ECEA/S1/S2 analyses and all negative receipts remain unchanged.

Limits: source/ABI plus explicit intraprocedural CFG/register/direct-FP
witnesses; no arbitrary opaque-callee alias closure, original Rust source
uniqueness, local-lifetime conclusion, or overall equivalence. The observed
private gate does not explain why overall matching dropped. Byte evidence
does not justify accepting S3 or trying a speculative compensating form.
