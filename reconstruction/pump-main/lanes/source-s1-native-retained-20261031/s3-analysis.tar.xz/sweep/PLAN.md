Prepared S3 measurement plan only. No source, ELF, compiler, scorer, SDK, VM,
or test execution was performed for this preparation. The reader has not been
executed. Future execution requires separate root admission of the exact
source/ELF and semantic/IR role review. Causal gate079c968 remains conditional;
this plan does not authorize a native build or a source attempt.

Question: does an ordinary private full-settings Result six-tuple helper,
with creator/fee/shared-flag selection before Ok and without an inner
Result<Pubkey>, produce a different native fallible/choice boundary? The
pre-fee C/N selection and removal of the inner key Result are source/IR
premises to bind, not facts inferred from copy width or symbol names.

The proposed source is under separate semantic review. This lane owns native
function/call layout, incoming fee transport/tests, fee-success/shared-head CFG,
and success-copy placement only. Context owns actual target32→curve/pool and
new-target sharing-payload→Fees CPI role/use proofs. Do not duplicate those
consumers here, change source, or append attributes/volatiles/mut.take/nested296.

Before any native read:

1. Root supplies full source/native admission, actual ELF SHA, and the exact
   baseline/candidate source binding. Keep ordinary current13fe reference
   separate from the S3 candidate. No score/build/ELF rerun is part of this lane.
2. Copy bindings-template.json to a new case-specific binding file. Replace
   the settings symbol regex with the actual source/IR-reviewed helper name;
   bind all hashes. Multiple matching STT_FUNC symbols must stop attribution,
   never select the first prefix match. Set the two admission flags only from
   actual root/source review, with no inferred approval.
3. Execute's incoming fee-tag R4 is a source/ABI premise to re-confirm. If the
   helper is outlined, bind its fee input from the actual caller transport and
   reviewed signature/IR: either registerN or incoming argument-frame offset.
   A supplied argument-frame offset is a reviewed call ABI input, not an old
   function's local FP slot. Leave it null when unresolved.

The prepared read_native.py reuses the sealed stdlib ELF/logical decoder
SHA2033142ac919d226a4539cc0f25b80066428794d198263dd0a73919c71af81e9.
Only execute/settings/sweep function extents are decoded. STT_FUNC.st_size
defines each body; no27,400B assumption or next-symbol subtraction is used.
LDDW is16B. Direct targets are pc+8+signed_imm*8; branch targets must be logical
starts. Conditional CFG uses both target/fallthrough; calls fall through and
EXIT terminates. No8B fixed-stride disassembler or compiler oracle is used.

One initial read for each newly admitted ELF should preserve:

- Exact selected function names, addresses, sizes, body hashes and logical
  rows; all direct calls with16 preceding logical rows. Resolve execute calls
  to actual settings/sweep symbol extents and record unknown direct targets.
  Report settings/sweep nonzero outlined witnesses and call PCs separately.
  Missing nonzero symbols alone mean NO_NONZERO_STT_FUNC_WITNESS, not proof of
  inlining, source absence, coldness or elimination. If source/IR review proves
  inlining, label that additional evidence separately.
- For execute and any outlined settings helper with a reviewed fee ABI root,
  derive its actual first-block direct FP spills through pure copies. Find
  later direct reads only when the nearest overlapping direct-FP writes on
  every backward CFG path are those derived spills. Report the actual slot,
  width, read PCs, and same-block conditional candidates/transforms. No old
  FP-1976/-1984 or old+ad8/+b30 anchors are coded into the reader. Unsupported
  later/indirect transport is UNKNOWN; do not count an arbitrary reused-slot
  read as a fee-presence test. Raw incoming-tag reads are not automatically
  canonical per-exit fee booleans.
- All direct FP→FP load/store pairs and contiguous7/9/16B geometric groups.
  These are raw transport candidates; their geometry does not authenticate a
  Result, Try, Option, tuple element, Rust local, or source lifetime.

After that initial read, use its cached selected-function logicalRows for
adaptive source/IR→native bindings; do not reopen the baseline or ELF simply
to obtain better anchors. Source/IR review must name exact feeSome success,
feeNone, creator/shared target choice, flag choice and actual shared-test PCs.
The reader's pure graph/choice_views functions can be applied to those cached
rows to retain exact instruction/block/predecessor/successor witnesses.

Required causal outcome table:

| Measurement | Deciding evidence and limits |
| --- | --- |
| settings/sweep layout | Actual STT_FUNC sizes and direct call targets; execute plus outlined helpers may be summed descriptively, with no size repayment or inliner-threshold claim. |
| Incoming fee transport | Reviewed ABI root→actual direct spill→backward reaching writes→read→explicit compare. If the helper transports fee via a frame/aggregate not covered by the small entry tracer, retain caller rows and mark UNKNOWN pending a bounded manual join. |
| private feeSome head versus common shared gate | Source/IR-bound semantic edges plus rebuilt native block predecessors/successors. A head with proven feeNone and successful feeSome predecessors is common. No predecessor-label inference from physical PC order or old intervals; absence of a private-looking block alone is not semantic proof. |
| Success-copy location | For each source/IR-attributed transport family, record exact load/store PCs and its position relative to reviewed creator/target and flag choices. Native dominance/before-after relations come from actual CFG, with same-block instruction order checked. Non-dominating copies remain path-specific/unknown; do not label all7/9 groups as the former inner Result. |
| Used-value boundary | Hand off selected carrier/raw ranges and hashes to context. Do not assert an allocation improvement merely from moved/deleted copy geometry, smaller helpers or different registers. |

The reader emits facts and candidates, not an automatic PASS for the hypothesis.
Its direct-FP reasoning does not establish arbitrary opaque-callee alias
closure. Fee byte-width/transforms must be checked before treating a compare
as fee presence; branches on combined predicates need explicit role review.
No physical block placement proves private-source coldness. No semantic type
or source uniqueness follows from copied bytes. Any branch/copy outside its
small supported transport tracer stays explicitly unresolved.

Prior outcomes remain negative and are not retested:

- Exact rejected C1 Option actual trace: early Result/Try transport persists;
  mutation alone was not its cause. No Option family is reopened.
- S1 actual: creator projection moved before direct fee checks, but common
  shared head and9096B outlined sweep remained;1034norm/347raw/687raw losses.
- S2 actual: pre-fee selected C/N really survived to the target pack, but one
  validation fee test/common shared head and9096B sweep remained; same rejection.
- Exact#3384 helper source has now been recovered and is negative. Do not
  repeat the obsolete UNKNOWN placement claim or claim first invention.
  Root's related-prior and079c968 gate review controls whether S3 is distinct.

No alternative form, grid, attribute, flag, size companion, VM case, source edit,
native/scorer invocation or publication is authorized by this prepared plan.
