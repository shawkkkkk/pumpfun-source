"""Read-only admission of one actual S3 candidate; never executes an ELF."""
from pathlib import Path
import hashlib
import json
import re
import stat
import sys
import tarfile

ROOT = Path('/dev/shm/pump-cto-settings-s3')
RUN = ROOT / 'work/native-run'
A = RUN / 'artifact'
BASE = '65f0162a3dcd381df0f831082dd6732c9af4ab78'
OP = 'd95abdd9a72bd492adc4cb8b11f329e72e9222db'


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(name):
    return json.loads((A / name).read_text())


def tar_bind(name, expected):
    with tarfile.open(A / name) as archive:
        members = archive.getmembers()
        need(len(members) == len(expected) and {m.name for m in members} == set(expected), name + ' member domain')
        for m in members:
            need(m.isfile(), name + ' regular member')
            row = expected[m.name]
            data = archive.extractfile(m).read()
            need(len(data) == row['bytes'] and sha(data) == row['sha256'], name + ':' + m.name)
            mode = row.get('executable', row.get('mode') == '100755')
            need(bool(m.mode & 0o111) == mode, name + ' mode:' + m.name)


need(sha((RUN / 'raw-artifact.zip').read_bytes()) == json.loads((RUN / 'DOWNLOAD-VERIFIED.json').read_text())['sha256'], 'transport digest')
pre = json.loads((ROOT / 'work/native-prep/preflight/evidence/PREFLIGHT.json').read_text())
need(read('PREFLIGHT.json') == dict(pre, preflightOnly=False), 'actual preflight differs from local frozen input admission')
for name in ('program-source-inputs.json', 'toolchain-source-inputs.json', 'source-selection.json', 'compiled-workspace-inputs.json'):
    expected = json.loads((ROOT / 'work/native-prep/preflight/evidence' / name).read_text())
    need(read(name) == expected, name + ' differs from admitted frozen inputs')
source = read('source-inputs.json')
need(source == read('preflight-builder-source-inputs.json'), 'builder source changed')
need(source == json.loads((ROOT / 'work/native-prep/preflight/evidence/preflight-builder-source-inputs.json').read_text()), 'builder differs from root Git source')
need(sha(json.dumps(source['files'], sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()) == source['sha256'], 'source aggregate')
tar_bind('program-source.tar.gz', {r['path']: r for r in read('program-source-inputs.json')['files']})
tar_bind('compiled-workspace.tar.gz', read('compiled-workspace-inputs.json'))
ops = read('operational-inputs.json')
need(ops['checkout'] == OP, 'operational checkout')
prepared = json.loads((ROOT / 'work/native-prep/PREPARATION-RESULT.json').read_text())['operationalFiles']
need({r['path']: (r['gitBlob'], r['sha256'], r['bytes']) for r in ops['files']} == {r['path']: (r['gitBlob'], r['sha256'], r['bytes']) for r in prepared}, 'operational files')
controller = read('controller-inputs.json')
prepared_by_path = {r['path']: r for r in prepared}
need(controller['checkout'] == OP and controller['runnerSha256'] == prepared_by_path['reconstruction/pump-main/lanes/current-native-control/pump_current_control.py']['sha256'] and controller['workflowSha256'] == prepared_by_path['.github/workflows/qualify-pump-macos-v144.yml']['sha256'], 'actual controller/workflow')
host = read('host.json')
need(host['base'] == BASE and host['machine'] == 'arm64' and host['platform'].startswith('macOS-26.'), 'host/revision')
build = read('build.json')
result = read('RESULT.json') if (A / 'RESULT.json').exists() else None
comparison = read('CANDIDATE-COMPARISON.json')
need(build['ok'] and build['runtime_valid'] and build['stack_warnings'] == [], 'build/stack diagnostics')
need(build['recipe'] == controller['recipe'] == 'identity' and build['triple'] == controller['triple'] == 'sbpf-solana-solana', 'recipe')
need(build['source_sha256'] == source['sha256'], 'compiled source binding')
if result: need(result['builderSourceSha256'] == source['sha256'], 'result source binding')
images = {n: sha((A / n).read_bytes()) for n in ('unstripped.so', 'candidate.so')}
need(images['unstripped.so'] == build['unstripped_sha256'], 'unstripped hash')
if result: need(result['unstrippedSha256'] == images['unstripped.so'], 'result unstripped binding')
need(images['candidate.so'] == build['candidate_sha256'], 'stripped hash')
if result: need(result['candidateSha256'] == images['candidate.so'], 'result stripped binding')
if result: need(result['base'] == BASE and all(result[k] is True for k in ('sourceUnchanged', 'registrySourceUnchanged', 'toolInputsUnchanged', 'coldTarget')), 'final invariant declarations')
for first, after in [('registry-source-inputs.json', 'registry-source-inputs-after.json'), ('tool-inputs-before.json', 'tool-inputs-after.json'), ('native-lld-input-before.json', 'native-lld-input-after.json')]:
    need(read(first) == read(after), first + ' changed')
cold = read('cold-target-inputs.json')
need(cold['base'] == BASE and cold['sourceSha256'] == source['sha256'] and cold['targetAbsentBeforeBuild'] is True and cold['dependencyTemplatesAbsent'] is True and cold['toolInputs'] == read('tool-inputs-before.json'), 'cold build inputs')
downloads = read('sdk-downloads.json')
need({r['version']: r['archiveSha256'] for r in downloads} == {'v1.44': '66e20d135fddd70ff519baf7ff320d762957f9aedf93a50e23756db23ad79351', 'v1.52': '1727dfb31e833ce777d01e70cb4b3cebd26b376bf09d80527f02457d4cf6fd00'} and all(r['archiveSha256'] == r['expectedArchiveSha256'] for r in downloads), 'SDK archives')
for name in ('bootstrap-before.log', 'bootstrap-after.log'):
    text = (A / name).read_text()
    need('SDK verified (full,' in text and 'Linux v1.44 sbpf target libraries verified (25 rlibs)' in text, name)
inventory = json.loads((ROOT / 'reconstruction/toolchain/v1.44-macos-inventory.json').read_text())['entries']
native = read('native-lld-input-before.json')
need(native['sha256'] == inventory[native['sdkRelativePath']]['sha256'] and native['bytes'] == inventory[native['sdkRelativePath']]['bytes'], 'native LLD inventory')
for path, digest in read('tool-inputs-before.json').items():
    if '/v1.44/platform-tools/' in path:
        relative = path.split('/v1.44/platform-tools/', 1)[1]
        need(inventory[relative]['sha256'] == digest, 'native SDK tool binding')
fingerprints = read('cargo-fingerprints.json')
need(fingerprints and all(r['rustflags'] == ['-Zremap-cwd-prefix='] for r in fingerprints.values()), 'actual target flags')
log = (A / 'build.log').read_text()
for package in ('pump-recovered', 'pump-token-ext'):
    need(re.search(r'(?m)^\s*Compiling ' + package + r' v', log), 'fresh local crate:' + package)
commands = [json.loads(line) for line in (A / 'commands.jsonl').read_text().splitlines()]
need([r['name'] for r in commands] == ['bootstrap-before', 'fetch-locked', 'cold-build', 'bootstrap-after', 'score'] and all(r['returncode'] == 0 for r in commands), 'actual command chain')
sys.path.insert(0, str(ROOT / 'reconstruction/harness'))
import score
windows, actual_hash = score.score_with_hash(A / 'unstripped.so')
saved = read('score.json')
need(saved['windows'] == {str(k): v for k, v in windows.items()}, 'full official independent score')
need(actual_hash == images['unstripped.so'] == saved['summary']['candidate_sha256'], 'official scored image')
need(len(windows) == 1035 and saved['summary'] == comparison['summary'], 'summary domain')
if result: need(saved['summary'] == result['summary'], 'result summary')
ref = json.loads((ROOT / 'work/current-13fe-reference/score.json').read_text())
expected_changes = {k: {'reference': ref['windows'][k], 'candidate': v} for k,v in saved['windows'].items() if v != ref['windows'][k]}
need(comparison['sourceCommit'] == BASE and comparison['fullRowsCompared'] == 1035 and comparison['changedRows'] == expected_changes, 'actual full current comparison')
need(comparison['referenceRun'] == 41170683278 and comparison['referenceArtifactId'] == 13031166975, 'reference binding')
need(comparison['noRawLosses'] == (not saved['summary']['raw_losses']) and comparison['noNormalizedLosses'] == (not saved['summary']['losses']), 'no loss statements')
summary = {'base': BASE, 'operationalCommit': OP, 'run': 41172052790, 'sourceSha256': source['sha256'], 'sourceFiles': len(source['files']), 'images': images, 'normalized': sum(v['normalized'] for v in windows.values()), 'raw': sum(v['raw'] for v in windows.values()), 'total': len(windows), 'unmatched': [hex(k) for k, v in windows.items() if not v['normalized']], 'sourceAndArchiveAdmission': 'PASS', 'independentOfficialScorer': 'PASS', 'limits': 'One frozenS3-versus13fe measurement only. Full original candidate score independently verified. A native negative is retained; no current-main PR qualification, runtime or whole meaningful ELF result is implied.'}
summary['comparison'] = comparison
out = ROOT / 'work/root/CANDIDATE-ELF-ADMISSION.json'
with out.open('x') as stream:
    json.dump(summary, stream, indent=2)
    stream.write('\n')
print(json.dumps({k: v for k, v in summary.items() if k != 'comparison'}))
