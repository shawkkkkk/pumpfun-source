The actual S3 consumer and Error284 joins are closed within the stated bounds. Source65f0162a3dcd381df0f831082dd6732c9af4ab78, run41172052790, ELF SHA100d222047a2281a4409d8f732266955368504479d3d4076b4f6e3af08ef37e4. Root admits the source/archive and unchanged1035 score rows (1034 raw/normalized); native no-loss passed. CTO remains unmatched. No source gain is claimed here.

Settings and sweep are both in execute (VA0x22a10,27400B). There is no outlined validate/settings/sweep symbol or direct call, and the actual creator, flags and Error284 sites are inside execute. No separate settings return ABI survives for this packet to identify a Result niche.

Selected target32:

- K is copied from the actual holder-PDA result FP[-1657,-1625) at+9b8..9f0.
- C is loaded from the curve pointer+8 at+1438..1470. The compiler physically forwards/reloads all32 bytes from curve; it is not an all-st-snapshot load claim.
- N is loaded from incoming new+1 at+1498..14d0.
- All three reach selected scratch FP[-1328,-1296), then a post-flags45-byte memcpy+19f0. In that chunk, selected target occupies32 bytes at offset13; the preceding13 bytes belong to the separate input sharing payload.
- Actual final target is FP[-1376,-1344), written only at+1a00/+1a10/+1a20/+1a30. Four reads+4ec0/+4ed0/+4ee0/+4ef0 feed curve.creator stores+4ec8/+4ed8/+4ee8/+4ef8. The same target pointer is passed to pool helper at+51f8→VA0x10a0e0, whose four actual reads serialize instruction-data bytes8..40. Caller/helper register bridges and the complete direct-write census are checked.

Sharing payload:

- This stays original N when shared/nonholder, independently of selected C. It uses actual3/8/8/13-byte transport; its13-byte suffix passes through the same45-byte memcpy beside target32.
- Final Option33 is assembled at+4110..4170 in FP[-1588,-1555). Byte0 is the inner Option tag; bytes1..32 are the original new payload on the update path. Overlapping suffix stores copy the same original bytes.
- Outer tag2 skips sharing CPI; tag0 calls reset with absent Pubkey payload; tag1 calls update. The actual+4e38 call passes FP-1588 to VA0x116718. That helper reads the tag at+98; its Some branch serializes four target words into instruction-data bytes9..41 at+110..148. Reset/absent payload bytes are excluded from value claims.

The observed0/1/2 tag is bound to sharing Option behavior. It does not establish a combined settings Result bool/enum niche. The45-byte chunk is an observed native transport block, not a claim about the complete Rust tuple/Result size or original source type.

Error284 remains a direct execute path: code6088/source284 stores+3ee0/+3ef0 construct AnchorError at FP-720; filename bytes are programs/pump/src/creator/admin_cto.rs (38 bytes). From call+3f28 uses outputFP-1744. Its136-byte converter and208-byte allocator match cached ECEA raw bodies. Converter writes allocated pointer at output+8 and variant0 at output+0; execute forwards that pair directly to root return and exits+3f58. This path exposes no intervening settings Result discriminator.

TARGET-TRUE-USE.json, SHARING-TRUE-USE.json and ERROR284.json contain exact raw rows. seal_analysis.py verifies the bounded joins from admitted extraction receipts, including direct bytewise reaching definitions, non-returning abort relocation and register bridges. The initial conservative reaching exploration is retained and explicitly superseded by v2; absent reset payload is not promoted into a value mismatch. A separate sweep-owned fee proof08cd32af… establishes the three fee tests/private successful-fee shared head; no fee-CFG audit or byte-progress metric was repeated here.

Limits remain: direct FP evidence does not rule out arbitrary hidden indirect/callee aliases; private owned buffers and normal readonly/resource/callee contracts are explicit assumptions. Pool/sharing serialization is conditional on actual presence/discriminant and successful allocation, with no CPI execution. No Rust lifetime, original helper/type, compiler cause, score execution, VM/test/compiler/IR/source variant or remote action is claimed. All work is RAM-local with inherited PYTHONDONTWRITEBYTECODE=1 and python3 -B.
