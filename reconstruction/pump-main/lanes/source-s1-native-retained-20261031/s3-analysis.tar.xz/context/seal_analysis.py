#!/usr/bin/env python3
"""Seal bounded S3 consumer joins from the once-extracted admitted native rows."""
import os, sys
sys.dont_write_bytecode = True
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
from pathlib import Path
import hashlib, json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def load(name): return json.loads((HERE/name).read_text())
functions = load('SELECTED-FUNCTIONS.json')
cto = next(f for f in functions if f['start'] == '0x22a10')
ii = {int(x['offset'],16): x for x in cto['instructions']}
pool = next(f for f in functions if f['start'] == '0x10a0e0')
sharing = next(f for f in functions if f['start'] == '0x116718')
converter = next(f for f in functions if f['start'] == '0x19bb30')
allocator = next(f for f in functions if f['symbol'] == '__rust_alloc')
rel = {int(x['cto_offset'],16): x['symbol'] for x in load('CTO-CALL-RELOCATIONS.json')}
def seq(lo,hi,table=ii): return [x for p,x in table.items() if lo <= p < hi]
def width(x): return {0:4,8:2,16:1,24:8}[x['opcode'] & 24]
def writes(lo,hi):
    return [x for x in ii.values() if x['opcode'] & 7 in (2,3) and x['dst']==10
            and x['displacement'] < hi and lo < x['displacement']+width(x)]
def defines(x,r):
    return (x['opcode'] & 7 in (1,4,7) and x['dst']==r) or (x['opcode'] in (0x85,0x8d) and r<6)
succ={}; pred={p:[] for p in ii}; nonreturning=[]
for p,x in ii.items():
    op=x['opcode']; nxt=p+len(bytes.fromhex(x['raw']))
    names=' '.join(x.get('callee',[]))
    stop=op in (0x85,0x8d) and (rel.get(p)=='abort' or any(n in names for n in ('unwrap_failed','panic_fmt','panic_bounds_check','sol_panic_')))
    if stop: nonreturning.append(x)
    if op==0x95 or stop: edges=[]
    elif op==0x05: edges=[int(x['branch_target'],16)]
    elif op in (0x85,0x8d): edges=[nxt]
    elif op & 7 in (5,6): edges=[nxt,int(x['branch_target'],16)]
    else: edges=[nxt]
    succ[p]=[q for q in edges if q in ii]
    for q in succ[p]: pred[q].append(p)
def reach(start,graph,omit=frozenset()):
    todo=[start]; seen=set()
    while todo:
        p=todo.pop()
        if p not in seen and p not in omit: seen.add(p); todo.extend(graph[p])
    return seen
def on_paths(a,b): return reach(a,succ) & reach(b,pred)
def assert_no_writes(a,b,lo,hi,exclude=()):
    bad=[x for x in writes(lo,hi) if int(x['offset'],16) in on_paths(a,b) and int(x['offset'],16) not in exclude]
    assert not bad,(hex(a),hex(b),lo,hi,bad)
    return dict(start=hex(a),end=hex(b),frame=[lo,hi],overlapping_direct_fp_writes=[])
def slice_witness(name,lo,hi): return dict(name=name,instructions=seq(lo,hi))
assert sha(ROOT/'work/root/CANDIDATE-ELF-ADMISSION.json') == 'b477052a47f8bcb4835cfd0e800f820f0c1dbad9aaf31ed4a3d43d737d4e17cd'
input_binding=load('INPUT.json')
assert input_binding['input_sha256']=='100d222047a2281a4409d8f732266955368504479d3d4076b4f6e3af08ef37e4'

# Final selected target is discovered from the actual curve consumers, not old S2 slots.
assert [int(x['offset'],16) for x in writes(-1376,-1344)] == [0x1a00,0x1a10,0x1a20,0x1a30]
assert 0x4ec0 in reach(0,succ) and 0x4ec0 not in reach(0,succ,{0x1a00})
curve=[]
for n,p in enumerate((0x4ec0,0x4ed0,0x4ee0,0x4ef0)):
    a,b=ii[p],ii[p+8]
    assert (a['opcode'],a['src'],a['displacement'])==(0x79,10,-1376+n*8)
    assert (b['opcode'],b['dst'],b['src'],b['displacement'])==(0x7b,1,a['dst'],8+n*8)
    curve.append(dict(load=a,store=b))
assert (ii[0x4e78]['opcode'],ii[0x4e78]['dst'],ii[0x4e78]['src'],ii[0x4e78]['displacement'])==(0x79,1,6,56)
assert not any(defines(x,1) for x in seq(0x4e80,0x4f00))
assert ii[0x51f8]['call_target']==pool['start']
assert (ii[0x51d8]['opcode'],ii[0x51d8]['dst'],ii[0x51d8]['src'])==(0xbf,3,10)
assert (ii[0x51e0]['opcode'],ii[0x51e0]['dst'],ii[0x51e0]['immediate'])==(0x07,3,-1376)
assert not any(defines(x,3) for x in seq(0x51e8,0x51f8))
poolii={int(x['offset'],16):x for x in pool['instructions']}
poolpairs=[]
for n,p in enumerate((0xe8,0xf8,0x108,0x118)):
    a,b=poolii[p],poolii[p+8]
    assert (a['opcode'],a['src'],a['displacement'])==(0x79,3,n*8)
    assert (b['opcode'],b['dst'],b['src'],b['displacement'])==(0x7b,6,a['dst'],8+n*8)
    poolpairs.append(dict(read=a,serialized_store=b))
assert not any(defines(x,3) for p,x in poolii.items() if p<0x118)
assert ii[0x19f0]['call_target']=='0x1b3610'
assert ii[0x19d0]['immediate']==-1256 and ii[0x19e0]['immediate']==-1184 and ii[0x19e8]['immediate']==45
pda=next(x for x in ii.values() if any('find_program_address' in n for n in x.get('callee',[])))
pdapc=int(pda['offset'],16)
pdaset=max(p for p,x in ii.items() if p<pdapc and x['opcode']==0x07 and x['dst']==1 and x['immediate']==-1657)
assert (ii[pdaset-8]['opcode'],ii[pdaset-8]['dst'],ii[pdaset-8]['src'])==(0xbf,1,10)
assert not any(defines(x,1) for x in seq(pdaset+8,pdapc))
assert_no_writes(pdapc+8,0x9b8,-1657,-1625)
target=dict(status='PROVED_BOUNDED',source_commit=input_binding['source'],elf_sha256=input_binding['input_sha256'],cto=dict(start=cto['start'],bytes=cto['bytes'],sha256=cto['sha256']),
    selected_scratch=dict(frame=[-1328,-1296],K=seq(0x9b8,0x9f8),C=seq(0x1428,0x1478),N=seq(0x1498,0x14d8),
      K_pda_call_and_setup=seq(pdaset-8,pdapc+8),K_pda_result_frame=[-1657,-1625],K_pda_no_overlapping_direct_writes_before_use=True,
      C_pointer_origin=seq(0x260,0x268)+seq(0x4f0,0x4f8),N_pointer_origin=seq(0,8)+seq(0x108,0x118)+seq(0xbb8,0xbc8),
      role_qualification='C is physically loaded from the curve pointer+8, not all from the owned st snapshot. N is read from incoming new+1. K uses the actual PDA result. Source roles follow the admitted Context/argument mapping.',
      reaching_definition_receipt='REACHING-DEFINITIONS-v2.json'),
    aggregate_transport=dict(source_frame=[-1184,-1139],destination_frame=[-1256,-1211],bytes=45,
      selected_target_subrange_in_source=[-1171,-1139],selected_target_subrange_in_destination=[-1243,-1211],
      adjacent_input_sharing_payload_suffix_bytes=13,instructions=seq(0x1968,0x1a58),
      contract='Actual named memcpy with r1=destination,r2=source,r3=45; disjoint buffers. This native chunk is not asserted to be the whole Result or tuple layout.'),
    final_frame=[-1376,-1344],all_direct_writes=writes(-1376,-1344),first_store_dominates_first_curve_read_in_direct_cfg=True,
    curve_pointer=ii[0x4e78],curve_words=curve,curve_register_bridge_checked=True,
    pool=dict(call=ii[0x51f8],argument=seq(0x51d8,0x51f8),helper_start=pool['start'],helper_bytes=pool['bytes'],helper_sha256=pool['sha256'],pairs=poolpairs,r3_preservation_checked=True,
      condition='Pool-present path and successful instruction-data allocation; no CPI execution.'),
    limits=['Direct FP-store absence is not arbitrary indirect/callee alias closure. Private owned target and normal callee contracts are assumed not to alias unrelated resource pointers.',
      'No original Rust type, source lifetime, new Result niche, or original8+24 representation is inferred. Actual selected scratch and final key are32 bytes in this image.'])
(HERE/'TARGET-TRUE-USE.json').write_text(json.dumps(target,indent=2)+'\n')

# Sharing Option buffer: Some(N) is a different value family from selected C/N/K.
optionstores=writes(-1588,-1555)
assert [int(x['offset'],16) for x in optionstores]==[0x4138,0x4148,0x4150,0x4160,0x4170]
assert ii[0x4e38]['call_target']==sharing['start'] and ii[0x4e30]['immediate']==-1588
assert not any(x['opcode'] in (0x85,0x8d) for x in seq(0x4110,0x4178))
checks=[assert_no_writes(0x1888,0x4110,-2328,-2320),assert_no_writes(0x1840,0x4140,-2352,-2344),
        assert_no_writes(0x1830,0x4130,-2368,-2360),assert_no_writes(0x1a58,0x4168,-1344,-1331)]
si={int(x['offset'],16):x for x in sharing['instructions']}
assert (si[0x98]['opcode'],si[0x98]['src'],si[0x98]['displacement'])==(0x71,3,0)
assert not any(defines(x,3) for p,x in si.items() if p<0x100)
assert si[0xe0]['branch_target']=='0x100' and si[0xe0]['immediate']==0
assert si[0x100]['immediate']==1 and si[0x108]['immediate']==1
serializer=[]
for n,p in enumerate((0x110,0x120,0x130,0x140)):
    a,b=si[p],si[p+8]
    assert (a['opcode'],a['src'],a['displacement'])==(0x79,3,n*8)
    assert (b['opcode'],b['dst'],b['src'],b['displacement'])==(0x7b,6,a['dst'],9+n*8)
    serializer.append(dict(read=a,serialized_store=b))
assert not any(defines(x,3) for p,x in si.items() if 0x108<=p<0x148)
sharing_result=dict(status='PROVED_BOUNDED_FOR_PRESENT_INNER_PAYLOAD_ABSENT_BYTES_EXCLUDED',elf_sha256=input_binding['input_sha256'],
    incoming_new=dict(pointer_load_and_spill=seq(0,8)+seq(0x108,0x118),reload=ii[0x1818],source_role='Decoded incoming new:Option<Pubkey>, ABI pointer savedFP-2288. Source caller/signature mapping is retained; no external deserializer execution.'),
    N_payload_construction=dict(instructions=seq(0x1818,0x18a8),prefix3='ushort new[1:3] plus byte new[3]<<16 at+1840/+1848/+1870/+1878, spillFP-2328.',
      middle_words='new[4:12]→FP-2352 and new[12:20]→FP-2368.',suffix13='new[20:28]→FP-1296 and new[25:33]→FP-1291; overlap is from the same original bytes.',
      suffix_transport='13 bytes pass through the first13 bytes of memcpy45 then FP[-1344,-1331) at+1a38..1a50.',
      presence_qualification='The update path is shared/nonholder with validated newSome. The holder arm sets r7=0 and bypasses N loads; nonshared sets r7=2. Raw graph alone overapproximates predicates, so source guard/valid decoded Option tags are explicit conditions.'),
    option_frame=[-1588,-1555],actual_assembly=seq(0x4110,0x4178),all_direct_writes=optionstores,
    present_byte_mapping=[dict(destination=[0,4],source='inner tag followed by original new payload bytes1..3'),dict(destination=[4,12],source='original new bytes4..11'),dict(destination=[12,20],source='original new bytes12..19'),dict(destination=[20,28],source='original new bytes20..27'),dict(destination=[25,33],source='original new bytes25..32; consistent overlap')],
    payload_preservation_checks=checks,
    outer_discriminant=dict(instructions=seq(0x17d0,0x18d8),tag_spill=ii[0x1c88],gate=seq(0x4100,0x4110),
      observed_roles={'2':'outer None:skip sharing CPI','0':'call sharing CPI with inner None/reset; no meaningful Pubkey payload','1':'call sharing CPI with inner Some(original new)'}),
    call=dict(instructions=seq(0x4e08,0x4e40),helper_start=sharing['start'],helper_bytes=sharing['bytes'],helper_sha256=sharing['sha256']),
    serializer=dict(tag_load=si[0x98],tag_branch=si[0xe0],none=seq(0xe8,0x100,si),some=seq(0x100,0x158,si),pairs=serializer,r3_preservation_checked=True,
      payload_output='Instruction-data bytes9..41 after8-byte discriminator and1-byte Option tag; successful allocation only.'),
    combined_result_layout=dict(status='UNRESOLVED_NO_OUTLINED_SETTINGS_RETURN_BOUNDARY',qualification='The actual0/1/2 tag is bound to nested sharing Option/CPI use. It is not identified as the combined settings Result error/success niche. No fresh layout oracle or LLVM capture was run.'),
    limits=['Some(None) and skipped outer None carry no meaningful Pubkey payload; exploratory reaching rows with entry/other old stores on those paths are excluded, not interpreted as mismatches.',
      'Direct stores and named memcpy are bounded proofs; hidden arbitrary alias writes remain outside scope.','Original N and selected target C are independently bound;45-byte co-transport does not make their values equal.'])
(HERE/'SHARING-TRUE-USE.json').write_text(json.dumps(sharing_result,indent=2)+'\n')

# Recognize actual Error284 constructor and immediate root return; no new Result ABI is guessed.
assert (ii[0x3ee0]['immediate'],ii[0x3ef0]['immediate'])==(6088,284)
assert ii[0x3f10]['immediate']==-1744 and ii[0x3f20]['immediate']==-720
assert ii[0x3f28]['call_target']==converter['start']
ptr=ii[0x3ec8]['immediate']; length=ii[0x3ef8]['immediate']; meta=next(s for s in input_binding['sections'] if s['name']=='.rodata')
ro=(HERE/meta['file']).read_bytes();filename=ro[ptr-int(meta['start'],16):ptr-int(meta['start'],16)+length]
assert filename==b'programs/pump/src/creator/admin_cto.rs'
ci={int(x['offset'],16):x for x in converter['instructions']}
assert ci[0x10]['immediate']==160 and ci[0x18]['immediate']==8 and ci[0x20]['call_target']==allocator['start']
assert ci[0x60]['immediate']==160 and ci[0x68]['call_target']=='0x1b3610'
assert (ci[0x70]['opcode'],ci[0x70]['dst'],ci[0x70]['src'],ci[0x70]['displacement'])==(0x7b,6,8,8)
assert (ci[0x78]['opcode'],ci[0x78]['dst'],ci[0x78]['displacement'],ci[0x78]['immediate'])==(0x7a,6,0,0)
assert ii[0x18]['displacement']==-2264 and ii[0x18]['src']==1
assert ii[0x3f48]['displacement']==8 and ii[0x3f50]['displacement']==0 and ii[0x3f58]['opcode']==0x95
prior=json.loads(Path('/dev/shm/pump-cto-ecea702/work/s1-abi-analysis/ECEA-ABI.json').read_text())['error284']
assert prior['converter']['sha256']==converter['sha256']
assert prior['allocator']['sha256']==allocator['sha256']
error=dict(status='RECOGNIZED_BOUNDED_DIRECT_EXECUTE_ERROR_RETURN',elf_sha256=input_binding['input_sha256'],emitting_function=cto['symbol'],function_start=cto['start'],
    object_frame=-720,converter_output_frame=-1744,source=dict(filename_pointer=hex(ptr),filename_length=length,filename_hex=filename.hex(),filename=filename.decode(),filename_sha256=hashlib.sha256(filename).hexdigest(),line=284,error_code=6088),
    constructor=seq(0x3e68,0x3f30),converter=dict(start=converter['start'],bytes=converter['bytes'],sha256=converter['sha256'],instructions=converter['instructions']),
    allocator=dict(start=allocator['start'],bytes=allocator['bytes'],sha256=allocator['sha256']),
    forwarding=seq(0x3f30,0x3f60),root_output_pointer_save=ii[0x18],
    observed_return='Converter writes allocated AnchorError pointer at output+8 and variant0 at output+0. Execute loads this pair and directly writes root return offsets8/0, then EXIT. No surviving outlined settings error return is traversed on this path.',
    cached_ecea_comparison=dict(converter_raw_equal=True,allocator_raw_equal=True,source_filename_equal=prior['source_location']['filename_bytes']==filename.hex()),
    result_niche_limit='Error284 does not expose a separate combined settings Result discriminator: private validate is inlined and this error forwards directly. The sharing Option tag is not evidence of Result niche encoding.',
    limits=['This recognizes one actual early error ABI path and constructor. It is not a theorem that every return/error path or future carrier has the same shape.'])
(HERE/'ERROR284.json').write_text(json.dumps(error,indent=2)+'\n')

topology=dict(status='ACTUAL_SOURCE_BOUND_SETTINGS_AND_SWEEP_IN_EXECUTE',source=input_binding['source'],elf_sha256=input_binding['input_sha256'],cto=dict(start=cto['start'],bytes=cto['bytes'],sha256=cto['sha256']),
    settings_symbols=[dict(start=f['start'],bytes=f['bytes'],symbol=f['symbol']) for f in functions if ('admin_cto8validate' in f['symbol'] or 'execute5sweep' in f['symbol'])],
    evidence='Creator K/C/N selection, sharing flags and6088/source284 sites are all in actual execute; no outlined settings/sweep symbol or direct call is present.',
    native_no_loss='PASS per root admission; all1035 score rows unchanged. CTO remains unmatched; no source gain follows.',
    layout='Target32 and sharing payload use distinct proven origins but share one observed45-byte memcpy. Combined Result variant/niche encoding remains unproved.',
    cfg_limits='Direct intraprocedural reachability and per-byte direct FP reaching stores only; abort relocation and canonical panic/unwrap functions stop flow. Initial exploratory REACHING-DEFINITIONS.json is retained and superseded by bytewise v2.',
    nonreturning_calls=nonreturning)
(HERE/'FUNCTION-TOPOLOGY.json').write_text(json.dumps(topology,indent=2)+'\n')
print('TARGET, SHARING, ERROR284 and TOPOLOGY sealed')
