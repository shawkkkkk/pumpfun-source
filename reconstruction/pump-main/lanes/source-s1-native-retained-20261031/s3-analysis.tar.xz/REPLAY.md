# Rejected S3 source, successful native no-loss build

The adjacent s3-raw-artifact.zip is the exact45-member transport ZIP from native
run41172052790. RESULT.json is SUCCESS and the raw/normalized no-loss guard
passed; it must not be relabelled a failed native build. The source proposal was
rejected because the saved internal CTO metric falls0.6725584182144997 to
0.38316357100059917 (normalized matched logical instructions2245 to1279,-966).
All1035 saved official rows were unchanged (1034raw/normalized). These measures
answer different questions. SOURCE-REJECTION.json records the rejection.

This archive preserves already-sealed target metric, fee/privategate, selected
consumer/sharing/Error284 joins, source proposal and semantic review identities,
native38-check admission, root metadata corrections, and VM-held/planning
receipts. It contains no .so, library copy, private fixture key, auth material,
private Slop flow or client-version record. Both native images remain in the
adjacent exact ZIP. Existing raw context .bin excerpts are public ELF data
witnesses, not program source or a synthesized executable.

The parent13fe raw/native reference is already retained on this same branch as
13fe-control-raw.zip and13FE-RECEIPT.json. The existing13fe finite runtime packet
does not transfer to S3. S3 VM was held before launch:0executions, no private
candidate snapshot, no runner start and no S3 runtime report.

All existing files are unmodified. Check MANIFEST.json to replay byte/hash joins
and inspect saved reports offline. Source65f0162a3dcd381df0f831082dd6732c9af4ab78
and its public parent13fe bind helper/capture identities. Absolute original RAM
paths in reports are provenance and can be mapped to members or the two raw
ZIPs for offline inspection. Root admission's initial missing-metadata reader
attempt was before scorer import; initial inherited native-negative wording
was corrected while preserving initial bytes. Actual root no-loss PASS and
RESULT SUCCESS remain authoritative. No native/scorer rerun accompanied that
metadata correction.

No metric, ELF analysis, scorer, compiler, SDK, VM, test, signature operation or
remote action was repeated for packaging. Historical plans and source-review
claims retain their original context. They authorize no next candidate, flag,
attribute or trial, and establish no unique original source/type, whole-program
identity, source gain, runtime equivalence, security clearance or later-main
qualification. No source PR is proposed for rejected S3.
