"""Review actualS3 receipts and map; never invokes compiler, SDK, scorer or VM."""
import csv
import fnmatch
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import struct
import tarfile
import zipfile

ROOT = Path('/dev/shm/pump-cto-settings-s3')
RUN = ROOT/'work/native-run'
A = RUN/'artifact'
OUT = RUN/'candidate-review'
BASE = '65f0162a3dcd381df0f831082dd6732c9af4ab78'
OP = 'd95abdd9a72bd492adc4cb8b11f329e72e9222db'
RUN_ID = 41172052790
checks, inputs = [], {}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def raw(path):
    data = path.read_bytes()
    key = str(path.relative_to(ROOT))
    value = {'bytes':len(data),'sha256':sha(data)}
    if key in inputs:
        assert inputs[key] == value, 'Input drift:'+key
    inputs[key] = value
    return data


def load(path):
    return json.loads(raw(path))


def a(name):
    return load(A/name)


def check(name, condition, detail=None):
    if not condition:
        raise AssertionError(name)
    checks.append({'name':name,'pass':True,'detail':detail})


def index(rows):
    result = {r['path']:r for r in rows}
    assert len(rows) == len(result)
    return result


def archive_bind(name, expected):
    seen = {}
    with tarfile.open(A/name,'r:gz') as archive:
        for member in archive:
            path = PurePosixPath(member.name)
            assert member.isfile() and not path.is_absolute() and '..' not in path.parts and member.name not in seen
            data = archive.extractfile(member).read()
            row = expected[member.name]
            assert len(data) == row['bytes'] and sha(data) == row['sha256']
            assert bool(member.mode&0o111) == row.get('executable',row.get('mode')=='100755')
            seen[member.name] = {'bytes':len(data),'sha256':sha(data)}
    assert set(seen) == set(expected)
    raw(A/name)
    return len(seen)


def elf_sections(data):
    assert data[:7] == b'\x7fELF\x02\x01\x01'
    h = struct.unpack_from('<HHIQQQIHHHHHH',data,16)
    shoff,shsize,shnum,shstr = h[5],h[10],h[11],h[12]
    assert h[0]==3 and h[1]==263 and h[2]==1 and h[7]==64 and h[8]==56 and h[9]==4
    assert shsize == 64 and shoff+shsize*shnum <= len(data)
    headers = [struct.unpack_from('<IIQQQQIIQQ',data,shoff+i*shsize) for i in range(shnum)]
    names = data[headers[shstr][4]:headers[shstr][4]+headers[shstr][5]]
    result = {}
    for row in headers:
        name = names[row[0]:names.index(b'\0',row[0])].decode()
        assert name not in result
        result[name] = {'type':row[1],'flags':row[2],'addr':row[3],'offset':row[4],'size':row[5],'link':row[6],'entsize':row[9]}
    return result,headers


zip_path = RUN/'raw-artifact.zip'
zip_raw = raw(zip_path)
check('released ZIP SHA and size',len(zip_raw)==2534297 and sha(zip_raw)=='0f1a82695dd41525fffbebe667c3067062a9a1fd1fd3fb4b70cbdb054965bdda')
api = load(RUN/'artifacts-final.json')['artifacts'][0]
check('provider artifact identity/digest/size',api['id']==13031054922 and api['digest']=='sha256:'+sha(zip_raw) and api['size_in_bytes']==len(zip_raw) and api['expired'] is False)
members = {}
with zipfile.ZipFile(zip_path) as archive:
    for item in archive.infolist():
        path = PurePosixPath(item.filename)
        assert not item.flag_bits&1 and ((item.external_attr>>16)&0o170000) in (0,0o100000) and not item.is_dir() and not path.is_absolute() and '..' not in path.parts and item.filename not in members
        data = archive.read(item)
        assert data == raw(A/item.filename)
        members[item.filename] = {'bytes':len(data),'sha256':sha(data)}
check('all45 ZIP CRCs and extracted member bytes',len(members)==45 and set(members)=={p.relative_to(A).as_posix() for p in A.rglob('*') if p.is_file()})
download = load(RUN/'DOWNLOAD-VERIFIED.json')
check('root acquisition list matches independent ZIP membership',download['sha256']==sha(zip_raw) and index(download['files'])=={name:dict(path=name,**value) for name,value in members.items()})
ops = a('operational-inputs.json')
prepared_ops = [{k:r[k] for k in ('path','mode','gitBlob','bytes','sha256')} for r in load(ROOT/'work/native-prep/PREPARATION-RESULT.json')['operationalFiles']]
public = load(OUT/'PUBLIC-OPERATIONAL.json')
check('public operational commit has sole frozen source parent and only three expected blobs',public['sha']==OP and [r['sha'] for r in public['parents']]==[BASE] and len(public['files'])==3 and {(r['filename'],r['sha']) for r in public['files']}=={(r['path'],r['gitBlob']) for r in ops['files']})
check('actual operational records equal prepared files',ops['checkout']==OP and sorted(ops['files'],key=lambda r:r['path'])==sorted(prepared_ops,key=lambda r:r['path']))
controller = a('controller-inputs.json')
op_by_path = index(ops['files'])
check('actual controller/workflow and documented environment',controller['checkout']==OP and controller['runnerSha256']==op_by_path['reconstruction/pump-main/lanes/current-native-control/pump_current_control.py']['sha256'] and controller['workflowSha256']==op_by_path['.github/workflows/qualify-pump-macos-v144.yml']['sha256'] and controller['recipe']=='identity' and controller['triple']=='sbpf-solana-solana' and controller['documentedEnvironment']['PYTHONDONTWRITEBYTECODE']=='1')
program,core = a('program-source-inputs.json'),a('toolchain-source-inputs.json')
source,selection,workspace = a('source-inputs.json'),a('source-selection.json'),a('compiled-workspace-inputs.json')
check('actual source141/CORE236/selected141/workspace142 counts and revision',program['base']==core['base']==BASE and len(program['files'])==len(source['files'])==141 and len(core['files'])==236 and len(workspace)==142 and selection['allGitFiles']==selection['selectedSourceFiles']==141 and selection['excludedGitPaths']==[])
check('actual source aggregate and preflight-builder equality',source==a('preflight-builder-source-inputs.json') and source['sha256']=='9fc3fd3c8e68d85e5bf4fcb2309694974aab3c5aaacab9741a1e0ea25c72a622' and sha(json.dumps(source['files'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())==source['sha256'])
for row in program['files']+core['files']:
    path = PurePosixPath(row['path'])
    assert not path.is_absolute() and '..' not in path.parts
    physical = ROOT/row['path']
    data = os.readlink(physical).encode() if row['mode']=='120000' else raw(physical)
    assert len(data)==row['bytes'] and sha(data)==row['sha256'] and hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['gitBlob']
    if row['mode']!='120000':assert bool(physical.stat().st_mode&0o111)==(row['mode']=='100755')
check('377 physical frozen input byte/blob/mode bindings',True)
check('both retained source archives match exact paths, bytes and modes',archive_bind('program-source.tar.gz',index(program['files']))==141 and archive_bind('compiled-workspace.tar.gz',workspace)==142)
check('native program/CORE/stage equal independently reviewed physical preflight vectors',program==load(ROOT/'work/native-prep/preflight/evidence/program-source-inputs.json') and core==load(ROOT/'work/native-prep/preflight/evidence/toolchain-source-inputs.json') and workspace==load(ROOT/'work/native-prep/preflight/evidence/compiled-workspace-inputs.json'))
build,result = a('build.json'),a('RESULT.json')
check('build/source/recipe/stack/result guard receipts',build['ok'] is True and build['runtime_valid'] is True and build['stack_warnings']==[] and build==a('cold-build.log') and build['source_sha256']==source['sha256']==result['builderSourceSha256'] and build['recipe']=='identity' and build['triple']=='sbpf-solana-solana' and result['base']==BASE and all(result[k] is True for k in ['sourceUnchanged','registrySourceUnchanged','toolInputsUnchanged','coldTarget']))
check('native Mac26 ARM64 host',a('host.json')['machine']=='arm64' and a('host.json')['platform'].startswith('macOS-26.'))
tools = a('tool-inputs-before.json')
registry = a('registry-source-inputs.json')
native = a('native-lld-input-before.json')
check('eight tools, complete registry and native LLD before/after bindings',len(tools)==8 and tools==a('tool-inputs-after.json') and registry==a('registry-source-inputs-after.json') and native==a('native-lld-input-after.json'),{'registry_records':len(registry)})
inventory = load(ROOT/'reconstruction/toolchain/v1.44-macos-inventory.json')['entries']
assert all(native[k]==inventory[native['sdkRelativePath']][k] for k in ['sha256','bytes','mode'])
for path,digest in tools.items():
    if '/v1.44/platform-tools/' in path:assert inventory[path.split('/v1.44/platform-tools/',1)[1]]['sha256']==digest
    elif '/hybrid144/' in path:assert inventory[path.split('/hybrid144/',1)[1]]['sha256']==digest
    else:assert path.endswith('/v1.52/platform-tools/llvm/bin/llvm-objdump')
check('all native/hybrid v1.44 tool records bind published full inventory',True)
cold = a('cold-target-inputs.json')
check('recorded cold target and template absence with exact source/tools',cold['base']==BASE and cold['sourceSha256']==source['sha256'] and cold['targetAbsentBeforeBuild'] is True and cold['dependencyTemplatesAbsent'] is True and cold['toolInputs']==tools)
downloads = a('sdk-downloads.json')
pins = {'v1.44':'66e20d135fddd70ff519baf7ff320d762957f9aedf93a50e23756db23ad79351','v1.52':'1727dfb31e833ce777d01e70cb4b3cebd26b376bf09d80527f02457d4cf6fd00'}
check('two exact SDK archive roles and pins',len(downloads)==2 and {r['version']:r['archiveSha256'] for r in downloads}==pins and all(r['archiveSha256']==r['expectedArchiveSha256'] and r['url']=='https://github.com/anza-xyz/platform-tools/releases/download/'+r['version']+'/platform-tools-osx-aarch64.tar.bz2' for r in downloads))
commands = [json.loads(row) for row in raw(A/'commands.jsonl').splitlines()]
assert [r['name'] for r in commands]==['bootstrap-before','fetch-locked','cold-build','bootstrap-after','score'] and all(r['returncode']==0 for r in commands)
for name in ['bootstrap-before','bootstrap-after']:
    command = next(r['command'] for r in commands if r['name']==name)
    assert '-B' in command and command[-2:]==['--sdk-check','full']
    text = raw(A/(name+'.log')).decode()
    assert 'v1.44 SDK verified (full, 2785 entries)' in text and 'Linux v1.44 sbpf target libraries verified (25 rlibs)' in text
fingerprints = a('cargo-fingerprints.json')
log = raw(A/'build.log').decode()
check('five successful commands, two full guards, fresh local crates and exact recorded flags',len(fingerprints)==2 and all(r['rustflags']==['-Zremap-cwd-prefix='] for r in fingerprints.values()) and all(re.search(r'Compiling '+p+r' v0\.1\.0 ',log) for p in ['pump-token-ext','pump-recovered']) and 'Finished `release`' in log and 'exceeded max offset' not in log)
link,admit,receipt = a('link-inputs.json'),a('link-order-admission.json'),a('link-receipt.json')
all_sources = index(program['files']+core['files'])
for name,row in {'ordered.ld':link['programScript'],**link['maintainedInputs']}.items():
    assert all_sources[row['path']]==row and sha(raw(A/'pinned-link-inputs'/name))==row['sha256']
check('all five retained raw link inputs bind physical program/CORE origins',True)
script = raw(A/'pinned-link-inputs/ordered.ld').decode()
check('fixed authenticated linker grammar and555 text selectors',link['programScript']['sha256']=='6954d9901b005312be6e7f980cb5e74a1440c174547c2040a881acf2e5c25b45' and link['maintainedInputs']['sbf_default.ld']['sha256']=='5e8370b9380f55411d827721e2e43c8cfd1eac71d1383e20b938397bc0bd82c3' and link['selectors']=={'.text':555,'.rodata':0,'.data.rel.ro':0})
check('actual link source/default/native LLD/parent receipt chain',receipt['script_sha256']==link['programScript']['sha256']==build['link_order']['script_sha256'] and receipt['default_script_sha256']==link['maintainedInputs']['sbf_default.ld']['sha256'] and receipt['lld_sha256']==native['sha256']==build['link_order']['lld_sha256'] and receipt['lld']==native['path'] and result['nativeLld']==native and result['linkOrder']==build['link_order']==admit['actualBuildLinkOrder'])
args = receipt['forwarded'];script_indices=[i for i,x in enumerate(args) if x in ['--script','-T']]
assert len(script_indices)==1 and not any(x.startswith(('--script=','@')) or (x.startswith('-T') and x!='-T') for x in args)
forwarded_script = PurePosixPath(args[script_indices[0]+1])
check('one private checked script, one native map and expected output',forwarded_script.is_absolute() and forwarded_script.parent.name.startswith('pump-link-script-') and forwarded_script.name=='ordered.ld' and str(forwarded_script)==admit['forwardedScript'] and [x for x in args if x.startswith('-Map=')]==['-Map=/Users/runner/work/_temp/pump-candidate-identity-work/link.map'] and args.count('-o')==1 and args[args.index('-o')+1].endswith('/target-identity/sbpf-solana-solana/release/deps/pump_recovered.so'))
map_raw = raw(A/'link.map')
check('full raw map/receipt hashes and frozen default/native bindings',sha(raw(A/'link-receipt.json'))==admit['receiptSha256'] and sha(map_raw)==admit['mapSha256'] and len(map_raw)==admit['mapBytes'] and admit['nativeLld']==native and admit['frozenProgramScript']==link['programScript'] and admit['frozenDefaultScript']==link['maintainedInputs']['sbf_default.ld'])
selectors=[]
for line in script.splitlines():
    match=re.fullmatch(r'    (\*[^()]*)\((?:"([^"]+)"|(\.text\*))\)',line)
    if match:selectors.append((match[1],match[2] or match[3]))
assert len(selectors)==556 and selectors[-1]==('*','.text*')
entries=[];output_rows={}
for number,line in enumerate(map_raw.decode().splitlines(),1):
    fields=line.split(maxsplit=4)
    if len(fields)==5 and fields[4] in ['.text','.rodata','.data.rel.ro','.dynamic','.dynsym','.dynstr','.rel.dyn']:
        assert fields[4] not in output_rows
        output_rows[fields[4]]={'address':int(fields[0],16),'size':int(fields[2],16),'line':number}
    match=re.match(r'^\s*([0-9a-f]+)\s+([0-9a-f]+)\s+([0-9a-f]+)\s+(\d+)\s+(.+):\((\.text[^()]*)\)$',line)
    if not match:continue
    filename=match[5];archive=re.match(r'^(.*\.rlib)\(([^()]*)\)$',filename)
    if archive:filename=archive[1]+':'+archive[2]
    hits=[i for i,(fp,sp) in enumerate(selectors) if fnmatch.fnmatchcase(filename,fp) and fnmatch.fnmatchcase(match[6],sp)]
    assert hits
    entries.append({'map_line':number,'address':int(match[1],16),'bytes':int(match[3],16),'section':match[6],'selector_index':min(hits)})
indices=[r['selector_index'] for r in entries]
check('actual input sections obey all555 explicit selectors and exactly tile text',len(entries)>=555 and indices==sorted(indices) and set(range(555)) <= set(indices) and sum(r['bytes'] for r in entries)==output_rows['.text']['size'] and entries[0]['address']==288 and all(a['address']+a['bytes']==b['address'] for a,b in zip(entries,entries[1:])))
unstripped,candidate=raw(A/'unstripped.so'),raw(A/'candidate.so')
us,headers=elf_sections(unstripped);cs,_=elf_sections(candidate)
for name,row in output_rows.items():assert row['address']==us[name]['addr']==cs[name]['addr'] and row['size']==us[name]['size']==cs[name]['size']
check('every allocated output section map geometry agrees with both actual ELFs',len(output_rows)==7)
for name,row in cs.items():
    if row['flags']&2:
        other=us[name]
        assert unstripped[other['offset']:other['offset']+other['size']]==candidate[row['offset']:row['offset']+row['size']]
check('stripped/symbol ELF allocated section bytes are identical',True)
sym=us['.symtab'];strings=us['.strtab'];string_raw=unstripped[strings['offset']:strings['offset']+strings['size']]
ctos=[]
for offset in range(sym['offset'],sym['offset']+sym['size'],sym['entsize']):
    name,info,other,shndx,value,size=struct.unpack_from('<IBBHQQ',unstripped,offset)
    if info&15!=2:continue
    text_name=string_raw[name:string_raw.index(b'\0',name)].decode()
    if 'admin_cto7execute' in text_name:ctos.append({'name':text_name,'address':value,'bytes':size,'info':info,'other':other,'section_index':shndx})
assert len(ctos)==1
cto=ctos[0];cto_map=[r for r in entries if 'admin_cto7execute' in r['section']]
check('unique current CTO symbol and map agree',len(cto_map)==1 and cto['address']==cto_map[0]['address']==0x22a10 and cto['bytes']==cto_map[0]['bytes'] and cto['bytes']>0 and cto['bytes']%8==0 and cto['name']=='_ZN14pump_recovered9admin_cto7execute17h3bd6d7f34f2e30d7E')
body_offset=us['.text']['offset']+cto['address']-us['.text']['addr'];cto['body_sha256']=sha(unstripped[body_offset:body_offset+cto['bytes']])
score=a('score.json');summary=score['summary'];windows=score['windows']
domain={r['original_start']:int(r['bytes']) for r in csv.DictReader(io.StringIO(raw(ROOT/'reconstruction/base/functions.tsv').decode()),delimiter='\t') if r['program']=='pump' and r['variant']=='selected'}
check('saved1035 score domain, types, summary and image hashes agree without scorer rerun',set(domain)==set(windows) and len(domain)==1035 and all(r['bytes']==domain[k] and type(r['raw']) is bool and type(r['normalized']) is bool for k,r in windows.items()) and summary==result['summary'] and summary['total']==len(windows) and summary['raw']==sum(r['raw'] for r in windows.values())==1034 and summary['normalized']==sum(r['normalized'] for r in windows.values())==1034 and summary['matched_text_bytes']==sum(r['bytes'] for r in windows.values() if r['normalized'])==1764808 and sha(unstripped)==summary['candidate_sha256']==build['unstripped_sha256']==result['unstrippedSha256'] and sha(candidate)==build['candidate_sha256']==result['candidateSha256'])
baseline=a('baseline-input.json');historical=load(ROOT/baseline['path']);assert sha(raw(ROOT/baseline['path']))==baseline['sha256']
for kind in ['normalized','raw']:
    gains=['0x%x'%int(k) for k in sorted(windows,key=int) if windows[k][kind] and not historical['windows'].get(k,{}).get(kind,False)]
    losses=['0x%x'%int(k) for k in sorted(windows,key=int) if not windows[k][kind] and historical['windows'].get(k,{}).get(kind,False)]
    prefix='' if kind=='normalized' else 'raw_'
    assert summary[prefix+'gains']==gains and summary[prefix+'losses']==losses
check('saved historical gain/loss arithmetic and single unmatched CTO', [hex(int(k)) for k,v in windows.items() if not v['normalized']]==['0x22a10'] and [hex(int(k)) for k,v in windows.items() if not v['raw']]==['0x22a10'])
root_admission=load(ROOT/'work/root/CANDIDATE-ELF-ADMISSION.json')
check('root one-off independent rescore receipt binds these actual bytes',root_admission['base']==BASE and root_admission['run']==RUN_ID and root_admission['operationalCommit']==OP and root_admission['images']=={'unstripped.so':sha(unstripped),'candidate.so':sha(candidate)} and root_admission['independentOfficialScorer']=='PASS')
check('exact root-admitted raw image SHA256 pins',len(unstripped)==2665792 and sha(unstripped)=='100d222047a2281a4409d8f732266955368504479d3d4076b4f6e3af08ef37e4' and len(candidate)==1934832 and sha(candidate)=='31ece96dc7eee70c8c7cc16ba401d63e668c3725a8d1c411834fd9494d8e01d0')
reference_admission=a('reference-admission.json');reference=ROOT/'work/current-13fe-reference';actual_reference=Path('/dev/shm/pump-cto-13fe453/work/native-run/artifact')
check('actual reference13fe43 member pins match original admitted bytes',reference_admission['base']=='13fe4536be64d8c5c10f8905e9d2236f423ac4f4' and reference_admission['run']==41170683278 and reference_admission['artifactId']==13031166975 and reference_admission['originalZipSha256']=='875edcd6e9ebb7e5b8fb2495d0008e723762b1f0251a02e038881fb56749fa92' and len(reference_admission['files'])==43 and reference_admission['coreEqual'] is True)
for name,row in reference_admission['files'].items():
    data=raw(reference/name);assert len(data)==row['bytes'] and sha(data)==row['sha256'] and data==(actual_reference/name).read_bytes()
comparison=a('CANDIDATE-COMPARISON.json');reference_score=load(reference/'score.json')
changed={k:{'reference':reference_score['windows'].get(k),'candidate':windows.get(k)} for k in windows.keys() | reference_score['windows'].keys() if windows.get(k)!=reference_score['windows'].get(k)}
check('all1035 saved score rows equal exact13fe baseline with zero changes',len(windows)==len(reference_score['windows'])==1035 and windows==reference_score['windows'] and changed==comparison['changedRows']=={} and comparison['fullRowsCompared']==1035 and comparison['allRowsEqual'] is True)
check('native source no-loss conclusion and persisted full comparison',comparison['sourceCommit']==BASE and comparison['sourceSha256']==source['sha256'] and comparison['referenceBase']==reference_admission['base'] and comparison['referenceRun']==41170683278 and comparison['referenceArtifactId']==13031166975 and comparison['summary']==summary and all(comparison[k] is True and result[k] is True for k in ['noNormalizedLosses','noRawLosses']) and result['fullScoreRowsCompared']==1035)
check('corrected root receipt exact hash and PASS with immutable data correction',sha(raw(ROOT/'work/root/CANDIDATE-ELF-ADMISSION.json'))=='b477052a47f8bcb4835cfd0e800f820f0c1dbad9aaf31ed4a3d43d737d4e17cd' and root_admission['nativeNoLossConclusion']=='PASS' and root_admission['comparison']==comparison)
initial=load(ROOT/'work/root/CANDIDATE-ELF-ADMISSION.initial-limits.json');attempt=load(ROOT/'work/root/admission/ATTEMPT-01.json')
check('prior reader/limits errors retained without altering actual result data',attempt['status']=='FAILED_ROOT_ADMISSION_METADATA_ADAPTER_BEFORE_SCORER_IMPORT' and {k:v for k,v in initial.items() if k not in ['limits','nativeNoLossConclusion','limitsCorrection']}=={k:v for k,v in root_admission.items() if k not in ['limits','nativeNoLossConclusion','limitsCorrection']})
run=load(RUN/'run-final.json');jobs=load(RUN/'jobs-final.json')['jobs'];steps=load(RUN/'steps-final.json')['steps']
check('actual attempt1 provider run/job/steps all successful',run['id']==RUN_ID and run['head_sha']==OP and run['run_attempt']==1 and run['conclusion']=='success' and len(jobs)==1 and jobs[0]['id']==124451910546 and jobs[0]['conclusion']=='success' and all(x['status']=='completed' and x['conclusion']=='success' for x in steps))
for key,value in list(inputs.items()):assert len((ROOT/key).read_bytes())==value['bytes'] and sha((ROOT/key).read_bytes())==value['sha256']
review={'verdict':'PASS independent actualS3 archive/provenance/link-map review','base':BASE,'operational_commit':OP,'run':RUN_ID,'checks':checks,
    'images':{'unstripped.so':sha(unstripped),'candidate.so':sha(candidate)},'source_sha256':source['sha256'],
    'link_map':{'bytes':len(map_raw),'sha256':sha(map_raw),'explicit_text_selectors':555,'matched_explicit_selectors':555,'text_input_sections':len(entries),'selector_order_monotone':True,'text_bytes':output_rows['.text']['size'],'CTO_map':cto_map[0]},
    'CTO':cto,'recorded_score':{k:summary[k] for k in ['normalized','raw','total','matched_text_bytes']},
    'limits':['No project imports, compiler, SDK, scorer, VM, native run, dispatch or source change by this reviewer.',
        'Remote SDK/registry trees and the deleted private linker copy are not physically rehashed locally; recorded full guards and frozen code/receipt bindings are checked.',
        'Cold target absence is the authenticated native controller declaration, not a separately observed remote filesystem state.',
        'Score rows/domain/arithmetic checked; root owns the already completed one independent official full rescore.',
        'ExactS3-versus13fe no-loss candidate result only. Score flags do not determine source progress or code identity; no candidate runtime, source gain, whole-original equality or security acceptance.']}
bindings={'schema':'actualS3-candidate-reference-bindings-v1','source':BASE,'operational_commit':OP,'run':RUN_ID,'artifact_id':api['id'],
    'reference_folder':str(A),'zip':{'path':str(zip_path),'bytes':len(zip_raw),'sha256':sha(zip_raw)},'members':members,
    'images':review['images'],'source_sha256':source['sha256'],'CTO':cto,
    'score_json':members['score.json'],'score_rows_canonical_sha256':sha(json.dumps(windows,sort_keys=True,separators=(',',':')).encode()),
    'independent_root_score_admission':inputs['work/root/CANDIDATE-ELF-ADMISSION.json'],'provenance_review':'REVIEW.json'}
for name,value in [('REVIEW.json',review),('REFERENCE-BINDINGS.json',bindings),('MAP-SELECTORS.json',{'selectors':selectors,'entries':entries,'outputs':output_rows}),('INPUTS.json',inputs)]:
    with (OUT/name).open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')
files={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(OUT.iterdir()) if p.is_file()}
with (OUT/'MANIFEST.json').open('x') as stream:json.dump({'run':RUN_ID,'source':BASE,'files':files},stream,indent=2);stream.write('\n')
print(json.dumps({'verdict':review['verdict'],'checks':len(checks),'CTO':cto,'reference_bindings_sha256':sha((OUT/'REFERENCE-BINDINGS.json').read_bytes()),'review_sha256':sha((OUT/'REVIEW.json').read_bytes()),'manifest_sha256':sha((OUT/'MANIFEST.json').read_bytes())},indent=2))
