"""Read only the admitted H1 prefix cache; preserve limited role attribution."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, sys

HERE = Path(__file__).parent
INPUT = HERE / 'H1-PREFIX.json'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def put(name, value):
    with (HERE / name).open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')

assert sys.dont_write_bytecode and os.environ.get('PYTHONDONTWRITEBYTECODE') == '1'
assert not (HERE / 'HOPT-MECHANISM.json').exists()
expected = '2036f2d719101d6b543a874f3956abd91feac8a8837c9954755a30682b6e7d05'
data = json.loads(INPUT.read_text())
assert data['prefix']['sha256'] == expected
assert data['input']['sha256'] == '602565457c192f65ff4601007acb9d52041d8fac4e5adfe93d8fb2686954a9b1'
assert data['status'] == 'PREFIX_CAPTURE_PASS' and not data['scopedOutlineCallsInPrefix']
before = {'path':str(INPUT),'bytes':INPUT.stat().st_size,'sha256':sha(INPUT),'mtimeNs':INPUT.stat().st_mtime_ns}
rows = data['rows']; by = {r['offset']:r for r in rows}
pred = {p:[] for p in by}
for r in rows:
    p = r['offset']; nxt = p + r['bytes']
    targets = [] if r['opcode'] == 0x95 else [r['jump']] + ([nxt] if r['opcode'] & 0xf0 else []) if 'jump' in r else [nxt]
    for q in targets:
        if q in by: pred[q].append(p)

def nearest(pc, defines):
    pending = list(pred[pc]); seen = set(); found = set(); entry = not pending
    while pending:
        p = pending.pop()
        if p in seen: continue
        seen.add(p); r = by[p]
        if defines(r): found.add(p)
        else:
            entry |= not pred[p]
            pending.extend(pred[p])
    return {'at':pc, 'definitions':sorted(found), 'entryWithoutDefinition':entry}
def reg(pc, number):
    result = nearest(pc, lambda r: number <= 5 if r['opcode'] in (0x85, 0x8d) else r['dst'] == number and (r['opcode'] == 0x18 or r['opcode'] & 7 in (1,4,7)))
    return dict(result, register=number)
def byte(pc, slot):
    result = nearest(pc, lambda r: r.get('memoryKind') == 'write' and r.get('memoryBase') == 10 and r['displacement'] <= slot < r['displacement'] + r['memoryWidth'])
    return dict(result, fpByte=slot)

assert by[0x10]['opcode'] == 0x7b and by[0x10]['src'] == 3 and by[0x10]['displacement'] == -2272
assert by[0x498]['opcode'] == 0x79 and by[0x498]['src'] == 10 and by[0x498]['dst'] == 5 and by[0x498]['displacement'] == -2272
incoming = [byte(0x498, p) for p in range(-2272,-2264)]
assert all(r['definitions'] == [0x10] and not r['entryWithoutDefinition'] for r in incoming)
copies = [reg(p,5) for p in (0x4a0,0x4d0,0x4e0,0x598,0x7d8)]
assert all(r['definitions'] == [0x498] and not r['entryWithoutDefinition'] for r in copies)
assert by[0x4d8]['opcode'] == by[0x7e0]['opcode'] == 0x57
assert by[0x4d8]['immediate'] == by[0x7e0]['immediate'] == 1
assert by[0x4b8]['opcode'] == 0x15 and by[0x4b8]['immediate'] == 2 and by[0x4b8]['jump'] == 0x4f0
assert by[0x4a8]['opcode'] == 0x57 and by[0x4a8]['immediate'] == 255
assert by[0x518]['opcode'] == 0x7b and by[0x518]['src'] == 8 and by[0x518]['displacement'] == -2336
assert by[0x1860]['opcode'] == 0x79 and by[0x1860]['src'] == 10 and by[0x1860]['dst'] == 2 and by[0x1860]['displacement'] == -2336
shared = [byte(0x1860, p) for p in range(-2336,-2328)]
assert all(r['definitions'] == [0x518] and not r['entryWithoutDefinition'] for r in shared)
assert by[0x1868]['opcode'] == 0x57 and by[0x1868]['immediate'] == 1
register_queries = [reg(0x4e8,4),reg(0x7e8,2),reg(0x9c0,2),reg(0x518,8),reg(0x510,3),reg(0x1880,2)]
assert register_queries[0]['definitions'] == [0x4d8]
assert register_queries[1]['definitions'] == [0x7e0]
assert register_queries[3]['definitions'] == [0x4c0,0x510]
assert register_queries[4]['definitions'] == [0x4b0,0x4e0]
assert register_queries[5]['definitions'] == [0x1868]
fd = [r for r in rows if r['opcode'] in (0x54,0x57) and r['immediate'] in (253,-3)]
assert not fd
table = []
for case,tag in [('None',2),('Some(false)',0),('Some(true)',1)]:
    caller = 0 if tag == 2 else (1 if tag & 1 else tag)
    table.append({'case':case,'inputR3':tag,'callerStoredNormalizedHolder':caller,'privateBit0':tag&1,'sharedBit0':caller&1})
    assert caller == tag & 1
result = {
    'status':'ALTERNATE_PARTIAL_LITERAL_HOLDER_AND1_REALIZED_WITH_EXPLICIT_NONE_BRANCH_AND_MULTIPLE_PROJECTIONS',
    'pid':os.getpid(),'utc':datetime.now(timezone.utc).isoformat(),'readerSHA256':sha(Path(__file__)),
    'input':before,'actualPrefix':data['prefix'],'execute':data['execute'],'prepare':data['prepare'],
    'incomingRawOption':{'spill':by[0x10],'reload':by[0x498],'byteQueries':incoming,'copyQueries':copies},
    'callerProjection':{'rows':[r for r in rows if 0x498<=r['offset']<=0x518], 'description':'Explicit low-byte None2 branch; Some path bit0 test. R8 is constant1 on true path and R3=0 or rawSomeFalse0 otherwise. Stored to FP[-2336,-2328).'},
    'privateProjection':{'rows':[r for r in rows if 0x7d8<=r['offset']<=0x7f8],'description':'Raw inputR5 copied toR2 and AND1, then zero branch. This value reaches the source289 error-control region and holder/new selection alongside a state-flag predecessor; no single universal SSA holder is asserted.'},
    'sharedProjection':{'rows':[r for r in rows if 0x1830<=r['offset']<=0x1880],'byteQueries':shared,'description':'Reload of caller-normalized holder; another AND1 governs branch1880 into the reset/hold region. Literal AND1 does not imply one shared projection with private validation.'},
    'registerQueries':register_queries,'validTagTruthTable':table,
    'fdOrMinus3ANDInstructionsInReleasedPrefix':fd,
    'unrelatedAND1':{'instruction':by[0x428],'sourceRegisterQuery':reg(0x420,9),'description':'Separate local classification predicate; excluded from hopt claims.'},
    'remainingAttribution':'Exact three-role source298 path binding and full error/type semantics remain unqualified. Recorded native branches/definitions, not source spelling or complete lowering theorem.',
    'sourceAdmission':{'raw':347,'normalized':1034,'total':1035,'rawLosses':687,'status':'REJECTED','targetMetricExecutions':0,'VMExecutions':0},
    'limits':['Cached-prefix read only: no new ELF decode, source edit, compiler, scorer, metric or VM.', 'Direct FP-byte/register reaching definitions with all calls returning and R0-R5 call-clobbered. Opaque indirect aliases and memory corruption are excluded premises.', 'Valid public Option tag domain None2/Somefalse0/Sometrue1 reused under unchanged source/IDL/SBF ABI; no new public-wrapper equality check.', 'No original Rust unwrap, equality, helper signature, private ABI, allocation/lifetime, causal match gain or runtime equivalence inferred.', 'No independent H1 native admission review is claimed; root provenance qualification is separate from rejection. STOP_NO_NEW_VARIANT_GO.']
}
assert before == {'path':str(INPUT),'bytes':INPUT.stat().st_size,'sha256':sha(INPUT),'mtimeNs':INPUT.stat().st_mtime_ns}
put('HOPT-MECHANISM.json',result)
print(json.dumps({'status':result['status'],'pid':os.getpid(),'sha256':sha(HERE/'HOPT-MECHANISM.json'),'sourceStillRejected':True}))
