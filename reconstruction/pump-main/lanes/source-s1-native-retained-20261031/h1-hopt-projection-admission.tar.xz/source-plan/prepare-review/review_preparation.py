"""Independent frozen H1 read/hash/Git/AST/archive review; never imports project code."""
from pathlib import Path, PurePosixPath
from collections import Counter
import ast, copy, hashlib, json, os, re, stat, subprocess, sys, tarfile, zipfile

assert os.environ.get('PYTHONDONTWRITEBYTECODE') == '1' and sys.dont_write_bytecode
ROOT=Path('/dev/shm/pump-cto-hopt-h1'); PREP=ROOT/'work/native-prep'
PARENT_ROOT=Path('/dev/shm/pump-cto-ebe5387'); OUT=Path(__file__).resolve().parent
BASE='568790dd4628bb39f9570562f6cc2d1892bcb358'; TREE='046f9648623558214365af9c766c141beaabfca0'
PARENT='ebe5387e12e948c2534618adf7a3cf0f27d9de51'
FREEZE='6b49c03b253941ca0d79251b98854e3735c22d0f317b8d2f490c366b3a70729d'
SOURCE='1e6c0e581c70dc4ba0d8303c98d05748a4c406c17c78128e8e9a33196b2042a7'
STAGE='8f92c8a25fe9f964c6d4f319191bcfd35a7543f65f4ebbf3ce69da039b45383a'
LEAF='bbc765ad4e59aecf495c74c89488f12e08d9258b098351abac21daac2cddd73b'
CORE=('reconstruction/harness','reconstruction/toolchain','reconstruction/base','reconstruction/pump-main/baseline','evidence/original/pump')
sha=lambda b:hashlib.sha256(b).hexdigest()
SHA=lambda p:sha(p.read_bytes())
load=lambda p:json.loads(p.read_text())
canonical=lambda x:sha(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
checks=[]
def check(name,condition):
    assert condition,name
    checks.append(name)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1',GIT_ALLOW_PROTOCOL='file',GIT_CONFIG_NOSYSTEM='1')
def git(*args):
    return subprocess.check_output(['git','-c','core.fsmonitor=false','-c','core.hooksPath=/dev/null',*args],cwd=ROOT,env=env,stderr=subprocess.PIPE)
def entries(prefixes):
    rows=[]
    for raw in git('ls-tree','-rz',BASE,'--',*prefixes).split(b'\0'):
        if not raw:continue
        meta,name=raw.split(b'\t',1);mode,kind,oid=meta.decode().split();name=name.decode()
        assert kind=='blob' and mode in ('100644','100755','120000')
        assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
        data=git('cat-file','blob',oid)
        assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid
        p=ROOT/name
        physical=os.fsencode(os.readlink(p)) if p.is_symlink() else p.read_bytes()
        assert physical==data
        assert (mode=='120000')==p.is_symlink()
        if mode!='120000':assert p.is_file() and bool(p.stat().st_mode&0o111)==(mode=='100755')
        rows.append({'path':name,'mode':mode,'gitBlob':oid,'bytes':len(data),'sha256':sha(data)})
    return rows

check('exact immutable author freeze',SHA(PREP/'FROZEN-MANIFEST.json')==FREEZE)
frozen=load(PREP/'FROZEN-MANIFEST.json');prepared=load(PREP/'PREPARATION-RESULT.json')
for r in frozen['files']:
    name=PurePosixPath(r['path']);p=PREP/name
    assert not name.is_absolute() and '..' not in name.parts and p.is_file() and not p.is_symlink()
    assert p.stat().st_size==r['bytes'] and SHA(p)==r['sha256']
check('all59 author frozen files authenticated',len(frozen['files'])==59)
commit=git('cat-file','commit',BASE)
check('genuine exact commit/tree/sole Ebe parent',git('rev-parse','HEAD').decode().strip()==BASE and hashlib.sha1(b'commit '+str(len(commit)).encode()+b'\0'+commit).hexdigest()==BASE and re.findall(rb'^parent ([0-9a-f]+)$',commit,re.M)==[PARENT.encode()] and re.search(rb'^tree ([0-9a-f]+)$',commit,re.M).group(1).decode()==TREE)
check('source delta only reviewed program leaf',git('diff-tree','--no-commit-id','--name-only','-r',BASE).decode().splitlines()==['programs/pump/src/creator/admin_cto.rs'])
program,core=entries(('programs/pump',)),entries(CORE)
check('independent typed Git vectors141/236 and CORE exact Ebe',len(program)==141 and len(core)==236 and core==load(PARENT_ROOT/'work/native-prep/toolchain-source-inputs.json')['files'])
leaf=next(r for r in program if r['path']=='programs/pump/src/creator/admin_cto.rs')
check('exact independently source-reviewed H1 leaf',leaf['sha256']==LEAF and leaf['gitBlob']=='6ff59d3fabcf85ed4b7506ecc3f332f492496af4' and leaf['bytes']==21958 and len((ROOT/leaf['path']).read_bytes().splitlines())==772 and (ROOT/leaf['path']).read_bytes()==Path('/dev/shm/pump-cto-hopt-h1-plan/proposal/admin_cto.rs').read_bytes())
source_auth={'source':BASE,'tree':TREE,'parent':PARENT,'leaf':leaf,'program':program,'core':core,'coreModes':dict(Counter(r['mode'] for r in core))}
(OUT/'SOURCE-AUTHENTICATION.json').write_text(json.dumps(source_auth,indent=2)+'\n')
evidence=PREP/'preflight/evidence';stage=PREP/'preflight/cold-work/ws'
check('actual preflight vectors equal independently typed Git',load(evidence/'program-source-inputs.json')==load(PREP/'program-source-inputs.json')=={'base':BASE,'files':program} and load(evidence/'toolchain-source-inputs.json')==load(PREP/'toolchain-source-inputs.json')=={'base':BASE,'files':core})
selected=[{'path':r['path'].removeprefix('programs/pump/'),'bytes':r['bytes'],'executable':r['mode']=='100755','sha256':r['sha256']} for r in program]
snapshot=load(evidence/'preflight-builder-source-inputs.json')
check('independently recomputed source aggregate',snapshot==load(PREP/'EXPECTED-SELECTED-SOURCE.json') and snapshot['files']==selected and snapshot['sha256']==canonical(selected)==SOURCE)
staged={}
for p in sorted(stage.rglob('*')):
    assert not p.is_symlink()
    if p.is_file():staged[p.relative_to(stage).as_posix()]={'bytes':p.stat().st_size,'executable':bool(p.stat().st_mode&0o111),'sha256':SHA(p)}
check('actual142 stage and aggregate',len(staged)==142 and staged==load(evidence/'compiled-workspace-inputs.json')==load(PREP/'EXPECTED-COMPILED-WORKSPACE.json') and canonical(staged)==STAGE)
toml=(ROOT/'programs/pump/Cargo.toml').read_text();ps=re.search(r'(?m)^\[profile\.release\]',toml).start();wi=re.search(r'(?m)^\[workspace\]',toml).start()
projection={r['path']:(ROOT/r['path']).read_bytes() for r in program if r['path'] not in ('programs/pump/Cargo.toml','programs/pump/Cargo.lock')}
projection['programs/pump/Cargo.toml']=(toml[:ps].rstrip()+'\n').encode()
projection['Cargo.toml']=('[workspace]\nmembers = ["programs/pump"]\nresolver = "2"\n\n'+toml[ps:wi].strip()+'\n').encode()
projection['Cargo.lock']=(ROOT/'programs/pump/Cargo.lock').read_bytes()
check('all staged bytes exact maintained source manifest projection',set(projection)==set(staged) and all((stage/n).read_bytes()==b for n,b in projection.items()))
for name,folder,expected in [('program-source.tar.gz',ROOT,{r['path'] for r in program}),('compiled-workspace.tar.gz',stage,set(staged))]:
    with tarfile.open(evidence/name) as t:
        members=t.getmembers();assert len(members)==len(expected)==len({m.name for m in members}) and {m.name for m in members}==expected
        for m in members:assert m.isfile() and t.extractfile(m).read()==(folder/m.name).read_bytes() and bool(m.mode&0o111)==bool((folder/m.name).stat().st_mode&0o111)
check('all283 archived source/stage members bytes and modes',True)
lane='reconstruction/pump-main/lanes/current-native-control';controller=PREP/'ops'/lane/'pump_current_control.py';prior=PARENT_ROOT/'work/native-prep/ops'/lane/'pump_current_control.py'
ct=ast.parse(controller.read_text());pt=ast.parse(prior.read_text());normal=copy.deepcopy(ct)
for n in normal.body:
    if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='BASE':n.value=ast.Constant(value=PARENT)
normal.body[0]=copy.deepcopy(pt.body[0])
check('whole plain controller AST including class and main unchanged except BASE/docstring',ast.dump(normal,include_attributes=False)==ast.dump(pt,include_attributes=False))
helpers=[n.name for n in ct.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name!='main']
check('all14 guard helpers/class bound',len(helpers)==14)
ops=('.github/workflows/qualify-pump-macos-v144.yml',lane+'/pump_current_control.py',lane+'/README.md')
check('exact3 normal operational paths',len(prepared['opsFiles'])==3 and {r['path'] for r in prepared['opsFiles']}==set(ops))
for r in prepared['opsFiles']:
    p=PREP/'ops'/r['path'];b=p.read_bytes()
    assert p.is_file() and not p.is_symlink() and not p.stat().st_mode&0o111 and r['mode']=='100644'
    assert len(b)==r['bytes'] and sha(b)==r['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==r['gitBlob']
check('exact3 OPS byte mode and Gitblob identities',True)
check('whole workflow only source pin and labels changed',(PREP/'ops'/ops[0]).read_text().replace(BASE,PARENT).replace(BASE[:8],PARENT[:8])==(PARENT_ROOT/'work/native-prep/ops'/ops[0]).read_text())
check('actual OPS patch hash and only3 registered diff paths',SHA(PREP/'OPS.patch')==prepared['opsPatchSha256'] and set(re.findall(r'^diff --git a/(\S+) b/\S+$',(PREP/'OPS.patch').read_text(),re.M))==set(ops))
ref=ROOT/'work/current-ebe-reference';actual=PARENT_ROOT/'work/native-run/artifact';reference=load(PREP/'REFERENCE-COPY-ADMISSION.json');pins=reference['files']
check('admitted exact Ebe43 reference pins',len(pins)==43 and reference['base']==PARENT and reference['run']==41176417138 and reference['artifactId']==13033007890 and reference['rawZipSHA256']=='b9ad6f1bc76f9b8fdb01e06b65262e3725ded83d544e394c8f0f568da6bfcfe5' and reference['rawZipBytes']==2539553)
check('exact external reference43 domain',{p.relative_to(ref).as_posix() for p in ref.rglob('*') if p.is_file() or p.is_symlink()}==set(pins))
for name,r in pins.items():
    p=ref/name;assert p.is_file() and not p.is_symlink() and p.stat().st_size==r['bytes'] and SHA(p)==r['sha256'] and p.read_bytes()==(actual/name).read_bytes()
with zipfile.ZipFile(actual.parent/'raw-artifact.zip') as z:
    assert z.testzip() is None and len(z.namelist())==43 and set(z.namelist())==set(pins)
    for n in z.namelist():assert z.read(n)==(ref/n).read_bytes()
check('actual raw Ebe ZIP and all43 members unchanged',SHA(actual.parent/'raw-artifact.zip')==reference['rawZipSHA256'])
for name,r in reference['separateQualificationRecords'].items():
    p=PREP/name;assert p.stat().st_size==r['bytes'] and SHA(p)==r['sha256'] and p.read_bytes()==Path(r['source']).read_bytes()
check('actual root/source/old semantic/metric qualifications separate from43',True)
score=load(ref/'score.json');official=load(PREP/'REFERENCE-ROOT-OFFICIAL-SCORE.json')
check('Ebe1035 saved/fresh rows equal and norm/raw arithmetic1034',len(score['windows'])==len(official['windows'])==1035 and all(score['windows'][k]['raw']==official['windows'][k]['raw'] and score['windows'][k]['normalized']==official['windows'][k]['normalized'] for k in score['windows']) and sum(r['raw'] for r in official['windows'].values())==sum(r['normalized'] for r in official['windows'].values())==1034)
before=load(PREP/'PREFLIGHT-INPUTS-BEFORE.json');after=load(PREP/'PREFLIGHT-INPUTS-AFTER.json')
check('all426 typed before and after records equal',before==after and len(before)==len({r['path'] for r in before})==426)
for r in after:
    p=Path(r['path']);assert p.is_relative_to(ROOT);st=p.lstat();b=os.fsencode(os.readlink(p)) if p.is_symlink() else p.read_bytes()
    assert len(b)==r['bytes'] and sha(b)==r['sha256'] and st.st_mode==r['mode'] and st.st_ino==r['inode'] and st.st_dev==r['device'] and st.st_mtime_ns==r['mtime_ns']
check('all426 inputs still physical identical after preflight and review',True)
execution=load(PREP/'PREFLIGHT-EXECUTION.json');process=load(PREP/'PREFLIGHT-PROCESS.json');outcome=load(PREP/'PREFLIGHT-RESULT.json')
check('actual one PID735943 exit0 no-SDK process receipt',process['pid']==outcome['pid']==735943 and outcome['status']=='PASS' and outcome['exitCode']==execution['exitCode']==0 and execution['head']==BASE and execution['controllerSha256']==SHA(controller) and not outcome['SDKBootstrapCargoCompilerScorerVMExecuted'])
check('bytecode-off argv and exact real rsync binding',process['argv']==outcome['argv']==execution['command'] and process['argv'][1]=='-B' and process['environment']['PYTHONDONTWRITEBYTECODE']=='1' and execution['rsyncSha256']=='a56c05b960beb734169619d5760b43ff495e84f85a93eb1f54fe58118262fb20' and outcome['stderrBytes']==0)
for n in ('stdout','stderr'):
    p=PREP/('preflight.'+n);assert p.stat().st_size==outcome[n+'Bytes'] and SHA(p)==outcome[n+'Sha256']
loader=ast.parse((PREP/'run_preflight.py').read_text());calls=[n for n in ast.walk(loader) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='main']
attrs=[n.targets[0].attr for n in ast.walk(loader) if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Attribute) and isinstance(n.targets[0].value,ast.Name) and n.targets[0].value.id=='module']
check('loader only redirects ROOT EVIDENCE WORK and calls preflight true once',attrs==['ROOT','EVIDENCE','WORK'] and len(calls)==1 and len(calls[0].keywords)==1 and calls[0].keywords[0].arg=='preflight_only' and ast.literal_eval(calls[0].keywords[0].value) is True)
pf=load(evidence/'PREFLIGHT.json');link=load(evidence/'link-inputs.json')
check('preflight returns before SDK bootstrap Cargo compiler native link configuration',pf['base']==BASE and pf['preflightOnly'] and not pf['sdkInstalledByPreflight'] and not pf['bootstrapRunByPreflight'] and not pf['cargoRunByPreflight'] and not pf['compilerRunByPreflight'] and not link['configureExecutedByPreflight'] and link['selectors']=={'.text':555,'.rodata':0,'.data.rel.ro':0} and not (PREP/'preflight/cold-work/target-identity').exists())
allrows={r['path']:r for r in program+core}
for name,r in {'ordered.ld':link['programScript'],**link['maintainedInputs']}.items():assert r==allrows[r['path']] and SHA(evidence/'pinned-link-inputs'/name)==r['sha256']
check('all5 immutable linker inputs and555 selectors bound',True)
guides=load(PREP/'INPUT-REVIEW.json')
for name,r in guides['guidesAndManifests'].items():assert SHA(ROOT/name)==r['sha256'] and (ROOT/name).read_bytes()==(PARENT_ROOT/name).read_bytes()
for prefix in CORE:
    assert not any(p.name=='__pycache__' or p.suffix in ('.pyc','.pyo') for p in (ROOT/prefix).rglob('*'))
check('current instructions manifests lock and CORE cache absence qualified Ebe',True)
check('material source review and old negatives byteexact',SHA(PREP/'SOURCE-SEMANTIC-REVIEW.json')=='070576a89d28647b49bffa424d276eed13e97a16be2481aa43798304dfc66f24' and SHA(PREP/'HOPT-PRIOR-MANIFEST.json')=='e0ec95eb9d44764473037ba93fa66c0824e8c178bb3fb7dd7ff98e6dab462442' and (PREP/'HOPT-PRIOR-ASSESSMENT.md').read_bytes()==Path('/dev/shm/pump-cto-ebe5387/work/hopt-unwrap-assessment/ASSESSMENT.md').read_bytes())
check('acquisition stops and no-SDK streams preserved',all((PREP/n).is_file() for n in ('GIT-ACQUISITION-ATTEMPT01.json','GIT-ACQUISITION-ATTEMPT02.json','preflight.stdout','preflight.stderr','prepare_inputs.stdout','prepare_inputs.stderr')))
check('tracked source remains clean',not git('status','--porcelain','--untracked-files=no').strip())
check('author freeze unchanged after independent read',SHA(PREP/'FROZEN-MANIFEST.json')==FREEZE)
report={'schema':'independent-h1-preparation-review-v1','status':'GO_PREPARATION_ONLY_NO_NATIVE_RESULT','source':BASE,'tree':TREE,'parent':PARENT,'sourceLeaf':leaf,'authorFreezeSha256':FREEZE,'frozenFiles':len(frozen['files']),'sourceFiles':141,'coreFiles':236,'coreModes':source_auth['coreModes'],'stageFiles':142,'selectedSourceSha256':SOURCE,'stageVectorSha256':STAGE,'operationalFiles':prepared['opsFiles'],'helpers':helpers,'actualPreflight':{'pid':735943,'seconds':outcome['elapsedSeconds'],'receiptSha256':SHA(PREP/'PREFLIGHT-EXECUTION.json'),'inputsUnchanged':426,'stdoutBytes':outcome['stdoutBytes'],'stderrBytes':outcome['stderrBytes']},'checks':checks,'limits':['Independent stdlib/hash/AST/Git/archive inspection only; no project import or repeated preflight.','Preparation GO only; root owns operational publication and any one normal build release.','H1 native masks/size/gain/no-loss/runtime remain unmeasured; source semantics GO and Ebe controls do not transfer those results.','Prior exact negatives and acquisition stops remain; no repair/grid/Result/flag/volatile variant follows.']}
(OUT/'REVIEW.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'checks':len(checks),'reviewSha256':SHA(OUT/'REVIEW.json'),'sourceAuthenticationSha256':SHA(OUT/'SOURCE-AUTHENTICATION.json'),'source':SOURCE,'stage':STAGE},indent=2))
