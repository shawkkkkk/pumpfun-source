GO for the exact H1 source proposal only: candidate `bbc765ad4e59aecf495c74c89488f12e08d9258b098351abac21daac2cddd73b`, Git blob `6ff59d3fabcf85ed4b7506ecc3f332f492496af4`.

Only lines283/289/339 change. None, Some(false) and Some(true) still project to false, false and true. The reused private holder negation preserves the existing short-circuit guard. `Option<bool>` is Copy, so the full hopt remains passed to the unchanged private Option<bool> validator. `unwrap_or(false)` uses a pure constant default and introduces no unwrap panic or default key.

All other source bytes, 20 macro suffixes and their coordinates, both volatile expressions334/338, validation/error order, C override, original-N sharing payload, flags, public ABI, wrappers and prepare/tail remain unchanged. This is a Rust source contract for valid decoded inputs, not malformed discriminants or a measured runtime result.

The retained private/caller unwrap singles, historical use-site controls and current v289h regressions remain material negatives. The fixed conjunction is not certified globally untried. Whether a role-bound bit0 projection replaces current FD/-3 shaping requires a separately admitted native image; no original unwrap, private ABI, compiler output, gain, allocation or size outcome follows from this review.

No source overlay, Git mutation, project tooling, preflight, compiler, SDK, scorer, metric, VM or remote write was executed. Root owns any later preparation and measurement; raw losses still reject the source.
