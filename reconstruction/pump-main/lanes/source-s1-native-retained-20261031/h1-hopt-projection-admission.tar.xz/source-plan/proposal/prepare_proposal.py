#!/usr/bin/env python3
"""Create only the root-authorized ignored H1 source proposal; no project execution."""
from pathlib import Path
import difflib
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/dev/shm/pump-cto-ebe5387/programs/pump/src/creator/admin_cto.rs')
EXPECTED_PARENT = 'a1a0bb06a5a260e13f5824235bbd19b6fa43883f07e3073e1cbcba03ab16601a'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def entry(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': sha(data)}

before_stat = SOURCE.stat()
parent = SOURCE.read_bytes()
assert sha(parent) == EXPECTED_PARENT
assert len(parent) == 21960 and len(parent.splitlines()) == 772
lines = parent.decode().splitlines(keepends=True)
edits = [
    (283, 'let holder=hopt==Some(true);', 'let holder=hopt.unwrap_or(false);'),
    (289, 'st.holder_reward&&!(hopt==Some(true))', 'st.holder_reward&&!holder'),
    (339, 'let holder=hopt==Some(true);', 'let holder=hopt.unwrap_or(false);'),
]
records = []
for line, old, new in edits:
    assert lines[line - 1].count(old) == 1
    records.append({'line': line, 'before': old, 'after': new,
                    'beforeLiteralSha256': sha(old.encode()),
                    'afterLiteralSha256': sha(new.encode())})
    lines[line - 1] = lines[line - 1].replace(old, new, 1)
candidate = ''.join(lines).encode()
old_lines = parent.splitlines(keepends=True)
new_lines = candidate.splitlines(keepends=True)
assert len(new_lines) == 772
changed_lines = [i for i, (a, b) in enumerate(zip(old_lines, new_lines), 1) if a != b]
assert changed_lines == [283, 289, 339]
undo = candidate.decode().splitlines(keepends=True)
for line, old, new in edits:
    assert undo[line - 1].count(new) == 1
    undo[line - 1] = undo[line - 1].replace(new, old, 1)
assert ''.join(undo).encode() == parent
macro = re.compile(r'\b(error|require(?:_\w+)?|msg)\s*!')
def macro_sites(data):
    return [(i, m.group(1), line[m.start():])
            for i, line in enumerate(data.decode().splitlines(), 1)
            for m in macro.finditer(line)]
assert macro_sites(parent) == macro_sites(candidate)
private_signature = old_lines[282].split(b'{', 1)[0]
assert new_lines[282].split(b'{', 1)[0] == private_signature
assert b'hopt:Option<bool>' in private_signature
assert b'->Result<Pubkey>' in private_signature
validate_call = b'validate(&st,hopt,fee,new,&holder_key,&sk)?'
assert parent.count(validate_call) == candidate.count(validate_call) == 1
assert old_lines[333] == new_lines[333] and old_lines[337] == new_lines[337]
assert b'read_volatile(holder_key as *const Pubkey as *const u8)' in new_lines[333]
assert b'read_volatile(holder_key as *const Pubkey as *const u8)' in new_lines[337]
assert b''.join(old_lines[339:]) == b''.join(new_lines[339:])
for line, before, after in edits:
    assert old_lines[line - 1].replace(before.encode(), b'', 1) == new_lines[line - 1].replace(after.encode(), b'', 1)
ROOT.joinpath('parent.rs').write_bytes(parent)
ROOT.joinpath('admin_cto.rs').write_bytes(candidate)
patch = ''.join(difflib.unified_diff(parent.decode().splitlines(True),
    candidate.decode().splitlines(True),
    fromfile='a/programs/pump/src/creator/admin_cto.rs',
    tofile='b/programs/pump/src/creator/admin_cto.rs', n=3)).encode()
ROOT.joinpath('source.patch').write_bytes(patch)
assert SOURCE.read_bytes() == parent
assert SOURCE.stat() == before_stat
proof = {
    'schema': 'ignored-h1-projection-source-contract-v1',
    'status': 'SOURCE_ONLY_EXACT_THREE_LITERAL_CHANGES_PENDING_ROOT_AND_INDEPENDENT_REVIEW',
    'parentPath': str(SOURCE), 'parent': entry(ROOT / 'parent.rs'),
    'candidate': entry(ROOT / 'admin_cto.rs'), 'patch': entry(ROOT / 'source.patch'),
    'lines': 772, 'changedLines': changed_lines, 'edits': records,
    'privateSignatureUnchanged': private_signature.decode(),
    'fullHoptPassedToValidate': validate_call.decode(),
    'allMacroSuffixesAndLineCoordinatesEqual': True,
    'macroSites': [{'line': i, 'macro': name} for i, name, _ in macro_sites(parent)],
    'volatileLinesByteEqual': [334, 338], 'allOtherBytesRecoverParentByExactUndo': True,
    'prepareAndTailAfterLine339ByteEqual': True,
    'frozenParentBytesAndStatUnchanged': True,
    'validPublicSemantics': [
        {'hopt': 'None', 'nativeTag': 2, 'oldHolder': False, 'newHolder': False},
        {'hopt': 'Some(false)', 'nativeTag': 0, 'oldHolder': False, 'newHolder': False},
        {'hopt': 'Some(true)', 'nativeTag': 1, 'oldHolder': True, 'newHolder': True},
    ],
    'sourceAuthoringOnly': True, 'compilePreflightScorerMetricVmRemoteMutations': 0,
    'sourceApproval': 'PENDING_ROOT_AND_INDEPENDENT_REVIEW',
    'gainOrOriginalUnwrapClaim': False,
}
ROOT.joinpath('PROOF.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps({'status': proof['status'], 'parent': proof['parent'],
                  'candidate': proof['candidate'], 'patch': proof['patch'],
                  'changedLines': changed_lines, 'macroSites': len(proof['macroSites'])}, indent=2))
