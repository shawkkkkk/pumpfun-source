#!/usr/bin/env python3
"""Prepare-only deliverable: root may execute after reviewing its pinned plan.

Retention only: stdlib byte/metadata/archive checks, no network, subprocess,
project imports, build, compiler, scorer, metric, VM, or binary decoding.
Compilation completed but remains unqualified after its metadata guard failed,
regardless of matching ELF hashes.
"""
import argparse
import decimal
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile
import zipfile

ROOT = Path('/dev/shm/pump-cto-912-bootstrap-closure')
OWN = Path('/dev/shm/cto-completion-obligations-review')
BASE = '9120883a957d7d9b2cab6140f66fb5bc9e6774d5'
TREE = '643b5908a1955db1503437d45a9da9a02bdbbd8d'
OP = '60c9ad3fe10cffcab0f1d28c8e99f23621ba3187'
OP_TREE = '4e5e6057a6368291cf8798809bc24cac511ab5f3'
RUN, JOB, ARTIFACT = 41215272713, 124578385642, 13047634711
ZIP_PIN = {'bytes': 2504474, 'sha256': '8d825f057250ef9f28aaf2f50c9c9552707ecd6215a5e58a017c1de73dc96c48'}
SOURCE_SHA = '6f5926830f08711a09d4b680f941338019217aaa48868b1afac8284619c0d6f3'
V1_SHA = 'be807c57090f2c8af8112c0b26504cd8614ac7572ee01d8b2187307a3952b18e'
STAGE_SHA = '051680359e8d86b69bd24357e25aaa955e6c68f82d25003ff63698816389fa52'
FREEZE_SHA = '73a3bc2d72f59d008e98af140f77adea4279b25b301bc5a669fda5841f08c114'
DIRECTORIES = ['idls', 'link', 'pump-token-ext', 'pump-token-ext/src', 'recovered', 'src', 'src/creator', 'src/quote_control', 'src/token_incentives', 'src/util']
IMAGES = {
    'unstripped.so': {'bytes': 2665688, 'sha256': 'dc79dde734b0cfb2ba84e505d62b5d3bdd801649e04e7ed9741366d07d095c8c'},
    'candidate.so': {'bytes': 1934832, 'sha256': 'd96c89272aa4fac9101d0bc5328596caecb63715b6514f554305bf8deb7cd3b8'},
}
ABSENT = ['RESULT.json', 'score.json', 'bootstrap-after.log', 'registry-source-inputs-after.json', 'tool-inputs-after.json', 'native-lld-input-after.json', 'cargo-fingerprints.json']
STATES = {}
LINK_STATES = {}
CORE_LINK_PATH = ROOT / 'reconstruction/base/original.so'
CORE_LINK_TEXT = '../../evidence/original/pump/deployed.so'
CORE_LINK_PIN = {'bytes': 40, 'sha256': '866f650843ae423a57516a1c735ffed9492821a4aafcbcfddeef17f5a34f43a6'}
CORE_LINK_BLOB = 'a09b803d1bca53352c8b10bb9abca16da16f21a5'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode()


def pretty(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def safe_name(name):
    require(isinstance(name, str) and name and '\\' not in name and '\x00' not in name, 'invalid archive name')
    path = PurePosixPath(name)
    require(not path.is_absolute() and all(p not in ('', '.', '..') for p in name.split('/')), 'unsafe archive path')
    require(str(path) == name, 'noncanonical archive name')
    return name


def regular(path):
    path = Path(path)
    require(path.is_absolute(), 'relative input path')
    # Reject symlinks in every ancestor, including the file itself.
    for component in [path, *path.parents]:
        require(not component.is_symlink(), 'symlink input: ' + str(component))
    info = path.lstat()
    require(stat.S_ISREG(info.st_mode), 'nonregular input: ' + str(path))
    return info


def signature(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def read(path, pin=None):
    path = Path(path)
    before = regular(path)
    with path.open('rb') as handle:
        require(signature(os.fstat(handle.fileno())) == signature(before), 'input replaced before read')
        data = handle.read()
        require(signature(os.fstat(handle.fileno())) == signature(before), 'input changed while reading')
    require(signature(regular(path)) == signature(before), 'input changed after read')
    if str(path) in STATES:
        require(STATES[str(path)] == (signature(before), identity(data)), 'input changed between checks')
    STATES[str(path)] = (signature(before), identity(data))
    if pin is not None:
        require(identity(data) == {k: pin[k] for k in ('bytes', 'sha256')}, 'input pin mismatch: ' + str(path))
    return data


def load(relative):
    return json.loads(read(ROOT / relative))


def git_blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\x00' + data).hexdigest()


def tracked_core_link(path, pin):
    """Read the one literal Git link object; never follow or read its target."""
    path = Path(path)
    require(path == CORE_LINK_PATH, 'unexpected tracked link domain')
    require({k: pin[k] for k in ('bytes', 'sha256')} == CORE_LINK_PIN, 'tracked link pin differs')
    # lstat/readlink only: neither this path nor its target is resolved.
    def ancestors():
        result = {}
        for component in path.parents:
            info = component.lstat()
            require(stat.S_ISDIR(info.st_mode) and not stat.S_ISLNK(info.st_mode), 'tracked link ancestor is not a real directory')
            result[str(component)] = signature(info)
        return result
    before_ancestors = ancestors()
    before = path.lstat()
    require(stat.S_ISLNK(before.st_mode) and before.st_size == CORE_LINK_PIN['bytes'], 'tracked link type/size differs')
    target_text = os.readlink(path)
    require(target_text == CORE_LINK_TEXT, 'tracked link target text differs')
    data = target_text.encode('utf-8')
    require(identity(data) == CORE_LINK_PIN and git_blob(data) == CORE_LINK_BLOB, 'tracked link text identity differs')
    require(signature(path.lstat()) == signature(before) and ancestors() == before_ancestors, 'tracked link or ancestor changed while reading')
    state = (signature(before), identity(data), before_ancestors)
    if str(path) in LINK_STATES:
        require(LINK_STATES[str(path)] == state, 'tracked link or ancestor changed between checks')
    LINK_STATES[str(path)] = state
    return data


def vector(rows, count, prefix):
    require(len(rows) == count, 'wrong source/CORE count')
    require(len({row['path'] for row in rows}) == count, 'duplicate source/CORE path')
    for row in rows:
        name = safe_name(row['path'])
        require(not prefix or name.startswith(prefix), 'wrong source domain')
        if row['mode'] == '120000':
            require(not prefix and ROOT / name == CORE_LINK_PATH and row['gitBlob'] == CORE_LINK_BLOB, 'unexpected source/CORE link')
            tracked_core_link(ROOT / name, row)
            continue
        data = read(ROOT / name, row)
        require(git_blob(data) == row['gitBlob'], 'Git blob mismatch: ' + name)
        require(row['mode'] in ('100644', '100755'), 'unsupported Git mode')
        require(bool(regular(ROOT / name).st_mode & 0o111) == (row['mode'] == '100755'), 'executable mismatch: ' + name)


def strict_tar(data, expected, git_rows=None):
    require(len(expected) == len(set(expected)), 'duplicate TAR vector')
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
        members = archive.getmembers()
        require(len(members) == len(expected), 'unexpected TAR member count')
        require(len({item.name for item in members}) == len(members), 'duplicate TAR member')
        require({item.name for item in members} == set(expected), 'TAR member domain differs')
        for item in members:
            safe_name(item.name)
            # The native Python TAR writer retained fractional mtime PAX
            # metadata. The complete TAR bytes are pinned, and mtime is the
            # only permitted extension; reject path/link/type extensions.
            require(item.isfile() and not item.linkname and set(item.pax_headers) <= {'mtime'}, 'nonregular/unsafe extended TAR member')
            if 'mtime' in item.pax_headers:
                value = item.pax_headers['mtime']
                require(isinstance(value, str) and re.fullmatch(r'[0-9]+(?:\.[0-9]+)?', value) is not None and decimal.Decimal(value).is_finite(), 'invalid PAX mtime')
            entry = expected[item.name]
            require(item.size == entry['bytes'], 'TAR member size differs')
            payload = archive.extractfile(item).read()
            require(identity(payload) == {k: entry[k] for k in ('bytes', 'sha256')}, 'TAR member hash differs')
            executable = entry.get('executable', entry.get('mode') == '100755')
            require((item.mode & 0o7777) == (0o755 if executable else 0o644), 'TAR mode differs')
            if git_rows is not None:
                require(git_blob(payload) == git_rows[item.name]['gitBlob'], 'TAR Git blob differs')


def screened(data):
    # Construct markers without placing them literally in this retained script.
    forbidden = [b'identity.' + b'slop.cash', b'poll' + b'Capability', b'-----BEGIN ' + b'PRIVATE KEY-----', b'-----BEGIN OPENSSH ' + b'PRIVATE KEY-----']
    require(all(marker not in data for marker in forbidden), 'private authentication material marker')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--plan-sha256', required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    require(args.plan == OWN / 'V2-GUARD-RETENTION-INPUTS.json', 'unexpected plan path')
    plan_bytes = read(args.plan)
    require(hashlib.sha256(plan_bytes).hexdigest() == args.plan_sha256, 'plan SHA mismatch')
    plan = json.loads(plan_bytes)
    require(plan['schema'] == 'pump-failed-v2-guard-retention-plan-v1', 'wrong plan schema')
    require(plan['root'] == str(ROOT) and plan['source'] == BASE and plan['operational'] == OP, 'wrong root/source/operational binding')
    require((plan['run'], plan['job'], plan['artifact']) == (RUN, JOB, ARTIFACT), 'wrong run binding')
    require(plan['zip'] == ZIP_PIN and len(plan['rawMembers']) == 35, 'wrong ZIP pins')
    require(args.out.is_absolute() and not args.out.exists() and not args.out.is_symlink(), 'output must be a new absolute directory')
    require(args.out.parent.resolve() == Path('/dev/shm') and args.out.name == 'pump-cto-912-v2-guard-failed-retention', 'unexpected output root')
    require(args.out.resolve() not in ROOT.parents and ROOT not in args.out.resolve().parents, 'output overlaps source root')

    payload = {}
    input_paths = []
    for item in plan['inputs']:
        name = safe_name(item['archive'])
        require(name not in payload, 'duplicate capsule name')
        path = Path(item['path'])
        require(ROOT in path.parents or path == OWN / 'retain_v2_guard_failure.py', 'unexpected input root')
        require('/cold-work/' not in str(path) and '/download-lease/' not in str(path), 'excluded input subtree')
        data = read(path, item)
        screened(data)
        payload[name] = data
        input_paths.append(str(path))
    require(len(input_paths) == len(set(input_paths)), 'duplicate input path')
    require(read(Path(__file__)) == payload['root-methods/retain_v2_guard_failure.py'], 'script is not pinned payload')
    # Freeze exact selected folder membership; duplicate staged checkout is excluded.
    for folder in ('native-prep', 'native-run'):
        actual = set()
        base = ROOT / 'work' / folder
        for path in base.rglob('*'):
            relative = path.relative_to(base).as_posix()
            if relative == 'preflight/cold-work' or relative.startswith('preflight/cold-work/'):
                continue
            require(not path.is_symlink(), 'symlink in selected input domain')
            if path.is_file() and relative != 'raw-artifact.zip':
                actual.add(str(path))
            else:
                require(path.is_dir() or relative == 'raw-artifact.zip', 'unsupported selected file type')
        planned = {p for p in input_paths if str(base) + '/' in p}
        require(actual == planned, 'selected input domain changed: ' + folder)

    raw_zip = read(ROOT / 'work/native-run/raw-artifact.zip', ZIP_PIN)
    admission = load('work/native-run/V2-GUARD-FAILURE-ADMISSION.json')
    require(admission['members'] == plan['rawMembers'] and admission['zip'] == ZIP_PIN and admission['CRC'] == 'PASS', 'root admission pins differ')
    require((admission['run'], admission['job'], admission['artifactId']) == (RUN, JOB, ARTIFACT), 'root admission run differs')
    require(admission['compiledSourceQualified'] is False and admission['newRootScoreMetricVM'] is False, 'failed build was reclassified')
    require(admission['sourceSchema'] == 'pump-source-inputs-v2' and admission['correctV2SHA256'] == SOURCE_SHA and admission['filesOnlySHA256'] == V1_SHA, 'admission source digest distinction differs')
    with zipfile.ZipFile(io.BytesIO(raw_zip)) as archive:
        entries = archive.infolist()
        require(len(entries) == 35 and len({e.filename for e in entries}) == 35, 'wrong/duplicate ZIP count')
        require({e.filename for e in entries} == set(plan['rawMembers']), 'ZIP member domain differs')
        require(archive.testzip() is None, 'ZIP CRC failure')
        for entry in entries:
            safe_name(entry.filename)
            mode = entry.external_attr >> 16
            require(not entry.is_dir() and not entry.flag_bits & 1 and not stat.S_ISLNK(mode), 'unsafe ZIP type/encryption')
            require(stat.S_IFMT(mode) in (0, stat.S_IFREG), 'nonregular ZIP mode')
            pin = plan['rawMembers'][entry.filename]
            require(entry.file_size == pin['bytes'], 'ZIP member length differs')
            data = archive.read(entry)
            require(identity(data) == pin, 'ZIP member hash differs')
            require(data == payload['work/native-run/artifact/' + entry.filename], 'ZIP/extracted bytes differ')
    require(not any(name in plan['rawMembers'] for name in ABSENT), 'unexpected afterguard/result/score marker')

    run = load('work/native-run/run-final.json')
    require((run['id'], run['head_sha'], run['run_attempt'], run['status'], run['conclusion']) == (RUN, OP, 1, 'completed', 'failure'), 'run state differs')
    jobs = load('work/native-run/jobs-final.json')
    require(jobs['total_count'] == 1 and len(jobs['jobs']) == 1, 'job domain differs')
    job = jobs['jobs'][0]
    require((job['id'], job['run_id'], job['head_sha'], job['run_attempt'], job['conclusion']) == (JOB, RUN, OP, 1, 'failure'), 'job state differs')
    metadata = load('work/native-run/ARTIFACT-METADATA.json')
    require((metadata['id'], metadata['size_in_bytes'], metadata['digest']) == (ARTIFACT, ZIP_PIN['bytes'], 'sha256:' + ZIP_PIN['sha256']), 'artifact metadata differs')
    artifacts = load('work/native-run/artifacts-final.json')
    require(artifacts['total_count'] == 1 and artifacts['artifacts'] == [metadata], 'artifact list differs')
    require(metadata['workflow_run']['id'] == RUN and metadata['workflow_run']['head_sha'] == OP and metadata['expired'] is False, 'artifact run binding differs')
    operational = load('work/native-run/PUBLIC-OPERATIONAL.json')
    require(operational['sha'] == OP and operational['commit']['tree']['sha'] == OP_TREE, 'operational object differs')
    require([p['sha'] for p in operational['parents']] == [BASE], 'operational parent differs')
    ops = load('work/native-run/artifact/operational-inputs.json')
    prep = load('work/native-prep/PREPARATION-RESULT.json')
    require(ops['checkout'] == OP and len(ops['files']) == 3 and ops['files'] == prep['opsFiles'], 'operational vector differs')
    require({r['filename']: r['sha'] for r in operational['files']} == {r['path']: r['gitBlob'] for r in ops['files']}, 'operational changed domain differs')
    for row in ops['files']:
        data = read(ROOT / 'work/native-prep/ops' / safe_name(row['path']), row)
        require(git_blob(data) == row['gitBlob'], 'prepared operational blob differs')
        require(bool(regular(ROOT / 'work/native-prep/ops' / row['path']).st_mode & 0o111) == (row['mode'] == '100755'), 'prepared operational mode differs')

    frozen = load('work/native-prep/FROZEN-MANIFEST.json')
    require(identity(read(ROOT / 'work/native-prep/FROZEN-MANIFEST.json'))['sha256'] == FREEZE_SHA, 'preparation freeze differs')
    require(frozen['source'] == BASE and frozen['tree'] == TREE, 'freeze source differs')
    require((frozen['sourceFiles'], frozen['coreFiles'], frozen['stageFiles']) == (263, 288, 264), 'freeze counts differ')
    for name, pin in frozen['files'].items():
        read(ROOT / 'work/native-prep' / safe_name(name), pin)
    go = load('work/ROOT-NATIVE-PREPARATION-GO.json')
    require(go['rootPreparationGO'] is True and go['preparationSHA256'] == FREEZE_SHA and go['source'] == BASE and go['OPS'] == ops['files'], 'root preparation GO differs')
    require(read(ROOT / 'work/native-prep/PREFLIGHT-INPUTS-BEFORE.json') == read(ROOT / 'work/native-prep/PREFLIGHT-INPUTS-AFTER.json'), 'historical preflight inputs changed')
    source = load('work/native-run/artifact/program-source-inputs.json')
    core = load('work/native-run/artifact/toolchain-source-inputs.json')
    require(source['base'] == BASE and core['base'] == BASE, 'source/CORE base differs')
    vector(source['files'], 263, 'programs/pump/')
    vector(core['files'], 288, '')
    snapshot = load('work/native-run/artifact/source-inputs.json')
    require(snapshot == load('work/native-run/artifact/preflight-builder-source-inputs.json') == load('work/native-prep/EXPECTED-SELECTED-SOURCE.json'), 'source snapshots differ')
    require(snapshot['schema'] == 'pump-source-inputs-v2' and snapshot['directories'] == DIRECTORIES, 'source schema/directories differ')
    require(snapshot['sha256'] == SOURCE_SHA and hashlib.sha256(canonical({'files': snapshot['files'], 'directories': DIRECTORIES})).hexdigest() == SOURCE_SHA, 'canonical v2 digest differs')
    require(hashlib.sha256(canonical(snapshot['files'])).hexdigest() == V1_SHA, 'historical files-only digest differs')
    selected_rows = [{'path': r['path'][len('programs/pump/'):], 'bytes': r['bytes'], 'executable': r['mode'] == '100755', 'sha256': r['sha256']} for r in source['files']]
    require(selected_rows == snapshot['files'], 'Git/source selected vectors differ')
    source_root = ROOT / 'programs/pump'
    actual_source_dirs, actual_source_files = [], []
    for path in source_root.rglob('*'):
        parts = path.relative_to(source_root).parts
        if '.git' in parts or parts[0] == 'target':
            continue
        require(not path.is_symlink(), 'source domain contains symlink')
        if path.is_dir():
            actual_source_dirs.append(path.relative_to(source_root).as_posix())
        else:
            require(path.is_file(), 'unsupported source domain type')
            actual_source_files.append(path.relative_to(source_root).as_posix())
    actual_source_dirs.sort()
    require(actual_source_dirs == DIRECTORIES, 'current source directory domain differs')
    require(sorted(actual_source_files) == sorted(row['path'] for row in snapshot['files']), 'current source file domain differs')
    stage = load('work/native-run/artifact/compiled-workspace-inputs.json')
    require(len(stage) == 264 and hashlib.sha256(canonical(stage)).hexdigest() == STAGE_SHA, 'staged vector differs')
    require(stage == load('work/native-prep/preflight/evidence/compiled-workspace-inputs.json'), 'preflight/native staged vectors differ')
    strict_tar(read(ROOT / 'work/native-run/artifact/program-source.tar.gz'), {r['path']: r for r in source['files']}, {r['path']: r for r in source['files']})
    strict_tar(read(ROOT / 'work/native-run/artifact/compiled-workspace.tar.gz'), stage)

    failure = load('work/native-run/artifact/FAILURE.json')
    require(failure == {'type': 'ValueError', 'message': 'actual builder and Git source vectors differ', 'base': BASE}, 'failure classification differs')
    require(admission['failure'] == failure and admission['images'] == IMAGES, 'admission failure/image pins differ')
    commands = [json.loads(line) for line in read(ROOT / 'work/native-run/artifact/commands.jsonl').splitlines()]
    require([c['name'] for c in commands] == ['bootstrap-before', 'fetch-locked', 'cold-build'] and all(c['returncode'] == 0 for c in commands), 'actual command boundary differs')
    build = load('work/native-run/artifact/build.json')
    require(build['ok'] is True and build['source_sha256'] == SOURCE_SHA and build['recipe'] == 'identity' and build['triple'] == 'sbpf-solana-solana', 'compiled record differs')
    require(build['runtime_valid'] is True and build['stack_warnings'] == [], 'compiler stack-warning gate differs')
    for name, pin in IMAGES.items():
        read(ROOT / 'work/native-run/artifact' / name, pin)
        key = 'unstripped_sha256' if name == 'unstripped.so' else 'candidate_sha256'
        require(build[key] == pin['sha256'], 'build image declaration differs')
    # Check absence only in the failed-run evidence root; never confuse a prior
    # tracked baseline score with a newly executed score for this run.
    for name in ABSENT:
        require(not (ROOT / 'work/native-run/artifact' / name).exists(), 'afterguard/result marker unexpectedly exists')
    for name in plan['absentRootMarkers']:
        require(not (ROOT / safe_name(name)).exists(), 'new root score/metric/VM marker exists')

    screened(plan_bytes)
    payload['RETENTION-INPUTS.json'] = plan_bytes
    manifest = {
        'schema': 'pump-failed-v2-guard-capsule-v1', 'source': BASE, 'sourceTree': TREE,
        'operational': OP, 'run': RUN, 'job': JOB, 'artifact': ARTIFACT,
        'inputs': {name: identity(data) for name, data in sorted(payload.items())},
        'sourceFiles': 263, 'coreFiles': 288, 'stageFiles': 264,
        'sourceSchema': 'pump-source-inputs-v2', 'sourceSHA256': SOURCE_SHA,
        'filesOnlySHA256': V1_SHA, 'sourceDirectories': DIRECTORIES,
        'rawZip': ZIP_PIN, 'rawMembers': 35, 'images': IMAGES,
        'decision': 'COMPILATION_COMPLETED_V2_METADATA_GUARD_FAILED_UNQUALIFIED',
        'compiledSourceQualified': False, 'newScoreMetricVM': False,
        'missing': ABSENT,
        'note': 'Compiler runtime_valid is its stack-warning gate, not VM execution. ELF byte identities confer no source/after-state qualification. No waiver, score, metric, or source acceptance.',
    }
    payload['CAPSULE-MANIFEST.json'] = pretty(manifest)
    # Build the deterministic archive in memory. No output exists until all
    # archive and source checks have passed. Do not execute any retained file.
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w:xz', format=tarfile.USTAR_FORMAT, preset=6) as archive:
        for name, data in sorted(payload.items()):
            item = tarfile.TarInfo(safe_name(name))
            item.size, item.mode, item.mtime = len(data), 0o644, 0
            item.uid = item.gid = 0
            item.uname = item.gname = ''
            archive.addfile(item, io.BytesIO(data))
    capsule = buffer.getvalue()
    with tarfile.open(fileobj=io.BytesIO(capsule), mode='r:xz') as archive:
        members = archive.getmembers()
        require([m.name for m in members] == sorted(payload), 'capsule domain/order differs')
        for member in members:
            require(member.isfile() and member.mode == 0o644 and member.mtime == 0 and member.uid == member.gid == 0 and not member.uname and not member.gname and not member.linkname, 'capsule metadata differs')
            require(archive.extractfile(member).read() == payload[member.name], 'capsule roundtrip differs')
    # Re-read every observed input before writing output, including full
    # source/CORE bytes. This is retention verification, not build admission.
    for path, (info, pin) in list(STATES.items()):
        require(signature(regular(path)) == info, 'input metadata changed before output')
        read(path, pin)
    require(set(LINK_STATES) == {str(CORE_LINK_PATH)}, 'tracked CORE link domain differs')
    tracked_core_link(CORE_LINK_PATH, CORE_LINK_PIN)
    capsule_name = 'latest912-v2-guard-failure.tar.xz'
    zip_name = 'latest912-v2-guard-failure-raw.zip'
    receipt = {key: manifest[key] for key in ('schema', 'source', 'sourceTree', 'operational', 'run', 'job', 'artifact', 'decision', 'compiledSourceQualified', 'newScoreMetricVM', 'missing', 'note', 'images', 'sourceFiles', 'coreFiles', 'stageFiles', 'sourceSchema', 'sourceSHA256', 'sourceDirectories')}
    receipt.update({'schema': 'pump-failed-v2-guard-retention-receipt-v1', 'planSHA256': args.plan_sha256, 'capsuleMembers': len(payload), 'rawMembers': 35, 'files': {capsule_name: identity(capsule), zip_name: ZIP_PIN}, 'inputChecks': 'All pinned regular bytes, the one literal tracked CORE symlink text without dereference, source/CORE Git blobs, executable modes, v2 directories, TAR/ZIP domains, hashes, CRC and root provenance checked; no build or scorer executed.'})
    args.out.mkdir(mode=0o700, exist_ok=False)
    for name, data in [(capsule_name, capsule), (zip_name, raw_zip), ('LATEST912-V2-GUARD-FAILURE-RECEIPT.json', pretty(receipt))]:
        with (args.out / name).open('xb') as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        require(read(args.out / name) == data, 'written output differs')
    print(json.dumps(receipt, sort_keys=True))


if __name__ == '__main__':
    main()
