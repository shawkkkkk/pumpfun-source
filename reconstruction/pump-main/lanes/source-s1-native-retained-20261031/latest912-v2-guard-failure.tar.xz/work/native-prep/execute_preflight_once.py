"""Execute the single root-authorized no-SDK preflight and retain full evidence."""
import datetime,hashlib,json,os,stat,subprocess,sys,time
from pathlib import Path
assert os.environ.get('PYTHONDONTWRITEBYTECODE')=='1'and sys.dont_write_bytecode and sys.flags.optimize==0
R=Path('/dev/shm/pump-cto-912-bootstrap-closure');O=R/'work/native-prep';sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def inspect(p):
 s=p.lstat();b=os.fsencode(os.readlink(p))if p.is_symlink()else p.read_bytes();assert p.is_symlink()or stat.S_ISREG(s.st_mode)
 return {'path':str(p),'bytes':len(b),'sha256':sha(b),'mode':s.st_mode,'inode':s.st_ino,'device':s.st_dev,'mtime_ns':s.st_mtime_ns}
paths=[R/x['path']for name in ['program-source-inputs.json','toolchain-source-inputs.json']for x in json.loads((O/name).read_text())['files']]
paths += [p for p in sorted((O/'ops').rglob('*'))if p.is_file()]+[O/'run_preflight.py',O/'ROOT-PREPARATION-REVIEW.json',Path('/workspace/pumpfun-source-workers/pump-lifecycle/work/host-tools/rsync-debian-13/extracted/usr/bin/rsync'),Path(sys.executable).resolve()]
before=[inspect(p)for p in paths];(O/'PREFLIGHT-INPUTS-BEFORE.json').write_text(json.dumps(before,indent=2)+'\n')
argv=[sys.executable,'-B','work/native-prep/run_preflight.py'];env=os.environ.copy();env.pop('PYTHONOPTIMIZE',None);env.pop('PYTHONPATH',None);env.update(PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1',TMPDIR='/dev/shm');start=now();clock=time.monotonic()
with(O/'PREFLIGHT-ONCE.json').open('x')as f:json.dump({'startUtc':start,'argv':argv,'source':'9120883a957d7d9b2cab6140f66fb5bc9e6774d5','onlyAuthorizedPreflight':True},f,indent=2);f.write('\n')
with(O/'preflight.stdout').open('xb')as out,(O/'preflight.stderr').open('xb')as err:
 p=subprocess.Popen(argv,cwd=R,env=env,stdout=out,stderr=err)
 with(O/'PREFLIGHT-PROCESS.json').open('x')as f:json.dump({'pid':p.pid,'ppid':os.getpid(),'argv':argv,'cwd':str(R),'startUtc':start,'environment':{k:env.get(k)for k in ['PYTHONDONTWRITEBYTECODE','PYTHONOPTIMIZE','PYTHONPATH','GIT_NO_LAZY_FETCH','TMPDIR']}},f,indent=2);f.write('\n')
 code=p.wait()
elapsed=time.monotonic()-clock;end=now();after=[inspect(q)for q in paths];(O/'PREFLIGHT-INPUTS-AFTER.json').write_text(json.dumps(after,indent=2)+'\n')
stdout=(O/'preflight.stdout').read_bytes();stderr=(O/'preflight.stderr').read_bytes();result={'status':'PASS'if code==0 and before==after else'FAIL','pid':p.pid,'argv':argv,'startUtc':start,'endUtc':end,'exitCode':code,'elapsedSeconds':elapsed,'stdoutBytes':len(stdout),'stdoutSha256':sha(stdout),'stderrBytes':len(stderr),'stderrSha256':sha(stderr),'inputsUnchanged':before==after,'sourceCoreReferenceOpsBoundFiles':len(paths),'SDKBootstrapCargoCompilerScorerVMExecuted':False}
(O/'PREFLIGHT-RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(0 if result['status']=='PASS'else 1)
