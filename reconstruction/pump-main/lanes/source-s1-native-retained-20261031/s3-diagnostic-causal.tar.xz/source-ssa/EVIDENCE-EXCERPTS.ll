; Bounded excerpts from admitted optimized S3 execute; numbered ORIGINAL target lines.
; TARGET-LINE 82, BLOCK start
  %_166.sroa.6.i.sroa.6 = alloca [13 x i8], align 1
; TARGET-LINE 99, BLOCK start
  %target.i = alloca [32 x i8], align 1
; TARGET-LINE 106, BLOCK start
  %sharing_update12.sroa.5 = alloca [13 x i8], align 1
; TARGET-LINE 107, BLOCK start
  %target11 = alloca [32 x i8], align 1
; TARGET-LINE 129, BLOCK start
  %val4 = alloca [33 x i8], align 4
; TARGET-LINE 135, BLOCK start
  %_42.sroa.44 = alloca [45 x i8], align 8
; TARGET-LINE 136, BLOCK start
  %_41.sroa.14 = alloca [45 x i8], align 8
; TARGET-LINE 138, BLOCK start
  %st = alloca [48 x i8], align 8
; TARGET-LINE 142, BLOCK start
  %hk = alloca [33 x i8], align 1
; TARGET-LINE 143, BLOCK start
  %holder_key = alloca [32 x i8], align 1
; TARGET-LINE 145, BLOCK start
  %mint = alloca [32 x i8], align 1
; TARGET-LINE 146, BLOCK start
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %mint)
; TARGET-LINE 147, BLOCK start
  %3 = getelementptr inbounds i8, ptr %ctx, i64 8
; TARGET-LINE 148, BLOCK start
  %_247 = load ptr, ptr %3, align 8, !nonnull !2, !align !3, !noundef !2
; TARGET-LINE 149, BLOCK start
  %4 = getelementptr inbounds i8, ptr %_247, i64 16
; TARGET-LINE 150, BLOCK start
  %_366 = load ptr, ptr %4, align 8, !nonnull !2, !align !3, !noundef !2
; TARGET-LINE 151, BLOCK start
  %_367 = load ptr, ptr %_366, align 8, !nonnull !2, !align !392, !noundef !2
; TARGET-LINE 152, BLOCK start
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %mint, ptr noundef nonnull align 1 dereferenceable(32) %_367, i64 32, i1 false)
; TARGET-LINE 153, BLOCK start
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_9)
; TARGET-LINE 154, BLOCK start
  %5 = getelementptr inbounds i8, ptr %_247, i64 144
; TARGET-LINE 155, BLOCK start
  %_368 = load ptr, ptr %5, align 8, !nonnull !2, !align !3, !noundef !2
; TARGET-LINE 156, BLOCK start
  %_369 = load ptr, ptr %_368, align 8, !nonnull !2, !align !392, !noundef !2
; TARGET-LINE 157, BLOCK start
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_9, ptr noundef nonnull align 1 dereferenceable(32) %_369, i64 32, i1 false)
; TARGET-LINE 158, BLOCK start
  %6 = getelementptr inbounds i8, ptr %_247, i64 56
; TARGET-LINE 159, BLOCK start
  %_250 = load ptr, ptr %6, align 8, !nonnull !2, !align !3, !noundef !2
; TARGET-LINE 177, BLOCK bb2
  br label %bb6
; TARGET-LINE 178, BLOCK bb2

; TARGET-LINE 179, BLOCK bb6
bb6:                                              ; preds = %bb1, %start, %bb2
; TARGET-LINE 180, BLOCK bb6
  %shared.sroa.0.0.off0 = phi i1 [ %12, %bb2 ], [ false, %start ], [ false, %bb1 ]
; TARGET-LINE 181, BLOCK bb6
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %holder_key)
; TARGET-LINE 182, BLOCK bb6
  call void @llvm.lifetime.start.p0(i64 33, ptr nonnull %hk)
; TARGET-LINE 183, BLOCK bb6
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_18)
; TARGET-LINE 184, BLOCK bb6
  store ptr @alloc_df68464402562fbf659e5577c3ed192b, ptr %_18, align 8
; TARGET-LINE 185, BLOCK bb6
  %13 = getelementptr inbounds i8, ptr %_18, i64 8
; TARGET-LINE 186, BLOCK bb6
  store i64 14, ptr %13, align 8
; TARGET-LINE 187, BLOCK bb6
  %14 = getelementptr inbounds [2 x { ptr, i64 }], ptr %_18, i64 0, i64 1
; TARGET-LINE 188, BLOCK bb6
  store ptr %mint, ptr %14, align 8
; TARGET-LINE 189, BLOCK bb6
  %15 = getelementptr inbounds [2 x { ptr, i64 }], ptr %_18, i64 0, i64 1, i32 1
; TARGET-LINE 190, BLOCK bb6
  store i64 32, ptr %15, align 8
; TARGET-LINE 191, BLOCK bb6
; call solana_pubkey::Pubkey::find_program_address
; TARGET-LINE 192, BLOCK bb6
  call void @_ZN13solana_pubkey6Pubkey20find_program_address17h57945082f260e69dE(ptr noalias nocapture noundef nonnull sret([33 x i8]) align 1 dereferenceable(33) %hk, ptr noalias noundef nonnull readonly align 8 %_18, i64 noundef 2, ptr noalias noundef nonnull readonly align 1 dereferenceable(32) @_ZN14pump_recovered2ID17h8e245cf89cf2c06bE) #27
; TARGET-LINE 193, BLOCK bb6
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_18)
; TARGET-LINE 194, BLOCK bb6
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %holder_key, ptr noundef nonnull align 1 dereferenceable(32) %hk, i64 32, i1 false)
; TARGET-LINE 195, BLOCK bb6
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %q)
; TARGET-LINE 196, BLOCK bb6
  %_254 = load ptr, ptr %6, align 8, !nonnull !2, !align !3, !noundef !2
; TARGET-LINE 220, BLOCK bb12
  %quote_locked.sroa.0.0.off0 = phi i1 [ true, %bb6 ], [ true, %bb9 ], [ %23, %bb11 ]
; TARGET-LINE 221, BLOCK bb12
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %q)
; TARGET-LINE 222, BLOCK bb12
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %st)
; TARGET-LINE 223, BLOCK bb12
  %24 = getelementptr inbounds i8, ptr %_254, i64 8
; TARGET-LINE 224, BLOCK bb12
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %st, ptr noundef nonnull align 8 dereferenceable(32) %24, i64 32, i1 false)
; TARGET-LINE 225, BLOCK bb12
  %25 = getelementptr inbounds i8, ptr %_247, i64 8
; TARGET-LINE 239, BLOCK bb12
  %37 = getelementptr inbounds i8, ptr %st, i64 32
; TARGET-LINE 241, BLOCK bb12
  %38 = getelementptr inbounds i8, ptr %st, i64 40
; TARGET-LINE 243, BLOCK bb12
  %39 = getelementptr inbounds i8, ptr %st, i64 41
; TARGET-LINE 245, BLOCK bb12
  %40 = getelementptr inbounds i8, ptr %st, i64 42
; TARGET-LINE 247, BLOCK bb12
  %41 = getelementptr inbounds i8, ptr %st, i64 43
; TARGET-LINE 250, BLOCK bb12
  %43 = getelementptr inbounds i8, ptr %st, i64 44
; TARGET-LINE 252, BLOCK bb12
  %44 = getelementptr inbounds i8, ptr %st, i64 45
; TARGET-LINE 258, BLOCK bb12
  call void @llvm.lifetime.start.p0(i64 45, ptr nonnull %_41.sroa.14)
; TARGET-LINE 259, BLOCK bb12
  call void @llvm.lifetime.start.p0(i64 45, ptr nonnull %_42.sroa.44)
; TARGET-LINE 262, BLOCK bb12
  call void @llvm.lifetime.start.p0(i64 13, ptr nonnull %_166.sroa.6.i.sroa.6)
; TARGET-LINE 462, BLOCK bb23.i
bb23.i:                                           ; preds = %bb14.i
; TARGET-LINE 463, BLOCK bb23.i
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %target.i)
; TARGET-LINE 464, BLOCK bb23.i
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %t.i), !noalias !5562
; TARGET-LINE 465, BLOCK bb23.i
  %82 = load i8, ptr %new, align 1, !range !394, !alias.scope !5557, !noalias !5581, !noundef !2
; TARGET-LINE 466, BLOCK bb23.i
  %trunc.not.not.i = icmp eq i8 %82, 0
; TARGET-LINE 467, BLOCK bb23.i
  br i1 %trunc.not.not.i, label %bb27.i, label %bb28.i
; TARGET-LINE 468, BLOCK bb23.i

; TARGET-LINE 469, BLOCK bb22.i
bb22.i:                                           ; preds = %bb16.i, %bb7.i
; TARGET-LINE 470, BLOCK bb22.i
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %target.i)
; TARGET-LINE 471, BLOCK bb22.i
  %83 = load i8, ptr %new, align 1, !range !394, !alias.scope !5557, !noalias !5581, !noundef !2
; TARGET-LINE 472, BLOCK bb22.i
  %trunc15.not.not.i = icmp eq i8 %83, 0
; TARGET-LINE 473, BLOCK bb22.i
  br i1 %trunc15.not.not.i, label %bb47.i, label %bb90.i
; TARGET-LINE 474, BLOCK bb22.i

; TARGET-LINE 475, BLOCK bb28.i
bb28.i:                                           ; preds = %bb23.i
; TARGET-LINE 476, BLOCK bb28.i
  %84 = getelementptr inbounds i8, ptr %new, i64 1
; TARGET-LINE 477, BLOCK bb28.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %t.i, ptr noundef nonnull align 1 dereferenceable(32) %84, i64 32, i1 false), !noalias !5581
; TARGET-LINE 478, BLOCK bb28.i
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_65.i), !noalias !5562
; TARGET-LINE 479, BLOCK bb28.i
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_65.i, i8 0, i64 32, i1 false), !noalias !5562
; TARGET-LINE 480, BLOCK bb28.i
  %85 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %t.i, ptr noundef nonnull dereferenceable(32) %_65.i, i64 32), !noalias !5562
; TARGET-LINE 481, BLOCK bb28.i
  %86 = icmp eq i32 %85, 0
; TARGET-LINE 482, BLOCK bb28.i
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_65.i), !noalias !5562
; TARGET-LINE 483, BLOCK bb28.i
  br i1 %86, label %bb32.i, label %bb37.i
; TARGET-LINE 484, BLOCK bb28.i

; TARGET-LINE 620, BLOCK bb38.i
  %115 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %t.i, ptr noundef nonnull dereferenceable(32) %holder_key, i64 32), !noalias !5593
; TARGET-LINE 684, BLOCK bb43.i
bb43.i:                                           ; preds = %bb38.i
; TARGET-LINE 685, BLOCK bb43.i
  %switch20.i = icmp eq i64 %1, 0
; TARGET-LINE 686, BLOCK bb43.i
  %extract.t17.i = icmp ne i8 %32, 0
; TARGET-LINE 687, BLOCK bb43.i
  br i1 %shared.sroa.0.0.off0, label %bb48.i, label %bb48.thread.i
; TARGET-LINE 688, BLOCK bb43.i

; TARGET-LINE 689, BLOCK bb48.i
bb48.i:                                           ; preds = %bb43.i
; TARGET-LINE 690, BLOCK bb48.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %target.i, ptr noundef nonnull align 8 dereferenceable(32) %24, i64 32, i1 false)
; TARGET-LINE 691, BLOCK bb48.i
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %t.i), !noalias !5562
; TARGET-LINE 692, BLOCK bb48.i
  br i1 %switch20.i, label %bb76.i, label %bb50.i
; TARGET-LINE 693, BLOCK bb48.i

; TARGET-LINE 694, BLOCK bb48.thread.i
bb48.thread.i:                                    ; preds = %bb43.i
; TARGET-LINE 695, BLOCK bb48.thread.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %target.i, ptr noundef nonnull align 1 dereferenceable(32) %84, i64 32, i1 false), !noalias !5581
; TARGET-LINE 696, BLOCK bb48.thread.i
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %t.i), !noalias !5562
; TARGET-LINE 697, BLOCK bb48.thread.i
  br i1 %switch20.i, label %bb78.i, label %bb50.i
; TARGET-LINE 698, BLOCK bb48.thread.i

; TARGET-LINE 699, BLOCK bb47.i
bb47.i:                                           ; preds = %bb22.i
; TARGET-LINE 700, BLOCK bb47.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %target.i, ptr noundef nonnull align 1 dereferenceable(32) %hk, i64 32, i1 false)
; TARGET-LINE 701, BLOCK bb47.i
  %switch21.i = icmp eq i64 %1, 0
; TARGET-LINE 702, BLOCK bb47.i
  br i1 %switch21.i, label %bb73.thread76.i, label %bb108.i
; TARGET-LINE 703, BLOCK bb47.i

; TARGET-LINE 704, BLOCK bb73.i
bb73.i:                                           ; preds = %bb65.i
; TARGET-LINE 705, BLOCK bb73.i
  %129 = load volatile i8, ptr %holder_key, align 1, !alias.scope !5560, !noalias !5593
; TARGET-LINE 706, BLOCK bb73.i
  br i1 %shared.sroa.0.0.off0, label %bb74.i, label %bb77.i
; TARGET-LINE 707, BLOCK bb73.i

; TARGET-LINE 708, BLOCK bb73.thread76.i
bb73.thread76.i:                                  ; preds = %bb47.i
; TARGET-LINE 709, BLOCK bb73.thread76.i
  br i1 %shared.sroa.0.0.off0, label %bb64, label %bb77.i
; TARGET-LINE 710, BLOCK bb73.thread76.i

; TARGET-LINE 711, BLOCK bb50.i
bb50.i:                                           ; preds = %bb48.thread.i, %bb48.i
; TARGET-LINE 712, BLOCK bb50.i
  br i1 %quote_locked.sroa.0.0.off0, label %bb51.i, label %bb55.i
; TARGET-LINE 713, BLOCK bb50.i

; TARGET-LINE 714, BLOCK bb55.i
bb55.i:                                           ; preds = %bb50.i
; TARGET-LINE 715, BLOCK bb55.i
  %.not84.i = icmp eq i8 %32, 0
; TARGET-LINE 716, BLOCK bb55.i
  br i1 %.not84.i, label %bb57.i, label %bb56.i
; TARGET-LINE 775, BLOCK bb57.i
bb57.i:                                           ; preds = %bb108.i, %bb55.i
; TARGET-LINE 776, BLOCK bb57.i
  %_145.sroa.0.0.copyload90.i = phi i32 [ 1, %bb55.i ], [ 0, %bb108.i ]
; TARGET-LINE 777, BLOCK bb57.i
  %cashback.sroa.0.1.off0.i = phi i1 [ %extract.t17.i, %bb55.i ], [ false, %bb108.i ]
; TARGET-LINE 778, BLOCK bb57.i
  %142 = load volatile i8, ptr %holder_key, align 1, !alias.scope !5560, !noalias !5593
; TARGET-LINE 779, BLOCK bb57.i
  %_116.not.i = icmp eq i8 %36, 0
; TARGET-LINE 780, BLOCK bb57.i
  br i1 %_116.not.i, label %bb61.i, label %bb65.i
; TARGET-LINE 781, BLOCK bb57.i

; TARGET-LINE 813, BLOCK bb84.i
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %target.i)
; TARGET-LINE 932, BLOCK bb77.i
bb77.i:                                           ; preds = %bb73.thread76.i, %bb73.i
; TARGET-LINE 933, BLOCK bb77.i
  %cashback.sroa.0.0.off069.i = phi i1 [ %cashback.sroa.0.1.off0.i, %bb73.i ], [ false, %bb73.thread76.i ]
; TARGET-LINE 934, BLOCK bb77.i
  br i1 %_20.not.i, label %bb78.i, label %bb64
; TARGET-LINE 935, BLOCK bb77.i

; TARGET-LINE 936, BLOCK bb74.i
bb74.i:                                           ; preds = %bb73.i
; TARGET-LINE 937, BLOCK bb74.i
  br i1 %_0.sroa.0.0.off0.i.i.not, label %bb76.i, label %bb64
; TARGET-LINE 938, BLOCK bb74.i

; TARGET-LINE 939, BLOCK bb78.i
bb78.i:                                           ; preds = %bb77.i, %bb48.thread.i
; TARGET-LINE 940, BLOCK bb78.i
  %cashback.sroa.0.0.off06973.i = phi i1 [ %cashback.sroa.0.0.off069.i, %bb77.i ], [ %extract.t17.i, %bb48.thread.i ]
; TARGET-LINE 941, BLOCK bb78.i
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_147.i), !noalias !5562
; TARGET-LINE 942, BLOCK bb78.i
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_147.i, i8 0, i64 32, i1 false), !noalias !5562
; TARGET-LINE 943, BLOCK bb78.i
  %171 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %st, ptr noundef nonnull dereferenceable(32) %_147.i, i64 32), !noalias !5610
; TARGET-LINE 944, BLOCK bb78.i
  %172 = icmp ne i32 %171, 0
; TARGET-LINE 945, BLOCK bb78.i
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_147.i), !noalias !5562
; TARGET-LINE 946, BLOCK bb78.i
  br label %bb64
; TARGET-LINE 947, BLOCK bb78.i

; TARGET-LINE 948, BLOCK bb76.i
bb76.i:                                           ; preds = %bb74.i, %bb48.i
; TARGET-LINE 949, BLOCK bb76.i
  %_145.sroa.0.0.copyload.i = phi i32 [ %_145.sroa.0.0.copyload90.i, %bb74.i ], [ 1, %bb48.i ]
; TARGET-LINE 950, BLOCK bb76.i
  %cashback.sroa.0.0.off07075.i = phi i1 [ %cashback.sroa.0.1.off0.i, %bb74.i ], [ %extract.t17.i, %bb48.i ]
; TARGET-LINE 951, BLOCK bb76.i
  %_145.sroa.4.0.new.sroa_idx.i = getelementptr inbounds i8, ptr %new, i64 1
; TARGET-LINE 952, BLOCK bb76.i
  %_166.sroa.6.i.sroa.0.0.copyload = load i24, ptr %_145.sroa.4.0.new.sroa_idx.i, align 1, !noalias !5581
; TARGET-LINE 953, BLOCK bb76.i
  %_166.sroa.6.i.sroa.4.0._145.sroa.4.0.new.sroa_idx.i.sroa_idx = getelementptr inbounds i8, ptr %new, i64 4
; TARGET-LINE 954, BLOCK bb76.i
  %_166.sroa.6.i.sroa.4.0.copyload = load i64, ptr %_166.sroa.6.i.sroa.4.0._145.sroa.4.0.new.sroa_idx.i.sroa_idx, align 1, !noalias !5581
; TARGET-LINE 955, BLOCK bb76.i
  %_166.sroa.6.i.sroa.5.0._145.sroa.4.0.new.sroa_idx.i.sroa_idx = getelementptr inbounds i8, ptr %new, i64 12
; TARGET-LINE 956, BLOCK bb76.i
  %_166.sroa.6.i.sroa.5.0.copyload = load ptr, ptr %_166.sroa.6.i.sroa.5.0._145.sroa.4.0.new.sroa_idx.i.sroa_idx, align 1, !noalias !5581
; TARGET-LINE 957, BLOCK bb76.i
  %_166.sroa.6.i.sroa.6.0._145.sroa.4.0.new.sroa_idx.i.sroa_idx = getelementptr inbounds i8, ptr %new, i64 20
; TARGET-LINE 958, BLOCK bb76.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(13) %_166.sroa.6.i.sroa.6, ptr noundef nonnull align 1 dereferenceable(13) %_166.sroa.6.i.sroa.6.0._145.sroa.4.0.new.sroa_idx.i.sroa_idx, i64 13, i1 false), !noalias !5581
; TARGET-LINE 959, BLOCK bb76.i
  br label %bb64
; TARGET-LINE 960, BLOCK bb76.i

; TARGET-LINE 961, BLOCK bb64
bb64:                                             ; preds = %bb76.i, %bb78.i, %bb74.i, %bb77.i, %bb73.thread76.i
; TARGET-LINE 962, BLOCK bb64
  %_166.sroa.6.i.sroa.0.0 = phi i24 [ undef, %bb73.thread76.i ], [ undef, %bb78.i ], [ undef, %bb77.i ], [ undef, %bb74.i ], [ %_166.sroa.6.i.sroa.0.0.copyload, %bb76.i ]
; TARGET-LINE 963, BLOCK bb64
  %_166.sroa.6.i.sroa.4.0 = phi i64 [ undef, %bb73.thread76.i ], [ undef, %bb78.i ], [ undef, %bb77.i ], [ undef, %bb74.i ], [ %_166.sroa.6.i.sroa.4.0.copyload, %bb76.i ]
; TARGET-LINE 964, BLOCK bb64
  %_166.sroa.6.i.sroa.5.0 = phi ptr [ undef, %bb73.thread76.i ], [ undef, %bb78.i ], [ undef, %bb77.i ], [ undef, %bb74.i ], [ %_166.sroa.6.i.sroa.5.0.copyload, %bb76.i ]
; TARGET-LINE 965, BLOCK bb64
  %cashback.sroa.0.0.off068.i = phi i1 [ false, %bb73.thread76.i ], [ %cashback.sroa.0.0.off06973.i, %bb78.i ], [ %cashback.sroa.0.0.off069.i, %bb77.i ], [ %cashback.sroa.0.1.off0.i, %bb74.i ], [ %cashback.sroa.0.0.off07075.i, %bb76.i ]
; TARGET-LINE 966, BLOCK bb64
  %_165.sroa.0.0.off0.i = phi i1 [ false, %bb73.thread76.i ], [ %172, %bb78.i ], [ false, %bb77.i ], [ false, %bb74.i ], [ false, %bb76.i ]
; TARGET-LINE 967, BLOCK bb64
  %_166.sroa.0.0.i = phi i32 [ 0, %bb73.thread76.i ], [ 2, %bb78.i ], [ 2, %bb77.i ], [ 0, %bb74.i ], [ %_145.sroa.0.0.copyload.i, %bb76.i ]
; TARGET-LINE 968, BLOCK bb64
  %_167.sroa.0.0.off0.i = phi i1 [ true, %bb73.thread76.i ], [ false, %bb78.i ], [ false, %bb77.i ], [ true, %bb74.i ], [ false, %bb76.i ]
; TARGET-LINE 969, BLOCK bb64
  %_42.sroa.44.37.sroa_idx = getelementptr inbounds i8, ptr %_42.sroa.44, i64 13
; TARGET-LINE 970, BLOCK bb64
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_42.sroa.44.37.sroa_idx, ptr noundef nonnull align 1 dereferenceable(32) %target.i, i64 32, i1 false), !noalias !5611
; TARGET-LINE 971, BLOCK bb64
  %173 = zext i1 %cashback.sroa.0.0.off068.i to i8
; TARGET-LINE 972, BLOCK bb64
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(13) %_42.sroa.44, ptr noundef nonnull align 1 dereferenceable(13) %_166.sroa.6.i.sroa.6, i64 13, i1 false), !noalias !5611
; TARGET-LINE 973, BLOCK bb64
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %target.i)
; TARGET-LINE 974, BLOCK bb64
  call void @llvm.lifetime.end.p0(i64 13, ptr nonnull %_166.sroa.6.i.sroa.6)
; TARGET-LINE 975, BLOCK bb64
  %_42.sroa.19.sroa.5.0.insert.ext = zext i24 %_166.sroa.6.i.sroa.0.0 to i32
; TARGET-LINE 976, BLOCK bb64
  %_42.sroa.19.sroa.5.0.insert.shift = shl nuw i32 %_42.sroa.19.sroa.5.0.insert.ext, 8
; TARGET-LINE 977, BLOCK bb64
  %_42.sroa.19.sroa.0.0.insert.insert = or disjoint i32 %_166.sroa.0.0.i, %_42.sroa.19.sroa.5.0.insert.shift
; TARGET-LINE 978, BLOCK bb64
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(45) %_41.sroa.14, ptr noundef nonnull align 8 dereferenceable(45) %_42.sroa.44, i64 45, i1 false)
; TARGET-LINE 979, BLOCK bb64
  call void @llvm.lifetime.end.p0(i64 45, ptr nonnull %_42.sroa.44)
; TARGET-LINE 980, BLOCK bb64
  %_41.sroa.14.37.sroa_idx = getelementptr inbounds i8, ptr %_41.sroa.14, i64 13
; TARGET-LINE 981, BLOCK bb64
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %target11, ptr noundef nonnull align 1 dereferenceable(32) %_41.sroa.14.37.sroa_idx, i64 32, i1 false)
; TARGET-LINE 982, BLOCK bb64
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(13) %sharing_update12.sroa.5, ptr noundef nonnull align 8 dereferenceable(13) %_41.sroa.14, i64 13, i1 false)
; TARGET-LINE 983, BLOCK bb64
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %sk)
; TARGET-LINE 984, BLOCK bb64
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %st)
; TARGET-LINE 985, BLOCK bb64
  call void @llvm.lifetime.end.p0(i64 45, ptr nonnull %_41.sroa.14)
; TARGET-LINE 986, BLOCK bb64
  %_54 = getelementptr inbounds i8, ptr %_247, i64 48
; TARGET-LINE 987, BLOCK bb64
; call pump_recovered::extend::prepare_bonding_curve
; TARGET-LINE 988, BLOCK bb64
  %174 = call { i64, ptr } @_ZN14pump_recovered6extend21prepare_bonding_curve17hd9c6422a7455e9efE(ptr noalias noundef nonnull readonly align 8 dereferenceable(168) %_254, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %_54, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %_247) #27
; TARGET-LINE 989, BLOCK bb64
  %175 = extractvalue { i64, ptr } %174, 0
; TARGET-LINE 997, BLOCK bb63
  call void @llvm.lifetime.end.p0(i64 13, ptr nonnull %_166.sroa.6.i.sroa.6)
; TARGET-LINE 998, BLOCK bb63
  call void @llvm.lifetime.end.p0(i64 45, ptr nonnull %_42.sroa.44)
; TARGET-LINE 1000, BLOCK bb63
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %st)
; TARGET-LINE 1001, BLOCK bb63
  call void @llvm.lifetime.end.p0(i64 45, ptr nonnull %_41.sroa.14)
; TARGET-LINE 1779, BLOCK bb70
  store ptr %holder_key, ptr %331, align 8, !noalias !5641
; TARGET-LINE 3034, BLOCK bb75
  %_92 = load i8, ptr %574, align 1, !noundef !2
; TARGET-LINE 3035, BLOCK bb75
  store i8 %_92, ptr %_91, align 1
; TARGET-LINE 3036, BLOCK bb75
  store ptr @alloc_837d2dfc2ca6132d7e624d246f381ca4, ptr %_86, align 8
; TARGET-LINE 3037, BLOCK bb75
  %575 = getelementptr inbounds i8, ptr %_86, i64 8
; TARGET-LINE 3038, BLOCK bb75
  store i64 14, ptr %575, align 8
; TARGET-LINE 3039, BLOCK bb75
  %576 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_86, i64 0, i64 1
; TARGET-LINE 3040, BLOCK bb75
  store ptr %mint, ptr %576, align 8
; TARGET-LINE 3041, BLOCK bb75
  %577 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_86, i64 0, i64 1, i32 1
; TARGET-LINE 3042, BLOCK bb75
  store i64 32, ptr %577, align 8
; TARGET-LINE 3043, BLOCK bb75
  %578 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_86, i64 0, i64 2
; TARGET-LINE 3044, BLOCK bb75
  store ptr %_91, ptr %578, align 8
; TARGET-LINE 3045, BLOCK bb75
  %579 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_86, i64 0, i64 2, i32 1
; TARGET-LINE 3046, BLOCK bb75
  store i64 1, ptr %579, align 8
; TARGET-LINE 3047, BLOCK bb75
  store ptr %_86, ptr %_83, align 8
; TARGET-LINE 3048, BLOCK bb75
  %580 = getelementptr inbounds i8, ptr %_83, i64 8
; TARGET-LINE 3049, BLOCK bb75
  store i64 3, ptr %580, align 8
; TARGET-LINE 3050, BLOCK bb75
  %581 = icmp ne i32 %_166.sroa.0.0.i, 2
; TARGET-LINE 3051, BLOCK bb75
  br i1 %581, label %bb24, label %bb26
; TARGET-LINE 3052, BLOCK bb75

; TARGET-LINE 3053, BLOCK bb74
bb74:                                             ; preds = %_ZN14pump_recovered9admin_cto7execute5sweep17h9943ff4781c7e018E.exit
; TARGET-LINE 3054, BLOCK bb74
  %582 = inttoptr i64 %_397.sroa.18.3 to ptr
; TARGET-LINE 3055, BLOCK bb74
  br label %bb55
; TARGET-LINE 3056, BLOCK bb74

; TARGET-LINE 3057, BLOCK bb26
bb26:                                             ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit262, %bb75
; TARGET-LINE 3058, BLOCK bb26
  %_308 = load ptr, ptr %6, align 8, !nonnull !2, !align !3, !noundef !2
; TARGET-LINE 3059, BLOCK bb26
  %583 = getelementptr inbounds i8, ptr %_308, i64 8
; TARGET-LINE 3060, BLOCK bb26
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %old_creator, ptr noundef nonnull align 8 dereferenceable(32) %583, i64 32, i1 false)
; TARGET-LINE 3061, BLOCK bb26
  %584 = getelementptr inbounds i8, ptr %_308, i64 112
; TARGET-LINE 3062, BLOCK bb26
  %old_fee = load i64, ptr %584, align 8, !noundef !2
; TARGET-LINE 3063, BLOCK bb26
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %583, ptr noundef nonnull align 1 dereferenceable(32) %target11, i64 32, i1 false)
; TARGET-LINE 3064, BLOCK bb26
  %585 = and i8 %0, 1
; TARGET-LINE 3065, BLOCK bb26
  %_311 = load ptr, ptr %6, align 8, !nonnull !2, !align !3, !noundef !2
; TARGET-LINE 3066, BLOCK bb26
  %586 = getelementptr inbounds i8, ptr %_311, i64 165
; TARGET-LINE 3067, BLOCK bb26
  store i8 %585, ptr %586, align 1
; TARGET-LINE 3068, BLOCK bb26
  %_312 = load ptr, ptr %6, align 8, !nonnull !2, !align !3, !noundef !2
; TARGET-LINE 3069, BLOCK bb26
  %587 = getelementptr inbounds i8, ptr %_312, i64 163
; TARGET-LINE 3070, BLOCK bb26
  store i8 %173, ptr %587, align 1
; TARGET-LINE 3071, BLOCK bb26
  %switch66 = icmp eq i64 %1, 1
; TARGET-LINE 3072, BLOCK bb26
  br i1 %switch66, label %bb27, label %bb28
; TARGET-LINE 3073, BLOCK bb26

; TARGET-LINE 3074, BLOCK bb24
bb24:                                             ; preds = %bb75
; TARGET-LINE 3075, BLOCK bb24
  store i32 %_42.sroa.19.sroa.0.0.insert.insert, ptr %val4, align 4
; TARGET-LINE 3076, BLOCK bb24
  %sharing_update12.sroa.3.0.val4.sroa_idx = getelementptr inbounds i8, ptr %val4, i64 4
; TARGET-LINE 3077, BLOCK bb24
  store i64 %_166.sroa.6.i.sroa.4.0, ptr %sharing_update12.sroa.3.0.val4.sroa_idx, align 4
; TARGET-LINE 3078, BLOCK bb24
  %sharing_update12.sroa.4.0.val4.sroa_idx = getelementptr inbounds i8, ptr %val4, i64 12
; TARGET-LINE 3079, BLOCK bb24
  store ptr %_166.sroa.6.i.sroa.5.0, ptr %sharing_update12.sroa.4.0.val4.sroa_idx, align 4
; TARGET-LINE 3080, BLOCK bb24
  %sharing_update12.sroa.5.0.val4.sroa_idx = getelementptr inbounds i8, ptr %val4, i64 20
; TARGET-LINE 3081, BLOCK bb24
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(13) %sharing_update12.sroa.5.0.val4.sroa_idx, ptr noundef nonnull align 1 dereferenceable(13) %sharing_update12.sroa.5, i64 13, i1 false)
; TARGET-LINE 3082, BLOCK bb24
  call void @llvm.lifetime.start.p0(i64 424, ptr nonnull %_97)
; TARGET-LINE 3083, BLOCK bb24
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_98.sroa.11)
; TARGET-LINE 3568, BLOCK _ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit262
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_98.sroa.11)
; TARGET-LINE 3569, BLOCK _ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit262
; call pump_recovered::pump_fees::cpi::admin_cto_sharing_config
; TARGET-LINE 3570, BLOCK _ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit262
  %675 = call { i64, ptr } @_ZN14pump_recovered9pump_fees3cpi24admin_cto_sharing_config17hb339d2894fd16ae6E(ptr noalias nocapture noundef nonnull align 8 dereferenceable(424) %_97, ptr noalias nocapture noundef nonnull readonly align 1 dereferenceable(33) %val4) #27
; TARGET-LINE 3571, BLOCK _ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit262
  %676 = extractvalue { i64, ptr } %675, 0
; TARGET-LINE 3572, BLOCK _ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit262
  call void @llvm.lifetime.end.p0(i64 424, ptr nonnull %_97)
; TARGET-LINE 3573, BLOCK _ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit262
  %677 = icmp eq i64 %676, 2
; TARGET-LINE 3574, BLOCK _ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit262
  br i1 %677, label %bb26, label %bb53
; TARGET-LINE 3659, BLOCK bb32
  store i64 1, ptr %702, align 8
; TARGET-LINE 3660, BLOCK bb32
  call void @llvm.lifetime.end.p0(i64 336, ptr nonnull %_177)
; TARGET-LINE 3661, BLOCK bb32
; call pump_recovered::pump_amm::cpi::admin_cto_pool
; TARGET-LINE 3662, BLOCK bb32
  %703 = call { i64, ptr } @_ZN14pump_recovered8pump_amm3cpi14admin_cto_pool17h6db7cfeb87b39219E(ptr noalias nocapture noundef nonnull align 8 dereferenceable(424) %_175, ptr noalias nocapture noundef nonnull readonly align 1 dereferenceable(32) %target11, i1 noundef zeroext %688, i64 noundef %1, i64 %2) #27
; TARGET-LINE 3663, BLOCK bb32
  %704 = extractvalue { i64, ptr } %703, 0
; TARGET-LINE 3664, BLOCK bb32
  call void @llvm.lifetime.end.p0(i64 424, ptr nonnull %_175)
; TARGET-LINE 3665, BLOCK bb32
  %705 = icmp eq i64 %704, 2
; TARGET-LINE 3666, BLOCK bb32
  br i1 %705, label %bb35, label %bb53
; TARGET-LINE 3894, BLOCK "_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit"
  call void @llvm.lifetime.end.p0(i64 33, ptr nonnull %hk)
; TARGET-LINE 3895, BLOCK "_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit"
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %holder_key)
; TARGET-LINE 3994, BLOCK bb55
  call void @llvm.lifetime.end.p0(i64 33, ptr nonnull %hk)
; TARGET-LINE 3995, BLOCK bb55
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %holder_key)
