#!/usr/bin/env python3
"""Read-only, standard-library sealing of the admitted optimized S3 SSA joins."""
import os, sys
sys.dont_write_bytecode = True
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
from pathlib import Path
import hashlib, json, re

HERE=Path(__file__).resolve().parent
DIAG=Path('/dev/shm/pump-cto-settings-s3-ir/work/ir-run')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
reviewp=DIAG/'independent-admission/REVIEW.json'
assert sha(reviewp)=='d34ab69789b49db30bc5ae206c53d5716453d692ff05a3b4d858a79d36aa5164'
review=json.loads(reviewp.read_text())
modulep=DIAG/'artifact/llvm-ir/pump_recovered.ll'
module=modulep.read_bytes()
assert hashlib.sha256(module).hexdigest()=='279dbcf5e79d749bb455bbc27b69374291164b0347c37242b65ee82892cd6b4e'
info=review['capture']['optimizedTargets'][0]
raw=module[info['rawModuleStart']:info['rawModuleEnd']]
assert hashlib.sha256(raw).hexdigest()=='53425fc17c3bea0a0344b03ce66a573862840795c1d7ff5367768411f6d7d5f0'
assert raw==(HERE/'optimized-target.ll').read_bytes()
lines=raw.decode().splitlines()
modlines=module.decode().splitlines()
blocks={}; defs={}; current=None
for n,line in enumerate(lines,1):
    m=re.match(r'^(".*?"|[-\w.$]+):',line)
    if m: current=m.group(1)
    blocks[n]=current
    m=re.match(r'\s*(%[-\w.$]+) = (.*)',line)
    if m: defs[m.group(1)]=(n,m.group(2))
def row(n): return dict(line=n,block=blocks[n],text=lines[n-1])
def definition(name): return row(defs[name][0])
def contains(text):
    found=[n for n,l in enumerate(lines,1) if text in l]
    assert len(found)==1,(text,found)
    return row(found[0])
allocas={}
for name,(n,d) in defs.items():
    m=re.fullmatch(r'alloca \[(\d+) x i8\], align (\d+)',d)
    if m: allocas[name]=dict(bytes=int(m.group(1)),align=int(m.group(2)),definition=row(n))
def root(name):
    if name in defs:
        m=re.fullmatch(r'getelementptr inbounds i8, ptr (%[-\w.$]+), i64 (-?\d+)',defs[name][1])
        if m:
            r,o=root(m.group(1));return r,o+int(m.group(2))
    return name,0
def pointer_arg(arg):
    m=re.search(r'(%[-\w.$]+)\s*$',arg);assert m,arg
    return m.group(1)
copies=[]
for n,line in enumerate(lines,1):
    if '@llvm.memcpy.p0.p0.i64(' not in line: continue
    args=line.split('@llvm.memcpy.p0.p0.i64(',1)[1].rsplit(')',1)[0].split(', ')
    assert len(args)==4,args
    dst,src=pointer_arg(args[0]),pointer_arg(args[1]);length=int(args[2].split()[-1])
    dr,do=root(dst);sr,so=root(src)
    copies.append(dict(**row(n),dst=dst,src=src,length=length,destination=dict(root=dr,interval=[do,do+length]),source=dict(root=sr,interval=[so,so+length]),
      destination_alignment=int(re.search(r'\balign (\d+)',args[0]).group(1)) if 'align ' in args[0] else None,
      source_alignment=int(re.search(r'\balign (\d+)',args[1]).group(1)) if 'align ' in args[1] else None,address_space=0))
def onecopy(dst,src,length):
    xs=[x for x in copies if x['dst']==dst and x['src']==src and x['length']==length];assert len(xs)==1,(dst,src,length);return xs[0]
def writes_to(name): return [x for x in copies if x['destination']['root']==name]
def refs(name):
    pat=re.compile(re.escape(name)+r'(?![-\w.$])')
    return [row(n) for n,l in enumerate(lines,1) if pat.search(l)]

src45='%_42.sroa.44'; dst45='%_41.sroa.14'; n13='%_166.sroa.6.i.sroa.6'; n13out='%sharing_update12.sroa.5'
target='%target.i'; targetout='%target11'
for name,size,align in [(src45,45,8),(dst45,45,8),(n13,13,1),(n13out,13,1),(target,32,1),(targetout,32,1),('%val4',33,4)]:
    assert allocas[name]['bytes']==size and allocas[name]['align']==align
assert root('%_42.sroa.44.37.sroa_idx')==(src45,13)
assert root('%_41.sroa.14.37.sroa_idx')==(dst45,13)
assert root('%_166.sroa.6.i.sroa.6.0._145.sroa.4.0.new.sroa_idx.i.sroa_idx')==('%new',20)
assert root('%24')==('%_254',8) and root('%84')==('%new',1)
copy_n=onecopy(n13,'%_166.sroa.6.i.sroa.6.0._145.sroa.4.0.new.sroa_idx.i.sroa_idx',13)
copy_n_in=onecopy(src45,n13,13)
copy_t_in=onecopy('%_42.sroa.44.37.sroa_idx',target,32)
copy45=onecopy(dst45,src45,45)
copy_t_out=onecopy(targetout,'%_41.sroa.14.37.sroa_idx',32)
copy_n_out=onecopy(n13out,dst45,13)
copy_n_val=onecopy('%sharing_update12.sroa.5.0.val4.sroa_idx',n13out,13)
assert copy_n_val['destination']==dict(root='%val4',interval=[20,33])
assert len(writes_to(n13))==1 and len(writes_to(n13out))==1 and len(writes_to(targetout))==1
assert len(writes_to(src45))==2 and len(writes_to(dst45))==1
target_writes=writes_to(target)
assert {(x['block'],x['src']) for x in target_writes}=={('bb48.i','%24'),('bb48.thread.i','%84'),('bb47.i','%hk')}
assert all(x['length']==32 and x['destination']['interval']==[0,32] for x in target_writes)
curve=onecopy('%583',targetout,32)
assert root('%583')==('%_308',8)
pool=contains('%703 = call { i64, ptr } @_ZN14pump_recovered8pump_amm3cpi14admin_cto_pool')
fees=contains('%675 = call { i64, ptr } @_ZN14pump_recovered9pump_fees3cpi24admin_cto_sharing_config')
assert '%target11' in pool['text'] and '%val4' in fees['text']
assert 'readonly align 1 dereferenceable(32) %target11' in pool['text']
assert 'readonly align 1 dereferenceable(33) %val4' in fees['text']

objects=[src45,dst45,n13,n13out,target,targetout,'%val4','%hk','%holder_key','%st']
relevant=[]
for name in objects: relevant.extend(x['line'] for x in refs(name))
for lo,hi in [(145,159),(177,196),(220,225),(462,484),(684,716),(775,781),(932,989),(3034,3083),(3568,3574),(3659,3666)]:relevant.extend(range(lo,hi+1))
relevant=sorted(set(relevant))
evidence='; Bounded excerpts from admitted optimized S3 execute; numbered ORIGINAL target lines.\n'
for n in relevant:evidence+=f'; TARGET-LINE {n}, BLOCK {blocks[n]}\n{lines[n-1]}\n'
(HERE/'EVIDENCE-EXCERPTS.ll').write_text(evidence)
used_metadata=set()
for n in relevant:used_metadata.update(re.findall(r'!(\d+)\b',lines[n-1]))
md={}
for line in modlines:
    m=re.match(r'^!(\d+) = (.*)$',line)
    if m:md[m.group(1)]=line
todo=list(used_metadata); closure={}
while todo:
    key=todo.pop()
    if key in closure or key not in md:continue
    closure[key]=md[key];todo.extend(re.findall(r'!(\d+)\b',md[key].split(' = ',1)[1]))
datalayout=next(l for l in modlines if l.startswith('target datalayout'))
triple=next(l for l in modlines if l.startswith('target triple'))
assert datalayout=='target datalayout = "e-m:e-p:64:64-i64:64-n32:64-S128"'
metadata=dict(datalayout=datalayout,triple=triple,relevant_type_definitions=[l for l in modlines[:100] if l.startswith('%"solana_pubkey::Pubkey"')],metadata_closure=[closure[k] for k in sorted(closure,key=int)],
    attributes=[l for l in modlines if re.match(r'^attributes #(1|27) = ',l)],
    interpretation_limit='Actual lifetime/alias metadata is retained, not interpreted as an original Rust source lifetime or type theorem.')
(HERE/'SSA-METADATA.json').write_text(json.dumps(metadata,indent=2)+'\n')

payload_phis=[definition(x) for x in ['%_166.sroa.6.i.sroa.0.0','%_166.sroa.6.i.sroa.4.0','%_166.sroa.6.i.sroa.5.0','%_166.sroa.0.0.i','%_145.sroa.0.0.copyload.i','%_145.sroa.0.0.copyload90.i']]
tag_gate=definition('%581')
result=dict(status='PROVED_BOUNDED_OPTIMIZED_SSA_FAMILIES',source=review['source'],run=review['run'],review_sha256=sha(reviewp),module_sha256=sha(modulep),target_sha256=hashlib.sha256(raw).hexdigest(),
    coordinates='All line numbers refer to the313382-byte optimized execute definition extracted at module byte range2785093..3098475. SSA/GEP coordinates are independent of native FP slots and machine SlotIndexes.',
    data_layout=datalayout,gep_offset_rule='All value-bearing interval joins in this receipt use actual getelementptr i8 literal offsets, stride1. Pointer-typed transported scalars occupy8 bytes under the admitted64-bit pointer DataLayout; they are not treated as dereferenceable resource pointers.',
    objects={name:allocas[name] for name in objects},
    N13=dict(source_interval=dict(root='%new',interval=[20,33],payload_relative_interval=[19,32]),parameter=lines[0],producer=copy_n,producer_block='bb76.i',input_to_source45=copy_n_in,
      through45=copy45,output_from45=copy_n_out,to_Option33=copy_n_val,fees_true_call=fees,
      siblings_and_tag_phis=payload_phis,outer_gate=tag_gate,
      qualifying_control='bb76.i is reached from bb48.i (shared nonholder, feeNone) or from bb74.i after valid feeSome when the actual nonholder predicate is true. Only that block writes the13-byte payload alloca. Other reset/skip predecessors have undef scalar sibling payload PHIs and no defining payload copy; absent payload bytes are excluded.',
      no_selected_C_substitution=True,write_census=dict(n13_all_writes=writes_to(n13),suffix_output_all_writes=writes_to(n13out))),
    selected_target32=dict(three_conditional_memory_definitions=target_writes,
      K=dict(source_object='%hk',interval=[0,32],PDA_call=contains('call void @_ZN13solana_pubkey6Pubkey20find_program_address'),holder_copy=onecopy('%holder_key','%hk',32)),
      C=dict(pointer_chain=[definition(x) for x in ['%3','%_247','%6','%_254','%24']],source_interval=dict(root='%_254',interval=[8,40]),snapshot_copy=onecopy('%st','%24',32),qualification='The selected C copy reads actual curve creator pointer%24 directly; the source snapshot also copies from%24. This is physical forwarding/reload provenance, not a demand that C load from st.'),
      N=dict(pointer=definition('%84'),source_interval=dict(root='%new',interval=[1,33]),validation_copy=onecopy('%t.i','%84',32)),
      source45_copy=copy_t_in,through45=copy45,output_copy=copy_t_out,curve_true_store=curve,curve_pointer_chain=[definition(x) for x in ['%_308','%583']],pool_true_call=pool,
      no_extra_target_memory_definition=True),
    copy45=dict(operation=copy45,coverage=[dict(copied_interval=[0,13],family='original N-sharing suffix13; meaningful update path only'),dict(copied_interval=[13,45],family='selected K/C/N target32')],source_subrange_writes=[copy_t_in,copy_n_in],destination_uses=[copy_t_out,copy_n_out],
      bounded_adjacency='Two actual byte-array allocas, each45 bytes/align8. Adjacency is already present in optimized SSA before backend allocation. These45 bytes are a subrange transport and do not establish complete Result/tuple layout.'),
    Option33=dict(construction=[row(n) for n in range(3074,3082)],tag_and_prefix_insert=[definition(x) for x in ['%_42.sroa.19.sroa.5.0.insert.ext','%_42.sroa.19.sroa.5.0.insert.shift','%_42.sroa.19.sroa.0.0.insert.insert']],
      input_piece_widths=[3,8,8,13],pointer_scalar_qualification='The8-byte middle payload at%new+12 is loaded/stored as LLVM ptr and merged in a phi ptr. It is transported Pubkey data; this receipt does not dereference it or label it an AccountInfo/Result pointer.',
      combined_settings_Result_discriminator='UNRESOLVED: observed%_166.sroa.0.0.i is bound to sharing gate/Option construction, not to a settings Result niche.'),
    object_reference_census={name:refs(name) for name in objects},
    alias_escape_bound='The listed private roots have only the retained intrinsic writes/reads/GEPs/lifetime uses; target11/val4 then escape only as actual noalias nocapture readonly CPI arguments. This is a bounded operand-use audit, not whole-program arbitrary alias proof.',
    stage_ownership='Sweep agent separately seals earliest copy/object history; machine agent separately joins actual objects/addresses/registers. No snapshot-pass origin or RA cause is independently inferred in this optimized-only family receipt.',
    limits=['No original Rust type/helper, source ownership/lifetime, Result size/niche, global966-match regression cause, new source form or measurement authorization is inferred.',
      'The source helper is already inlined in optimized execute. Missing pre-inlining/MIR history is not reconstructed from metadata or final source.',
      'Scalar undef and uninitialized/absent payload on reset/skip paths is retained as absent, not promoted to meaningful data equality.'],
    native_seals={str(p):sha(p) for p in [HERE.parent/'context-s3/TARGET-TRUE-USE.json',HERE.parent/'context-s3/SHARING-TRUE-USE.json',HERE.parent/'context-s3/MANIFEST.json']})
(HERE/'SSA-FAMILIES.json').write_text(json.dumps(result,indent=2)+'\n')
inputs=dict(status='ROOT_CODE_IDENTITY_ADMITTED_SOURCE_SSA_READ_ONLY',source=review['source'],run=review['run'],normal_elf_sha256=review['referenceUnstrippedSha256'],diagnostic_elf_sha256=review['images']['unstripped.so'],stripped_sha256=review['images']['candidate.so'],review_path=str(reviewp),review_sha256=sha(reviewp),module_path=str(modulep),module_sha256=sha(modulep),target_module_range=[info['rawModuleStart'],info['rawModuleEnd']],target_bytes=len(raw),target_sha256=hashlib.sha256(raw).hexdigest(),
    excluded_working_copy='optimized-target.ll is the full extracted target working input. It must not be duplicated in the causal retention archive; exact full IR already belongs to the raw diagnostic ZIP.')
(HERE/'INPUTS.json').write_text(json.dumps(inputs,indent=2)+'\n')
print('Optimized SSA families and bounded excerpts sealed')
