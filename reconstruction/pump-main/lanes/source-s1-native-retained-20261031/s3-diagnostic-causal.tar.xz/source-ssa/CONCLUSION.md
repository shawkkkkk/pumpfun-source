The admitted optimized S3 SSA proves separate incoming-N sharing suffix13 and selected K/C/N32 provenance through the observed45-byte transport. It does not establish an original Result type, combined Result niche or source lifetime.

Input is source65f0162a3dcd381df0f831082dd6732c9af4ab78, diagnostic41173731317. Independent admissiond34ab697… passes50 checks and binds the diagnostic code to normalS3: full stripped bytes/non-symbol sections/functions and all1035 saved score rows match, with only696 local OBJECT names differing. This read executes no scorer or compiler. Optimized execute is313382 bytes, target SHA53425fc1…, extracted from admitted module279dbcf5… at byte offsets2785093..3098475. Line numbers below are target-relative.

The byte map is explicit:

| Source family | Optimized producer |45-byte source interval | After45-byte copy |
|---|---|---|---|
| Incoming N sharing suffix13 | bb76.i line958 copies %new+20 to %_166.sroa.6.i.sroa.6 | %_42.sroa.44[0,13), line972 | %_41.sroa.14[0,13)→%sharing_update12.sroa.5, line982 |
| Selected K/C/N32 | Three conditional32-byte writes to %target.i | %_42.sroa.44[13,45), line970 | %_41.sroa.14[13,45)→%target11, line981 |

Line978 is the actual memcpy45 from %_42.sroa.44 to %_41.sroa.14, both alloca[45xi8]/align8. The13-byte offset is an actual i8 GEP; it is not inferred by adding unrelated widths. The admitted DataLayout is e-m:e-p:64:64-i64:64-n32:64-S128.

Selected target sources are fully distinct: K is the first32 bytes of actual PDA sret %hk; C is %24=%_254+8 (curve creator), also the source of the earlier st snapshot; N is %84=%new+1. Their bb47.i/bb48.i/bb48.thread.i memcpy32 definitions are the only writes to %target.i. C is physically read directly from the curve-derived pointer rather than st storage. The resulting %target11 is the source of the actual curve.creator memcpy at line3063 (%583=curve+8), and the pool CPI's readonly32-byte argument at line3662. These independently join the existing admitted native curve/pool consumer proof.

Sharing remains N even when selected target is C. %new is an actual readonly/dereferenceable33-byte input pointer. bb76.i loads the other payload pieces as i24 from new+1, i64 from new+4 and LLVM ptr from new+12; the latter is transported8-byte Pubkey data, not a dereferenced resource pointer. The suffix13 comes from new[20,33), equivalently Pubkey payload[19,32). The final %val4[20,33) memcpy at line3081 reads %sharing_update12.sroa.5, while its preceding scalar stores form the tag/3/8/8 pieces. Fees CPI line3570 consumes %val4 as readonly33 bytes. The existing native serializer proof supplies its actual tag-dependent reads.

Only bb76.i initializes the suffix13. It is the shared/nonholder update path, reached directly for feeNone or after valid feeSome. Other reset/skip predecessors have undef scalar sibling payload PHIs and no meaningful Pubkey payload definition. Those bytes remain excluded. The phi i32 %_166.sroa.0.0.i is bound to the sharing gate (line3050 compares against2) and %val4 construction. It is not identified as the settings Result discriminator. The complete Rust Result/tuple size or niche remains unresolved.

SSA-METADATA.json preserves exact lifetime, alias/noalias and type/DataLayout records. EVIDENCE-EXCERPTS.ll retains bounded exact producer/PHI/copy/consumer text with original line numbers; SSA-FAMILIES.json includes object reference and write censuses. The listed roots remain private intrinsic-storage objects until %target11/%val4 are passed through actual nocapture readonly arguments. This is bounded operand provenance, not arbitrary whole-program alias analysis or a Rust scope theorem.

The sweep owner separately records that45-byte transport already exists before the first retained JT snapshot; the machine owner separately joins these actual object identities through frame/register stages. This optimized source-family proof does not assign an earlier pass origin or explain the966-match regression versus13fe. Full source/private-helper history before the retained window is not reconstructed.

One initial sealing selector incorrectly assumed the holder PDA was the only find_program_address call in execute; it matched two actual calls. The failed script/stdout/stderr are retained. The corrected selector binds the actual %hk sret root, and the stdlib-only sealing pass succeeds. No measurements or trace bytes were changed.

Retention allowlist excludes optimized-target.ll, the full extracted working definition: full IR belongs only to the raw diagnostic ZIP. No ELF/scorer/VM/compiler/metric/test/source variant or remote action occurred. Python used inherited PYTHONDONTWRITEBYTECODE=1 and python3 -B.
