"""One fixed admitted S3 IR inspection; stdlib text/hash only, no LLVM tools."""
from pathlib import Path
import hashlib
import json
import re

OUT = Path(__file__).resolve().parent
ROOT = Path('/dev/shm/pump-cto-settings-s3-ir/work/ir-run')
ADMISSION = ROOT/'independent-admission/REVIEW.json'
SHA = 'd34ab69789b49db30bc5ae206c53d5716453d692ff05a3b4d858a79d36aa5164'
ROOTS = ['%_42.sroa.44', '%_385.sroa.10', '%_41.sroa.14', '%target.i',
         '%_166.sroa.6.i.sroa.6', '%new', '%st', '%holder_key', '%hk', '%_22']


def sha(b): return hashlib.sha256(b).hexdigest()


def inspect(label, path, expected):
    b = path.read_bytes()
    assert sha(b) == expected
    rows = []
    block = 'entry'
    for n, text in enumerate(b.decode().splitlines(), 1):
        if re.match(r'^[A-Za-z0-9_.$-]+:', text): block = text.split(':', 1)[0]
        rows.append({'line': n, 'block': block, 'text': text.strip()})
    aliases = {p: (p, 0) for p in ROOTS}
    changed = True
    while changed:
        changed = False
        for r in rows:
            m = re.match(r'(%[-\w.$]+) = getelementptr inbounds i8, ptr (%[-\w.$]+), i64 (-?\d+)$', r['text'])
            if m and m[2] in aliases and m[1] not in aliases:
                base, off = aliases[m[2]]; aliases[m[1]] = (base, off+int(m[3])); changed = True
    copies = []
    for r in rows:
        m = re.search(r'@llvm\.memcpy\.p0\.p0\.i64\((ptr[^,]*), (ptr[^,]*), i64 (\d+), i1 (false|true)\)(.*)', r['text'])
        if not m: continue
        dest, source = [re.findall(r'%[-\w.$]+', m[x])[-1] for x in [1, 2]]
        n = int(m[3]); c = dict(r, destination=dest, source=source, length=n,
                             destinationAttributes=m[1], sourceAttributes=m[2],
                             volatile=m[4], trailingMetadata=m[5], addressSpaces=[0, 0])
        for key, pointer in [('sourceRange', source), ('destinationRange', dest)]:
            if pointer in aliases:
                root, off = aliases[pointer]; c[key] = {'object': root, 'bytes': [off, off+n]}
        if any(aliases.get(p, ('', 0))[0] in ROOTS[:5] for p in [source, dest]): copies.append(c)
    objects = {}
    for root in ROOTS[:5]:
        names = [p for p, (base, _) in aliases.items() if base == root]
        uses = [r for r in rows if set(re.findall(r'%[-\w.$]+', r['text'])) & set(names)]
        objects[root] = {'allocation': next((r for r in uses if r['text'].startswith(root+' = alloca ')), None),
                         'aliases': {p: aliases[p][1] for p in names}, 'allDirectReferences': uses,
                         'lifetimeCalls': [r for r in uses if '@llvm.lifetime.' in r['text']],
                         'nonIntrinsicCallEscapes': [r for r in uses if ' call ' in ' '+r['text'] and '@llvm.' not in r['text']]}
    return {'stage': label, 'path': str(path), 'bytes': len(b), 'sha256': sha(b),
            'objects': objects, 'relevantCopies': copies,
            'literal45Copies': [c for c in copies if c['length'] == 45],
            'sharingPayloadScalarPhis': [r for r in rows if re.match(r'%_166\.sroa\.6\.i\.sroa\.[045]\.0 = phi ', r['text'])],
            'actualValidateCalls': [r for r in rows if 'call ' in r['text'] and '@_ZN14pump_recovered9admin_cto8validate17h' in r['text']],
            'metadataDefinitionsIncluded': any(r['text'].startswith('!') and ' = ' in r['text'] for r in rows)}


def main():
    target = OUT/'COPY45.json'
    assert not target.exists()
    raw = ADMISSION.read_bytes(); assert sha(raw) == SHA
    admission = json.loads(raw); stages = []
    for stage in admission['capture']['stages']:
        t = stage.get('targetIr')
        if not t: continue
        p = ROOT/'artifact'/t['file']; s = inspect(stage['file'], p, t['sha256'])
        parent = (ROOT/'artifact'/stage['file']).read_bytes(); assert sha(parent) == stage['sha256']
        lo, hi = t['rawLogStart']-stage['rawLogOffset'], t['rawLogEnd']-stage['rawLogOffset']
        assert parent[lo:hi] == p.read_bytes()
        s.update(parentDumpSha256=sha(parent), parentDumpByteInterval=[lo, hi], actualHeading=stage['heading'])
        stages.append(s)
    optimized = admission['capture']['optimizedTargets'][0]
    s = inspect('optimized', OUT/'optimized-target.ll', optimized['sha256'])
    s.update(parentModuleSha256=optimized['rawModuleSha256'], parentModuleByteInterval=[optimized['rawModuleStart'], optimized['rawModuleEnd']])
    stages.append(s)
    assert [len(s['literal45Copies']) for s in stages] == [2, 2, 2, 2, 1]
    result = {'schema': 's3-copy45-fixed-admitted-stages-v1', 'diagnosticRun': admission['run'],
              'admissionSha256': SHA, 'source': admission['source'], 'diagnosticImages': admission['images'],
              'normalUnstrippedSha256': admission['referenceUnstrippedSha256'],
              'dataLayout': 'e-m:e-p:64:64-i64:64-n32:64-S128', 'actualJumpThreadingPairs': 2,
              'stages': stages, 'earliestQualified45': 'already before first captured JumpThreading',
              'formationAttribution': 'predates earliest retained snapshot; earlier pass/source lowering unknown',
              'temporaryEliminationInterval': 'after JT2 snapshot through optimized IR, with unobserved intervening pass identity',
              'JT2TargetBeforeAfterByteEqual': stages[2]['sha256'] == stages[3]['sha256'],
              'limits': ['Byte0..12 meaning is incoming N suffix only on the meaningful sharing-payload path; reset/skip payload bytes are not qualified.',
                         'The source object is already [45 x i8]; GEP i8 offset13 and copied lengths establish exact [0,13)/[13,45) intervals.',
                         'Standalone pass definitions omit metadata node definitions; printed metadata IDs are retained without importing meanings from another stage.',
                         'No private pre-inlining helper call/definition is retained here; inline blocks do not recover an earlier Result ABI.',
                         'No original source/type/lifetime uniqueness, unprinted-pass attribution, global metric cause, machine-stage analysis, or new source authorization.'],
              'producerSha256': sha(Path(__file__).read_bytes())}
    target.write_text(json.dumps(result, indent=2)+'\n')


if __name__ == '__main__': main()
