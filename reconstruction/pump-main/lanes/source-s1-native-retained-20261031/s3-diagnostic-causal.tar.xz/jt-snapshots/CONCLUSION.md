The qualified45-byte copy predates the earliest retained S3 snapshot. Neither
captured JumpThreading invocation introduces its length or adjacency. The
intermediate45-byte temporary disappears only in the unsampled interval from
JT2-after to optimized IR; its responsible pass is unresolved.

This inspection is bound to diagnostic41173731317 by independent admission
REVIEW SHA256d34ab69789b49db30bc5ae206c53d5716453d692ff05a3b4d858a79d36aa5164.
Diagnostic unstripped5a375b97… differs from normal100d2220… only in permitted
local OBJECT names; both stripped images hash31ece96d…. All non-symbol section
payloads, semantic functions, numeric symbols and1035 saved score rows match
normal S3. Native SUCCESS/source REJECTED/VM0 remain separate. No ELF, compiler,
LLVM tool, scorer, metric or VM was run for this IR inspection.

The actual capture has two JT pairs, four snapshots. The earlier four-pair
preparation mistake is retained and corrected in PAIR-COUNT-CORRECTION.json;
there is no inferred missing JT3/JT4. Ordered target definitions:

| Actual stage | Target bytes | SHA256 | Qualified45 operations |
| --- | ---: | --- | ---: |
| JT1-before |330832|f67b7ee715f567ccc4543d63d2d937da74f9c319825ed57bea064928f6e98bc3|2|
| JT1-after |327281|b12293791d9e64cac0c8e282ffe6095b60ad902e839c10f20ba286cf968da563|2|
| JT2-before |321948|c94f443931ab552694befe48d063083ab7771dab97a2a684aabcd47909f498bf|2|
| JT2-after |321948|c94f443931ab552694befe48d063083ab7771dab97a2a684aabcd47909f498bf|2|
| Optimized |313382|53425fc17c3bea0a0344b03ce66a573862840795c1d7ff5367768411f6d7d5f0|1|

The optimized parent module is41,907,795B/SHA256
279dbcf5e79d749bb455bbc27b69374291164b0347c37242b65ee82892cd6b4e.
Its actual DataLayout is e-m:e-p:64:64-i64:64-n32:64-S128. GEPs here use i8,
so their literal offsets are byte offsets; ptr address spaces are0. Both copy
length and whole-object intervals are explicit in the retained instructions.

Already in JT1-before:

- `%_42.sroa.44` is alloca[45xi8],align8. In bb81.i, its GEP+13 receives
  memcpy32 from `%target.i`, while its base receives memcpy13 from
  `%_166.sroa.6.i.sroa.6`. This establishes disjoint[13,45) and[0,13)
  subranges within one actual45-byte object, before any45-byte intrinsic.
- `%target.i` is alloca32,align1. Its three local sources are `%st[0,32)`,
  `%new[1,33)` and `%holder_key[0,32)`. The first-stage K chain is actual PDA
  sret33 `%hk`→32-byte `%_22`→`%holder_key`→`%target.i`. These are selected
  C/N/K source identities on their respective reviewed successful paths.
- bb76.i writes the13-byte sharing suffix from `%new[20,33)`. Only this path
  supplies meaningful incoming-N bytes for the prefix; other success
  predecessors have undef sibling payload PHIs and no such13-buffer writer.
  Reset/skip paths are not asserted to carry meaningful N Pubkey bytes.
- The observed success route reaches bb64, which copies the entire[0,45)
  range `%_42.sroa.44`→`%_385.sroa.10`→`%_41.sroa.14`. The middle object is
  alloca45,align1; the destination is alloca45,align8. Both operations are
  nonvolatile llvm.memcpy.p0.p0.i64 with literal45. Destination+13 is later
  decomposed to target32, and its base to sharing suffix13. The observed
  error route bypasses these45 copies. This current control distinction does
  not establish a combined Result niche or original ABI.

The same objects, byte partition and two45 operations survive all four JT
snapshots. JT1 changes the success/error control joins without creating this
transport. JT2's complete target definition is byte-identical before/after.
Optimized IR retains `%_42[0,45)`→`%_41[0,45)` directly, both align8, and the
middle `%_385` object/copies/lifetimes are absent. Only JT2-after→optimized is
a supported elimination interval; naming MemCpyOpt, SROA, MIR or another
unprinted pass as its cause would exceed the trace.

COPY45.json records every direct reference/constant-GEP alias, relevant copy,
allocation and lifetime intrinsic for these objects in each target. Their
retained address uses are GEP/memcpy/lifetime intrinsics; no direct non-intrinsic
call escape was found by this bounded closure. The45 copies have no trailing
alias/TBAA metadata. Their32/13 construction writes retain printed noalias
lists. Early function dumps omit metadata definitions, so their numeric IDs
are not resolved using a different stage. Optimized nodes are separately
retained in OPTIMIZED-METADATA.json. LLVM lifetime markers are observations,
not original Rust scope/ownership proof.

The optimized family/consumer seal is independently owned by cto_context_abi:
context-s3-ssa/MANIFEST SHA256
9d69b6b2bfc8296f5eb5ccc64a50cf054e65c8defb6e47bc643da4b7cfe1384d.
It binds optimized selected C to actual curve-derived `%24`, K to `%hk`, N to
`%new+1`, target32 to curve/pool, and the separate sharing payload to Fees.
Our local parser conservatively leaves the deeper optimized `%24` source
unresolved rather than misidentifying it as the earlier snapshot object `%st`.
Source C and native C need not share the same physical storage. No provisional
`_56.i` shorthand is used as an artifact value identity.

This result locates representation, not a missing source correction. The trace
has no pre-inlining private validate definition/call at the earlier necessary
phase and no matched13fe IR baseline. It cannot establish original Rust
Result/tuple/struct size or uniqueness, bool niches, source lifetimes, a global
−966M cause, or a new transport/field-order/attribute trial. Machine lowering
is a separate cto_ir_review seal; this lane did not inspect machine dumps.

For durable retention, copy only the allowlisted small records in MANIFEST.json.
The local optimized-target.ll extract is intentionally excluded; complete IR
and machine files remain in the original diagnostic ZIP.
