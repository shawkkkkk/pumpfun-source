# Same-S3 machine lowering: the 45-byte copy predates allocation

This packet uses root/capture-qualified run 41173731317, source `65f0162a3dcd381df0f831082dd6732c9af4ab78`. The independent 50-check admission is SHA `d34ab69789b49db30bc5ae206c53d5716453d692ff05a3b4d858a79d36aa5164`; whole stripped identity with normal S3 is `31ece96dc7eee70c8c7cc16ba401d63e668c3725a8d1c411834fd9494d8e01d0`. No ELF, compiler, metric, scorer or VM was run by this review.

There is exactly one explicitly length 45 memcpy in each of the five complete machine dumps:

| Stage | Call line / block | Source (R2) | Destination (R1) |
|---|---|---|---|
|after finalize-isel|1722 / bb.60.bb64|FI132 `_42.sroa.44`, 45 B, align 8|FI133 `_41.sroa.14`, 45 B, align 8|
|before greedy|1525 / bb.64.bb64|FI44 `_92.i`, 48 B, align 8|FI47 `authority_info.i`, 48 B, align 8|
|after greedy|1765 / bb.64.bb64|same FI44|same FI47|
|after virtual-register rewrite|1665 / bb.64.bb64|R2 receives FI44 address|R1 receives FI47 address|
|after block placement|1500 / bb.60.bb64|R2=FP-1184|R1=FP-1256|

At instruction selection, `%681` and `%682` are the two frame addresses and `%683=MOV_ri45`; R1/R2/R3 copy those values into `JAL &memcpy`. Before greedy, length 45 is materialized directly in R3. References FI132/FI133 become FI44/FI47, and FI132/FI133 are dead. The 13-byte input object similarly changes reference from FI79 to FI54, a 16-byte object; FI79 is dead. These are observed remappings/coalescing between finalize-isel and before-greedy. Several unprinted passes lie in that interval; this does not identify a particular pass or a Rust lifetime reason.

The copy's address/length definitions are unchanged across the before/after greedy pair. A neighboring scalar spill to stack190 appears; after register rewrite it stores R3. Its source field, allocation priority and later slot-color mapping are not established here. It does not create or resize the memcpy. Register rewriting removes the virtual address COPY intermediates; the final dump exposes FP arithmetic and physical load/store operands. Those changes are bounded to their sampled intervals rather than attributed solely to the pass named in a later heading.

The45-byte source is visibly constructed before the call: selected target32 from FI96 is stored at offsets13/21/29/37, while two overlapping8-byte stores at0/5 cover the separate13-byte prefix. The copied destination is then read at13/21/29/37 into FI104/final target32, while its0/5 loads feed the separate sharing suffix. The peer SSA/consumer proof owns their K/C/N and original-N identities; reused labels such as `authority_info` and `event_signers` do not establish account roles.

The final machine lines1483..1512 match all 30 logical operations in the already sealed normal-native copy witness, including argument construction, surrounding 32+13 stores and subsequent target/sharing loads. In particular, R1=FP-1256, R2=FP-1184, R3=45 reaches the sealed native call at CTO+`0x19f0` to memcpy `0x1b3610`. This is an operation/operand join to recorded raw bytes, not a new disassembly or a count based on MI print labels. Prefixes such as `19824B` are LLVM SlotIndexes, never native byte PCs.

The conclusion is narrow: this memcpy already exists before allocation. Later frame reuse, physical registers and block placement explain its lowering, not its creation. The separate early-IR packet bounds its presence before the first retained JumpThreading snapshot; this machine packet does not repeat or extend that IR attribution.

Nothing here identifies an original Result/bool niche, tuple layout, source lifetime, allocator priority, reason for the 966-match regression or justified followup source variant. Normal native no-loss SUCCESS and source REJECTION remain unchanged, and VM remains unlaunched. Exact input pins, catalogue, producer and the 30-operation join are retained in this packet.
