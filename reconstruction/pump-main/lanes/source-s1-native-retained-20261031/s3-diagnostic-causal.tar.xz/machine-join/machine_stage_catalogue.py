"""Catalogue qualified S3 machine text only; no compiler/ELF/scorer imports.

Run only after root/capture identity GO, with explicit hashes for all five
stage files and the identity receipt. Constant recognition is intentionally
limited to same-block physical definitions and unique virtual COPY/MOV_ri
definitions. An unknown/ambiguous result remains unknown. This tool does not
map source fields, establish native PCs or explain allocator choices.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re

SOURCE = '65f0162a3dcd381df0f831082dd6732c9af4ab78'
NORMAL_STRIP = '31ece96dc7eee70c8c7cc16ba401d63e668c3725a8d1c411834fd9494d8e01d0'
SYMBOL = '_ZN14pump_recovered9admin_cto7execute17h3bd6d7f34f2e30d7E'
STAGES = [('After', 'finalize-isel'), ('Before', 'greedy'), ('After', 'greedy'),
          ('After', 'virtregrewriter'), ('After', 'block-placement')]
REG = r'(?:\$r\d+|%\d+)'
DEFINITION = re.compile(r'^\s*(?:\d+[A-Za-z]\s+)?\s*(?:dead\s+)?(' + REG + r')(?::\w+)?\s*=\s*(.*)$')
BLOCK = re.compile(r'^\s*(?:\d+[A-Za-z]\s+)?(bb\.\d+[^:]*):')


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pinned(path, expected):
    need(path.is_file() and not path.is_symlink(), 'nonregular pinned input: ' + str(path))
    data = path.read_bytes()
    need(len(data) == expected['bytes'] and sha(data) == expected['sha256'], 'input hash/size: ' + str(path))
    return data


def parse(data, when, stage):
    text = data.decode()
    header = re.compile(r'(?m)^[#;]?\s*\*\*\* IR Dump ' + when + r' [^\n]*\(' + re.escape(stage) + r'\) \*\*\*')
    need(len(header.findall(text)) == 1, 'one matching stage heading required')
    begin = '# Machine code for function ' + SYMBOL + ':'
    end = '# End machine code for function ' + SYMBOL + '.'
    need(text.count(begin) == text.count(end) == 1, 'one complete exact machine function required')
    lines = text.splitlines()
    first = next(i for i, line in enumerate(lines) if line.startswith(begin))
    last = next(i for i, line in enumerate(lines) if line == end)
    need(first < last, 'machine extent order')
    rows = []
    block = None
    frames = {}
    for i in range(first, last + 1):
        line = lines[i]
        fm = re.match(r'\s*fi#(-?\d+):\s*(.*)', line)
        if fm:
            frames[int(fm.group(1))] = {'line': i + 1, 'text': line}
        bm = BLOCK.match(line)
        if bm:
            block = bm.group(1)
        dm = DEFINITION.match(line)
        rows.append({'line': i + 1, 'text': line, 'block': block,
                     'definition': dm.group(1) if dm else None,
                     'rhs': dm.group(2) if dm else None})
    return lines, rows, frames


def catalogue(data, when, stage):
    lines, rows, frames = parse(data, when, stage)
    definitions = {}
    for i, row in enumerate(rows):
        if row['definition']:
            definitions.setdefault(row['definition'], []).append(i)

    def nearest(reg, before):
        if reg.startswith('%'):
            dd = definitions.get(reg, [])
            return dd[0] if len(dd) == 1 else None
        block = rows[before]['block']
        for i in range(before - 1, -1, -1):
            row = rows[i]
            if row['block'] != block:
                return None
            if row['definition'] == reg:
                return i
            # Do not infer a physical argument across another call's clobber.
            if re.search(r'\b(?:JAL|JALX|CALL)\b', row['text']) and reg in {'$r0', '$r1', '$r2', '$r3', '$r4', '$r5'}:
                return None
        return None

    def trace(reg, before, seen=()):
        index = nearest(reg, before)
        if index is None or (reg, index) in seen or len(seen) >= 12:
            return {'register': reg, 'status': 'UNKNOWN_OR_AMBIGUOUS'}
        row = rows[index]
        result = {'register': reg, 'status': 'EXPLICIT_DEFINITION',
                  'line': row['line'], 'text': row['text']}
        rhs = re.sub(r'^(?:(?:nuw|nsw|killed|undef)\s+)+', '', row['rhs'])
        immediate = re.match(r'MOV_ri\s+(-?\d+)\b', rhs)
        if immediate:
            result['recognizedConstant'] = int(immediate.group(1))
        copied = re.match(r'(?:COPY|MOV_rr)\s+(?:killed\s+)?(' + REG + r')', rhs)
        if copied:
            child = trace(copied.group(1), index, seen + ((reg, index),))
            result['copiedDefinition'] = child
            if 'recognizedConstant' in child:
                result['recognizedConstant'] = child['recognizedConstant']
        refs = sorted(set(int(x) for x in re.findall(r'%stack\.(-?\d+)', rhs)))
        if refs:
            result['frameReferences'] = [{'id': x, 'descriptor': frames.get(x)} for x in refs]
        return result

    calls = []
    for i, row in enumerate(rows):
        if not re.search(r'\bJAL\b[^\n]*\bmemcpy\b', row['text']):
            continue
        args = {reg: trace(reg, i) for reg in ['$r1', '$r2', '$r3']}
        frame_ids = sorted(set(int(x) for rr in rows[max(0, i - 20):i + 12]
                               for x in re.findall(r'%stack\.(-?\d+)', rr['text'])))
        calls.append({'line': row['line'], 'block': row['block'], 'call': row['text'],
                      'arguments': args,
                      'recognizedLength': args['$r3'].get('recognizedConstant'),
                      'window': [{'line': x['line'], 'text': x['text']} for x in rows[max(0, i - 20):i + 12]],
                      'nearbyFrameDescriptors': [{'id': x, 'descriptor': frames.get(x)} for x in frame_ids]})
    candidates = [c['line'] for c in calls if c['recognizedLength'] == 45]
    return {'when': when, 'pass': stage, 'machineHeader': next(r['text'] for r in rows if r['text'].startswith('# Machine code')),
            'memcpyCalls': calls, 'recognizedLength45CallLines': candidates,
            'uniqueLength45Candidate': len(candidates) == 1,
            'limits': 'Text catalogue only. SlotIndex suffixes such as27472B are not native byte PCs. Unique virtual definitions and same-block physical definitions only; no CFG/alias/source-role/native-PC or allocator-cause proof.'}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--qualified-inputs', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    inputs = json.loads(args.qualified_inputs.read_bytes())
    need(inputs['sourceCommit'] == SOURCE and inputs['normalStrippedSha256'] == NORMAL_STRIP, 'exact measured S3 source/reference required')
    need(inputs['rootCaptureIdentityGO'] is True, 'root/capture qualification must precede this reader')
    receipt = inputs['identityReceipt']
    pinned(Path(receipt['path']), receipt)
    stages = inputs['stages']
    need([(s['when'], s['pass']) for s in stages] == STAGES, 'complete five-stage ordered domain')
    need(len({s['path'] for s in stages}) == 5, 'distinct stage paths')
    output = args.output.resolve()
    need(not output.exists(), 'owned output must start absent')
    resolved = [Path(s['path']).resolve() for s in stages] + [Path(receipt['path']).resolve(), args.qualified_inputs.resolve()]
    need(all(output != p and output not in p.parents and p not in output.parents for p in resolved), 'output/input overlap')
    result = {'source': SOURCE, 'normalStrippedSha256': NORMAL_STRIP,
              'qualificationInputsSha256': sha(args.qualified_inputs.read_bytes()), 'stages': [],
              'status': 'CATALOGUE_REQUIRES_MANUAL_TRUE_USE_AND_NATIVE_JOIN',
              'noCompilerElfMetricScorerVmSourceExecution': True}
    for s in stages:
        data = pinned(Path(s['path']), s)
        result['stages'].append({'input': s, **catalogue(data, s['when'], s['pass'])})
    output.mkdir(parents=True)
    (output / 'CATALOGUE.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'source': SOURCE,
                      'length45Candidates': {s['when'] + ':' + s['pass']: s['recognizedLength45CallLines'] for s in result['stages']}}, indent=2))


if __name__ == '__main__':
    main()
