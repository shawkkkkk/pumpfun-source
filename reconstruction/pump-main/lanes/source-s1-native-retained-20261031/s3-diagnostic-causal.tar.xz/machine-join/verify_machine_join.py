"""Bounded qualified S3 machine-text to sealed native-copy witness join.

No ELF is opened, and no project module/compiler/scorer/VM is invoked.
"""
from pathlib import Path
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
pins = json.loads((HERE / 'qualified-inputs.json').read_bytes())
catalogue = json.loads((HERE / 'catalogue/CATALOGUE.json').read_bytes())
assert catalogue['qualificationInputsSha256'] == sha((HERE / 'qualified-inputs.json').read_bytes())
receipt = Path(pins['identityReceipt']['path']).read_bytes()
assert sha(receipt) == 'd34ab69789b49db30bc5ae206c53d5716453d692ff05a3b4d858a79d36aa5164'
stages = {}
for pin, stage in zip(pins['stages'], catalogue['stages']):
    raw = Path(pin['path']).read_bytes()
    assert len(raw) == pin['bytes'] and sha(raw) == pin['sha256']
    calls = [c for c in stage['memcpyCalls'] if c['recognizedLength'] == 45]
    assert len(calls) == 1
    stages[(pin['when'], pin['pass'])] = (raw.decode().splitlines(), calls[0])


def line(stage, number):
    return stages[stage][0][number - 1]


def frame(lines, index):
    rows = [(i + 1, text) for i, text in enumerate(lines)
            if re.match(r'\s*fi#' + str(index) + r':', text)]
    assert len(rows) == 1
    return {'line': rows[0][0], 'text': rows[0][1]}


isel = ('After', 'finalize-isel')
before = ('Before', 'greedy')
after = ('After', 'greedy')
rewrite = ('After', 'virtregrewriter')
placement = ('After', 'block-placement')
assert line(isel, 1716).strip() == '%681:gpr = MOV_rr %stack.133._41.sroa.14'
assert line(isel, 1717).strip() == '%682:gpr = MOV_rr %stack.132._42.sroa.44'
assert line(isel, 1718).strip() == '%683:gpr = MOV_ri 45'
for key in [before, after]:
    call = stages[key][1]
    assert call['arguments']['$r1']['copiedDefinition']['text'].endswith('%681:gpr = MOV_rr %stack.47.authority_info.i')
    assert call['arguments']['$r2']['copiedDefinition']['text'].endswith('%682:gpr = MOV_rr %stack.44._92.i')
    for index in [79, 132, 133]:
        assert frame(stages[key][0], index)['text'].endswith('dead')
for reg in ['$r1', '$r2', '$r3']:
    a = stages[before][1]['arguments'][reg]
    b = stages[after][1]['arguments'][reg]
    assert a['text'] == b['text']
assert line(rewrite, 1662).endswith('$r1 = MOV_rr %stack.47.authority_info.i')
assert line(rewrite, 1663).endswith('$r2 = MOV_rr %stack.44._92.i')
assert line(rewrite, 1664).endswith('$r3 = MOV_ri 45')

# The exact final block's operation sequence is joined to cached native rows,
# not to the printed SlotIndexes or a recomputed function disassembly.
native_path = Path('/dev/shm/pump-cto-settings-s3/work/context-s3/TARGET-TRUE-USE.json')
native_raw = native_path.read_bytes()
assert sha(native_raw) == 'bb54b678860eca2cb5e8753bf999c12d028e402170392962cd2c28c124b3353a'
native = json.loads(native_raw)['aggregate_transport']
assert native['bytes'] == 45 and native['source_frame'] == [-1184, -1139] and native['destination_frame'] == [-1256, -1211]
machine_rows = []
for number in range(1483, 1513):
    text = line(placement, number).strip()
    core = text.split(' ::', 1)[0]
    machine_rows.append({'line': number, 'text': text, 'core': core})


def machine_semantics(text):
    text = text.replace('killed ', '').replace('(tied-def 0)', '')
    m = re.fullmatch(r'\$r(\d+) = LDD_V1 \$r(\d+), (-?\d+)', text)
    if m:
        d, s, offset = map(int, m.groups())
        return (121, d, s, offset, 0)
    m = re.fullmatch(r'STD_V1 \$r(\d+), \$r(\d+), (-?\d+)', text)
    if m:
        s, d, offset = map(int, m.groups())
        return (123, d, s, offset, 0)
    m = re.fullmatch(r'\$r(\d+) = MOV_rr \$r(\d+)', text)
    if m:
        d, s = map(int, m.groups())
        return (191, d, s, 0, 0)
    m = re.fullmatch(r'\$r(\d+) = ADD_ri \$r(\d+), (-?\d+)', text)
    if m:
        d, s, imm = map(int, m.groups())
        assert d == s
        return (7, d, 0, 0, imm)
    m = re.fullmatch(r'\$r(\d+) = MOV_ri (-?\d+)', text)
    if m:
        d, imm = map(int, m.groups())
        return (183, d, 0, 0, imm)
    if text.startswith('JAL &memcpy,'):
        return ('CALL', 'memcpy')
    raise AssertionError(('unhandled selected instruction', text))


assert len(machine_rows) == len(native['instructions']) == 30
joined = []
for machine, raw in zip(machine_rows, native['instructions']):
    semantics = machine_semantics(machine['core'])
    if semantics[0] == 'CALL':
        assert raw['offset'] == '0x19f0' and raw['opcode'] == 133 and raw['callee'] == ['memcpy']
        assert raw['call_target'] == '0x1b3610'
    else:
        assert semantics == tuple(raw[key] for key in ['opcode', 'dst', 'src', 'displacement', 'immediate'])
    joined.append({'machine': machine, 'sealedNative': raw})

report = {
    'status': 'PROVED_BOUNDED_FIVE_STAGE_COPY_LOWERING_AND_NATIVE_JOIN',
    'source': pins['sourceCommit'], 'identityReceiptSha256': sha(receipt),
    'normalStrippedSha256': pins['normalStrippedSha256'],
    'stageCalls': [{'when': key[0], 'pass': key[1], 'line': value[1]['line'],
                    'block': value[1]['block'], 'length': 45} for key, value in stages.items()],
    'beforeGreedyReferenceRemap': {
        'source45': [132, 44], 'destination45': [133, 47], 'inputSharingSuffix13': [79, 54],
        'descriptors': [{'stage': key, 'objects': {str(i): frame(stages[key][0], i)
                        for i in [44, 47, 54, 79, 96, 103, 104, 132, 133]}}
                        for key in [isel, before, after, rewrite, placement]],
        'bound': 'Reference/descriptor coalescing observed between finalize-isel and before-greedy. This is not a dedicated stack-coloring pass dump or Rust lifetime attribution.',
    },
    'greedyCopyArgumentDefinitionsUnchanged': True,
    'neighboringGreedySpill': {
        'afterGreedyLine': 1746, 'text': line(after, 1746),
        'afterRewriterLine': 1648, 'rewrittenText': line(rewrite, 1648),
        'bound': 'A neighboring scalar is spilled to stack.190 and rewritten from virtual1766 to physicalR3. Its source field/priority and later slot-color mapping are not established; this does not create or resize the copy.',
    },
    'finalCopyArguments': {'r1': 'FP-1256', 'r2': 'FP-1184', 'r3': 45},
    'sealedNativeWitness': {'path': str(native_path), 'sha256': sha(native_raw)},
    'thirtyInstructionNativeJoin': joined,
    'limitations': [
        'Only admitted machine text and sealed native instruction witnesses were read. No ELF reopened or new metric/scorer/compiler/VM executed.',
        'SlotIndexes are not bytePCs. The native PC anchor comes only from the sealed 30-operation sequence join.',
        'The length45 operation predates allocation; reference coalescing and physical frame layout occur in later sampled intervals.',
        'Frame names authority_info/event_signers/_92 are reused object labels, not account/payload identities. Peer source-SSA/true-consumer proof owns those semantic identities.',
        'No exact unsampled pass, allocator cost/priority, source lifetime, original Result/bool niche/type, metric regression cause or new source trial follows.',
    ],
}
(HERE / 'MACHINE-JOIN.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'joinedOperations': len(joined),
                  'reportSha256': sha((HERE / 'MACHINE-JOIN.json').read_bytes())}, indent=2))
