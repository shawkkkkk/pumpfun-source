# Frozen963d retained runtime evidence

The exact native control ZIP is the adjacent963d-control-raw.zip. Its candidate.so
is the runtime image, so no native image is duplicated in this archive. Preserve
all original member bytes; MANIFEST.json binds the complete report and receipts.

runtime/runtime-report.json is the full363-case public signed synthetic report,
not a reduced summary. Existing RESULT/SEALED and run_once.py retain the726 saved
transaction verification implementation and result. Public transaction bytes
contain signatures/messages/accounts/instruction data, not keypair serialization.
Packaging performed structural inspection only; no VM or crypto audit was rerun.

For offline evidence review: verify SHA256s, compare INPUTS-BEFORE/AFTER, count the
363 match rows and169 success/194 rejection outcomes per side, and inspect all726
saved transactions. No additional execution is needed to inspect the capture.

For an explicitly authorized future reproduction, use the exact public repository
checkpoint963d1eefbed3a81a51d2d52f80026c5434a7a423 and runtime-inputs/RECIPE.json,
plus actual runtime/HANDOFF.json, to map original absolute RAM paths to a fresh
checkout. The preparatory RECIPE/READY statuses remain unmodified; actual launch
and result are in HANDOFF/PROCESS/RESULT. INPUTS-BEFORE lists the24 source/data/image
inputs, external Python/VM package identities and source141 vector. Obtain those
public captures/scripts from that checkpoint and verify every recorded hash;
environment package versions/file identities are in ENVIRONMENT.json. Runtime
libraries, original public program/dependency captures and fixture source are
identified rather than copied here; no private fixture keys or credentials are
included. This archive performs no implicit download or execution.

This finite unchanged-source comparison is not full-program identity, source
gain, security clearance, or qualification of later source. Native score remains
1034raw/1034normalized with CTO unresolved. Prior C1/S1/S2 negatives stay retained.
