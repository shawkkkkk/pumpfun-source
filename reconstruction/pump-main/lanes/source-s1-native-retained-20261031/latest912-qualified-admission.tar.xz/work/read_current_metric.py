"""One normalized CTO measurement using the previously sealed Ebe metric."""
from pathlib import Path
import datetime, difflib, hashlib, importlib.util, json, os, sys, time

R=Path('/dev/shm/pump-cto-912-v2-control')
O=R/'work/current-target-metric'
HELPER=Path('/dev/shm/pump-cto-ebe5387/work/target-token-metric/read_target.py')
OLD=Path('/dev/shm/pump-cto-ebe5387/work/target-token-metric/stdout')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path,value):
    with path.open('x') as stream:stream.write(json.dumps(value,indent=2)+'\n')
def identity(path):
    s=path.stat();return {'path':str(path),'bytes':s.st_size,'sha256':sha(path),'mode':s.st_mode,'device':s.st_dev,'inode':s.st_ino,'mtimeNs':s.st_mtime_ns}
assert sys.dont_write_bytecode and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1'
assert not O.exists()
assert sha(HELPER)=='6eccf05c2b37ec55d519e606731273c1621a13afbf6bdf06e5da5493a03b43b6'
assert sha(OLD)=='e77fa54acbb9a9d90d80a1d2abc74c88a01d7872a70659fda26bd948406c731d'
admission=R/'work/root/CURRENT-ELF-ADMISSION.json';review=R/'work/secondary-admission-reader/actual-review/REVIEW.json'
assert sha(admission)=='a9f1f4c1c884853ebd193c19b608cde3f19ffaefcb58d868aee6e12185a4398a'
assert sha(review)=='0fd1e8c5d2627032f2cde735812449b58a27b17bf3a5ac41135660d101352433'
a=json.loads(admission.read_text());v=json.loads(review.read_text());old=json.loads(OLD.read_text())
assert a['base']=='9120883a957d7d9b2cab6140f66fb5bc9e6774d5' and a['raw']==a['normalized']==1034 and a['nativeNoLossConclusion']=='PASS'
assert len(v['checks'])==39 and all(r['pass'] for r in v['checks'])
assert old['Ebe']['normalizedMatchingLogicalInstructionsM']==2247
sealed_d421=R/'work/native-prep/REFERENCE-TARGET-METRIC.json'
assert sha(sealed_d421)=='51e7f8d4fe871d481e235f3d5d7901a3055b81835697b0df6a5d4b5d72680e1b'
d421=json.loads(sealed_d421.read_text());assert d421['source']=='d4219123cf0fbbefcfc7e77450efeda6684b812b' and d421['current']['M']==2248
assert a['sourceSha256']=='6f5926830f08711a09d4b680f941338019217aaa48868b1afac8284619c0d6f3' and a['coreFiles']==288 and a['stageFiles']==264
assert all(a['comparison'][k] for k in ['noRawLosses','noNormalizedLosses','allRowsEqual'])
spec=importlib.util.spec_from_file_location('sealed_ebe_metric_functions',HELPER);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
method_root=Path('/dev/shm/pump-cto-ebe5387/reconstruction/harness')
for name,expected in module.METHOD.items():assert sha(method_root/name)==expected
original=R/'evidence/original/pump/deployed.so';candidate=R/'work/native-run/artifact/unstripped.so';archive=R/'work/native-run/raw-artifact.zip'
assert sha(original)==module.ORIGINAL and sha(candidate)==a['images']['unstripped.so']=='dc79dde734b0cfb2ba84e505d62b5d3bdd801649e04e7ed9741366d07d095c8c'
assert sha(archive)=='bfffe349ab4563fcfcc07e6d9bffcadb0046260e71b5857173b708402599f6f4'
paths=[Path(__file__),HELPER,OLD,sealed_d421,admission,review,original,candidate,archive,R/'programs/pump/src/creator/admin_cto.rs',Path(sys.executable).resolve(),*[method_root/n for n in module.METHOD]]
before=[identity(p) for p in paths];O.mkdir();dump(O/'BEFORE.json',before)
dump(O/'STARTED.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'readerSHA256':sha(Path(__file__)),'source':a['base'],'nativeQualification':sha(admission),'rootSecondaryQualification':sha(review),'method':'Same sealed Ebe normalizer/SequenceMatcher; no current method substitution or old Ebe ELF read.','measurementsPermitted':1})
clock=time.monotonic()
try:
    ob=original.read_bytes();cb=candidate.read_bytes();os_,_=module.elf(ob);cs,syms=module.elf(cb)
    original_body=module.body(os_,old['original']['start'],old['original']['bytes'])
    assert hashlib.sha256(original_body).hexdigest()==old['original']['bodySha256']
    symbols=[s for s in syms if s[0]==a['CTO']['name'] and s[1]&15==2 and s[2]==cs['.text'][2]];assert len(symbols)==1;s=symbols[0]
    current_body=module.body(cs,s[3],s[4]);assert hashlib.sha256(current_body).hexdigest()==a['CTO']['bodySha256']
    original_tokens=module.normalized_tokens(original_body,os_);tokens=module.normalized_tokens(current_body,cs)
    matcher=difflib.SequenceMatcher(None,original_tokens,tokens,autojunk=False)
    matching=sum(b.size for b in matcher.get_matching_blocks())
    result={'status':'CURRENT_912_TARGET_TOKEN_MEASUREMENT_COMPLETE','source':a['base'],'provider':{'run':41217095271,'artifact':13048299239,'operational':'289ec59df531dc563573564769a787efc968f599'},'images':{'unstripped':sha(candidate),'original':sha(original)},'methodFiles':module.METHOD,'original':old['original'],'current':{'symbol':s[0],'start':s[3],'bytes':s[4],'bodySHA256':hashlib.sha256(current_body).hexdigest(),'logicalInstructions':len(tokens),'M':matching,'ratio':matcher.ratio()},'sealedEbe':{'M':2247,'receiptSHA256':sha(OLD),'recomputed':False},'currentMinusSealedEbeM':matching-2247,'sealedD421':{'M':2248,'receiptSHA256':sha(sealed_d421),'recomputed':False},'currentMinusSealedD421M':matching-2248,'reportedPlusOneConfirmed':matching-2248==1,'limits':'One target-token similarity measurement on qualified current source. No new official score, compiler, VM, raw metric, source variant, original Rust signature/lifetime or whole-window equality claim. Root secondary39 review is not an independent agent review.'}
    dump(O/'RESULT.json',result)
    after=[identity(p) for p in paths];assert after==before;dump(O/'AFTER.json',after)
    dump(O/'EXECUTION.json',{'pid':os.getpid(),'elapsedSeconds':time.monotonic()-clock,'exitCode':0,'inputsUnchanged':True,'inputCount':len(paths),'resultSHA256':sha(O/'RESULT.json'),'metricExecutions':1,'otherCompilerScorerVMExecutions':0})
    print(json.dumps(result,indent=2))
except BaseException as error:
    dump(O/'FAILURE.json',{'type':type(error).__name__,'message':str(error),'retryAuthorized':False});raise
