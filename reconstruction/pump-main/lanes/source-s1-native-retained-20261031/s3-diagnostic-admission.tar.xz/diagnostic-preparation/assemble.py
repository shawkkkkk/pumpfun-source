"""Prepare one fixed-source S3 trace; no compiler/collector execution."""
import ast,hashlib,json,os,shutil,sys
from pathlib import Path
assert os.environ.get('PYTHONDONTWRITEBYTECODE')=='1'and sys.dont_write_bytecode and sys.flags.optimize==0
R=Path('/dev/shm/pump-cto-settings-s3-ir');O=R/'work/diagnostic-prep';C1=Path('/dev/shm/pump-cto-option-c1/work/diagnostic-prep');S3=Path('/dev/shm/pump-cto-settings-s3');P13=Path('/dev/shm/pump-cto-13fe453');S='65f0162a3dcd381df0f831082dd6732c9af4ab78';P='13fe4536be64d8c5c10f8905e9d2236f423ac4f4';SOURCE='9fc3fd3c8e68d85e5bf4fcb2309694974aab3c5aaacab9741a1e0ea25c72a622';LANE='reconstruction/pump-main/lanes/current-native-ir-capture/';sha=lambda b:hashlib.sha256(b).hexdigest()
published=json.loads((C1/'PUBLISHED.json').read_text())
for row in published['files']:assert sha((C1/'ops'/row['path']).read_bytes())==row['sha256']
def bind_copy(root,dest,run,artifact,zipsha):
 folder=root/'work/native-run/artifact';download=json.loads((root/'work/native-run/DOWNLOAD-VERIFIED.json').read_text());assert download['run']==run and download['artifact']==artifact and download['sha256']==zipsha
 table={p.relative_to(folder).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in folder.rglob('*')if p.is_file()};assert table=={r['path']:{'bytes':r['bytes'],'sha256':r['sha256']}for r in download['files']};assert all(not p.is_symlink()for p in folder.rglob('*'))
 dest.mkdir(exist_ok=False)
 for n,e in table.items():
  p=dest/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(folder/n,p);assert sha(p.read_bytes())==e['sha256']
 return table,download
ref,rd=bind_copy(P13,R/'work/current13fe-reference',41170683278,13031166975,'875edcd6e9ebb7e5b8fb2495d0008e723762b1f0251a02e038881fb56749fa92')
trace,td=bind_copy(S3,R/'work/s3-normal-reference',41172052790,13031054922,'0f1a82695dd41525fffbebe667c3067062a9a1fd1fd3fb4b70cbdb054965bdda');assert len(ref)==43 and len(trace)==45
assert trace['candidate.so']['sha256']=='31ece96dc7eee70c8c7cc16ba401d63e668c3725a8d1c411834fd9494d8e01d0'and trace['unstripped.so']['sha256']=='100d222047a2281a4409d8f732266955368504479d3d4076b4f6e3af08ef37e4'
normal=json.loads((S3/'work/native-run/artifact/RESULT.json').read_text());assert normal['base']==S and normal['sourceUnchanged']and normal['coldTarget']and normal['noNormalizedLosses']and normal['noRawLosses']
old=(C1/'ops'/LANE/'pump_ir_control.py').read_text();lines=old.splitlines(keepends=True)
values={'BASE':S,'EXPECTED_SOURCE_SHA256':SOURCE,'REFERENCE_BASE':P,'REFERENCE_SOURCE_SHA256':'ba203d5c8b0cda5ab3bb6eec65266a992331b7a8a361b9977a3d2ab474b11fe2','REFERENCE_RUN':41170683278,'REFERENCE_ARTIFACT':13031166975,'REFERENCE_ZIP_SHA256':rd['sha256'],'REFERENCE_FILES':ref,'TRACE_RUN':41172052790,'TRACE_ARTIFACT':13031054922,'TRACE_ZIP_SHA256':td['sha256'],'TRACE_FILES':trace,'TRACE_TARGET_EXTENT':(141840,27400)}
for n in reversed(ast.parse(old).body):
 if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)and n.targets[0].id in values:lines[n.lineno-1:n.end_lineno]=[n.targets[0].id+' = '+repr(values[n.targets[0].id])+'\n']
new=''.join(lines).replace('current39eb-reference','current13fe-reference').replace('c1-normal-reference','s3-normal-reference').replace('pump-c1-diagnostic','pump-s3-diagnostic').replace('C1','S3').replace('current39eb','current13fe').replace('c1-reference','s3-reference')
start=new.index("    failure = json.loads((TRACE_REFERENCE / 'FAILURE.json').read_text())")
end=new.index("    comparison = json.loads((TRACE_REFERENCE / 'CANDIDATE-COMPARISON.json').read_text())",start)
new=new[:start]+"    normal_result = json.loads((TRACE_REFERENCE / 'RESULT.json').read_text())\n    require(normal_result['base'] == BASE and normal_result['sourceUnchanged']\n            and normal_result['registrySourceUnchanged'] and normal_result['toolInputsUnchanged']\n            and normal_result['coldTarget'] and normal_result['noNormalizedLosses']\n            and normal_result['noRawLosses'] and 'FAILURE.json' not in TRACE_FILES,\n            'actual normal S3 success admission differs; source-metric rejection is separate')\n"+new[end:]
new=new.replace("and comparison['noNormalizedLosses'] and not comparison['noRawLosses'], 'original S3 negative comparison differs')","and comparison['noNormalizedLosses'] and comparison['noRawLosses'], 'actual normal S3 no-loss comparison differs')")
new=new.replace('One exact-S3 compiler trace; original source no-loss guard remains authoritative and negative.','One fixed-S3 compiler trace; native no-loss success and internal source-metric rejection remain separate.').replace('actual already-measured S3 negative artifact','actual already-measured normal S3 artifact')
new=new.replace('# Save independent exact-S3 trace identity before the unchanged source-loss guard.\n    # A trace cannot promote the measured negative source into a passing candidate.','# Save exact-S3 trace identity before the unchanged native no-loss guard.\n    # Internal source-metric rejection remains separate from native success.')
dest=O/'ops'/LANE;dest.mkdir(parents=True,exist_ok=True);(dest/'pump_ir_control.py').write_text(new)
capture=(C1/'ops'/LANE/'capture.py').read_text();updated_capture=capture.replace('0a6f3cd63c65df63915d912d09e69b3d163628d3cb70b1212aeca021ea32d3f2',SOURCE).replace('C1','S3');(dest/'capture.py').write_text(updated_capture)
wf=(C1/'ops/.github/workflows/qualify-pump-macos-v144.yml').read_text()
for a,b in [('0fc50efbc599fa1e025169c8db06fceb25c9c192',S),('0fc50efb','65f0162a'),('39eb377aa6c6ce4aacff273aa13732abb0c0078a',P),('41159607118','41170683278'),('13026402898','13031166975'),('41162533835','41172052790'),('13027638017','13031054922'),('current39eb-reference','current13fe-reference'),('c1-normal-reference','s3-normal-reference'),('pump-c1-diagnostic','pump-s3-diagnostic'),('C1','S3'),('measured-negative S3','fixed rejected-source S3')]:wf=wf.replace(a,b)
w=O/'ops/.github/workflows/qualify-pump-macos-v144.yml';w.parent.mkdir(parents=True,exist_ok=True);w.write_text(wf)
def functions(s):return {n.name:ast.dump(n,include_attributes=False)for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
f0,f1=functions(old),functions(new);changed=[n for n in f0 if f0[n]!=f1[n]];assert set(changed)<={'verify_current_reference','verify_trace_reference','diagnostic_comparison','main'}
c0,c1=functions(capture),functions(updated_capture);assert all(c0[n]==c1[n]for n in c0 if n!='capture')
for name in ['LLVM_ARGUMENTS','ROOT_ARGUMENTS','STAGES','ENVIRONMENT_KEYS','OWNED_OUTPUTS','BUILD_OUTPUTS']:
 def assignment(text):return next(n for n in ast.parse(text).body if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)and n.targets[0].id==name)
 assert ast.dump(assignment(capture),include_attributes=False)==ast.dump(assignment(updated_capture),include_attributes=False)
for target,src in [('NORMAL-S3-ROOT-ADMISSION.json',S3/'work/root/CANDIDATE-ELF-ADMISSION.json'),('NORMAL-S3-VM-HELD.json',S3/'work/runtime-inputs/HELD-RECEIPT.json'),('BASELINE13FE-ROOT-ADMISSION.json',P13/'work/root/CURRENT-ELF-ADMISSION.json')]: (O/target).write_bytes(src.read_bytes())
(O/'ACTUAL-S3-BINDING.json').write_text(json.dumps({'status':'PREPARED_NORMAL_S3_SELF_REFERENCE_AND13FE_BASELINE','source':S,'sourceSha256':SOURCE,'baseline':{'base':P,'files':ref,'download':rd},'normalSelfReference':{'base':S,'files':trace,'download':td},'nativeNoLoss':'SUCCESS preserved; internal source-metric rejection remains source FAIL','runtimeS3':'HELD0; no VM authorized by this diagnostic preparation','templatePublished':published,'controllerChangedFunctionASTs':changed,'collectorChangedFunctionASTs':[n for n in c0 if c0[n]!=c1[n]],'flagsStagesCollectorParserUnchanged':True,'guardAdaptation':'Only trace-reference C1 FAILURE predicate is replaced with strict actual normal-S3 RESULT/source/registry/tool/cold/no-loss SUCCESS predicate. All complete byte/section/symbol/row identity and capture-completeness predicates retained.','actualTargetSymbol':'_ZN14pump_recovered9admin_cto7execute17h3bd6d7f34f2e30d7E','actualTargetExtent':[141840,27400],'nativeDiagnosticExecutions':0},indent=2)+'\n')
print(json.dumps({'source':S,'normalSelfReferenceMembers':len(trace),'baselineMembers':len(ref),'controllerChangedFunctions':changed,'collectorFlagsAndParserUnchanged':True,'actualCompilerExecutions':0}))
