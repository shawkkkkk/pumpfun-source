import ast,datetime,difflib,hashlib,json,os,subprocess,sys
from pathlib import Path
assert os.environ.get('PYTHONDONTWRITEBYTECODE')=='1'and sys.dont_write_bytecode and sys.flags.optimize==0
R=Path('/dev/shm/pump-cto-settings-s3-ir');O=R/'work/diagnostic-prep';S='65f0162a3dcd381df0f831082dd6732c9af4ab78';T='f36a4e0b3c02822750ce5c41529b7a75e16f79c0';P='13fe4536be64d8c5c10f8905e9d2236f423ac4f4';sha=lambda b:hashlib.sha256(b).hexdigest();env=os.environ|{'GIT_NO_LAZY_FETCH':'1','PYTHONDONTWRITEBYTECODE':'1'}
def git(*args):return subprocess.run(['git',*args],cwd=R,env=env,capture_output=True,check=True).stdout
assert git('rev-parse','HEAD','HEAD^{tree}').decode().split()==[S,T]and not git('status','--porcelain','--untracked-files=no').strip()
assert[x[7:]for x in git('cat-file','-p',S).decode().splitlines()if x.startswith('parent ')]==[P]
pf=json.loads((O/'PREFLIGHT-RESULT.json').read_text());assert pf['status']=='PASS'and pf['exitCode']==0 and pf['inputsUnchanged']and pf['sourceCoreReferenceOpsBoundFiles']==470
actual=json.loads((O/'preflight/evidence/PREFLIGHT.json').read_text());assert(actual['programGitFiles'],actual['selectedSourceFiles'],actual['workspaceFiles'],actual['coreFiles'])==(141,141,142,236)
assert actual['preflightOnly']and actual['sourceSha256']=='9fc3fd3c8e68d85e5bf4fcb2309694974aab3c5aaacab9741a1e0ea25c72a622'
stage=json.loads((O/'preflight/evidence/compiled-workspace-inputs.json').read_text());stage_sha=sha(json.dumps(stage,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode());assert stage_sha=='8ecb6144b71aee05d37cb1bebd4f2b0b3343c7eb88f0a3366d17c4dc0381e9db'
ops=['.github/workflows/qualify-pump-macos-v144.yml','reconstruction/pump-main/lanes/current-native-ir-capture/pump_ir_control.py','reconstruction/pump-main/lanes/current-native-ir-capture/capture.py','reconstruction/pump-main/lanes/current-native-ir-capture/README.md'];meta={}
for raw in git('ls-tree','-rz',S,'--',*ops).split(b'\0'):
 if raw:
  m,p=raw.split(b'\t');mode,kind,oid=m.decode().split();assert kind=='blob';meta[p.decode()]=(mode,oid)
files=[];patch=[]
for p in ops:
 b=(O/'ops'/p).read_bytes();old=git('cat-file','blob',S+':'+p)if p in meta else b'';oid=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();previous=meta[p][1]if p in meta else'0'*40
 patch.append('diff --git a/'+p+' b/'+p+'\n')
 if p not in meta:patch.append('new file mode 100644\n')
 elif meta[p][0]!='100644':patch.extend(['old mode '+meta[p][0]+'\n','new mode 100644\n'])
 patch.append('index '+previous+'..'+oid+(' 100644'if p in meta and meta[p][0]=='100644'else'')+'\n');patch.extend(difflib.unified_diff(old.decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile='a/'+p if p in meta else'/dev/null',tofile='b/'+p))
 files.append({'path':p,'mode':'100644','bytes':len(b),'sha256':sha(b),'gitBlob':oid})
(O/'OPS.patch').write_text(''.join(patch));cmd=['git','apply','--cached','--check','--whitespace=error',str(O/'OPS.patch')];check=subprocess.run(cmd,cwd=R,env=env,capture_output=True);(O/'PATCH-CHECK.json').write_text(json.dumps({'argv':cmd,'exitCode':check.returncode,'stdout':check.stdout.decode(errors='replace'),'stderr':check.stderr.decode(errors='replace'),'indexMutation':False},indent=2)+'\n');assert check.returncode==0
guides={}
for p in ['AGENTS.md','CONTRIBUTING.md','README.md','SECURITY.md','docs/SCOPE.md','docs/COMPLETION.md','docs/PARALLEL_WORK.md','programs/pump/Cargo.toml','programs/pump/Cargo.lock']:
 b=(R/p).read_bytes();assert b==git('cat-file','blob',S+':'+p);guides[p]={'bytes':len(b),'sha256':sha(b),'sameFrozenS3Git':True}
errors=(O/'preflight.stderr').read_text().splitlines();assert len(set(errors))==1 and'nesting too deep'in errors[0]
qualified=Path('/dev/shm/pump-cto-option-c1/work/review/diagnostic-admission/ADMISSION.json')
review={'status':'PASS_FIXED_C1_COLLECTOR_REUSE_AND_S3_REFERENCE_INPUT_REVIEW','genuineSource':S,'guidesManifests':guides,'C1ActualDiagnosticAdmission':{'path':str(qualified),'sha256':sha(qualified.read_bytes())},'fixedFlags':'Same C1 LLVM_ARGUMENTS/ROOT_ARGUMENTS/STAGES/ENVIRONMENT_KEYS AST; no memcpyopt/MIR/opt/llc/threshold/layout flags.','referenceGuardChange':'Actual normalS3 SUCCESS/source/registry/tools/cold/no-loss guard replaces only C1 historical FAILURE requirement. All byte/section/function/numeric/1035 identity and capture complete predicates retained.','sourceRejection':'NativeNoLossSuccess is distinct from rejected internal source metric; S3 VMheld0; diagnostic cannot promote source.','localGitStderr':{'bytes':(O/'preflight.stderr').stat().st_size,'line_count':len(errors),'unique_line_count':len(set(errors)),'text':errors[0],'effect':'Old readonly alternate nesting warning only; all Git reads returned success and exact full source/CORE/reference guards passed. Preserved raw; no retry.'},'postPreflightCosmeticAmendment':'DESCRIPTION-ONLY-POST-PREFLIGHT.json; exact executed controller retained, only module docstring changed; no rerun.','SDKCompilerScorerVMCollectorExecution':False}
(O/'INPUT-REVIEW.json').write_text(json.dumps(review,indent=2)+'\n')
frozen=[]
for p in sorted(O.rglob('*')):
 if not p.is_file():continue
 n=p.relative_to(O).as_posix()
 if n.startswith('preflight/cold-work/')or n in ['FROZEN-MANIFEST.json','PREPARATION-RESULT.json']:continue
 b=p.read_bytes();frozen.append({'path':n,'bytes':len(b),'sha256':sha(b)})
(O/'FROZEN-MANIFEST.json').write_text(json.dumps({'status':'FROZEN_FIXED_S3_DIAGNOSTIC_PREPARATION_ONLY','files':frozen},indent=2)+'\n')
summary={'status':'READY_INDEPENDENT_REVIEW_NO_NATIVE_CAPTURE_RELEASE','source':S,'tree':T,'soleParent':P,'leafSha256':'32d4d71065f96e0d24f65ead880974a4e4cc95919ec2ef0bc113a0d536e3d7b9','sourceFiles':141,'coreFiles':236,'stageFiles':142,'sourceSha256':actual['sourceSha256'],'stageSha256':stage_sha,'opsFiles':files,'opsPatchSha256':sha((O/'OPS.patch').read_bytes()),'frozenManifestSha256':sha((O/'FROZEN-MANIFEST.json').read_bytes()),'frozenFileCount':len(frozen),'baselineReference':{'base':P,'run':41170683278,'artifactId':13031166975,'members':43,'folder':'work/current13fe-reference'},'normalS3SelfReference':{'base':S,'run':41172052790,'artifactId':13031054922,'members':45,'strippedSha256':'31ece96dc7eee70c8c7cc16ba401d63e668c3725a8d1c411834fd9494d8e01d0','unstrippedSha256':'100d222047a2281a4409d8f732266955368504479d3d4076b4f6e3af08ef37e4','folder':'work/s3-normal-reference'},'actualPreflight':pf,'moduleDocstringOnlyPostPreflightAmendment':json.loads((O/'DESCRIPTION-ONLY-POST-PREFLIGHT.json').read_text()),'diagnosticComparators':'Complete stripped bytes; all non-symbol section payloads including allocated data/text; semantic function/numeric symbols; whole text+function addresses/sizes imply function-body equality; all1035 rows; full capture stages and one compiler boundary. No predicate relaxation.','actualDiagnosticCompilerOrSDKScorerVMExecutions':0,'trackedSourceClean':True,'noSourceOverlay':True,'limits':'Preparation and one noSDK preflight only. Native source no-loss success/internal metric rejection/VMheld0 remain separate. S3 bool-niche origin unproved. Root owns publication and one dispatch only after independent GO.','utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(O/'PREPARATION-RESULT.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'status':summary['status'],'source':S,'tree':T,'parent':P,'frozenManifestSha256':summary['frozenManifestSha256'],'files':len(frozen),'ops':files,'preparationResultSha256':sha((O/'PREPARATION-RESULT.json').read_bytes()),'patchCheck':check.returncode}))
