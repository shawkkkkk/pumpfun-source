"""Real physical S3 source/stage/current-control preflight; no native operations."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys

assert os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode and sys.flags.optimize==0
ROOT=Path(__file__).resolve().parents[2]
FOLDER=ROOT/'work/diagnostic-prep'
CONTROLLER=FOLDER/'ops/reconstruction/pump-main/lanes/current-native-ir-capture/pump_ir_control.py'
RSYNC=Path('/workspace/pumpfun-source-workers/pump-lifecycle/work/host-tools/rsync-debian-13/extracted/usr/bin/rsync')
assert hashlib.sha256(RSYNC.read_bytes()).hexdigest()=='a56c05b960beb734169619d5760b43ff495e84f85a93eb1f54fe58118262fb20'
os.environ.update(PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1',GIT_ALLOW_PROTOCOL='file',RUNNER_TEMP=str(FOLDER/'runner-temp'))
os.environ['PATH']=str(RSYNC.parent)+os.pathsep+os.environ['PATH']
os.environ['LD_LIBRARY_PATH']=str(RSYNC.parents[1]/'lib/x86_64-linux-gnu')
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('s3_diagnostic_native_control',CONTROLLER)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.ROOT=ROOT;module.EVIDENCE=FOLDER/'preflight/evidence';module.WORK=FOLDER/'preflight/cold-work'
module.REFERENCE=ROOT/'work/current13fe-reference'
module.TRACE_REFERENCE=ROOT/'work/s3-normal-reference'
module.main(preflight_only=True)
staged=json.loads((module.EVIDENCE/'compiled-workspace-inputs.json').read_text())
projection=hashlib.sha256(json.dumps(staged,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
(FOLDER/'PREFLIGHT-EXECUTION.json').write_text(json.dumps({'command':[sys.executable,'-B','work/diagnostic-prep/run_preflight.py'],'exitCode':0,
 'sourceRoot':str(ROOT),'sourceCommit':module.BASE,'controllerSha256':hashlib.sha256(CONTROLLER.read_bytes()).hexdigest(),
 'expectedSourceSha256':module.EXPECTED_SOURCE_SHA256,'projectedWorkspaceSha256':projection,'referenceRoot':str(module.REFERENCE),
 'referenceRun':module.REFERENCE_RUN,'referenceArtifactId':module.REFERENCE_ARTIFACT,'rsyncSha256':hashlib.sha256(RSYNC.read_bytes()).hexdigest(),
 'evidence':str(module.EVIDENCE),'work':str(module.WORK),'sdkBootstrapCargoCompilerScorerRuntimeExecuted':False,
 'nativeOperationalParentAdmissionExercised':False},indent=2)+'\n')
