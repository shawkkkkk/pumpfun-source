"""Assemble a fixed-run stdlib reader without executing the reader or project."""
from pathlib import Path
import ast,hashlib,json
O=Path('/dev/shm/pump-cto-settings-s3-ir/work/ir-run/independent-admission')
P=Path('/dev/shm/pump-cto-settings-s3/work/native-run/candidate-review/review_actual.py')
s=P.read_text();prefix=s[:s.index("unstripped,candidate=raw(A/'unstripped.so'),raw(A/'candidate.so')")]
prefix=prefix.replace('Review actualS3 receipts and map; never invokes compiler, SDK, scorer or VM.','Fixed one-run S3 diagnostic admission. Stdlib only; no project/compiler/scorer/VM execution.')
prefix=prefix.replace("import csv\n","import ast\nimport csv\n")
prefix=prefix.replace("ROOT = Path('/dev/shm/pump-cto-settings-s3')","ROOT = Path('/dev/shm/pump-cto-settings-s3-ir')")
prefix=prefix.replace("RUN = ROOT/'work/native-run'","RUN = ROOT/'work/ir-run'")
prefix=prefix.replace("OUT = RUN/'candidate-review'","OUT = RUN/'independent-admission'")
prefix=prefix.replace("OP = 'd95abdd9a72bd492adc4cb8b11f329e72e9222db'","OP = '445aa99c55668ba8ae210d3c648b134f6be4440f'")
prefix=prefix.replace('RUN_ID = 41172052790','RUN_ID = 41173731317')
prefix=prefix.replace("zip_path = RUN/'raw-artifact.zip'","release=load(OUT/'RELEASE.json')\nassert release['run']==RUN_ID and release['attempt']==1 and release['operationalCommit']==OP and release['source']==BASE and release['rootAcquiredAndCrcAdmitted'] is True\nassert not (OUT/'REVIEW.json').exists() and not (OUT/'ADMISSION-FAILURE.json').exists(), 'one admission attempt only'\nzip_path = RUN/'raw-artifact.zip'")
prefix=prefix.replace("len(zip_raw)==2534297 and sha(zip_raw)=='0f1a82695dd41525fffbebe667c3067062a9a1fd1fd3fb4b70cbdb054965bdda'","len(zip_raw)==release['zipBytes'] and sha(zip_raw)==release['zipSha256']")
prefix=prefix.replace("api['id']==13031054922","api['id']==release['artifactId']")
prefix=prefix.replace("'all45 ZIP CRCs and extracted member bytes',len(members)==45","'all diagnostic ZIP CRCs and exact extracted member bytes',len(members)>=45")
prefix=prefix.replace("{p.relative_to(A).as_posix() for p in A.rglob('*') if p.is_file()}","{p.relative_to(A).as_posix() for p in A.rglob('*') if p.is_file() or p.is_symlink()}")
prefix=prefix.replace("data == raw(A/item.filename)","not (A/item.filename).is_symlink() and data == raw(A/item.filename)")
prefix=prefix.replace("ROOT/'work/native-prep/PREPARATION-RESULT.json'","ROOT/'work/diagnostic-prep/PREPARATION-RESULT.json'")
prefix=prefix.replace("['operationalFiles']","['opsFiles']")
start=prefix.index("public = load(OUT/'PUBLIC-OPERATIONAL.json')")
end=prefix.index("check('actual operational records equal prepared files'",start)
prefix=prefix[:start]+"dispatch=load(RUN/'DISPATCH.json')\ncheck('root operational dispatch binds exact frozen source and reviewed four-file OPS',dispatch['operationalCommit']==OP and dispatch['source']==BASE and dispatch['review']=='b3e8dba422f1769035a2c69de79880af78cb10c7219cb6da92462920babc7839' and dispatch['exitCode']==0)\n"+prefix[end:]
prefix=prefix.replace('current-native-control/pump_current_control.py','current-native-ir-capture/pump_ir_control.py')
prefix=prefix.replace('work/native-prep/preflight/evidence','work/diagnostic-prep/preflight/evidence')
prefix=prefix.replace('pump-candidate-identity-work/link.map','pump-s3-diagnostic-work/link.map')
prefix=prefix.replace("physical = ROOT/row['path']","physical = ROOT/row['path']\n    assert physical.is_symlink() if row['mode']=='120000' else physical.is_file() and not physical.is_symlink()")
suffix=r'''
NORMAL=ROOT/'work/s3-normal-reference';PARENTREF=ROOT/'work/current13fe-reference'
prepared=load(ROOT/'work/diagnostic-prep/PREPARATION-RESULT.json')
assert prepared['frozenManifestSha256']=='8bb16cf3ade9335b327d572898ae0328c7bf4d8985ae246754f5181a87e1858f'
bindings=load(ROOT/'work/diagnostic-prep/ACTUAL-S3-BINDING.json')
for folder,table in [(NORMAL,bindings['normalSelfReference']['files']),(PARENTREF,bindings['baseline']['files'])]:
 assert {p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file() or p.is_symlink()}==set(table)
 for name,row in table.items():
  p=folder/name;assert p.is_file() and not p.is_symlink();b=raw(p);assert len(b)==row['bytes'] and sha(b)==row['sha256']
check('actual normalS3 self45 and13fe baseline43 exact pinned members',len(bindings['normalSelfReference']['files'])==45 and len(bindings['baseline']['files'])==43)
normal_result=load(NORMAL/'RESULT.json')
check('normal S3 native SUCCESS and no-loss remain authenticated',normal_result['base']==BASE and all(normal_result[k] is True for k in ('sourceUnchanged','registrySourceUnchanged','toolInputsUnchanged','coldTarget','noNormalizedLosses','noRawLosses')) and not (NORMAL/'FAILURE.json').exists())
check('complete logical registry equals normal S3 before and after',registry==load(NORMAL/'registry-source-inputs.json')==load(NORMAL/'registry-source-inputs-after.json'))
for name in ('program-source-inputs.json','toolchain-source-inputs.json','source-inputs.json','compiled-workspace-inputs.json'):
 assert a(name)==load(NORMAL/name)
check('diagnostic source141 CORE236 selected/stage142 equal normal S3',True)
reference_admission=a('reference-admission.json');trace_admission=a('s3-reference-admission.json')
check('both hosted reference-admission tables and role identities',reference_admission['base']=='13fe4536be64d8c5c10f8905e9d2236f423ac4f4' and reference_admission['run']==41170683278 and reference_admission['artifactId']==13031166975 and reference_admission['files']==bindings['baseline']['files'] and trace_admission['run']==41172052790 and trace_admission['artifactId']==13031054922 and trace_admission['files']==bindings['normalSelfReference']['files'] and trace_admission['sourceAndCoreAndStageEqual'] is True)
unstripped,candidate=raw(A/'unstripped.so'),raw(A/'candidate.so');normal_unstripped,normal_candidate=raw(NORMAL/'unstripped.so'),raw(NORMAL/'candidate.so')
check('complete stripped bytes equal actual normal S3',candidate==normal_candidate and sha(candidate)=='31ece96dc7eee70c8c7cc16ba401d63e668c3725a8d1c411834fd9494d8e01d0')
us,headers=elf_sections(unstripped);ns,_=elf_sections(normal_unstripped);cs,_=elf_sections(candidate)
assert set(us)==set(ns)
section_equality={name:unstripped[row['offset']:row['offset']+row['size']]==normal_unstripped[ns[name]['offset']:ns[name]['offset']+ns[name]['size']] for name,row in us.items()}
check('all non-symbol section payloads equal normal S3',all(equal for name,equal in section_equality.items() if name not in ('.symtab','.strtab')))
def symbols(blob,sections):
 table=sections['.symtab'];strings=sections['.strtab'];text=blob[strings['offset']:strings['offset']+strings['size']]
 assert table['entsize']==24 and table['size']%24==0
 result=[]
 for position in range(table['offset'],table['offset']+table['size'],24):
  name,info,other,section,value,size=struct.unpack_from('<IBBHQQ',blob,position);end=text.find(b'\0',name)
  assert end>=name;result.append((text[name:end].decode(),info,other,section,value,size))
 return result
actual_symbols,normal_symbols=symbols(unstripped,us),symbols(normal_unstripped,ns)
check('all symbol numeric fields equal with explicit domain count',len(actual_symbols)==len(normal_symbols) and all(x[1:]==y[1:] for x,y in zip(actual_symbols,normal_symbols)))
functions=sorted(x for x in actual_symbols if x[1]&15==2);normal_functions=sorted(x for x in normal_symbols if x[1]&15==2)
check('every semantic function symbol equal',functions==normal_functions)
name_changes=[{'index':i,'actual':list(x),'reference':list(y)} for i,(x,y) in enumerate(zip(actual_symbols,normal_symbols)) if x!=y]
check('only local OBJECT names may differ',all(x['actual'][1]==x['reference'][1]==1 and x['actual'][0]!=x['reference'][0] and x['actual'][1:]==x['reference'][1:] for x in name_changes))
check('saved complete local-name-difference record exact',a('local-symbol-name-differences.json')==name_changes)
for name,row in output_rows.items():assert row['address']==us[name]['addr']==cs[name]['addr'] and row['size']==us[name]['size']==cs[name]['size']
check('all seven allocated section map geometries agree',len(output_rows)==7)
for name,row in cs.items():
 if row['flags']&2:
  other=us[name];assert unstripped[other['offset']:other['offset']+other['size']]==candidate[row['offset']:row['offset']+row['size']]
check('stripped and unstripped allocated payload equality',True)
S='_ZN14pump_recovered9admin_cto7execute17h3bd6d7f34f2e30d7E'
targets=[x for x in actual_symbols if x[0]==S and x[1]&15==2];assert len(targets)==1
target=targets[0];target_map=[x for x in entries if 'admin_cto7execute' in x['section']]
assert len(target_map)==1 and target[-2:]==(0x22a10,27400) and target_map[0]['address']==target[-2] and target_map[0]['bytes']==target[-1]
target_offset=us['.text']['offset']+target[-2]-us['.text']['addr'];target_body=unstripped[target_offset:target_offset+target[-1]]
check('same normal-S3 target body and extent',sha(target_body)=='a8bf685d74da8226d39a8fc9f17eb0100b84a56db69415f241bb2a2b3f75e570')
score=a('score.json');summary=score['summary'];windows=score['windows'];normal_score=load(NORMAL/'score.json');parent_score=load(PARENTREF/'score.json')
domain={r['original_start']:int(r['bytes']) for r in csv.DictReader(io.StringIO(raw(ROOT/'reconstruction/base/functions.tsv').decode()),delimiter='\t') if r['program']=='pump' and r['variant']=='selected'}
check('all1035 saved official rows equal normal S3 and parent; no scorer executed',len(windows)==1035 and windows==normal_score['windows']==parent_score['windows'] and set(windows)==set(domain))
check('saved score types/arithmetic and actual image hashes',all(row['bytes']==domain[k] and type(row['raw']) is bool and type(row['normalized']) is bool for k,row in windows.items()) and summary['total']==1035 and summary['raw']==sum(x['raw'] for x in windows.values())==1034 and summary['normalized']==sum(x['normalized'] for x in windows.values())==1034 and summary['matched_text_bytes']==sum(x['bytes'] for x in windows.values() if x['normalized'])==1764808 and sha(unstripped)==summary['candidate_sha256']==build['unstripped_sha256']==result['unstrippedSha256'] and sha(candidate)==build['candidate_sha256']==result['candidateSha256'] and summary==result['summary'])
summary_differences={k:{'actual':summary.get(k),'reference':normal_score['summary'].get(k)} for k in summary.keys()|normal_score['summary'].keys() if summary.get(k)!=normal_score['summary'].get(k)}
assert set(summary_differences)<={'candidate_sha256'}
for kind in ('normalized','raw'):
 gains=['0x%x'%int(k) for k in sorted(windows,key=int) if windows[k][kind] and not parent_score['windows'].get(k,{}).get(kind,False)]
 losses=['0x%x'%int(k) for k in sorted(windows,key=int) if not windows[k][kind] and parent_score['windows'].get(k,{}).get(kind,False)]
 prefix='' if kind=='normalized' else 'raw_';assert summary[prefix+'gains']==gains==[] and summary[prefix+'losses']==losses==[]
comparison=a('CANDIDATE-COMPARISON.json')
check('actual saved no-loss comparison remains SUCCESS',comparison['sourceCommit']==BASE and comparison['sourceSha256']==source['sha256'] and comparison['referenceBase']=='13fe4536be64d8c5c10f8905e9d2236f423ac4f4' and comparison['referenceRun']==41170683278 and comparison['referenceArtifactId']==13031166975 and comparison['summary']==summary and comparison['changedRows']=={} and comparison['allRowsEqual'] and comparison['fullRowsCompared']==result['fullScoreRowsCompared']==1035 and all(comparison[k] is result[k] is True for k in ('noNormalizedLosses','noRawLosses')))
cap=a('capture-result.json');stages=(('After','finalize-isel'),('Before','greedy'),('After','greedy'),('After','virtregrewriter'),('After','block-placement'))
llvm_args=('-filter-print-funcs='+S,'-print-before=jump-threading','-print-after=jump-threading','-print-after=finalize-isel','-print-before=greedy','-print-after=greedy','-print-after=virtregrewriter','-print-after=block-placement')
extra=['--emit=link,llvm-ir']+[x for v in llvm_args for x in ('-C','llvm-args='+v)]
assert cap['symbol']==S and cap['sourceSha256']==source['sha256'] and cap['rootAdditionalArguments']==extra and cap['rootOnlyCargoRustcArguments'] is True and len(cap['calls'])==1
call=cap['calls'][0];work=PurePosixPath(cold['target']).parent;sdk=PurePosixPath(native['path']).parents[2];env=call['compilerEnvironment']
original=[str(sdk/'rust/bin/cargo'),'build','--manifest-path',str(work/'ws/programs/pump/Cargo.toml'),'--release','--target','sbpf-solana-solana','--locked','--offline']
assert call['originalArgv']==original and call['diagnosticArgv']==[original[0],'rustc',*original[2:],'--lib','--',*extra]
assert call['argvDelta']=={'replacedIndex':1,'from':'build','to':'rustc','appended':['--lib','--',*extra]} and call['cwd']==str(work/'ws') and call['originalKeywordNames']==['cwd','env','timeout'] and call['originalPositionalCount']==0 and call['timeout'] is None
assert env['CARGO_TARGET_DIR']==cold['target'] and env['CARGO_TARGET_SBPF_SOLANA_SOLANA_RUSTFLAGS']=='-Zremap-cwd-prefix=' and env['PYTHONDONTWRITEBYTECODE']=='1' and env['PUMP_LINK_ROOT_CRATE']=='pump_recovered' and env['PUMP_LINK_SCRIPT']==str(work/'ws/programs/pump/link/ordered.ld') and env['PUMP_LINK_SCRIPT_SHA256']==link['programScript']['sha256']
assert env['RUSTC'] in tools and env['RUSTC_WRAPPER'].endswith('/reconstruction/harness/pump_link_rustc.sh') and env['PUMP_LINK_LLD'].endswith('/rust/lib/rustlib/aarch64-apple-darwin/bin/rust-lld') and env['PUMP_LINK_MAP']==str(work/'link.map') and env['PUMP_LINK_RECEIPT']==str(work/'link-receipt.json')
check('exactly one frozen compiler forwarding and fixed root-only args',True)
log_raw=raw(A/'build.log');heads=list(re.finditer(rb'(?m)^(?:[#;] )?\*\*\* IR Dump [^\r\n]+',log_raw))
assert cap['rawBuildLogPresent'] is True and cap['rawBuildLogSha256']==sha(log_raw) and cap['rawBuildLogBytes']==len(log_raw) and len(cap['passDumps'])==len(heads)
def ir_extent(blob):
 definitions=list(re.finditer(rb'(?m)^define\b[^\n]*@"?'+re.escape(S.encode())+rb'"?\(',blob))
 if len(definitions)!=1:return None
 begin=definitions[0].start();end=re.search(rb'(?m)^\}',blob[begin:])
 return (begin,begin+end.end()) if end else None
derived=[]
for i,head in enumerate(heads):
 end=heads[i+1].start() if i+1<len(heads) else len(log_raw);part=log_raw[head.start():end];timing_match=re.search(rb'IR Dump (Before|After)\b',head.group());assert timing_match
 timing=timing_match[1].decode();pass_match=re.search(rb'\((finalize-isel|greedy|virtregrewriter|block-placement|jump-threading)\)',head.group())
 phase=pass_match[1].decode() if pass_match else None
 if phase is None and re.fullmatch(rb'; \*\*\* IR Dump (?:Before|After) JumpThreadingPass on '+re.escape(S.encode())+rb' \*\*\*',head.group()):phase='jump-threading'
 if phase is None and re.search(rb'IR Dump (Before|After) Jump Threading(?: on [^\r\n]+)? \*\*\*:?[ \t]*$',head.group()):phase='jump-threading'
 assert phase is not None,'unqualified raw heading; no fallback/search'
 stem='dump-%03d-%s-%s'%(i+1,timing.lower(),phase);filename='compiler-dumps/'+stem+'.txt';assert raw(A/filename)==part
 opening=b'# Machine code for function '+S.encode()+b':';closing=b'# End machine code for function '+S.encode()+b'.';machine=part.count(opening)==part.count(closing)==1 and part.find(opening)<part.find(closing)
 extent=ir_extent(part);target_ir=None
 if extent:
  target_file='compiler-dumps/'+stem+'-target.ll';target_bytes=part[extent[0]:extent[1]];assert raw(A/target_file)==target_bytes
  target_ir={'file':target_file,'rawLogStart':head.start()+extent[0],'rawLogEnd':head.start()+extent[1],'bytes':len(target_bytes),'sha256':sha(target_bytes)}
 row={'file':filename,'bytes':len(part),'sha256':sha(part),'rawLogOffset':head.start(),'rawLogEnd':end,'heading':head.group().decode(),'timing':timing,'pass':phase,'containsTargetSymbol':S.encode() in part,'completeTargetMachineFunction':machine,'completeTargetIrFunction':extent is not None,'targetIr':target_ir}
 assert cap['passDumps'][i]==row;derived.append(row)
machine_dumps=[x for x in derived if x['pass'] in {s for _,s in stages}];jt=[x for x in derived if x['pass']=='jump-threading']
requested=[{'timing':t,'pass':p,'files':[x['file'] for x in machine_dumps if x['timing']==t and x['pass']==p and x['completeTargetMachineFunction']]} for t,p in stages]
check('five complete ordered target machine stages',len(machine_dumps)==5 and [(x['timing'],x['pass']) for x in machine_dumps]==list(stages) and all(len(x['files'])==1 for x in requested) and cap['requestedStages']==requested and cap['machineDumps']==machine_dumps)
assert len(jt)>=4 and len(jt)%2==0 and all(x['timing']==('Before' if i%2==0 else 'After') and x['completeTargetIrFunction'] for i,x in enumerate(jt))
pairs=[{'iteration':i//2+1,'before':jt[i]['file'],'after':jt[i+1]['file'],'beforeTarget':jt[i]['targetIr'],'afterTarget':jt[i+1]['targetIr'],'complete':True} for i in range(0,len(jt),2)]
check('complete ordered JT pairs and every metadata/file/heading binding',cap['jumpThreadingDumps']==jt and cap['jumpThreadingPairs']==pairs and cap['minimumJumpThreadingPairs']==2)
modules=[]
for row in cap['llvmIr']:
 data=raw(A/row['file']);extent=ir_extent(data)
 assert set(row)=={'file','bytes','sha256','containsTargetDefinition'} and row['bytes']==len(data) and row['sha256']==sha(data) and row['containsTargetDefinition']==(extent is not None)
 if extent:modules.append({'file':row['file'],'rawModuleSha256':sha(data),'rawModuleStart':extent[0],'rawModuleEnd':extent[1],'bytes':extent[1]-extent[0],'sha256':sha(data[extent[0]:extent[1]])})
check('optimized target definition and complete root module retained',len(modules)>=1 and {x['file'] for x in cap['llvmIr']}=={p.relative_to(A).as_posix() for p in (A/'llvm-ir').rglob('*') if p.is_file()})
check('capture completion guards accurately report complete actual outputs',all(cap[k] is True for k in ('compilerCompleted','buildOk','captureComplete','sourceUnchanged','allMachineStagesObserved','allRequestedStagesObserved','jumpThreadingPairingValid','targetDefinitionRetained')))
diag=a('DIAGNOSTIC-COMPARISON.json')
check('hosted identity and capture report independently reproduced',all(diag[k] is True for k in ('attributionQualified','codeIdentityQualified','completeStrippedBytesEqual','nonSymbolSectionPayloadsEqual','semanticFunctionSymbolsEqual','symbolNumericFieldsEqual','localSymbolDifferencesNamesOnly','full1035RowsEqual','targetDefinitionRetained','allMachineStagesObserved','jumpThreadingPairingValid','allRequestedStagesObserved','captureComplete','compilerCompleted','buildOk')) and diag['referenceRun']==41172052790 and diag['referenceArtifactId']==13031054922 and diag['symbolNameDifferenceCount']==len(name_changes) and diag['scoreSummaryDifferences']==summary_differences and diag['captureResultSha256']==sha(raw(A/'capture-result.json')) and diag['jumpThreadingPairCount']==len(pairs) and diag['actualCompilerCommands']==cap['calls'])
for name,row in diag['sectionPayloads'].items():assert row['equal']==section_equality[name] and row['actualSha256']==sha(unstripped[us[name]['offset']:us[name]['offset']+us[name]['size']]) and row['referenceSha256']==sha(normal_unstripped[ns[name]['offset']:ns[name]['offset']+ns[name]['size']])
assert set(diag['sectionPayloads'])==set(us)
assert diag['fullElfHashesEqual']=={'unstripped':sha(unstripped)==sha(normal_unstripped),'stripped':True} and diag['referenceUnstrippedSha256']==sha(normal_unstripped) and diag['actualUnstrippedSha256']==sha(unstripped) and diag['referenceStrippedSha256']==diag['actualStrippedSha256']==sha(candidate)
assert diag['captureMethodSha256']==op_by_path['reconstruction/pump-main/lanes/current-native-ir-capture/capture.py']['sha256']
assert diag['targetSymbol']==S and diag['referenceSourceSha256']==source['sha256'] and diag['fullScoreSummaryEqual']==(summary==normal_score['summary'])
expected_members=set(bindings['normalSelfReference']['files'])|{'capture-result.json','local-symbol-name-differences.json','DIAGNOSTIC-COMPARISON.json','s3-reference-admission.json','s3-reference-target-symbol.json'}|{x['file'] for x in cap['llvmIr']}|{x['file'] for x in derived}|{x['targetIr']['file'] for x in jt}
check('exact complete diagnostic artifact member domain',set(members)==expected_members)
run=load(RUN/'run-final.json');jobs=load(RUN/'jobs-final.json')['jobs'];steps=load(RUN/'steps-final.json')['steps']
check('actual attempt1 run job and steps conclusion',run['id']==RUN_ID and run['head_sha']==OP and run['run_attempt']==1 and run['conclusion']==release['providerConclusion']=='success' and len(jobs)==1 and jobs[0]['conclusion']=='success' and all(x['status']=='completed' and x['conclusion']=='success' for x in steps) and 'FAILURE.json' not in members)
for name,value in list(inputs.items()):assert len((ROOT/name).read_bytes())==value['bytes'] and sha((ROOT/name).read_bytes())==value['sha256']
report={'verdict':'PASS independent actual fixed-S3 diagnostic code/trace/provenance admission','source':BASE,'operationalCommit':OP,'run':RUN_ID,'artifactId':api['id'],'checks':checks,'images':{'unstripped.so':sha(unstripped),'candidate.so':sha(candidate)},'referenceUnstrippedSha256':sha(normal_unstripped),'completeUnstrippedEqual':unstripped==normal_unstripped,'completeStrippedEqual':True,'sectionPayloadEquality':section_equality,'allFunctionSymbolsEqual':True,'allSymbolNumericFieldsEqual':True,'localObjectNameDifferences':len(name_changes),'CTO':{'symbol':S,'address':target[-2],'bytes':target[-1],'bodySha256':sha(target_body)},'score':{'raw':1034,'normalized':1034,'total':1035,'allRowsEqualNormalS3':True,'allRowsEqual13fe':True,'scorerRerun':False},'capture':{'compilerCalls':1,'jumpThreadingPairs':len(pairs),'machineStages':5,'optimizedTargets':modules,'stages':derived},'nativeDiagnosticOutcome':'SUCCESS','normalS3NativeOutcome':'SUCCESS_NO_LOSS','sourceVerdict':'SOURCE_REJECTED_INTERNAL_METRIC','S3VmExecutions':0,'limits':['Independent stdlib read/hash/archive/ELF/provenance admission only; no project import, scorer/compiler/SDK/VM/native/test/metric repeat or network/API operation.','Remote SDK/registry and deleted private linker copy are not physically rehashed locally; recorded guards/inventory and fixed source are authenticated.','Strict stripped and saved-row identity extends the already officially rescored normal S3 binding; no new official scorer execution.','Complete same-source trace does not establish Rust source/type/bool-niche uniqueness, source gain, runtime equivalence, original whole-ELF identity, later-main transfer or any next candidate authorization. Native SUCCESS and internal source rejection/VM0 remain separate.']}
bindings_out={'source':BASE,'operationalCommit':OP,'run':RUN_ID,'artifactId':api['id'],'zip':{'bytes':len(zip_raw),'sha256':sha(zip_raw)},'members':members,'images':report['images'],'CTO':report['CTO'],'scoreRowsCanonicalSha256':sha(json.dumps(windows,sort_keys=True,separators=(',',':')).encode()),'readerReference':'REVIEW.json'}
for name,value in [('REVIEW.json',report),('REFERENCE-BINDINGS.json',bindings_out),('MAP-SELECTORS.json',{'selectors':selectors,'entries':entries,'outputs':output_rows}),('INPUTS.json',inputs)]:
 with (OUT/name).open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')
files={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(OUT.iterdir()) if p.is_file() and p.name not in ('reader.stdout','reader.stderr')}
with (OUT/'MANIFEST.json').open('x') as stream:json.dump({'status':'SEALED_INDEPENDENT_ACTUAL_ADMISSION_PASS','source':BASE,'run':RUN_ID,'files':files},stream,indent=2);stream.write('\n')
print(json.dumps({'verdict':'PASS','checks':len(checks),'reviewSha256':sha((OUT/'REVIEW.json').read_bytes()),'bindingsSha256':sha((OUT/'REFERENCE-BINDINGS.json').read_bytes()),'manifestSha256':sha((OUT/'MANIFEST.json').read_bytes()),'pairs':len(pairs),'machines':5,'localObjectNameDifferences':len(name_changes)}))
'''
body=prefix+suffix
header='"""One-run actual S3 diagnostic admission. Execute only after root ZIP release."""\nimport os,sys\nassert os.environ.get("PYTHONDONTWRITEBYTECODE")=="1" and sys.dont_write_bytecode\n'
# Keep every admission operation in one function so the once-only wrapper can
# retain a precise failure without rewriting or retrying any actual input.
reader=header+'\ndef admission():\n'+''.join('    '+line+'\n' for line in body.splitlines())+'''\nif __name__ == '__main__':
    from pathlib import Path
    import json,traceback
    folder=Path('/dev/shm/pump-cto-settings-s3-ir/work/ir-run/independent-admission')
    assert (folder/'RELEASE.json').is_file(), 'root has not released actual ZIP admission'
    try: admission()
    except BaseException as error:
        with (folder/'ADMISSION-FAILURE.json').open('x') as stream:
            original_failure=folder.parent/'artifact/FAILURE.json'
            saved_failure=json.loads(original_failure.read_text()) if original_failure.is_file() else None
            json.dump({'status':'FAILED_INDEPENDENT_ADMISSION','type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc(),'originalDiagnosticFailurePreserved':saved_failure,'inputsUnmodified':True,'noCompilerScorerVmOrMetricRepeated':True},stream,indent=2);stream.write('\\n')
        raise
'''
ast.parse(reader)
(O/'admit_actual.py').write_text(reader)
(O/'PREPARED-READER.json').write_text(json.dumps({'status':'PREPARED_NOT_EXECUTED','source':'65f0162a3dcd381df0f831082dd6732c9af4ab78','operationalCommit':'445aa99c55668ba8ae210d3c648b134f6be4440f','run':41173731317,'attempt':1,'readerSha256':hashlib.sha256(reader.encode()).hexdigest(),'qualifiedProvenanceReaderSha256':hashlib.sha256(P.read_bytes()).hexdigest(),'referenceTraceReader':'/dev/shm/pump-cto-option-c1/work/root/admission/admit_c1_trace.py','releaseRequired':'RELEASE.json missing until explicit root actual ZIP acquisition/admission','syntaxParsedOnly':True,'admissionExecutions':0,'projectImports':0,'compilerScorerSDKVmMetricsExecuted':False},indent=2)+'\n')
print(json.dumps({'status':'PREPARED_NOT_EXECUTED','readerBytes':len(reader.encode()),'readerSha256':hashlib.sha256(reader.encode()).hexdigest()}))
