"""Audit remaining expected-value constructors using metadata, not admission."""
from pathlib import Path,PurePosixPath
import ast,hashlib,json,os,re,sys
assert os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode
R=Path('/dev/shm/pump-cto-settings-s3-ir');O=R/'work/ir-run/independent-admission';A=R/'work/ir-run/artifact';P=R/'work/diagnostic-prep'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());checks=[]
def check(name,value):assert value,name;checks.append(name)
c=load(A/'capture-result.json');call=c['calls'][0];env=call['compilerEnvironment'];cold=load(A/'cold-target-inputs.json');tools=load(A/'tool-inputs-before.json');native=load(A/'native-lld-input-before.json');inventory=load(R/'reconstruction/toolchain/v1.44-macos-inventory.json')['entries']
S='_ZN14pump_recovered9admin_cto7execute17h3bd6d7f34f2e30d7E';work=PurePosixPath(cold['target']).parent
cargo=[path for path in tools if path.endswith('/v1.44/platform-tools/rust/bin/cargo')]
check('one inventory-bound v1.44 cargo record',len(cargo)==1 and tools[cargo[0]]==inventory['rust/bin/cargo']['sha256']=='cd27e4113fc155b5e79fca97c1cc5447ef89d1c8ce3d0e1e5679d2dd7a9ab0ef')
sdk=PurePosixPath(cargo[0]).parents[2]
ft=ast.parse((R/'reconstruction/harness/fastbuild.py').read_text());sdk_node=next(n for n in ft.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='SDK')
check('frozen fastbuild SDK recipe uses home-cache v1.44 prefix',ast.unparse(sdk_node.value)=="Path.home() / '.cache/solana/v1.44/platform-tools'")
prior=load(Path('/dev/shm/pump-cto-option-c1/work/diagnostic-run/artifact/capture-result.json'))['calls'][0]
check('exact Cargo SDK path equals qualified C1',str(sdk/'rust/bin/cargo')==cargo[0]==prior['originalArgv'][0])
llvm_args=('-filter-print-funcs='+S,'-print-before=jump-threading','-print-after=jump-threading','-print-after=finalize-isel','-print-before=greedy','-print-after=greedy','-print-after=virtregrewriter','-print-after=block-placement')
extra=['--emit=link,llvm-ir']+[x for v in llvm_args for x in ('-C','llvm-args='+v)]
original=[str(sdk/'rust/bin/cargo'),'build','--manifest-path',str(work/'ws/programs/pump/Cargo.toml'),'--release','--target','sbpf-solana-solana','--locked','--offline']
check('complete original argv manifest target flags order exact',call['originalArgv']==original)
check('complete diagnostic argv and delta exact',call['diagnosticArgv']==[original[0],'rustc',*original[2:],'--lib','--',*extra] and call['argvDelta']=={'replacedIndex':1,'from':'build','to':'rustc','appended':['--lib','--',*extra]} and c['rootAdditionalArguments']==extra)
check('cwd positional keyword timeout forwarding metadata exact',call['cwd']==str(work/'ws') and call['originalKeywordNames']==['cwd','env','timeout'] and call['originalPositionalCount']==0 and call['timeout'] is None)
link=load(A/'link-inputs.json')
check('all remaining compiler env derived path constructors exact',env['CARGO_TARGET_DIR']==cold['target'] and env['CARGO_TARGET_SBPF_SOLANA_SOLANA_RUSTFLAGS']=='-Zremap-cwd-prefix=' and env['PYTHONDONTWRITEBYTECODE']=='1' and env['PUMP_LINK_ROOT_CRATE']=='pump_recovered' and env['PUMP_LINK_SCRIPT']==str(work/'ws/programs/pump/link/ordered.ld') and env['PUMP_LINK_SCRIPT_SHA256']==link['programScript']['sha256'] and env['RUSTC'] in tools and env['RUSTC_WRAPPER'].endswith('/reconstruction/harness/pump_link_rustc.sh') and env['PUMP_LINK_LLD'].endswith('/rust/lib/rustlib/aarch64-apple-darwin/bin/rust-lld') and env['PUMP_LINK_MAP']==str(work/'link.map') and env['PUMP_LINK_RECEIPT']==str(work/'link-receipt.json'))
stages=(('After','finalize-isel'),('Before','greedy'),('After','greedy'),('After','virtregrewriter'),('After','block-placement'))
records=c['passDumps'];parsed=[]
for i,row in enumerate(records):
 h=row['heading'].encode();tm=re.search(rb'IR Dump (Before|After)\b',h);assert tm;timing=tm[1].decode();pm=re.search(rb'\((finalize-isel|greedy|virtregrewriter|block-placement|jump-threading)\)',h);phase=pm[1].decode() if pm else None
 if phase is None and re.fullmatch(rb'; \*\*\* IR Dump (?:Before|After) JumpThreadingPass on '+re.escape(S.encode())+rb' \*\*\*',h):phase='jump-threading'
 if phase is None and re.search(rb'IR Dump (Before|After) Jump Threading(?: on [^\r\n]+)? \*\*\*:?[ \t]*$',h):phase='jump-threading'
 assert phase is not None and timing==row['timing'] and phase==row['pass']
 stem='dump-%03d-%s-%s'%(i+1,timing.lower(),phase);assert row['file']=='compiler-dumps/'+stem+'.txt'
 if row['targetIr']:assert row['targetIr']['file']=='compiler-dumps/'+stem+'-target.ll'
 parsed.append((timing,phase))
check('all known heading metadata and dump target filename constructors agree',len(parsed)==9)
machine=[x for x in records if x['pass'] in {p for _,p in stages}];jt=[x for x in records if x['pass']=='jump-threading']
requested=[{'timing':t,'pass':p,'files':[x['file'] for x in machine if x['timing']==t and x['pass']==p and x['completeTargetMachineFunction']]} for t,p in stages]
check('machine metadata table constructors exact',len(machine)==5 and [(x['timing'],x['pass']) for x in machine]==list(stages) and requested==c['requestedStages'] and machine==c['machineDumps'])
pairs=[{'iteration':i//2+1,'before':jt[i]['file'],'after':jt[i+1]['file'],'beforeTarget':jt[i]['targetIr'],'afterTarget':jt[i+1]['targetIr'],'complete':True} for i in range(0,len(jt),2)]
check('actual four JT snapshots construct exactly two pairs',len(jt)==4 and len(pairs)==2 and pairs==c['jumpThreadingPairs'] and jt==c['jumpThreadingDumps'])
check('module metadata schema and paths as expected',len(c['llvmIr'])>=1 and all(set(x)=={'file','bytes','sha256','containsTargetDefinition'} and (A/x['file']).is_file() for x in c['llvmIr']))
binding=load(P/'ACTUAL-S3-BINDING.json');download=load(R/'work/ir-run/DOWNLOAD-VERIFIED.json')
expected=set(binding['normalSelfReference']['files'])|{'capture-result.json','local-symbol-name-differences.json','DIAGNOSTIC-COMPARISON.json','s3-reference-admission.json','s3-reference-target-symbol.json'}|{x['file'] for x in c['llvmIr']}|{x['file'] for x in records}|{x['targetIr']['file'] for x in jt}
check('complete member-domain constructor agrees with root64 metadata',len(expected)==64 and expected==set(download['files']))
d=load(A/'DIAGNOSTIC-COMPARISON.json');score=load(A/'score.json');reference=load(R/'work/s3-normal-reference/score.json')
summary_diff={k:{'actual':score['summary'].get(k),'reference':reference['summary'].get(k)} for k in score['summary'].keys()|reference['summary'].keys() if score['summary'].get(k)!=reference['summary'].get(k)}
check('remaining report summary source target pair constructors agree',d['scoreSummaryDifferences']==summary_diff and d['fullScoreSummaryEqual']==(score['summary']==reference['summary']) and d['targetSymbol']==S and d['referenceSourceSha256']==c['sourceSha256'] and d['jumpThreadingPairCount']==2 and d['actualCompilerCommands']==c['calls'])
record={'status':'PASS_EXPECTED_VALUE_CONSTRUCTOR_AUDIT_ONLY_NOT_ACTUAL_ADMISSION','checks':checks,'wrongSDKConstructor':'PurePosixPath(native[path]).parents[2] incorrectly walks the private hybrid Rust LLD directory, not the fixed SDK root','nativeLld':native,'expectedCargo':cargo[0],'fixedSdk':str(sdk),'cargoInventorySha256':tools[cargo[0]],'fastbuildSha256':sha(R/'reconstruction/harness/fastbuild.py'),'qualifiedC1Cargo':prior['originalArgv'][0],'exactExpectedArgv':original,'exactExpectedDiagnosticArgv':call['diagnosticArgv'],'derivedWork':str(work),'actualSnapshotCount':len(jt),'actualPairCount':len(pairs),'actualMachineStageCount':len(machine),'receiptOutputNote':'Reader final manifest must exclude in-flight continuation/constructor stdout and stderr, as it already excludes reader.stdout/reader.stderr. This is an output receipt path fix only, no artifact predicate change.','sourceCodeTraceGuardsRelaxed':False,'rawTraceOrELFIdentityRecomputedHere':False,'readerContinuationsExecutedHere':0,'nativeCompilerScorerSDKVmMetricExecutions':0}
(O/'CONSTRUCTOR-AUDIT.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':record['status'],'checks':len(checks),'auditSha256':sha(O/'CONSTRUCTOR-AUDIT.json'),'expectedCargo':cargo[0]}))
