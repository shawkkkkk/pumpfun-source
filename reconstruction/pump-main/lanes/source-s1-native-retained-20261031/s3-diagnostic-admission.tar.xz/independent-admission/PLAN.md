# Independent admission for the one S3 diagnostic

Scope is only run41173731317, attempt1, operational445aa99c55668ba8ae210d3c648b134f6be4440f,
source65f0162a3dcd381df0f831082dd6732c9af4ab78. The source remains rejected for
its saved internal metric; normal S3 native SUCCESS/no-loss and S3 VMheld0 are
separate facts. No next candidate or source acceptance is implied.

The admission reader remains unexecuted until root downloads the actual ZIP to
work/ir-run/raw-artifact.zip, admits provider identity/digest/CRC/safe members,
and explicitly releases it. RELEASE.json will then contain only root-supplied
run/attempt/OP/artifact ID/ZIP size/SHA and provider conclusion; no credentials.
No SDK/compiler/scorer/VM/project-module import or network call is permitted.

The bounded stdlib reader reuses the qualified C1 diagnostic checks and the
already reviewed S3 provenance/link-map admission. It independently binds:

- Exact transport/provider/root member identities, frozen four OPS, source141,
  CORE236, selected source and maintained142 stage, both source archives.
- Two full bootstrap receipts, SDK pins/inventory declarations, registry/tool/
  native LLD before-after, cold target/templates, fresh local fingerprints,
  fixed link inputs,555 selectors/full map and allocated ELF geometry.
- Actual normal S3 self-reference45 and separate13fe baseline43, including
  original normal-S3 SUCCESS/no-loss and unchanged1035 saved score rows.
- Complete stripped bytes; all non-symbol section payloads; exact semantic
  function and numeric-symbol rows. Only names of STB_LOCAL/STT_OBJECT may
  differ. Full unstripped identity is recorded separately, never required.
- Exactly one frozen cargo-build to cargo-rustc forwarding event and only the
  known root emit/filter/JT/five-machine flags. Raw argv, env and delta bind.
- Actual raw headings, ordered complete JT before/after pairs, five complete
  machine bodies, optimized target definition, retained module and raw-log
  hashes/offsets, exact saved slices and metadata. No zip-shortening admission.

The reader validates saved score domain/arithmetic and byte/row identity with
already officially rescored normal S3; it does not rerun the official scorer.
It retains original diagnostic failure if present and writes its independent
code/trace conclusion separately. An admission failure is preserved explicitly.
No native rerun, flag/parser search, IR change, source change or publication.

Preparation is not actual admission. Root alone acquires and releases the
artifact. The admission is executed once after that release; raw inputs remain
unchanged. No provider digest or artifact ID is guessed in advance.
