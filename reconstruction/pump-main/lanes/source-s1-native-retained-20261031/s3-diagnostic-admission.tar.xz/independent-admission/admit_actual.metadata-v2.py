"""One-run actual S3 diagnostic admission. Execute only after root ZIP release."""
import os,sys
assert os.environ.get("PYTHONDONTWRITEBYTECODE")=="1" and sys.dont_write_bytecode

def admission():
    """Fixed one-run S3 diagnostic admission. Stdlib only; no project/compiler/scorer/VM execution."""
    import ast
    import csv
    import fnmatch
    import hashlib
    import io
    import json
    import os
    from pathlib import Path, PurePosixPath
    import re
    import struct
    import tarfile
    import zipfile
    
    ROOT = Path('/dev/shm/pump-cto-settings-s3-ir')
    RUN = ROOT/'work/ir-run'
    A = RUN/'artifact'
    OUT = RUN/'independent-admission'
    BASE = '65f0162a3dcd381df0f831082dd6732c9af4ab78'
    OP = '445aa99c55668ba8ae210d3c648b134f6be4440f'
    RUN_ID = 41173731317
    checks, inputs = [], {}
    
    
    def sha(raw):
        return hashlib.sha256(raw).hexdigest()
    
    
    def raw(path):
        data = path.read_bytes()
        key = str(path.relative_to(ROOT))
        value = {'bytes':len(data),'sha256':sha(data)}
        if key in inputs:
            assert inputs[key] == value, 'Input drift:'+key
        inputs[key] = value
        return data
    
    
    def load(path):
        return json.loads(raw(path))
    
    
    def a(name):
        return load(A/name)
    
    
    def check(name, condition, detail=None):
        if not condition:
            raise AssertionError(name)
        checks.append({'name':name,'pass':True,'detail':detail})
    
    
    def index(rows):
        result = {r['path']:r for r in rows}
        assert len(rows) == len(result)
        return result
    
    
    def archive_bind(name, expected):
        seen = {}
        with tarfile.open(A/name,'r:gz') as archive:
            for member in archive:
                path = PurePosixPath(member.name)
                assert member.isfile() and not path.is_absolute() and '..' not in path.parts and member.name not in seen
                data = archive.extractfile(member).read()
                row = expected[member.name]
                assert len(data) == row['bytes'] and sha(data) == row['sha256']
                assert bool(member.mode&0o111) == row.get('executable',row.get('mode')=='100755')
                seen[member.name] = {'bytes':len(data),'sha256':sha(data)}
        assert set(seen) == set(expected)
        raw(A/name)
        return len(seen)
    
    
    def elf_sections(data):
        assert data[:7] == b'\x7fELF\x02\x01\x01'
        h = struct.unpack_from('<HHIQQQIHHHHHH',data,16)
        shoff,shsize,shnum,shstr = h[5],h[10],h[11],h[12]
        assert h[0]==3 and h[1]==263 and h[2]==1 and h[7]==64 and h[8]==56 and h[9]==4
        assert shsize == 64 and shoff+shsize*shnum <= len(data)
        headers = [struct.unpack_from('<IIQQQQIIQQ',data,shoff+i*shsize) for i in range(shnum)]
        names = data[headers[shstr][4]:headers[shstr][4]+headers[shstr][5]]
        result = {}
        for row in headers:
            name = names[row[0]:names.index(b'\0',row[0])].decode()
            assert name not in result
            result[name] = {'type':row[1],'flags':row[2],'addr':row[3],'offset':row[4],'size':row[5],'link':row[6],'entsize':row[9]}
        return result,headers
    
    
    release=load(OUT/'RELEASE.json')
    assert release['run']==RUN_ID and release['attempt']==1 and release['operationalCommit']==OP and release['source']==BASE and release['rootAcquiredAndCrcAdmitted'] is True
    assert not (OUT/'REVIEW.json').exists() and not (OUT/'ADMISSION-CONTINUATION-FAILURE.json').exists(), 'one root-released metadata continuation only'
    assert sha(raw(OUT/'ADMISSION-FAILURE.json'))=='4345dafd54cc9f2d10244f925222aa208de042f9bf4fbb23e367a9f6c6ad40b3', 'original reader failure must remain unchanged'
    continuation=load(OUT/'CONTINUATION-RELEASE.json')
    assert continuation['run']==RUN_ID and continuation['operationalCommit']==OP and continuation['metadataAdapterContinuationAuthorized'] is True
    zip_path = RUN/'raw-artifact.zip'
    zip_raw = raw(zip_path)
    check('released ZIP SHA and size',len(zip_raw)==release['zipBytes'] and sha(zip_raw)==release['zipSha256'])
    api = load(RUN/'ARTIFACT-METADATA.json')
    check('provider artifact identity/digest/size',api['id']==release['artifactId'] and api['digest']=='sha256:'+sha(zip_raw) and api['size_in_bytes']==len(zip_raw) and api['expired'] is False)
    members = {}
    with zipfile.ZipFile(zip_path) as archive:
        for item in archive.infolist():
            path = PurePosixPath(item.filename)
            assert not item.flag_bits&1 and ((item.external_attr>>16)&0o170000) in (0,0o100000) and not item.is_dir() and not path.is_absolute() and '..' not in path.parts and item.filename not in members
            data = archive.read(item)
            assert not (A/item.filename).is_symlink() and data == raw(A/item.filename)
            members[item.filename] = {'bytes':len(data),'sha256':sha(data)}
    check('all diagnostic ZIP CRCs and exact extracted member bytes',len(members)>=45 and set(members)=={p.relative_to(A).as_posix() for p in A.rglob('*') if p.is_file() or p.is_symlink()})
    download = load(RUN/'DOWNLOAD-VERIFIED.json')
    check('root acquisition list matches independent ZIP membership',download['sha256']==sha(zip_raw) and download['files']==members)
    ops = a('operational-inputs.json')
    prepared_ops = [{k:r[k] for k in ('path','mode','gitBlob','bytes','sha256')} for r in load(ROOT/'work/diagnostic-prep/PREPARATION-RESULT.json')['opsFiles']]
    dispatch=load(RUN/'DISPATCH.json')
    check('root operational dispatch binds exact frozen source and reviewed four-file OPS',dispatch['operationalCommit']==OP and dispatch['source']==BASE and dispatch['review']=='b3e8dba422f1769035a2c69de79880af78cb10c7219cb6da92462920babc7839' and dispatch['exitCode']==0)
    check('actual operational records equal prepared files',ops['checkout']==OP and sorted(ops['files'],key=lambda r:r['path'])==sorted(prepared_ops,key=lambda r:r['path']))
    controller = a('controller-inputs.json')
    op_by_path = index(ops['files'])
    check('actual controller/workflow and documented environment',controller['checkout']==OP and controller['runnerSha256']==op_by_path['reconstruction/pump-main/lanes/current-native-ir-capture/pump_ir_control.py']['sha256'] and controller['workflowSha256']==op_by_path['.github/workflows/qualify-pump-macos-v144.yml']['sha256'] and controller['recipe']=='identity' and controller['triple']=='sbpf-solana-solana' and controller['documentedEnvironment']['PYTHONDONTWRITEBYTECODE']=='1')
    program,core = a('program-source-inputs.json'),a('toolchain-source-inputs.json')
    source,selection,workspace = a('source-inputs.json'),a('source-selection.json'),a('compiled-workspace-inputs.json')
    check('actual source141/CORE236/selected141/workspace142 counts and revision',program['base']==core['base']==BASE and len(program['files'])==len(source['files'])==141 and len(core['files'])==236 and len(workspace)==142 and selection['allGitFiles']==selection['selectedSourceFiles']==141 and selection['excludedGitPaths']==[])
    check('actual source aggregate and preflight-builder equality',source==a('preflight-builder-source-inputs.json') and source['sha256']=='9fc3fd3c8e68d85e5bf4fcb2309694974aab3c5aaacab9741a1e0ea25c72a622' and sha(json.dumps(source['files'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())==source['sha256'])
    for row in program['files']+core['files']:
        path = PurePosixPath(row['path'])
        assert not path.is_absolute() and '..' not in path.parts
        physical = ROOT/row['path']
        assert physical.is_symlink() if row['mode']=='120000' else physical.is_file() and not physical.is_symlink()
        data = os.readlink(physical).encode() if row['mode']=='120000' else raw(physical)
        assert len(data)==row['bytes'] and sha(data)==row['sha256'] and hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['gitBlob']
        if row['mode']!='120000':assert bool(physical.stat().st_mode&0o111)==(row['mode']=='100755')
    check('377 physical frozen input byte/blob/mode bindings',True)
    check('both retained source archives match exact paths, bytes and modes',archive_bind('program-source.tar.gz',index(program['files']))==141 and archive_bind('compiled-workspace.tar.gz',workspace)==142)
    check('native program/CORE/stage equal independently reviewed physical preflight vectors',program==load(ROOT/'work/diagnostic-prep/preflight/evidence/program-source-inputs.json') and core==load(ROOT/'work/diagnostic-prep/preflight/evidence/toolchain-source-inputs.json') and workspace==load(ROOT/'work/diagnostic-prep/preflight/evidence/compiled-workspace-inputs.json'))
    build,result = a('build.json'),a('RESULT.json')
    check('build/source/recipe/stack/result guard receipts',build['ok'] is True and build['runtime_valid'] is True and build['stack_warnings']==[] and build==a('cold-build.log') and build['source_sha256']==source['sha256']==result['builderSourceSha256'] and build['recipe']=='identity' and build['triple']=='sbpf-solana-solana' and result['base']==BASE and all(result[k] is True for k in ['sourceUnchanged','registrySourceUnchanged','toolInputsUnchanged','coldTarget']))
    check('native Mac26 ARM64 host',a('host.json')['machine']=='arm64' and a('host.json')['platform'].startswith('macOS-26.'))
    tools = a('tool-inputs-before.json')
    registry = a('registry-source-inputs.json')
    native = a('native-lld-input-before.json')
    check('eight tools, complete registry and native LLD before/after bindings',len(tools)==8 and tools==a('tool-inputs-after.json') and registry==a('registry-source-inputs-after.json') and native==a('native-lld-input-after.json'),{'registry_records':len(registry)})
    inventory = load(ROOT/'reconstruction/toolchain/v1.44-macos-inventory.json')['entries']
    assert all(native[k]==inventory[native['sdkRelativePath']][k] for k in ['sha256','bytes','mode'])
    for path,digest in tools.items():
        if '/v1.44/platform-tools/' in path:assert inventory[path.split('/v1.44/platform-tools/',1)[1]]['sha256']==digest
        elif '/hybrid144/' in path:assert inventory[path.split('/hybrid144/',1)[1]]['sha256']==digest
        else:assert path.endswith('/v1.52/platform-tools/llvm/bin/llvm-objdump')
    check('all native/hybrid v1.44 tool records bind published full inventory',True)
    cold = a('cold-target-inputs.json')
    check('recorded cold target and template absence with exact source/tools',cold['base']==BASE and cold['sourceSha256']==source['sha256'] and cold['targetAbsentBeforeBuild'] is True and cold['dependencyTemplatesAbsent'] is True and cold['toolInputs']==tools)
    downloads = a('sdk-downloads.json')
    pins = {'v1.44':'66e20d135fddd70ff519baf7ff320d762957f9aedf93a50e23756db23ad79351','v1.52':'1727dfb31e833ce777d01e70cb4b3cebd26b376bf09d80527f02457d4cf6fd00'}
    check('two exact SDK archive roles and pins',len(downloads)==2 and {r['version']:r['archiveSha256'] for r in downloads}==pins and all(r['archiveSha256']==r['expectedArchiveSha256'] and r['url']=='https://github.com/anza-xyz/platform-tools/releases/download/'+r['version']+'/platform-tools-osx-aarch64.tar.bz2' for r in downloads))
    commands = [json.loads(row) for row in raw(A/'commands.jsonl').splitlines()]
    assert [r['name'] for r in commands]==['bootstrap-before','fetch-locked','cold-build','bootstrap-after','score'] and all(r['returncode']==0 for r in commands)
    for name in ['bootstrap-before','bootstrap-after']:
        command = next(r['command'] for r in commands if r['name']==name)
        assert '-B' in command and command[-2:]==['--sdk-check','full']
        text = raw(A/(name+'.log')).decode()
        assert 'v1.44 SDK verified (full, 2785 entries)' in text and 'Linux v1.44 sbpf target libraries verified (25 rlibs)' in text
    fingerprints = a('cargo-fingerprints.json')
    log = raw(A/'build.log').decode()
    check('five successful commands, two full guards, fresh local crates and exact recorded flags',len(fingerprints)==2 and all(r['rustflags']==['-Zremap-cwd-prefix='] for r in fingerprints.values()) and all(re.search(r'Compiling '+p+r' v0\.1\.0 ',log) for p in ['pump-token-ext','pump-recovered']) and 'Finished `release`' in log and 'exceeded max offset' not in log)
    link,admit,receipt = a('link-inputs.json'),a('link-order-admission.json'),a('link-receipt.json')
    all_sources = index(program['files']+core['files'])
    for name,row in {'ordered.ld':link['programScript'],**link['maintainedInputs']}.items():
        assert all_sources[row['path']]==row and sha(raw(A/'pinned-link-inputs'/name))==row['sha256']
    check('all five retained raw link inputs bind physical program/CORE origins',True)
    script = raw(A/'pinned-link-inputs/ordered.ld').decode()
    check('fixed authenticated linker grammar and555 text selectors',link['programScript']['sha256']=='6954d9901b005312be6e7f980cb5e74a1440c174547c2040a881acf2e5c25b45' and link['maintainedInputs']['sbf_default.ld']['sha256']=='5e8370b9380f55411d827721e2e43c8cfd1eac71d1383e20b938397bc0bd82c3' and link['selectors']=={'.text':555,'.rodata':0,'.data.rel.ro':0})
    check('actual link source/default/native LLD/parent receipt chain',receipt['script_sha256']==link['programScript']['sha256']==build['link_order']['script_sha256'] and receipt['default_script_sha256']==link['maintainedInputs']['sbf_default.ld']['sha256'] and receipt['lld_sha256']==native['sha256']==build['link_order']['lld_sha256'] and receipt['lld']==native['path'] and result['nativeLld']==native and result['linkOrder']==build['link_order']==admit['actualBuildLinkOrder'])
    args = receipt['forwarded'];script_indices=[i for i,x in enumerate(args) if x in ['--script','-T']]
    assert len(script_indices)==1 and not any(x.startswith(('--script=','@')) or (x.startswith('-T') and x!='-T') for x in args)
    forwarded_script = PurePosixPath(args[script_indices[0]+1])
    check('one private checked script, one native map and expected output',forwarded_script.is_absolute() and forwarded_script.parent.name.startswith('pump-link-script-') and forwarded_script.name=='ordered.ld' and str(forwarded_script)==admit['forwardedScript'] and [x for x in args if x.startswith('-Map=')]==['-Map=/Users/runner/work/_temp/pump-s3-diagnostic-work/link.map'] and args.count('-o')==1 and args[args.index('-o')+1].endswith('/target-identity/sbpf-solana-solana/release/deps/pump_recovered.so'))
    map_raw = raw(A/'link.map')
    check('full raw map/receipt hashes and frozen default/native bindings',sha(raw(A/'link-receipt.json'))==admit['receiptSha256'] and sha(map_raw)==admit['mapSha256'] and len(map_raw)==admit['mapBytes'] and admit['nativeLld']==native and admit['frozenProgramScript']==link['programScript'] and admit['frozenDefaultScript']==link['maintainedInputs']['sbf_default.ld'])
    selectors=[]
    for line in script.splitlines():
        match=re.fullmatch(r'    (\*[^()]*)\((?:"([^"]+)"|(\.text\*))\)',line)
        if match:selectors.append((match[1],match[2] or match[3]))
    assert len(selectors)==556 and selectors[-1]==('*','.text*')
    entries=[];output_rows={}
    for number,line in enumerate(map_raw.decode().splitlines(),1):
        fields=line.split(maxsplit=4)
        if len(fields)==5 and fields[4] in ['.text','.rodata','.data.rel.ro','.dynamic','.dynsym','.dynstr','.rel.dyn']:
            assert fields[4] not in output_rows
            output_rows[fields[4]]={'address':int(fields[0],16),'size':int(fields[2],16),'line':number}
        match=re.match(r'^\s*([0-9a-f]+)\s+([0-9a-f]+)\s+([0-9a-f]+)\s+(\d+)\s+(.+):\((\.text[^()]*)\)$',line)
        if not match:continue
        filename=match[5];archive=re.match(r'^(.*\.rlib)\(([^()]*)\)$',filename)
        if archive:filename=archive[1]+':'+archive[2]
        hits=[i for i,(fp,sp) in enumerate(selectors) if fnmatch.fnmatchcase(filename,fp) and fnmatch.fnmatchcase(match[6],sp)]
        assert hits
        entries.append({'map_line':number,'address':int(match[1],16),'bytes':int(match[3],16),'section':match[6],'selector_index':min(hits)})
    indices=[r['selector_index'] for r in entries]
    check('actual input sections obey all555 explicit selectors and exactly tile text',len(entries)>=555 and indices==sorted(indices) and set(range(555)) <= set(indices) and sum(r['bytes'] for r in entries)==output_rows['.text']['size'] and entries[0]['address']==288 and all(a['address']+a['bytes']==b['address'] for a,b in zip(entries,entries[1:])))
    
    NORMAL=ROOT/'work/s3-normal-reference';PARENTREF=ROOT/'work/current13fe-reference'
    prepared=load(ROOT/'work/diagnostic-prep/PREPARATION-RESULT.json')
    assert prepared['frozenManifestSha256']=='8bb16cf3ade9335b327d572898ae0328c7bf4d8985ae246754f5181a87e1858f'
    bindings=load(ROOT/'work/diagnostic-prep/ACTUAL-S3-BINDING.json')
    for folder,table in [(NORMAL,bindings['normalSelfReference']['files']),(PARENTREF,bindings['baseline']['files'])]:
     assert {p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file() or p.is_symlink()}==set(table)
     for name,row in table.items():
      p=folder/name;assert p.is_file() and not p.is_symlink();b=raw(p);assert len(b)==row['bytes'] and sha(b)==row['sha256']
    check('actual normalS3 self45 and13fe baseline43 exact pinned members',len(bindings['normalSelfReference']['files'])==45 and len(bindings['baseline']['files'])==43)
    normal_result=load(NORMAL/'RESULT.json')
    check('normal S3 native SUCCESS and no-loss remain authenticated',normal_result['base']==BASE and all(normal_result[k] is True for k in ('sourceUnchanged','registrySourceUnchanged','toolInputsUnchanged','coldTarget','noNormalizedLosses','noRawLosses')) and not (NORMAL/'FAILURE.json').exists())
    check('complete logical registry equals normal S3 before and after',registry==load(NORMAL/'registry-source-inputs.json')==load(NORMAL/'registry-source-inputs-after.json'))
    for name in ('program-source-inputs.json','toolchain-source-inputs.json','source-inputs.json','compiled-workspace-inputs.json'):
     assert a(name)==load(NORMAL/name)
    check('diagnostic source141 CORE236 selected/stage142 equal normal S3',True)
    reference_admission=a('reference-admission.json');trace_admission=a('s3-reference-admission.json')
    check('both hosted reference-admission tables and role identities',reference_admission['base']=='13fe4536be64d8c5c10f8905e9d2236f423ac4f4' and reference_admission['run']==41170683278 and reference_admission['artifactId']==13031166975 and reference_admission['files']==bindings['baseline']['files'] and trace_admission['run']==41172052790 and trace_admission['artifactId']==13031054922 and trace_admission['files']==bindings['normalSelfReference']['files'] and trace_admission['sourceAndCoreAndStageEqual'] is True)
    unstripped,candidate=raw(A/'unstripped.so'),raw(A/'candidate.so');normal_unstripped,normal_candidate=raw(NORMAL/'unstripped.so'),raw(NORMAL/'candidate.so')
    check('complete stripped bytes equal actual normal S3',candidate==normal_candidate and sha(candidate)=='31ece96dc7eee70c8c7cc16ba401d63e668c3725a8d1c411834fd9494d8e01d0')
    us,headers=elf_sections(unstripped);ns,_=elf_sections(normal_unstripped);cs,_=elf_sections(candidate)
    assert set(us)==set(ns)
    section_equality={name:unstripped[row['offset']:row['offset']+row['size']]==normal_unstripped[ns[name]['offset']:ns[name]['offset']+ns[name]['size']] for name,row in us.items()}
    check('all non-symbol section payloads equal normal S3',all(equal for name,equal in section_equality.items() if name not in ('.symtab','.strtab')))
    def symbols(blob,sections):
     table=sections['.symtab'];strings=sections['.strtab'];text=blob[strings['offset']:strings['offset']+strings['size']]
     assert table['entsize']==24 and table['size']%24==0
     result=[]
     for position in range(table['offset'],table['offset']+table['size'],24):
      name,info,other,section,value,size=struct.unpack_from('<IBBHQQ',blob,position);end=text.find(b'\0',name)
      assert end>=name;result.append((text[name:end].decode(),info,other,section,value,size))
     return result
    actual_symbols,normal_symbols=symbols(unstripped,us),symbols(normal_unstripped,ns)
    check('all symbol numeric fields equal with explicit domain count',len(actual_symbols)==len(normal_symbols) and all(x[1:]==y[1:] for x,y in zip(actual_symbols,normal_symbols)))
    functions=sorted(x for x in actual_symbols if x[1]&15==2);normal_functions=sorted(x for x in normal_symbols if x[1]&15==2)
    check('every semantic function symbol equal',functions==normal_functions)
    name_changes=[{'index':i,'actual':list(x),'reference':list(y)} for i,(x,y) in enumerate(zip(actual_symbols,normal_symbols)) if x!=y]
    check('only local OBJECT names may differ',all(x['actual'][1]==x['reference'][1]==1 and x['actual'][0]!=x['reference'][0] and x['actual'][1:]==x['reference'][1:] for x in name_changes))
    check('saved complete local-name-difference record exact',a('local-symbol-name-differences.json')==name_changes)
    for name,row in output_rows.items():assert row['address']==us[name]['addr']==cs[name]['addr'] and row['size']==us[name]['size']==cs[name]['size']
    check('all seven allocated section map geometries agree',len(output_rows)==7)
    for name,row in cs.items():
     if row['flags']&2:
      other=us[name];assert unstripped[other['offset']:other['offset']+other['size']]==candidate[row['offset']:row['offset']+row['size']]
    check('stripped and unstripped allocated payload equality',True)
    S='_ZN14pump_recovered9admin_cto7execute17h3bd6d7f34f2e30d7E'
    targets=[x for x in actual_symbols if x[0]==S and x[1]&15==2];assert len(targets)==1
    target=targets[0];target_map=[x for x in entries if 'admin_cto7execute' in x['section']]
    assert len(target_map)==1 and target[-2:]==(0x22a10,27400) and target_map[0]['address']==target[-2] and target_map[0]['bytes']==target[-1]
    target_offset=us['.text']['offset']+target[-2]-us['.text']['addr'];target_body=unstripped[target_offset:target_offset+target[-1]]
    check('same normal-S3 target body and extent',sha(target_body)=='a8bf685d74da8226d39a8fc9f17eb0100b84a56db69415f241bb2a2b3f75e570')
    score=a('score.json');summary=score['summary'];windows=score['windows'];normal_score=load(NORMAL/'score.json');parent_score=load(PARENTREF/'score.json')
    domain={r['original_start']:int(r['bytes']) for r in csv.DictReader(io.StringIO(raw(ROOT/'reconstruction/base/functions.tsv').decode()),delimiter='\t') if r['program']=='pump' and r['variant']=='selected'}
    check('all1035 saved official rows equal normal S3 and parent; no scorer executed',len(windows)==1035 and windows==normal_score['windows']==parent_score['windows'] and set(windows)==set(domain))
    check('saved score types/arithmetic and actual image hashes',all(row['bytes']==domain[k] and type(row['raw']) is bool and type(row['normalized']) is bool for k,row in windows.items()) and summary['total']==1035 and summary['raw']==sum(x['raw'] for x in windows.values())==1034 and summary['normalized']==sum(x['normalized'] for x in windows.values())==1034 and summary['matched_text_bytes']==sum(x['bytes'] for x in windows.values() if x['normalized'])==1764808 and sha(unstripped)==summary['candidate_sha256']==build['unstripped_sha256']==result['unstrippedSha256'] and sha(candidate)==build['candidate_sha256']==result['candidateSha256'] and summary==result['summary'])
    summary_differences={k:{'actual':summary.get(k),'reference':normal_score['summary'].get(k)} for k in summary.keys()|normal_score['summary'].keys() if summary.get(k)!=normal_score['summary'].get(k)}
    assert set(summary_differences)<={'candidate_sha256'}
    for kind in ('normalized','raw'):
     gains=['0x%x'%int(k) for k in sorted(windows,key=int) if windows[k][kind] and not parent_score['windows'].get(k,{}).get(kind,False)]
     losses=['0x%x'%int(k) for k in sorted(windows,key=int) if not windows[k][kind] and parent_score['windows'].get(k,{}).get(kind,False)]
     prefix='' if kind=='normalized' else 'raw_';assert summary[prefix+'gains']==gains==[] and summary[prefix+'losses']==losses==[]
    comparison=a('CANDIDATE-COMPARISON.json')
    check('actual saved no-loss comparison remains SUCCESS',comparison['sourceCommit']==BASE and comparison['sourceSha256']==source['sha256'] and comparison['referenceBase']=='13fe4536be64d8c5c10f8905e9d2236f423ac4f4' and comparison['referenceRun']==41170683278 and comparison['referenceArtifactId']==13031166975 and comparison['summary']==summary and comparison['changedRows']=={} and comparison['allRowsEqual'] and comparison['fullRowsCompared']==result['fullScoreRowsCompared']==1035 and all(comparison[k] is result[k] is True for k in ('noNormalizedLosses','noRawLosses')))
    cap=a('capture-result.json');stages=(('After','finalize-isel'),('Before','greedy'),('After','greedy'),('After','virtregrewriter'),('After','block-placement'))
    llvm_args=('-filter-print-funcs='+S,'-print-before=jump-threading','-print-after=jump-threading','-print-after=finalize-isel','-print-before=greedy','-print-after=greedy','-print-after=virtregrewriter','-print-after=block-placement')
    extra=['--emit=link,llvm-ir']+[x for v in llvm_args for x in ('-C','llvm-args='+v)]
    assert cap['symbol']==S and cap['sourceSha256']==source['sha256'] and cap['rootAdditionalArguments']==extra and cap['rootOnlyCargoRustcArguments'] is True and len(cap['calls'])==1
    call=cap['calls'][0];work=PurePosixPath(cold['target']).parent;sdk=PurePosixPath(native['path']).parents[2];env=call['compilerEnvironment']
    original=[str(sdk/'rust/bin/cargo'),'build','--manifest-path',str(work/'ws/programs/pump/Cargo.toml'),'--release','--target','sbpf-solana-solana','--locked','--offline']
    assert call['originalArgv']==original and call['diagnosticArgv']==[original[0],'rustc',*original[2:],'--lib','--',*extra]
    assert call['argvDelta']=={'replacedIndex':1,'from':'build','to':'rustc','appended':['--lib','--',*extra]} and call['cwd']==str(work/'ws') and call['originalKeywordNames']==['cwd','env','timeout'] and call['originalPositionalCount']==0 and call['timeout'] is None
    assert env['CARGO_TARGET_DIR']==cold['target'] and env['CARGO_TARGET_SBPF_SOLANA_SOLANA_RUSTFLAGS']=='-Zremap-cwd-prefix=' and env['PYTHONDONTWRITEBYTECODE']=='1' and env['PUMP_LINK_ROOT_CRATE']=='pump_recovered' and env['PUMP_LINK_SCRIPT']==str(work/'ws/programs/pump/link/ordered.ld') and env['PUMP_LINK_SCRIPT_SHA256']==link['programScript']['sha256']
    assert env['RUSTC'] in tools and env['RUSTC_WRAPPER'].endswith('/reconstruction/harness/pump_link_rustc.sh') and env['PUMP_LINK_LLD'].endswith('/rust/lib/rustlib/aarch64-apple-darwin/bin/rust-lld') and env['PUMP_LINK_MAP']==str(work/'link.map') and env['PUMP_LINK_RECEIPT']==str(work/'link-receipt.json')
    check('exactly one frozen compiler forwarding and fixed root-only args',True)
    log_raw=raw(A/'build.log');heads=list(re.finditer(rb'(?m)^(?:[#;] )?\*\*\* IR Dump [^\r\n]+',log_raw))
    assert cap['rawBuildLogPresent'] is True and cap['rawBuildLogSha256']==sha(log_raw) and cap['rawBuildLogBytes']==len(log_raw) and len(cap['passDumps'])==len(heads)
    def ir_extent(blob):
     definitions=list(re.finditer(rb'(?m)^define\b[^\n]*@"?'+re.escape(S.encode())+rb'"?\(',blob))
     if len(definitions)!=1:return None
     begin=definitions[0].start();end=re.search(rb'(?m)^\}',blob[begin:])
     return (begin,begin+end.end()) if end else None
    derived=[]
    for i,head in enumerate(heads):
     end=heads[i+1].start() if i+1<len(heads) else len(log_raw);part=log_raw[head.start():end];timing_match=re.search(rb'IR Dump (Before|After)\b',head.group());assert timing_match
     timing=timing_match[1].decode();pass_match=re.search(rb'\((finalize-isel|greedy|virtregrewriter|block-placement|jump-threading)\)',head.group())
     phase=pass_match[1].decode() if pass_match else None
     if phase is None and re.fullmatch(rb'; \*\*\* IR Dump (?:Before|After) JumpThreadingPass on '+re.escape(S.encode())+rb' \*\*\*',head.group()):phase='jump-threading'
     if phase is None and re.search(rb'IR Dump (Before|After) Jump Threading(?: on [^\r\n]+)? \*\*\*:?[ \t]*$',head.group()):phase='jump-threading'
     assert phase is not None,'unqualified raw heading; no fallback/search'
     stem='dump-%03d-%s-%s'%(i+1,timing.lower(),phase);filename='compiler-dumps/'+stem+'.txt';assert raw(A/filename)==part
     opening=b'# Machine code for function '+S.encode()+b':';closing=b'# End machine code for function '+S.encode()+b'.';machine=part.count(opening)==part.count(closing)==1 and part.find(opening)<part.find(closing)
     extent=ir_extent(part);target_ir=None
     if extent:
      target_file='compiler-dumps/'+stem+'-target.ll';target_bytes=part[extent[0]:extent[1]];assert raw(A/target_file)==target_bytes
      target_ir={'file':target_file,'rawLogStart':head.start()+extent[0],'rawLogEnd':head.start()+extent[1],'bytes':len(target_bytes),'sha256':sha(target_bytes)}
     row={'file':filename,'bytes':len(part),'sha256':sha(part),'rawLogOffset':head.start(),'rawLogEnd':end,'heading':head.group().decode(),'timing':timing,'pass':phase,'containsTargetSymbol':S.encode() in part,'completeTargetMachineFunction':machine,'completeTargetIrFunction':extent is not None,'targetIr':target_ir}
     assert cap['passDumps'][i]==row;derived.append(row)
    machine_dumps=[x for x in derived if x['pass'] in {s for _,s in stages}];jt=[x for x in derived if x['pass']=='jump-threading']
    requested=[{'timing':t,'pass':p,'files':[x['file'] for x in machine_dumps if x['timing']==t and x['pass']==p and x['completeTargetMachineFunction']]} for t,p in stages]
    check('five complete ordered target machine stages',len(machine_dumps)==5 and [(x['timing'],x['pass']) for x in machine_dumps]==list(stages) and all(len(x['files'])==1 for x in requested) and cap['requestedStages']==requested and cap['machineDumps']==machine_dumps)
    assert len(jt)>=4 and len(jt)%2==0 and all(x['timing']==('Before' if i%2==0 else 'After') and x['completeTargetIrFunction'] for i,x in enumerate(jt))
    pairs=[{'iteration':i//2+1,'before':jt[i]['file'],'after':jt[i+1]['file'],'beforeTarget':jt[i]['targetIr'],'afterTarget':jt[i+1]['targetIr'],'complete':True} for i in range(0,len(jt),2)]
    check('complete ordered JT pairs and every metadata/file/heading binding',cap['jumpThreadingDumps']==jt and cap['jumpThreadingPairs']==pairs and cap['minimumJumpThreadingPairs']==2)
    modules=[]
    for row in cap['llvmIr']:
     data=raw(A/row['file']);extent=ir_extent(data)
     assert set(row)=={'file','bytes','sha256','containsTargetDefinition'} and row['bytes']==len(data) and row['sha256']==sha(data) and row['containsTargetDefinition']==(extent is not None)
     if extent:modules.append({'file':row['file'],'rawModuleSha256':sha(data),'rawModuleStart':extent[0],'rawModuleEnd':extent[1],'bytes':extent[1]-extent[0],'sha256':sha(data[extent[0]:extent[1]])})
    check('optimized target definition and complete root module retained',len(modules)>=1 and {x['file'] for x in cap['llvmIr']}=={p.relative_to(A).as_posix() for p in (A/'llvm-ir').rglob('*') if p.is_file()})
    check('capture completion guards accurately report complete actual outputs',all(cap[k] is True for k in ('compilerCompleted','buildOk','captureComplete','sourceUnchanged','allMachineStagesObserved','allRequestedStagesObserved','jumpThreadingPairingValid','targetDefinitionRetained')))
    diag=a('DIAGNOSTIC-COMPARISON.json')
    check('hosted identity and capture report independently reproduced',all(diag[k] is True for k in ('attributionQualified','codeIdentityQualified','completeStrippedBytesEqual','nonSymbolSectionPayloadsEqual','semanticFunctionSymbolsEqual','symbolNumericFieldsEqual','localSymbolDifferencesNamesOnly','full1035RowsEqual','targetDefinitionRetained','allMachineStagesObserved','jumpThreadingPairingValid','allRequestedStagesObserved','captureComplete','compilerCompleted','buildOk')) and diag['referenceRun']==41172052790 and diag['referenceArtifactId']==13031054922 and diag['symbolNameDifferenceCount']==len(name_changes) and diag['scoreSummaryDifferences']==summary_differences and diag['captureResultSha256']==sha(raw(A/'capture-result.json')) and diag['jumpThreadingPairCount']==len(pairs) and diag['actualCompilerCommands']==cap['calls'])
    for name,row in diag['sectionPayloads'].items():assert row['equal']==section_equality[name] and row['actualSha256']==sha(unstripped[us[name]['offset']:us[name]['offset']+us[name]['size']]) and row['referenceSha256']==sha(normal_unstripped[ns[name]['offset']:ns[name]['offset']+ns[name]['size']])
    assert set(diag['sectionPayloads'])==set(us)
    assert diag['fullElfHashesEqual']=={'unstripped':sha(unstripped)==sha(normal_unstripped),'stripped':True} and diag['referenceUnstrippedSha256']==sha(normal_unstripped) and diag['actualUnstrippedSha256']==sha(unstripped) and diag['referenceStrippedSha256']==diag['actualStrippedSha256']==sha(candidate)
    assert diag['captureMethodSha256']==op_by_path['reconstruction/pump-main/lanes/current-native-ir-capture/capture.py']['sha256']
    assert diag['targetSymbol']==S and diag['referenceSourceSha256']==source['sha256'] and diag['fullScoreSummaryEqual']==(summary==normal_score['summary'])
    expected_members=set(bindings['normalSelfReference']['files'])|{'capture-result.json','local-symbol-name-differences.json','DIAGNOSTIC-COMPARISON.json','s3-reference-admission.json','s3-reference-target-symbol.json'}|{x['file'] for x in cap['llvmIr']}|{x['file'] for x in derived}|{x['targetIr']['file'] for x in jt}
    check('exact complete diagnostic artifact member domain',set(members)==expected_members)
    run=json.loads(load(RUN/'poll-009/run.json')['result']['structuredContent']['content'])
    jobs=json.loads(load(RUN/'terminal/jobs-raw.json')['result']['structuredContent']['content'])['jobs']
    assert len(jobs)==1
    steps=jobs[0]['steps']
    check('actual attempt1 run job and steps conclusion',run['id']==RUN_ID and run['head_sha']==OP and run['run_attempt']==1 and run['conclusion']==release['providerConclusion']=='success' and len(jobs)==1 and jobs[0]['conclusion']=='success' and all(x['status']=='completed' and x['conclusion']=='success' for x in steps) and 'FAILURE.json' not in members)
    for name,value in list(inputs.items()):assert len((ROOT/name).read_bytes())==value['bytes'] and sha((ROOT/name).read_bytes())==value['sha256']
    report={'verdict':'PASS independent actual fixed-S3 diagnostic code/trace/provenance admission','source':BASE,'operationalCommit':OP,'run':RUN_ID,'artifactId':api['id'],'checks':checks,'images':{'unstripped.so':sha(unstripped),'candidate.so':sha(candidate)},'referenceUnstrippedSha256':sha(normal_unstripped),'completeUnstrippedEqual':unstripped==normal_unstripped,'completeStrippedEqual':True,'sectionPayloadEquality':section_equality,'allFunctionSymbolsEqual':True,'allSymbolNumericFieldsEqual':True,'localObjectNameDifferences':len(name_changes),'CTO':{'symbol':S,'address':target[-2],'bytes':target[-1],'bodySha256':sha(target_body)},'score':{'raw':1034,'normalized':1034,'total':1035,'allRowsEqualNormalS3':True,'allRowsEqual13fe':True,'scorerRerun':False},'capture':{'compilerCalls':1,'jumpThreadingPairs':len(pairs),'machineStages':5,'optimizedTargets':modules,'stages':derived},'nativeDiagnosticOutcome':'SUCCESS','normalS3NativeOutcome':'SUCCESS_NO_LOSS','sourceVerdict':'SOURCE_REJECTED_INTERNAL_METRIC','S3VmExecutions':0,'limits':['Independent stdlib read/hash/archive/ELF/provenance admission only; no project import, scorer/compiler/SDK/VM/native/test/metric repeat or network/API operation.','Remote SDK/registry and deleted private linker copy are not physically rehashed locally; recorded guards/inventory and fixed source are authenticated.','Strict stripped and saved-row identity extends the already officially rescored normal S3 binding; no new official scorer execution.','Complete same-source trace does not establish Rust source/type/bool-niche uniqueness, source gain, runtime equivalence, original whole-ELF identity, later-main transfer or any next candidate authorization. Native SUCCESS and internal source rejection/VM0 remain separate.']}
    bindings_out={'source':BASE,'operationalCommit':OP,'run':RUN_ID,'artifactId':api['id'],'zip':{'bytes':len(zip_raw),'sha256':sha(zip_raw)},'members':members,'images':report['images'],'CTO':report['CTO'],'scoreRowsCanonicalSha256':sha(json.dumps(windows,sort_keys=True,separators=(',',':')).encode()),'readerReference':'REVIEW.json'}
    for name,value in [('REVIEW.json',report),('REFERENCE-BINDINGS.json',bindings_out),('MAP-SELECTORS.json',{'selectors':selectors,'entries':entries,'outputs':output_rows}),('INPUTS.json',inputs)]:
     with (OUT/name).open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')
    files={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(OUT.iterdir()) if p.is_file() and p.name not in ('reader.stdout','reader.stderr')}
    with (OUT/'MANIFEST.json').open('x') as stream:json.dump({'status':'SEALED_INDEPENDENT_ACTUAL_ADMISSION_PASS','source':BASE,'run':RUN_ID,'files':files},stream,indent=2);stream.write('\n')
    print(json.dumps({'verdict':'PASS','checks':len(checks),'reviewSha256':sha((OUT/'REVIEW.json').read_bytes()),'bindingsSha256':sha((OUT/'REFERENCE-BINDINGS.json').read_bytes()),'manifestSha256':sha((OUT/'MANIFEST.json').read_bytes()),'pairs':len(pairs),'machines':5,'localObjectNameDifferences':len(name_changes)}))

if __name__ == '__main__':
    from pathlib import Path
    import json,traceback
    folder=Path('/dev/shm/pump-cto-settings-s3-ir/work/ir-run/independent-admission')
    assert (folder/'RELEASE.json').is_file() and (folder/'CONTINUATION-RELEASE.json').is_file(), 'root has not released metadata adapter continuation'
    try: admission()
    except BaseException as error:
        with (folder/'ADMISSION-CONTINUATION-FAILURE.json').open('x') as stream:
            original_failure=folder.parent/'artifact/FAILURE.json'
            saved_failure=json.loads(original_failure.read_text()) if original_failure.is_file() else None
            json.dump({'status':'FAILED_INDEPENDENT_ADMISSION','type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc(),'originalDiagnosticFailurePreserved':saved_failure,'inputsUnmodified':True,'noCompilerScorerVmOrMetricRepeated':True},stream,indent=2);stream.write('\n')
        raise
