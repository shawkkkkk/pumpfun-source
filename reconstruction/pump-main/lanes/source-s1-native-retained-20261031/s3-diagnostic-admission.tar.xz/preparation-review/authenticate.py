"""Independent read/hash/AST/archive/Git admission; never imports project code."""
from pathlib import Path,PurePosixPath
import ast,copy,hashlib,json,os,re,stat,subprocess,sys,tarfile,zipfile
assert os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode
ROOT=Path('/dev/shm/pump-cto-settings-s3-ir');PREP=ROOT/'work/diagnostic-prep';OWN=ROOT/'work/capture-review'
BASE='65f0162a3dcd381df0f831082dd6732c9af4ab78';PARENT='13fe4536be64d8c5c10f8905e9d2236f423ac4f4'
SOURCE='9fc3fd3c8e68d85e5bf4fcb2309694974aab3c5aaacab9741a1e0ea25c72a622';STAGE='8ecb6144b71aee05d37cb1bebd4f2b0b3343c7eb88f0a3366d17c4dc0381e9db'
CORE=('reconstruction/harness','reconstruction/toolchain','reconstruction/base','reconstruction/pump-main/baseline','evidence/original/pump')
NORMAL=Path('/dev/shm/pump-cto-settings-s3');OLD=Path('/dev/shm/pump-cto-option-c1/work/diagnostic-prep')
ENV=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1',GIT_ALLOW_PROTOCOL='file');CHECKS=[];GIT_WARNINGS=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def canonical(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
def git(*args):
 p=subprocess.run(['git',*args],cwd=ROOT,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
 if p.stderr:GIT_WARNINGS.append({'args':list(args),'bytes':len(p.stderr),'sha256':hashlib.sha256(p.stderr).hexdigest()})
 return p.stdout
def check(name,value):
 assert value,name
 CHECKS.append(name)
def physical(prefixes):
 rows=[]
 for row in git('ls-tree','-rz',BASE,'--',*prefixes).split(b'\0'):
  if not row:continue
  meta,name=row.split(b'\t',1);mode,kind,oid=meta.decode().split();name=name.decode();p=ROOT/name
  assert kind=='blob' and mode in ('100644','100755','120000')
  if mode=='120000':assert p.is_symlink();data=os.fsencode(os.readlink(p))
  else:
   assert p.is_file() and not p.is_symlink() and bool(p.stat().st_mode&0o111)==(mode=='100755');data=p.read_bytes()
  assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid
  rows.append({'path':name,'mode':mode,'gitBlob':oid,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 actual={p.relative_to(ROOT).as_posix() for prefix in prefixes for p in (ROOT/prefix).rglob('*') if p.is_file() or p.is_symlink()}
 assert actual=={r['path'] for r in rows}
 return rows
def vector(root):
 rows={}
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink()
  if p.is_file():rows[p.relative_to(root).as_posix()]={'bytes':p.stat().st_size,'executable':bool(p.stat().st_mode&0o111),'sha256':sha(p)}
 return rows
def assignments(tree):return {n.targets[0].id:n for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
def nodes(tree):return {n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def dump(node):return ast.dump(node,include_attributes=False)
def literal_changes(a,b,path=()):
 if type(a)!=type(b):raise AssertionError(('AST kind',path))
 if isinstance(a,ast.Constant) and isinstance(a.value,str) and isinstance(b.value,str):
  return [] if a.value==b.value else [{'path':list(path),'actual':a.value,'prior':b.value}]
 if isinstance(a,ast.AST):
  result=[]
  for name in a._fields:result+=literal_changes(getattr(a,name),getattr(b,name),path+(name,))
  return result
 if isinstance(a,list):
  assert len(a)==len(b),('AST length',path)
  return [x for i,(aa,bb) in enumerate(zip(a,b)) for x in literal_changes(aa,bb,path+(str(i),))]
 assert a==b,('AST value',path,a,b)
 return []

expected_freeze=sys.argv[1];check('exact author freeze',sha(PREP/'FROZEN-MANIFEST.json')==expected_freeze)
freeze=load(PREP/'FROZEN-MANIFEST.json')
prepared=load(PREP/'PREPARATION-RESULT.json')
check('exact final preparation result and46-file freeze',sha(PREP/'PREPARATION-RESULT.json')=='cb8293f75e9d127cd4578349a36402fb2de484a3981e67f8e70dc173da029ee7' and len(freeze['files'])==46)
for row in freeze['files']:
 name=PurePosixPath(row['path']);assert not name.is_absolute() and '..' not in name.parts
 p=PREP/row['path'];assert p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],row['path']
check('all declared final preparation files bound',len(freeze['files'])>20)
check('genuine exact source HEAD/tree',git('rev-parse','HEAD').decode().strip()==BASE and git('rev-parse','HEAD^{tree}').decode().strip()=='f36a4e0b3c02822750ce5c41529b7a75e16f79c0')
headers=git('cat-file','-p','HEAD').split(b'\n\n',1)[0].splitlines()
check('sole13fe parent and one unchanged proposed leaf', [x[7:].decode() for x in headers if x.startswith(b'parent ')]==[PARENT] and git('diff','--no-ext-diff','--no-textconv','--no-renames','--name-only',PARENT,BASE).decode().splitlines()==['programs/pump/src/creator/admin_cto.rs'])
program=physical(('programs/pump',));core=physical(CORE)
check('physical typed Git141 program and236 CORE',len(program)==141 and len(core)==236)
for row in program+core:
 p=ROOT/row['path'];q=NORMAL/row['path'];assert p.is_symlink()==q.is_symlink()
 assert (os.readlink(p)==os.readlink(q)) if p.is_symlink() else p.read_bytes()==q.read_bytes()
check('every source and CORE byte equals already-measured S3',True)
evidence=PREP/'preflight/evidence'
check('preflight source and CORE vectors exact physical Git',load(evidence/'program-source-inputs.json')=={'base':BASE,'files':program} and load(evidence/'toolchain-source-inputs.json')=={'base':BASE,'files':core})
selected=[{'path':r['path'].removeprefix('programs/pump/'),'bytes':r['bytes'],'executable':r['mode']=='100755','sha256':r['sha256']} for r in program]
snapshot=load(evidence/'preflight-builder-source-inputs.json')
check('selected141 aggregate exact measured source',snapshot['files']==selected and snapshot['sha256']==canonical(selected)==SOURCE)
stage=PREP/'preflight/cold-work/ws';staged=vector(stage)
check('physical142 stage and canonical vector exact measured S3',len(staged)==142 and staged==load(evidence/'compiled-workspace-inputs.json')==load(NORMAL/'work/native-run/artifact/compiled-workspace-inputs.json') and canonical(staged)==STAGE)
toml=(ROOT/'programs/pump/Cargo.toml').read_text();ps=re.search(r'(?m)^\[profile\.release\]',toml).start();wi=re.search(r'(?m)^\[workspace\]',toml).start()
projection={'programs/pump/'+r['path'].removeprefix('programs/pump/'):(ROOT/r['path']).read_bytes() for r in program if r['path'].removeprefix('programs/pump/') not in ('Cargo.toml','Cargo.lock')}
projection['programs/pump/Cargo.toml']=(toml[:ps].rstrip()+'\n').encode();projection['Cargo.toml']=('[workspace]\nmembers = ["programs/pump"]\nresolver = "2"\n\n'+toml[ps:wi].strip()+'\n').encode();projection['Cargo.lock']=(ROOT/'programs/pump/Cargo.lock').read_text().encode()
check('maintained manifest and lock projection independently accounted',set(projection)==set(staged) and all((stage/name).read_bytes()==b for name,b in projection.items()))
archive_counts={}
for name,root,rows in [('program-source.tar.gz',ROOT,{r['path']:r for r in program}),('compiled-workspace.tar.gz',stage,staged)]:
 with tarfile.open(evidence/name) as t:
  members=t.getmembers();assert len(members)==len({m.name for m in members})==len(rows) and {m.name for m in members}==set(rows)
  for m in members:
   assert m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts
   assert t.extractfile(m).read()==(root/m.name).read_bytes() and bool(m.mode&0o111)==bool((root/m.name).stat().st_mode&0o111)
  archive_counts[name]=len(members)
check('283 emitted source and stage archive members exact',sum(archive_counts.values())==283)

lane='reconstruction/pump-main/lanes/current-native-ir-capture'
controller=PREP/'ops'/lane/'pump_ir_control.py';collector=PREP/'ops'/lane/'capture.py'
ct=ast.parse(controller.read_text());pt=ast.parse((OLD/'ops'/lane/'pump_ir_control.py').read_text());ca=assignments(ct);pa=assignments(pt)
constant=lambda n:ast.literal_eval(ca[n].value)
ops=constant('OPS');check('exact four registered operational paths',ops==('.github/workflows/qualify-pump-macos-v144.yml',lane+'/pump_ir_control.py',lane+'/capture.py',lane+'/README.md'))
ops_rows=[]
for name in ops:
 p=PREP/'ops'/name;b=p.read_bytes();assert not p.is_symlink() and not p.stat().st_mode&0o111
 ops_rows.append({'path':name,'mode':'100644','bytes':len(b),'sha256':sha(p),'gitBlob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
check('four OPS exact declared hashes modes and Git blobs',ops_rows==prepared['opsFiles'])
check('frozen S3 source and parent baseline pins',constant('BASE')==BASE and constant('EXPECTED_SOURCE_SHA256')==SOURCE and constant('EXPECTED_PROGRAM_FILES')==141 and constant('REFERENCE_BASE')==PARENT and constant('REFERENCE_SOURCE_SHA256')=='ba203d5c8b0cda5ab3bb6eec65266a992331b7a8a361b9977a3d2ab474b11fe2')
cn,pn=nodes(ct),nodes(pt);unchanged=[name for name in cn if name not in ('main','verify_current_reference','verify_trace_reference','diagnostic_comparison')]
check('all16 guard helper and class ASTs exact qualified C1',len(unchanged)==16 and all(dump(cn[n])==dump(pn[n]) for n in unchanged))
string_changes={n:literal_changes(cn[n],pn[n]) for n in ('verify_current_reference','diagnostic_comparison','main')}
check('main reference and strict comparator only string literals differ',True)
cap=ast.parse(collector.read_text());oldcap=ast.parse((OLD/'ops'/lane/'capture.py').read_text());cap_assign=assignments(cap)
expected_changes=literal_changes(cap,oldcap)
check('entire collector differs only selected source pin and one source description',len(expected_changes)==2 and {x['actual'] for x in expected_changes}=={SOURCE,'selected source differs from frozen already-measured S3 source'})
check('exact known target and five-machine stage contract',constant('TARGET_SYMBOL')=='_ZN14pump_recovered9admin_cto7execute17h3bd6d7f34f2e30d7E' and constant('TRACE_TARGET_EXTENT')==(141840,27400) and ast.literal_eval(cap_assign['STAGES'].value)==(('After','finalize-isel'),('Before','greedy'),('After','greedy'),('After','virtregrewriter'),('After','block-placement')))
prior_review=Path('/dev/shm/pump-cto-option-c1/work/review/diagnostic-prep/REVIEW.json')
check('prior exact C1 collector qualification preserved',sha(prior_review)=='08cc84fbdecdd69b1bdc3618ee210d2ed1df739000480bd282fa147799c0af50' and sha(OLD/'ops'/lane/'capture.py')=='d88b7fa8a9de7a1754783143a50d31e2651613d94ad13167f48be147a56009f3')

reference_counts={}
for name,root_name,origin,table,run_id,artifact_id,zip_hash,zip_size in [
 ('parent','current13fe-reference',Path('/dev/shm/pump-cto-13fe453/work/native-run/artifact'),'REFERENCE_FILES',41170683278,13031166975,'875edcd6e9ebb7e5b8fb2495d0008e723762b1f0251a02e038881fb56749fa92',2539578),
 ('normalS3','s3-normal-reference',NORMAL/'work/native-run/artifact','TRACE_FILES',41172052790,13031054922,'0f1a82695dd41525fffbebe667c3067062a9a1fd1fd3fb4b70cbdb054965bdda',2534297)]:
 pins=constant(table);ref=ROOT/'work'/root_name;actual={p.relative_to(ref).as_posix() for p in ref.rglob('*') if p.is_file() or p.is_symlink()}
 assert actual==set(pins) and len(pins)==(43 if name=='parent' else 45)
 for path,row in pins.items():
  p=ref/path;q=origin/path;assert p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'] and p.read_bytes()==q.read_bytes()
 transport=origin.parent/'raw-artifact.zip';assert transport.stat().st_size==zip_size and sha(transport)==zip_hash
 with zipfile.ZipFile(transport) as z:
  assert z.testzip() is None
  assert {x.filename for x in z.infolist()}==set(pins) and len(z.infolist())==len(pins)
  for member in z.infolist():
   pp=PurePosixPath(member.filename);assert not pp.is_absolute() and '..' not in pp.parts and not member.is_dir() and not stat.S_ISLNK(member.external_attr>>16)
   assert z.read(member)==(ref/member.filename).read_bytes()
 prefix='REFERENCE' if name=='parent' else 'TRACE'
 assert constant(prefix+'_RUN')==run_id and constant(prefix+'_ARTIFACT')==artifact_id and constant(prefix+'_ZIP_SHA256')==zip_hash
 reference_counts[name]=len(pins)
check('actual43 parent and45 normal S3 references and transport ZIPs authenticated',True)
selfref=ROOT/'work/s3-normal-reference';baseline=ROOT/'work/current13fe-reference';normal_result=load(selfref/'RESULT.json');comparison=load(selfref/'CANDIDATE-COMPARISON.json')
check('actual S3 native SUCCESS and no-loss exact provenance',normal_result['base']==BASE and normal_result['sourceUnchanged'] and normal_result['registrySourceUnchanged'] and normal_result['toolInputsUnchanged'] and normal_result['coldTarget'] and normal_result['noRawLosses'] and normal_result['noNormalizedLosses'] and 'FAILURE.json' not in constant('TRACE_FILES') and comparison['allRowsEqual'] and comparison['changedRows']=={} and comparison['fullRowsCompared']==1035)
check('trace source CORE selected and stage exact physical preflight',load(selfref/'program-source-inputs.json')=={'base':BASE,'files':program} and load(selfref/'toolchain-source-inputs.json')=={'base':BASE,'files':core} and load(selfref/'source-inputs.json')==snapshot and load(selfref/'compiled-workspace-inputs.json')==staged)
check('saved all1035 official rows equal parent no score execution',load(selfref/'score.json')['windows']==load(baseline/'score.json')['windows'] and len(load(selfref/'score.json')['windows'])==1035)
check('copied root success admission and VM held receipts exact',sha(PREP/'NORMAL-S3-ROOT-ADMISSION.json')=='b477052a47f8bcb4835cfd0e800f820f0c1dbad9aaf31ed4a3d43d737d4e17cd' and (PREP/'NORMAL-S3-ROOT-ADMISSION.json').read_bytes()==(NORMAL/'work/root/CANDIDATE-ELF-ADMISSION.json').read_bytes() and (PREP/'NORMAL-S3-VM-HELD.json').read_bytes()==(NORMAL/'work/runtime-inputs/HELD-RECEIPT.json').read_bytes())
check('prior independently admitted normal S3 native38checks retained',sha(NORMAL/'work/native-run/candidate-review/REVIEW.json')=='29a17fafa3d32a88dce607bbaede8b4248d38974ac115b8d1b81f4c660baba8a')
before=load(PREP/'PREFLIGHT-INPUTS-BEFORE.json');after=load(PREP/'PREFLIGHT-INPUTS-AFTER.json')
check('all470 original preflight inputs unchanged across actual run',before==after and len(before)==470 and len({r['path'] for r in before})==470)
executed=PREP/'PREFLIGHT-CONTROLLER-EXECUTED.py';amendment=load(PREP/'DESCRIPTION-ONLY-POST-PREFLIGHT.json')
executed_ast=ast.parse(executed.read_text());final_ast=copy.deepcopy(ct)
check('final controller changes only cosmetic module description after preflight',sha(executed)==amendment['executed_controller_sha256']=='fd20be35c4a303a1ffdbd6629422f1832461b6371c520f703816a567e204f2f2' and sha(controller)==amendment['final_controller_sha256']=='d83ff3ec3f37103c80d47acd058741691bd5e0b332814f8c16b1e764222182d5' and dump(ast.Module(body=executed_ast.body[1:],type_ignores=[]))==dump(ast.Module(body=final_ast.body[1:],type_ignores=[])))
amended_inputs=0
for row in after:
 p=Path(row['path']);assert p.is_relative_to(ROOT)
 if p==controller:
  assert row['bytes']==executed.stat().st_size and row['sha256']==sha(executed)
  amended_inputs+=1;continue
 data=os.fsencode(os.readlink(p)) if p.is_symlink() else p.read_bytes();st=p.lstat()
 assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'] and st.st_mode==row['mode'] and st.st_ino==row['inode'] and st.st_dev==row['device'] and st.st_mtime_ns==row['mtime_ns'],str(p)
check('only documented docstring input changed after original run',amended_inputs==1)
execution=load(PREP/'PREFLIGHT-EXECUTION.json');process=load(PREP/'PREFLIGHT-PROCESS.json');outcome=load(PREP/'PREFLIGHT-RESULT.json')
check('one actual PID721894 preflight success no native operations',process['pid']==outcome['pid']==721894 and outcome['status']=='PASS' and outcome['exitCode']==execution['exitCode']==0 and execution['sourceCommit']==BASE and not outcome['SDKBootstrapCargoCompilerScorerVMExecuted'] and not execution['nativeOperationalParentAdmissionExercised'])
check('preflight binds exact executed controller with final logic unchanged',execution['controllerSha256']==sha(executed))
for name in ('stdout','stderr'):
 p=PREP/('preflight.'+name);assert p.stat().st_size==outcome[name+'Bytes'] and sha(p)==outcome[name+'Sha256']
check('exact stdout stderr and original physical input records authenticated',True)
loader=ast.parse((PREP/'run_preflight.py').read_text());main_calls=[n for n in ast.walk(loader) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='main']
check('loader enters preflight only once',len(main_calls)==1 and len(main_calls[0].keywords)==1 and main_calls[0].keywords[0].arg=='preflight_only' and ast.literal_eval(main_calls[0].keywords[0].value) is True)
pf=load(evidence/'PREFLIGHT.json');link=load(evidence/'link-inputs.json')
check('555 selectors and real stage preflight stopped before SDK cargo compiler',link['selectors']=={'.text':555,'.rodata':0,'.data.rel.ro':0} and not link['configureExecutedByPreflight'] and pf['preflightOnly'] and not pf['sdkInstalledByPreflight'] and not pf['bootstrapRunByPreflight'] and not pf['cargoRunByPreflight'] and not pf['compilerRunByPreflight'] and not (PREP/'preflight/cold-work/target-identity').exists())
for name in ('AGENTS.md','CONTRIBUTING.md','README.md','SECURITY.md','docs/SCOPE.md','docs/COMPLETION.md','docs/PARALLEL_WORK.md','programs/pump/Cargo.toml','programs/pump/Cargo.lock'):
 assert (ROOT/name).read_bytes()==(NORMAL/name).read_bytes()
check('guides manifests lock hooks source unchanged from measured S3',True)
workflow=(PREP/'ops/.github/workflows/qualify-pump-macos-v144.yml').read_text()
check('one manual native controller two exact artifact downloads and always upload',workflow.count('run: python3 -B '+lane+'/pump_ir_control.py')==1 and workflow.count('actions/download-artifact@d3f86a106a0bac45b974a628896c90dbdf5c8093')==2 and 'run-id: 41170683278' in workflow and "artifact-ids: '13031166975'" in workflow and 'run-id: 41172052790' in workflow and "artifact-ids: '13031054922'" in workflow and 'if: always()' in workflow and 'cancel-in-progress: false' in workflow)
check('tracked source remains clean',not git('status','--porcelain','--untracked-files=no').strip())
record={'status':'PASS','authorFreezeSha256':expected_freeze,'frozenFiles':len(freeze['files']),'operationalFiles':ops_rows,'source':BASE,'sourceTree':'f36a4e0b3c02822750ce5c41529b7a75e16f79c0','sourceParent':PARENT,'programFiles':len(program),'coreFiles':len(core),'stageFiles':len(staged),'selectedSourceSha256':SOURCE,'stageVectorSha256':STAGE,'archiveMembers':archive_counts,'references':reference_counts,'unchanged16Helpers':unchanged,'stringOnlyFunctionChanges':string_changes,'collectorChanges':expected_changes,'checks':CHECKS,'originalPreflight':{'pid':721894,'elapsedSeconds':outcome['elapsedSeconds'],'executionSha256':sha(PREP/'PREFLIGHT-EXECUTION.json')},'gitReadonlyWarnings':GIT_WARNINGS,'limits':'Independent stdlib read/hash/AST/Git/archive review only. No project import or preflight/test/SDK/compiler/scorer/VM/metric/native repeat, dispatch or API write. Strict actual capture and code identity remain pending root-owned one job. Native SUCCESS/source rejection/VM0 remain separate; no source gain or source PR.'}
(OWN/'AUTHENTICATION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':'PASS','checks':len(CHECKS),'authenticationSha256':sha(OWN/'AUTHENTICATION.json'),'source':SOURCE,'stage':STAGE}))
