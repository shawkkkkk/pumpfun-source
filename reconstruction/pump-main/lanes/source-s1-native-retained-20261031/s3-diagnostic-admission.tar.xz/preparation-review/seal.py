"""Seal the independent S3 diagnostic preparation review, no project execution."""
from pathlib import Path
import ast,copy,hashlib,json,os,re,subprocess,sys
assert os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode
ROOT=Path('/dev/shm/pump-cto-settings-s3-ir');PREP=ROOT/'work/diagnostic-prep';OWN=ROOT/'work/capture-review';OLD=Path('/dev/shm/pump-cto-option-c1/work/diagnostic-prep')
lane='reconstruction/pump-main/lanes/current-native-ir-capture'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
dump=lambda n:ast.dump(n,include_attributes=False)
def assign(t):return {n.targets[0].id:n for n in t.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
def funcs(t):return {n.name:n for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
auth=load(OWN/'AUTHENTICATION.json');assert sha(OWN/'AUTHENTICATION.json')=='45fed31c18890268feaa24c8b93b1c805813a61f9895d6e68cdffc81a5a8ff51'
actual=ast.parse((PREP/'ops'/lane/'pump_ir_control.py').read_text());prior=ast.parse((OLD/'ops'/lane/'pump_ir_control.py').read_text());current_nodes,prior_nodes=funcs(actual),funcs(prior)
expected=ast.parse("""normal_result = json.loads((TRACE_REFERENCE / 'RESULT.json').read_text())
require(normal_result['base'] == BASE and normal_result['sourceUnchanged']
        and normal_result['registrySourceUnchanged'] and normal_result['toolInputsUnchanged']
        and normal_result['coldTarget'] and normal_result['noNormalizedLosses']
        and normal_result['noRawLosses'] and 'FAILURE.json' not in TRACE_FILES,
        'actual normal S3 success admission differs; source-metric rejection is separate')
require(comparison['sourceCommit'] == BASE and comparison['sourceSha256'] == EXPECTED_SOURCE_SHA256
        and comparison['referenceBase'] == REFERENCE_BASE and comparison['referenceRun'] == REFERENCE_RUN
        and comparison['referenceArtifactId'] == REFERENCE_ARTIFACT and comparison['fullRowsCompared'] == 1035
        and comparison['noNormalizedLosses'] and comparison['noRawLosses'], 'actual normal S3 no-loss comparison differs')
""").body
trace=copy.deepcopy(current_nodes['verify_trace_reference']);old_trace=prior_nodes['verify_trace_reference']
for index,node in zip((3,4,6),expected):assert dump(trace.body[index])==dump(node)
for index in (3,4,6):trace.body[index]=copy.deepcopy(old_trace.body[index])
for n in ast.walk(trace):
 if isinstance(n,ast.Constant) and isinstance(n.value,str):n.value=n.value.replace('s3-reference-','c1-reference-')
assert dump(trace)==dump(old_trace)
normalized=copy.deepcopy(actual);old_assign=assign(prior)
allowed_pins={'BASE','EXPECTED_SOURCE_SHA256','REFERENCE_BASE','REFERENCE_SOURCE_SHA256','EVIDENCE','WORK','REFERENCE','REFERENCE_RUN','REFERENCE_ARTIFACT','REFERENCE_ZIP_SHA256','REFERENCE_FILES','TRACE_REFERENCE','TRACE_RUN','TRACE_ARTIFACT','TRACE_ZIP_SHA256','TRACE_FILES','TRACE_TARGET_EXTENT'}
for name,node in assign(normalized).items():
 if name in allowed_pins:node.value=copy.deepcopy(old_assign[name].value)
normalized.body[0]=copy.deepcopy(prior.body[0])
for index,node in enumerate(normalized.body):
 if isinstance(node,(ast.FunctionDef,ast.ClassDef)):normalized.body[index]=copy.deepcopy(prior_nodes[node.name])
assert dump(normalized)==dump(prior)

patch=(PREP/'OPS.patch').read_bytes();groups=re.split(rb'(?m)(?=^diff --git )',patch);paths=[]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1',GIT_ALLOW_PROTOCOL='file')
for group in groups:
 if not group:continue
 lines=group.splitlines(keepends=True);m=re.fullmatch(rb'diff --git a/(.+) b/(.+)\n',lines[0]);assert m and m[1]==m[2]
 name=m[1].decode();paths.append(name);new_file=b'--- /dev/null\n' in lines
 old=[] if new_file else subprocess.check_output(['git','show','65f0162a3dcd381df0f831082dd6732c9af4ab78:'+name],cwd=ROOT,env=env,stderr=subprocess.PIPE).splitlines(keepends=True)
 result=[];cursor=0;i=0
 while i<len(lines):
  header=re.match(rb'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[i])
  if not header:i+=1;continue
  old_start=int(header[1]);old_count=int(header[2] or b'1');new_count=int(header[4] or b'1');start=max(0,old_start-1)
  assert start>=cursor;result.extend(old[cursor:start]);cursor=start;i+=1;removed=added=0
  while i<len(lines) and not lines[i].startswith(b'@@ '):
   line=lines[i];assert line[:1] in (b' ',b'+',b'-'),line[:60]
   if line[:1] in (b' ',b'-'):
    assert cursor<len(old) and old[cursor]==line[1:];cursor+=1;removed+=1
   if line[:1] in (b' ',b'+'):result.append(line[1:]);added+=1
   i+=1
  assert removed==old_count and added==new_count
 result.extend(old[cursor:]);assert b''.join(result)==(PREP/'ops'/name).read_bytes()
assert len(paths)==4 and set(paths)=={r['path'] for r in auth['operationalFiles']}
freeze=load(PREP/'FROZEN-MANIFEST.json');assert sha(PREP/'FROZEN-MANIFEST.json')==auth['authorFreezeSha256']
for row in freeze['files']:
 p=PREP/row['path'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
supplement={'status':'PASS','traceReferenceFunctionalDelta':'Exactly replace original C1 FAILURE admission with normal-S3 RESULT source/registry/tool/cold/noLoss SUCCESS and require both no-loss flags; same pinned source/CORE/stage/target/full-score checks.','wholeModuleDelta':'All imports/top-level code exact C1 apart frozen source/reference/owned-path/target-size constants and module description; all functions separately authenticated.','patchReconstruction':'All four unified-diff paths reconstructed in memory from exact frozen S3 Git or empty new files and equal final OPS bytes; no index/worktree mutation.','patchSha256':sha(PREP/'OPS.patch'),'noExecution':'No project import, no preflight/test/SDK/compiler/scorer/VM/metric/native repeat or remote action.'}
(OWN/'SUPPLEMENTAL.json').write_text(json.dumps(supplement,indent=2)+'\n')
review={'verdict':'GO exact measured-S3 four-file diagnostic preparation only','source':auth['source'],'sourceSha256':auth['selectedSourceSha256'],'authorFreezeSha256':auth['authorFreezeSha256'],'operations':auth['operationalFiles'],'authenticationSha256':sha(OWN/'AUTHENTICATION.json'),'supplementalSha256':sha(OWN/'SUPPLEMENTAL.json'),'checks':[
 {'check':'Frozen checkout, four operational files and patch','pass':True,'detail':'All46 frozen preparation files,141physical Git source/236CORE/142stage, exact maintained projection and283 archive members authenticated. Four-file patch independently reconstructs exact OPS bytes.'},
 {'check':'Known qualified capture boundary and guards','pass':True,'detail':'Entire C1 collector exact apart selected S3 source pin and source-description text. Fixed target/JT/five-machine flags, argv/cwd/env/forwarding/restoration/output admission and partial retention unchanged. All16 guard helper/class ASTs exact; main only descriptive strings/cache-label changes.'},
 {'check':'Actual baseline and successful S3 self-reference','pass':True,'detail':'Both original transport ZIPs/CRC/safe exact43+45 members and extracted bytes bind actual13fe baseline and normalS3. S3 RESULT/noLossSUCCESS, source/CORE/stage, target extent27400 and all1035rows authenticated; source internal rejection remains separate. Only functional reference change is exact successful-result guard replacing C1 negative failure guard.'},
 {'check':'Strict code and complete trace qualification','pass':True,'detail':'Diagnostic comparator exact C1 AST apart two scope strings: full stripped bytes, all non-symbol payloads, all semantic functions and numeric symbol fields, allowed-only-local-OBJECT names, all1035rows required. Optimized target definition, two ordered complete JT pairs, five complete machine bodies and single compiler call required; partial bytes retained and unqualified.'},
 {'check':'Single real noSDK preflight','pass':True,'detail':'Original PID721894/exit0/1.8331s,470unchanged before/after bindings, exact stdout/stderr and real maintained stage/link receipts authenticated without rerun. Final controller has only documented module docstring amendment; executed controller copy/hash and all remaining AST exact.'},
 {'check':'Workflow and claim boundary','pass':True,'detail':'Manual-only macos26 pinned actions, exact two artifacts, one controller and always upload. Direct-childS3 fourOPS guard retained. No source PR/gain, original-source/type/bool-niche claim or S3 runtime qualification; actual source metric negative and VMheld0 preserved.'}
 ],'limits':['Preparation-only GO; actual optimized/JT/machine output and strict same-S3 code/row identity remain pending one root-owned capture.','Native normal S3 SUCCESS/noLoss and internal source rejection are different results. Diagnostic success cannot promote rejected S3 or authorize any next source/flag/layout variant.','Independent read/hash/AST/archive/Git only. No project/preflight/test/SDK/compiler/scorer/VM/metric/native execution, source edit, dispatch or API write.']}
(OWN/'REVIEW.json').write_text(json.dumps(review,indent=2)+'\n')
names=['authenticate.py','authenticate.stdout','authenticate.stderr','AUTHENTICATION.json','seal.py','SUPPLEMENTAL.json','REVIEW.json']
(OWN/'MANIFEST.json').write_text(json.dumps({'status':'SEALED_INDEPENDENT_PREPARATION_GO','files':{n:{'bytes':(OWN/n).stat().st_size,'sha256':sha(OWN/n)} for n in names},'originalPreparationUnchanged':True},indent=2)+'\n')
print(json.dumps({'verdict':'GO','reviewSha256':sha(OWN/'REVIEW.json'),'authenticationSha256':sha(OWN/'AUTHENTICATION.json'),'supplementalSha256':sha(OWN/'SUPPLEMENTAL.json'),'manifestSha256':sha(OWN/'MANIFEST.json')}))
