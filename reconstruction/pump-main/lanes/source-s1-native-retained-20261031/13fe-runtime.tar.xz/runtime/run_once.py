"""One released 13fe CTO runtime comparison. Never retries the VM runner."""
import base64
import datetime
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time

ROOT = Path('/dev/shm/pump-cto-13fe453')
OUT = ROOT / 'work/runtime-13fe'
REV = '13fe4536be64d8c5c10f8905e9d2236f423ac4f4'
EXPECTED = 'fe099633c59f1a409f66d7b7bd6ce702580116c92ac24cb26842a351f3ee459e'
EXPECTED_SIZE = 1934832
EXPECTED_SOURCE = 'ba203d5c8b0cda5ab3bb6eec65266a992331b7a8a361b9977a3d2ab474b11fe2'
ARTIFACT = ROOT / 'work/native-run/artifact'
CANDIDATE = ARTIFACT / 'candidate.so'
SNAPSHOT = OUT / 'candidate-frozen.so'
REPORT = OUT / 'runtime-report.json'
ADMISSION = ROOT / 'work/root/CURRENT-ELF-ADMISSION.json'
SCRIPTS = [
    'pump_admin_cto_differential.py', 'fees_donation_create_differential.py',
    'fees_admin_differential.py', 'pump_validate_admin.py',
    'pump_amm_admin_differential.py', 'pump_amm_reusable_harness.py',
    'pump_differential_output.py',
]
IMAGES = [
    ('original', 'pump'), ('original', 'pump_fees'), ('original', 'pump_amm'),
    ('dependencies', 'spl_token'), ('dependencies', 'spl_token_2022'),
    ('dependencies', 'associated_token'),
]
INPUTS = [(f'scripts/{name}', 'runtime-source') for name in SCRIPTS]
INPUTS += [(f'evidence/upstream/{name}.json', 'runtime-data')
           for name in ('pump', 'pump_fees', 'pump_amm')]
INPUTS += [('research/imported-lab/analysis/pump_fun/config-snapshot.json', 'runtime-data')]
INPUTS += [(f'evidence/{kind}/{name}/deployed.so', 'runtime-image') for kind, name in IMAGES]
INPUTS += [(f'evidence/{kind}/{name}/capture.json', 'capture-admission-metadata') for kind, name in IMAGES]
INPUTS += [('requirements.txt', 'dependency-pin')]


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def inspect(path):
    state = path.lstat()
    need(stat.S_ISREG(state.st_mode), 'Input must be a physical regular file: ' + str(path))
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data),
            'gitBlob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(),
            'physical_mode': state.st_mode, 'device': state.st_dev, 'inode': state.st_ino,
            'mtime_ns': state.st_mtime_ns}


ENV = os.environ.copy()
ENV.pop('PYTHONOPTIMIZE', None)
ENV.pop('PYTHONPATH', None)
ENV['PYTHONDONTWRITEBYTECODE'] = '1'
ENV['GIT_NO_LAZY_FETCH'] = '1'
TEMP = Path('/dev/shm/p13fe-363-' + str(os.getpid()))
ENV['TMPDIR'] = str(TEMP)


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, env=ENV)


def tree(paths):
    entries = {}
    for entry in git('ls-tree', '-r', '-z', REV, '--', *paths).rstrip(b'\0').split(b'\0'):
        metadata, path = entry.split(b'\t')
        entries[path.decode()] = metadata.decode().split()
    return entries


def bound_inputs():
    entries = tree([path for path, _ in INPUTS])
    need(len(entries) == len(INPUTS) == 24, 'Wrong current Git input cardinality')
    rows = []
    for path, kind in INPUTS:
        actual = inspect(ROOT / path)
        mode, typ, blob = entries[path]
        need(typ == 'blob' and mode in ('100644', '100755'), 'Unexpected Git input type: ' + path)
        need(actual['gitBlob'] == blob, 'Physical input differs from frozen Git: ' + path)
        need((ROOT / path).read_bytes() == git('show', f'{REV}:{path}'), 'Full Git byte mismatch: ' + path)
        need(bool(actual['physical_mode'] & 0o111) == (mode == '100755'), 'Input mode mismatch: ' + path)
        rows.append({**actual, 'path': path, 'kind': kind, 'mode': mode})
    bindings = []
    for kind, name in IMAGES:
        prefix = f'evidence/{kind}/{name}/'
        image = next(row for row in rows if row['path'] == prefix + 'deployed.so')
        capture = json.loads((ROOT / (prefix + 'capture.json')).read_bytes())
        need(image['sha256'] == capture['payload_sha256'] and image['bytes'] == capture['payload_bytes'],
             'Captured image binding failed: ' + name)
        bindings.append({'path': image['path'], 'program_id': capture['program'],
                         'sha256': image['sha256'], 'bytes': image['bytes'],
                         'capture': prefix + 'capture.json'})
    return {'source_revision': REV, 'root': str(ROOT), 'input_count': len(rows),
            'actually_consumed_runtime_inputs': 17, 'admission_only_inputs': 7,
            'files': rows, 'image_bindings': bindings,
            'input_vector_sha256': sha(json.dumps(rows, sort_keys=True, separators=(',', ':')).encode())}


def bound_source():
    source = json.loads((ARTIFACT / 'source-inputs.json').read_bytes())
    declared = json.loads((ARTIFACT / 'program-source-inputs.json').read_bytes())
    need(source['sha256'] == EXPECTED_SOURCE and declared['base'] == REV, 'Wrong native source cohort')
    entries = tree(['programs/pump'])
    need(len(entries) == len(source['files']) == len(declared['files']) == 141, 'Wrong source cardinality')
    actual_rows, binding_rows = [], []
    for path, (mode, typ, blob) in sorted(entries.items()):
        actual = inspect(ROOT / path)
        need(typ == 'blob' and mode in ('100644', '100755') and actual['gitBlob'] == blob,
             'Source differs from Git: ' + path)
        need((ROOT / path).read_bytes() == git('show', f'{REV}:{path}'), 'Full source Git byte mismatch: ' + path)
        actual_rows.append({'path': str(Path(path).relative_to('programs/pump')),
                            'bytes': actual['bytes'], 'executable': bool(actual['physical_mode'] & 0o111),
                            'sha256': actual['sha256']})
        binding_rows.append({**actual, 'path': path, 'mode': mode})
    need(actual_rows == source['files'], 'Source bytes/modes differ from native manifest')
    aggregate = sha(json.dumps(actual_rows, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode())
    need(aggregate == EXPECTED_SOURCE, 'Source aggregate mismatch')
    for row in declared['files']:
        actual = next(item for item in binding_rows if item['path'] == row['path'])
        need(all(actual[key] == row[key] for key in ('mode', 'gitBlob', 'bytes', 'sha256')),
             'Native source Git binding differs: ' + row['path'])
    return {'sha256': aggregate, 'file_count': len(actual_rows), 'files': binding_rows}


def bound_external():
    rows, versions = [], {}
    for name in ('solders', 'jsonalias', 'typing_extensions'):
        distribution = importlib.metadata.distribution(name)
        versions[name] = distribution.version
        for path in sorted(distribution.files, key=str):
            if '__pycache__' in path.parts or str(path).endswith('.pyc'):
                continue
            absolute = Path(distribution.locate_file(path))
            if absolute.is_file():
                rows.append(inspect(absolute))
    need(versions['solders'] == '0.27.1', 'Unexpected solders runtime version')
    executable = Path(sys.executable).resolve()
    return {'versions': versions, 'files': rows, 'python_executable': inspect(executable),
            'python_version': sys.version, 'optimized': sys.flags.optimize,
            'dont_write_bytecode': sys.dont_write_bytecode}


def candidate(path):
    actual = inspect(path)
    need(actual['sha256'] == EXPECTED and actual['bytes'] == EXPECTED_SIZE,
         'Candidate full-byte admission failed: ' + str(path))
    return actual


def main():
    need(os.environ.get('PYTHONDONTWRITEBYTECODE') == '1' and sys.flags.optimize == 0 and sys.dont_write_bytecode, 'Explicit no-bytecode environment and normal Python -B required')
    need(Path(__file__).resolve().parent == OUT, 'Wrong controller root')
    need(not any((OUT / path).exists() for path in ('RUN-STARTED.json', 'runtime-report.json',
             'candidate-frozen.so', 'stdout.log', 'stderr.log')), 'Prior attempt exists; no duplicate run')
    need(git('rev-parse', 'HEAD').decode().strip() == REV, 'Physical revision changed')
    need(not git('status', '--porcelain', '--untracked-files=no').strip(), 'Tracked root is dirty')
    admission_raw = ADMISSION.read_bytes()
    admission = json.loads(admission_raw)
    need(admission['base'] == REV and admission['run'] == 41170683278 and
         admission['images']['candidate.so'] == EXPECTED and admission['sourceSha256'] == EXPECTED_SOURCE and
         admission['sourceAndArchiveAdmission'] == admission['independentOfficialScorer'] == 'PASS',
         'Wrong or incomplete fresh native admission')
    before = {'inputs': bound_inputs(), 'source': bound_source(), 'external_runtime': bound_external()}
    prep = json.loads((ROOT / 'work/runtime-inputs/ENVIRONMENT.json').read_bytes())
    for row in prep['runtime_files']:
        actual_runtime = inspect(Path(row['path']))
        need(actual_runtime['sha256'] == row['sha256'] and actual_runtime['bytes'] == row['bytes'], 'Prepared VM library/wrapper changed')
    identity = json.loads((ROOT / 'work/runtime-inputs/IDENTITY-FREEZE.json').read_bytes())
    need(before['external_runtime']['python_executable']['sha256'] == identity['python_sha256'], 'Prepared Python changed')
    artifact_before = candidate(CANDIDATE)
    with SNAPSHOT.open('xb') as stream:
        stream.write(CANDIDATE.read_bytes())
    SNAPSHOT.chmod(0o400)
    snapshot_before = candidate(SNAPSHOT)
    TEMP.mkdir(mode=0o700)
    argv = [sys.executable, '-B', 'scripts/pump_admin_cto_differential.py',
            '--candidate', str(SNAPSHOT), '--output', str(REPORT)]
    write('INPUTS-BEFORE.json', before)
    write('ROOT-ADMISSION.json', {'receipt': admission, 'bytes': len(admission_raw), 'sha256': sha(admission_raw)})
    write('RUN-STARTED.json', {'utc': now(), 'controller_pid': os.getpid(), 'argv': argv,
          'cwd': str(ROOT), 'environment': {key: ENV.get(key) for key in
          ('PYTHONOPTIMIZE', 'PYTHONPATH', 'PYTHONDONTWRITEBYTECODE', 'GIT_NO_LAZY_FETCH', 'TMPDIR')},
          'candidate_before': artifact_before, 'snapshot_before': snapshot_before,
          'controller': inspect(Path(__file__))})
    started = time.monotonic()
    with (OUT / 'stdout.log').open('xb') as stdout, (OUT / 'stderr.log').open('xb') as stderr:
        process = subprocess.Popen(argv, cwd=ROOT, env=ENV, stdout=stdout, stderr=stderr)
        write('PROCESS.json', {'pid': process.pid, 'ppid': os.getpid(), 'utc': now(),
              'argv': argv, 'proc_cmdline': Path(f'/proc/{process.pid}/cmdline').read_bytes().decode().split('\0')})
        print(json.dumps({'event': 'runtime-started', 'pid': process.pid, 'utc': now()}), flush=True)
        code = process.wait()
    process_result = {'pid': process.pid, 'exit_code': code, 'elapsed_seconds': time.monotonic() - started,
                      'finished_utc': now()}
    write('PROCESS-RESULT.json', process_result)
    problems = []
    identities_unchanged = False
    if code != 0:
        problems.append('Runner exited ' + str(code))
    try:
        after = {'inputs': bound_inputs(), 'source': bound_source(), 'external_runtime': bound_external()}
        write('INPUTS-AFTER.json', after)
        need(after == before, 'Input/source/runtime physical binding drifted during run')
        artifact_after, snapshot_after = candidate(CANDIDATE), candidate(SNAPSHOT)
        need(artifact_before == artifact_after and snapshot_before == snapshot_after, 'Candidate physical binding drifted')
        need(ADMISSION.read_bytes() == admission_raw, 'Root admission changed during runtime')
        need(git('rev-parse', 'HEAD').decode().strip() == REV, 'Root revision changed during runtime')
        need(not git('status', '--porcelain', '--untracked-files=no').strip(), 'Tracked root changed during runtime')
        identities_unchanged = True
    except Exception as error:
        problems.append(str(error))
    result = {'cohort': REV, 'native_run': 41170683278, 'candidate_sha256': EXPECTED,
              'source_sha256': EXPECTED_SOURCE, **process_result, 'raw_report_retained': REPORT.exists()}
    if REPORT.exists():
        raw = REPORT.read_bytes()
        result.update({'report_bytes': len(raw), 'report_sha256': sha(raw)})
        try:
            report = json.loads(raw)
            rows = report['cases']
            need(report['case_count'] == len(rows) == 363, 'Actual case cardinality differs from 363')
            result.update({'case_count': len(rows), 'match_count': sum(row['match'] is True for row in rows),
                           'mismatches': report['mismatches']})
            need(report['mismatches'] == [] and all(row['match'] is True for row in rows), 'Differential mismatch')
            expected_provenance = {str(ROOT / row['path']): row['sha256'] for row in before['inputs']['files']}
            expected_provenance[str(SNAPSHOT)] = EXPECTED
            need(report['candidate_sha256'] == EXPECTED, 'Wrong candidate report hash')
            need(report['original_sha256'] == expected_provenance[str(ROOT / 'evidence/original/pump/deployed.so')],
                 'Wrong original report hash')
            for path, value in report['provenance'].items():
                need(expected_provenance.get(path) == value, 'Unbound actual report provenance: ' + path)
            required = [str(ROOT / row['path']) for row in before['inputs']['files']
                        if row['kind'] == 'runtime-image'] + [str(SNAPSHOT)]
            need(all(path in report['provenance'] for path in required), 'Report missing actual image hashes')
            verified = sum(row[side].get('signatures_verified') is True for row in rows for side in ('original', 'candidate'))
            nonsigner = sum(row[side].get('pool_authority_top_level_signer') is False for row in rows for side in ('original', 'candidate'))
            result.update({'signatures_verified_rows': verified, 'pool_authority_nonsigner_rows': nonsigner,
                'original_success': sum(row['original']['error'] is None for row in rows),
                'candidate_success': sum(row['candidate']['error'] is None for row in rows),
                'original_rejected': sum(row['original']['error'] is not None for row in rows),
                'candidate_rejected': sum(row['candidate']['error'] is not None for row in rows)})
            need(verified == nonsigner == 726, 'Signature/pool-authority invariant failed')
            from solders.transaction import Transaction
            from solders.pubkey import Pubkey
            pool = Pubkey.from_string('6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P')
            mint = Pubkey.from_bytes(bytes([61]) * 32)
            pool_authority = Pubkey.find_program_address([b'pool-authority', bytes(mint)], pool)[0]
            cryptographic_checks = 0
            for row in rows:
                for side in ('original', 'candidate'):
                    tx = Transaction.from_bytes(base64.b64decode(row[side]['transaction_base64'], validate=True))
                    need(all(tx.verify_with_results()), 'Saved transaction signature failed: ' + row['case']['name'])
                    signed = tx.message.header.num_required_signatures
                    need(pool_authority not in list(tx.message.account_keys)[:signed], 'Saved pool authority is a top-level signer')
                    cryptographic_checks += 1
            result['independent_saved_transaction_verifications'] = cryptographic_checks
        except Exception as error:
            problems.append(str(error))
    else:
        problems.append('No complete raw runtime report retained')
    result['inputs_unchanged'] = identities_unchanged
    result['problems'] = problems
    result['status'] = 'PASS' if not problems else 'FAIL'
    write('RESULT.json', result)
    retained = {}
    for path in sorted(OUT.iterdir()):
        if path.is_file():
            data = path.read_bytes()
            retained[path.name] = {'bytes': len(data), 'sha256': sha(data)}
    write('SEALED-RECEIPT.json', {'schema': 'frozen-13fe-cto-runtime-v1', 'sealed_utc': now(),
          'result': result, 'files': retained,
          'limits': 'Exactly one unchanged 363-case synthetic signed LiteSVM comparison for frozen13fe candidate. '
                    'No full-program equivalence, security clearance, source gain, or qualification of later source.',
          'agent_disclosure': {'provider': 'OpenAI', 'model': 'GPT-6', 'client': 'Codex'}})
    print(json.dumps(result, indent=2), flush=True)
    return 0 if not problems else 1


if __name__ == '__main__':
    raise SystemExit(main())
