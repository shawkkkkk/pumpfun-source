"""Cache-only S4 mechanism proof; no ELF, tail, compiler, metric, or VM."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
CACHE = HERE / "S4-PREFIX.json"
CACHE_SHA = "07cf2e060769de01ee7e9af56d78c39b66df585fad99f7e18f34898cee2ede3a"
EBE = Path("/dev/shm/pump-cto-ebe5387/work/fee-success-live-copies/LIVE-COPIES.json")
ORIGINAL = Path("/dev/shm/pump-cto-option-c1/work/shared-boundary-query/ORIGINAL-SHARED-FLOW.json")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert sha(CACHE) == CACHE_SHA
    assert sha(EBE) == "b60a9191788b2585fd9a4d959688e97b4c8f0ddcc320cf37c4cfa48d37d751e0"
    assert sha(ORIGINAL) == "05e4f56ad4280ae06df4eda4ae7296dd0bb3cadc8c6def1ee068ec1fdc0ae978"
    data = json.loads(CACHE.read_text())
    assert data["status"] == "PREFIX_CAPTURE_PASS"
    assert not data["scopedOutlineCallsInPrefix"]
    rows = data["rows"]
    by = {r["offset"]: r for r in rows}
    succ = {int(k): v for k, v in data["successors"].items()}
    pred = {int(k): v for k, v in data["predecessors"].items()}

    def span(lo, hi):
        return [r for r in rows if lo <= r["offset"] < hi]

    def reach(start, graph, removed=None):
        todo, seen = [start], set()
        while todo:
            p = todo.pop()
            if p == removed or p in seen:
                continue
            seen.add(p)
            todo.extend(graph[p])
        return seen

    def path_nodes(start, end):
        return reach(start, succ) & reach(end, pred)

    def overlaps(row, kind, lo, hi):
        return (row.get("memoryKind") == kind and row.get("memoryBase") == 10
                and row["displacement"] < hi
                and lo < row["displacement"] + row["memoryWidth"])

    def reg_defs(pc, register):
        todo, seen, defs = list(pred[pc]), set(), set()
        entry = False
        while todo:
            p = todo.pop()
            if p in seen:
                continue
            seen.add(p)
            r = by[p]
            defined = (register <= 5 if r["opcode"] == 0x85 else
                       r["dst"] == register and (r["opcode"] == 0x18 or r["opcode"] & 7 in (1, 4, 7)))
            if defined:
                defs.add(p)
            else:
                entry |= not pred[p]
                todo.extend(pred[p])
        return {"at": pc, "register": register, "definitions": [by[p] for p in sorted(defs)],
                "entryWithoutDefinition": entry}

    # Actual selected-key object is read by the four outer-pack loads below.
    key_reads = [r for r in rows if overlaps(r, "read", -1280, -1248)]
    key_writes = [r for r in rows if overlaps(r, "write", -1280, -1248)]
    assert [r["offset"] for r in key_reads] == [0x1B98, 0x1BA8, 0x1BB8, 0x1BC8]
    assert [r["offset"] for r in key_writes] == [0x5A0, 0x5B0, 0x5C0, 0x5E0, 0x5F0,
            0x600, 0x610, 0x640, 0x650, 0x660, 0x670, 0xC10, 0xC18, 0xC20, 0xC28]

    # Derive fee spill and reads from actual reviewed public incomingR4.
    fee_spills = [r for r in rows[:8] if r["opcode"] == 0x7B and r["src"] == 4 and r["dst"] == 10]
    assert len(fee_spills) == 1
    slot = fee_spills[0]["displacement"]
    fee_writes = [r for r in rows if overlaps(r, "write", slot, slot + 8)]
    assert fee_writes == fee_spills
    fee_reads = [r for r in rows if r.get("memoryKind") == "read" and r.get("memoryBase") == 10 and r["displacement"] == slot]
    fee_tests = [by[r["offset"] + r["bytes"]] for r in fee_reads]
    assert [r["offset"] for r in fee_tests] == [0xB20, 0x14B0]
    assert all(r["opcode"] == 0x15 and r["immediate"] == 0 for r in fee_tests)

    # C first8 merges with N at+670; C remaining24 was already stored.
    c_checks = []
    for test in fee_tests:
        nodes = path_nodes(0x590, test["offset"])
        assert test["offset"] not in reach(0x590, succ, removed=0x670)
        writes_after_complete = [r for r in key_writes if r["offset"] != 0x670
                                 and r["offset"] in path_nodes(0x670, test["offset"])]
        assert not writes_after_complete
        c_checks.append({"feeTest": test, "nodesOnDirectPathsFromCChoice": len(nodes),
                         "completedCStore670DominatesFrom590": True,
                         "overlappingDirectKeyWritesAfterComplete": writes_after_complete})
    nodes_to_outer = path_nodes(0x670, 0x1BD0)
    later_writes = [r for r in key_writes if r["offset"] != 0x670 and r["offset"] in nodes_to_outer]
    assert not later_writes

    # Original source roles are bound by fresh literal pointer chains, not Ebe frames.
    assert by[0x110]["dst"] == 7 and by[0x110]["src"] == 9 and by[0x110]["displacement"] == -4088
    assert by[0x538]["dst"] == 7 and by[0x538]["immediate"] == 1
    assert [r["offset"] for r in reg_defs(0x638, 7)["definitions"]] == [0x538]
    assert [r["offset"] for r in reg_defs(0x590, 6)["definitions"]] == [0x260]
    assert by[0x260]["displacement"] == 56 and by[0x590]["immediate"] == 8
    assert by[0x218]["callName"] and "find_program_address" in by[0x218]["callName"]
    assert by[0x1E8]["immediate"] == -1665

    # Meaningful N is retained independently before target choice and copied later.
    n_saved_writes = [r for r in rows if overlaps(r, "write", -1632, -1600)]
    assert [r["offset"] for r in n_saved_writes] == [0x4A8, 0x4B8, 0x4C8, 0x4D8]
    n_copy = span(0x1A10, 0x1A50)
    assert len(n_copy) == 8
    assert [r["displacement"] for r in n_copy[::2]] == [-1608, -1616, -1624, -1632]
    assert [r["displacement"] for r in n_copy[1::2]] == [-688, -696, -704, -712]

    result = {
        "status": "STRUCTURAL_PREDICTION_REALIZED_SOURCE_STILL_REJECTED",
        "nativeInput": data["input"], "source": data["source"],
        "actualBounds": {"execute": data["execute"], "prepare": data["prepare"], "prefix": data["prefix"]},
        "primaryLateKNThenPreUseCOverwrite": "ABSENT_IN_BOUND_SELECTED_KEY_FLOW",
        "secondaryActualCChoiceBeforeFee": "PROVED_BY_COMPLETED32_BYTE_SELECTION_AND_DIRECT_CFG",
        "sourceAcceptance": "REJECTED_687_RAW_LOSSES; this structural result supplies no target metric, runtime, gain, or source GO",
        "outlineBoundary": {"symbols": data["scopedOutlineSymbols"], "calls": data["scopedOutlineCallsInPrefix"]},
        "actualFeeTag": {"incomingABIRegister": 4, "spill": fee_spills[0], "reads": fee_reads, "tests": fee_tests,
                         "roleLimit": "Uses the reviewed unchanged public execute Option fee ABI; no original Unit ABI is inferred."},
        "selectedKey": {
            "frameRange": [-1280, -1248],
            "KProducer": {"PDASetupAndCopy": span(0x1E0, 0x260), "targetRows": span(0x5D8, 0x618),
                          "meaning": "source hk.0 key32 from actual named PDA outputFP-1665; not seed/mint/bump"},
            "CProducer": {"pointerRows": [by[p] for p in (0x260, 0x590)], "targetRows": span(0x590, 0x5D8) + [by[0x670]],
                          "meaning": "actual curve pointer accounts+56, creator at+8; remaining24 stores5a0/5b0/5c0 and first8 store670 complete C32"},
            "NProducer": {"publicPointerRows": [by[p] for p in (0, 0x110, 0x538)], "targetRows": span(0x628, 0x678),
                          "meaning": "new payload pointer+1; valid nonholder SomeN uses638..670"},
            "zeroFallbackRows": span(0xC10, 0xC38),
            "zeroFallbackLimit": "Missingnew can form zero before validation; nonholder None must later fail existing required-new validation. No successful N value or original type is invented from this branch.",
            "choiceGuardRows": span(0x540, 0x590),
            "allDirectWrites": key_writes, "allDirectReads": key_reads,
            "CCompletedBeforeFeeProof": c_checks,
            "CToOuterPathNodes": len(nodes_to_outer), "overlappingDirectWritesAfterCComplete": later_writes,
            "outerCopyRows": span(0x1B98, 0x1BD8), "outerDestination": [-1384, -1352],
            "consumerLimit": "The proved current native consumer is the pre-prepare outer32 pack. No S4 curve/Fees/pool tail is read or transferred from Ebe/S3."},
        "distinctNSharing": {
            "savedFrameRange": [-1632, -1600], "eagerSaveRows": span(0x490, 0x4E0),
            "allDirectSavedWrites": n_saved_writes,
            "sharedNonholderChoiceRows": span(0x19C0, 0x1A10),
            "copyRows": n_copy, "scratchRange": [-712, -680],
            "outerCopyRows": span(0x1B58, 0x1B98), "outerDestination": [-1352, -1320],
            "meaning": "Meaningful N32 copied only on shared nonholder branch; distinct and adjacent to selectedK/C/N32. Reset/absent payload paths get no invented Pubkey meaning.",
            "consumerLimit": "No S4 final Fees serialization or observable payload claim."},
        "validFeePathHeads": {"someAfterRange": span(0x1798, 0x17A8),
                              "someSharedRead": span(0x19C0, 0x19D8),
                              "noneHolderSharedRead": span(0x1A70, 0x1A98),
                              "noneNonholderSharedRead": span(0x17A8, 0x17C8),
                              "limit": "Validated success paths have distinct shared reads. Raw predecessor19b8 also has the fallible error/success-tag gate; no original Result/Unit ABI is recovered from it."},
        "registerChecks": [reg_defs(0x638, 7), reg_defs(0x590, 6)],
        "comparators": {"EbeLiveCopyReceipt": {"path": str(EBE), "sha256": sha(EBE)},
                        "OriginalPrefeeSelectionReceipt": {"path": str(ORIGINAL), "sha256": sha(ORIGINAL)},
                        "difference": "Ebe late commonK/N fragments followed by C replacement is gone. S4 selectedK/C/N32 reaches fee checks and outer pack without later direct key writes, consistent with the original prefee-selection constraint. Packing and native phase sizes remain independently different; no original Unit ABI claim."},
        "limits": ["Direct register/FP/CFG proof and reviewed public argument/callee-save contracts; no arbitrary opaque-callee alias closure.",
                   "CompletedC dominates both reachable fee-test sites from Cchoice; no direct overlapping key write exists afterward. This does not claim a universal memory fence or Rust lifetime theorem.",
                   "Only saved native prefix is consumed here; no second ELF decode, original decode, metric, scorer, compiler, VM, or source action.",
                   "Current tail consumers remain outside release; original closed consumers cannot be transferred into S4 frames.",
                   "Source is rejected; NO_NEW_VARIANT_GO, no automatic retry or metric/VM release."]}
    (HERE / "MECHANISM.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "primary": result["primaryLateKNThenPreUseCOverwrite"],
                      "secondary": result["secondaryActualCChoiceBeforeFee"],
                      "outputSha256": sha(HERE / "MECHANISM.json")}, indent=2))


if __name__ == "__main__":
    main()
