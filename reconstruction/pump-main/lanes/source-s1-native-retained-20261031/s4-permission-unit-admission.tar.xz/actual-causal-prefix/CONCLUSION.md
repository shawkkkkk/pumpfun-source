S4 realizes the predeclared structural change in the bounded native prefix. The Ebe late validated-K/N key transport followed by a pre-use C overwrite is absent. Actual C32 selection completes before fee validation and survives into the outer selected-key pack. The source remains rejected for687 raw losses; no target metric, runtime, gain, source acceptance, or new variant follows from this result.

The single released inspection ran as PID732401. It derived actual executeVA0x22a10/27144 bytes and the named prepare call at+1c10, rather than reusing Ebe+1a88. The decoded prefix is7192 bytes/851 logical instructions, SHAdccbdbac3436efb7244a6ae0b829302dfa30f454c4243180796196d21ed89007. No scoped named validate/sweep function or matching prefix call was found. BEFORE/AFTER hashes bind the admitted source, GO, plan, independent39-check review, root admission, and exact ELF; all inputs remained unchanged. Native decoding occurred once; the second ELF byte read was an integrity hash only.

The actual selected-key object isFP[-1280,-1248). Its producers are field-bound:

| Value | Actual producer and selection |
| --- | --- |
| K | Actual holder-rewards PDA outputFP-1665 from named call+218. Four key-word copies+5d8..610 select K32. The separate retained key startsFP-1704; no key identity is inferred from a reused Ebe offset. |
| C | Actual accounts+56 curve pointer at+260; +590 adds8 to creator. Stores+5a0/+5b0/+5c0 select C's remaining24 bytes and+670 stores its first8. This completes C32 before validation/fee branches. |
| N | Actual public-new pointer load+110, payload increment+538, then four loads/stores+638..670 select valid N32. A separately guarded missing-new zero fallback+c10..c28 is not assigned a successful N value. |

From the C-choice entry+590, completed first-word store+670 dominates both reachable fee tests. Incoming feeR4 is actually spilled at+8 toFP-2312; the only two prefix reads/tests are+b18/+b20 and+14a8/+14b0. There is no direct write overlapping the selected key after completed C selection on paths reaching either fee test or the outer key consumer. These are direct CFG/FP facts, with opaque-callee alias limits retained. An early C load alone was not used as the criterion: the complete32-byte selected object is established.

The only direct selected-key reads in the prefix are+1b98/+1ba8/+1bb8/+1bc8. They copy its four words to outerFP[-1384,-1352) at+1ba0/+1bb0/+1bc0/+1bd0. No post-fee C replacement of this object occurs. This differs from Ebe common+1760..1798 K/N fragments followed by C replacement+1870..18b8. S4's C choice also precedes the creator/target validation body, whereas the original05e4 receipt places nonholder selection after the supplied-new checks. The narrower pre-fee/survival criterion is realized; full original phase order or source ABI is not claimed.

Incoming N remains separate. Before selection, public-new payload bytes are saved at+4a8/+4b8/+4c8/+4d8 intoFP[-1632,-1600). The shared nonholder path copies those four words at+1a10..1a48 into scratchFP[-712,-680), then+1b58..1b90 copies them into outerFP[-1352,-1320). That object is adjacent to and distinct from selected K/C/N. Reset/absent paths have no invented Pubkey payload meaning. The proved current consumers are these pre-prepare stores; no S4 tail, curve, Fees, pool, event, or serialized-output consumer was inspected or imported from Ebe/S3.

Validated feeSome paths reach shared read/test+19c0/+19c8 after range-success+1798/+17a0. Validated feeNone holder and nonholder paths use their separate shared reads+1a88 and+17b0. The raw fallible-tag join also has a predecessor to+19c0; no original Result/Unit ABI is inferred from that branch. Two fee-presence tests remain, so this is not a claim of the original three-site layout.

MECHANISM.json retains exact raw producers, choice guards, all direct key writes/reads, path/dominance checks, distinct N copy, comparator hashes, and limits. The original05e4 preselected-K/C/N8+24 proof and Ebe03d36cec/b60a9191 late-copy counterexample are read unchanged. No whole-original decode, native retry, compiler, scorer, metric, VM, source edit, or source fix occurred. NO_NEW_VARIANT_GO.
