"""Authenticate genuine S4 inputs and the unchanged plain Ebe control recipe."""
from pathlib import Path
import ast, hashlib, json, os, shutil, subprocess, sys
assert os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode and sys.flags.optimize==0
R=Path('/dev/shm/pump-cto-permission-s4');O=R/'work/native-prep';OLD=Path('/dev/shm/pump-cto-ebe5387')
S='a119f880c73de06084df27a2b2cbffec09a6f46c';P='ebe5387e12e948c2534618adf7a3cf0f27d9de51';T='cb9c5dc663f5e54509ea12fefef3af7b96fcd1c0'
CORE=('reconstruction/harness','reconstruction/toolchain','reconstruction/base','reconstruction/pump-main/baseline','evidence/original/pump')
OPS=['.github/workflows/qualify-pump-macos-v144.yml','reconstruction/pump-main/lanes/current-native-control/pump_current_control.py','reconstruction/pump-main/lanes/current-native-control/README.md']
sha=lambda b:hashlib.sha256(b).hexdigest();env={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_ALLOW_PROTOCOL':'file','PYTHONDONTWRITEBYTECODE':'1'}
def git(*a):return subprocess.run(['git',*a],cwd=R,env=env,check=True,capture_output=True).stdout
assert git('rev-parse','HEAD').decode().strip()==S and git('rev-parse','HEAD^{tree}').decode().strip()==T
assert[x[7:].decode()for x in git('cat-file','-p',S).split(b'\n\n',1)[0].splitlines()if x.startswith(b'parent ')]==[P]
def entries(commit,prefixes,physical=True):
    rows=[]
    for raw in git('ls-tree','-rz',commit,'--',*prefixes).split(b'\0'):
        if not raw:continue
        meta,name=raw.split(b'\t',1);mode,kind,oid=meta.decode().split();name=name.decode();assert kind=='blob'and mode in ['100644','100755','120000'];b=git('cat-file','blob',oid)
        if physical:
            p=R/name
            if mode=='120000':assert p.is_symlink();actual=os.fsencode(os.readlink(p))
            else:assert p.is_file()and not p.is_symlink();actual=p.read_bytes();assert bool(p.stat().st_mode&0o111)==(mode=='100755')
            assert b==actual
        rows.append({'path':name,'mode':mode,'gitBlob':oid,'bytes':len(b),'sha256':sha(b)})
    return rows
source=entries(S,('programs/pump',));core=entries(S,CORE);assert(len(source),len(core))==(141,236)and core==entries(P,CORE,False)
delta=git('diff','--no-ext-diff','--no-textconv','--no-renames','--name-only',P,S).decode().splitlines();assert delta==['programs/pump/src/creator/admin_cto.rs']
leaf=next(x for x in source if x['path']==delta[0]);assert leaf['gitBlob']=='a4b264bcc460dc2c5b11fe3857c17291e2df123d'and leaf['sha256']=='1206b75e470ce58eb84e02f7b077e04ca91effd8ca57f4b0592d9ab617c75ee8'and leaf['bytes']==21995
selected=sorted([{'path':x['path'].removeprefix('programs/pump/'),'bytes':x['bytes'],'executable':x['mode']=='100755','sha256':x['sha256']}for x in source],key=lambda x:x['path'])
selected_sha=sha(json.dumps(selected,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode());assert selected_sha=='9e7f44ab78eb9e87c295ae213f06059a3f226104444e036ad8282e318c6eac6a'
snapshot={'schema':'pump-source-inputs-v1','sha256':selected_sha,'files':selected}
staged=json.loads((OLD/'work/native-prep/preflight/evidence/compiled-workspace-inputs.json').read_text());staged[delta[0]]={'bytes':leaf['bytes'],'executable':False,'sha256':leaf['sha256']};stage_sha=sha(json.dumps(staged,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode());assert len(staged)==142
guides={}
for name in ['AGENTS.md','CONTRIBUTING.md','README.md','SECURITY.md','docs/SCOPE.md','docs/COMPLETION.md','docs/PARALLEL_WORK.md','programs/pump/Cargo.toml','programs/pump/Cargo.lock','programs/pump/pump-token-ext/Cargo.toml']:
    b=(R/name).read_bytes();assert b==git('cat-file','blob',S+':'+name)==git('cat-file','blob',P+':'+name)==(OLD/name).read_bytes();guides[name]={'bytes':len(b),'sha256':sha(b),'byteEqualReviewedEbe':True}
hooks={}
for name in ['source_inputs.py','fastbuild.py','build_process.py','link_order.py','pump_physical_source_wrapper.py','pump_link_rustc.py','pump_link_lld.py','sbf_default.ld']:
    b=(R/'reconstruction/harness'/name).read_bytes();assert b==(OLD/'reconstruction/harness'/name).read_bytes();hooks[name]={'bytes':len(b),'sha256':sha(b),'byteEqualReviewedEbe':True}
assert not any(x['path'].endswith('/build.rs')for x in source)
rsync=Path('/workspace/pumpfun-source-workers/pump-lifecycle/work/host-tools/rsync-debian-13/extracted/usr/bin/rsync');assert sha(rsync.read_bytes())=='a56c05b960beb734169619d5760b43ff495e84f85a93eb1f54fe58118262fb20'
for name,value in [('program-source-inputs.json',{'base':S,'files':source}),('toolchain-source-inputs.json',{'base':S,'files':core}),('EXPECTED-SELECTED-SOURCE.json',snapshot),('EXPECTED-COMPILED-WORKSPACE.json',staged),('SOURCE-TREE-DELTA.json',{'source':S,'parent':P,'tree':T,'fullChangedPaths':delta,'onlySourceLeaf':leaf,'nonselectedChanges':[]}),('INPUT-REVIEW.json',{'status':'PASS_BEFORE_PROJECT_EXECUTION','guidesAndManifests':guides,'hooks':hooks,'core236ByteModeBlobEqualReviewedEbe':True,'buildRsPresent':False,'observedFlaggedHook':False,'reviewBasis':'Actual genuine AGENTS/CONTRIBUTING/crate manifests read; lockfile/guides/full CORE and all executed helpers byteequal the qualified reviewed Ebe control. Exact full candidate delta is the reviewed single program leaf. No stopped lane, source flag, install hook or runtime is resumed.','rsyncSha256':sha(rsync.read_bytes())})]:
    (O/name).write_text(json.dumps(value,indent=2)+'\n')

REF=OLD/'work/native-run/artifact';DEST=R/'work/current-ebe-reference';download=json.loads((OLD/'work/native-run/DOWNLOAD-VERIFIED.json').read_text());admit=json.loads((OLD/'work/root/CURRENT-ELF-ADMISSION.json').read_text())
assert sha((OLD/'work/root/CURRENT-ELF-ADMISSION.json').read_bytes())=='47cd591397090a3fcd3e8dc80e2a1900e0b7ac45dae257d55bf28ec8e181df5e'
assert admit['base']==P and admit['run']==41176417138 and(admit['total'],admit['raw'],admit['normalized'])==(1035,1034,1034)and admit['sourceAndArchiveAdmission']==admit['independentOfficialScorer']=='PASS'
assert download['artifactId']==13033007890 and download['members']==43 and download['bytes']==2539553 and download['sha256']=='b9ad6f1bc76f9b8fdb01e06b65262e3725ded83d544e394c8f0f568da6bfcfe5'
table={}
for p in sorted(REF.rglob('*')):
    if p.is_file():assert not p.is_symlink();b=p.read_bytes();table[p.relative_to(REF).as_posix()]={'bytes':len(b),'sha256':sha(b)}
assert len(table)==43 and table==download['files']
assert json.loads((REF/'toolchain-source-inputs.json').read_text())['files']==core
zipfile=OLD/'work/native-run/raw-artifact.zip';assert zipfile.stat().st_size==2539553 and sha(zipfile.read_bytes())==download['sha256']
DEST.mkdir(exist_ok=False)
for name,row in table.items():
    p=DEST/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(REF/name,p);b=p.read_bytes();assert len(b)==row['bytes']and sha(b)==row['sha256']
for name,row in table.items():assert sha((REF/name).read_bytes())==row['sha256']
copies=[('REFERENCE-ROOT-ADMISSION.json',OLD/'work/root/CURRENT-ELF-ADMISSION.json'),('REFERENCE-DOWNLOAD-VERIFIED.json',OLD/'work/native-run/DOWNLOAD-VERIFIED.json'),('REFERENCE-ROOT-OFFICIAL-SCORE.json',OLD/'work/root/admission/official-score/score.json'),('REFERENCE-TARGET-METRIC.json',OLD/'work/target-token-metric/measurement/RESULT.json'),('REFERENCE-REMOTE-RETENTION.json',OLD/'work/root/remote-retention/REMOTE-RETENTION.json'),('SOURCE-PUBLICATION-ROOT-GO.json',Path('/dev/shm/pump-cto-permission-unit-plan/source-publication/ROOT-GO.json')),('SOURCE-SEMANTIC-REVIEW.json',Path('/dev/shm/pump-cto-permission-unit-plan/source-review/REVIEW.json'))]
copy_meta={}
for name,p in copies:
    b=p.read_bytes();(O/name).write_bytes(b);copy_meta[name]={'bytes':len(b),'sha256':sha(b),'source':str(p)}
assert copy_meta['REFERENCE-ROOT-OFFICIAL-SCORE.json']['sha256']=='eb31f3f8bac9ae9a31f3f932dd99a952ee57e6c46c876c901bb778c00ab6def5'
assert copy_meta['REFERENCE-TARGET-METRIC.json']['sha256']=='e77fa54acbb9a9d90d80a1d2abc74c88a01d7872a70659fda26bd948406c731d'
assert copy_meta['SOURCE-SEMANTIC-REVIEW.json']['sha256']=='2eef96a3b181928c967c23b2fece12c4eea2fe188dc0183686e536143fc65be8'
score=json.loads((O/'REFERENCE-ROOT-OFFICIAL-SCORE.json').read_text());assert len(score['windows'])==1035 and score['summary']['candidate_sha256']==admit['images']['unstripped.so']
assert(sum(x['raw']for x in score['windows'].values()),sum(x['normalized']for x in score['windows'].values()))==(1034,1034)
metric=json.loads((O/'REFERENCE-TARGET-METRIC.json').read_text());assert metric['Ebe']['normalizedMatchingLogicalInstructionsM']==2247 and metric['Ebe']['elfSha256']==admit['images']['unstripped.so']
(O/'REFERENCE-COPY-ADMISSION.json').write_text(json.dumps({'status':'PASS_ACTUAL_ADMITTED_EBE43_EXTERNAL_REFERENCE','base':P,'run':41176417138,'artifactId':13033007890,'sourceAggregate':'6b02f60a97777892b9cfb3b93ff40679226e08dca15b8313899df342c68e07e7','rawZipSHA256':download['sha256'],'rawZipBytes':2539553,'originalReference':str(REF),'copiedReference':str(DEST),'files':table,'separateQualificationRecords':copy_meta,'rootFreshScoreRows':1035,'raw':1034,'normalized':1034,'sealedM':2247,'measurementExecutionsHere':0,'role':'Exact43 original native members, unchanged plain controller. Root fresh score and targetM kept separately in native-prep, not inserted into43 artifact domain or in-job reference code. Root will compare new actual output; no Ebe runtime result transfers.'},indent=2)+'\n')

template=OLD/'work/native-prep/ops';old=(template/OPS[1]).read_text();new=old.replace('One faithful cold build of the exact frozen ebe5387e source checkpoint.','One faithful cold build of the exact frozen a119f880 source checkpoint.').replace("BASE = '"+P+"'","BASE = '"+S+"'");assert old!=new
trees=[ast.parse(old),ast.parse(new)]
for tree in trees:
    tree.body[0].value.value='DESCRIPTION'
    a=[n for n in tree.body if isinstance(n,ast.Assign)and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)and n.targets[0].id=='BASE'];assert len(a)==1;a[0].value.value='BASE'
assert ast.dump(trees[0],include_attributes=False)==ast.dump(trees[1],include_attributes=False)
wf=(template/OPS[0]).read_text();newwf=wf.replace(P,S).replace('ebe5387e','a119f880')
for name,text in[(OPS[1],new),(OPS[0],newwf)]:p=O/'ops'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
(O/'CONTROLLER-ADAPTATION.json').write_text(json.dumps({'status':'PASS_EXACT_PLAIN_EBE_CONTROL_ONLY_BASE_AND_MODULE_DESCRIPTION','template':str(template/OPS[1]),'templateSha256':sha(old.encode()),'controllerSha256':sha(new.encode()),'wholeModuleASTIdenticalExceptBaseAndFirstDocstring':True,'allFunctionsMethodsMainUnchanged':True,'workflowSourcePinAndLabelsOnly':True,'candidateDiagnosticReferenceFrameworkAdded':False,'source':S,'projectExecutions':0},indent=2)+'\n')
(O/'DERIVATION.json').write_text(json.dumps({'sourceCommit':S,'sourceTree':T,'sourceParent':P,'sourceFiles':141,'coreFiles':236,'expectedStageFiles':142,'selectedSourceSha256':selected_sha,'expectedStageVectorSha256':stage_sha,'actualMaintainedStageDeferredToOncePreflight':True,'expectedProjectionFromQualifiedEbeWithOnlyExactGitLeafChanged':True,'leaf':leaf,'allCoreEqualEbe':True,'fullSourceDelta':delta,'SDKCompilerScorerMetricVmExecutions':0},indent=2)+'\n')
print(json.dumps({'status':'AUTHENTICATED_S4_INPUTS_AND_PLAIN_OPS_NO_PREFLIGHT_YET','sourceSHA256':selected_sha,'stageSHA256':stage_sha,'controllerSHA256':sha(new.encode()),'actualReferenceMembers':43,'separateFreshEbeScoreAndM':True}))
