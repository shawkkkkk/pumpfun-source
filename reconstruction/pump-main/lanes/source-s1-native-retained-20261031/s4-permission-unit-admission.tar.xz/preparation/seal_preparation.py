"""Freeze exact plain S4 normal preparation after the single no-SDK preflight."""
from pathlib import Path
import ast, datetime, difflib, hashlib, json, os, subprocess, sys, tarfile
assert os.environ.get('PYTHONDONTWRITEBYTECODE')=='1'and sys.dont_write_bytecode and sys.flags.optimize==0
R=Path('/dev/shm/pump-cto-permission-s4');O=R/'work/native-prep';S='a119f880c73de06084df27a2b2cbffec09a6f46c';P='ebe5387e12e948c2534618adf7a3cf0f27d9de51';T='cb9c5dc663f5e54509ea12fefef3af7b96fcd1c0';sha=lambda b:hashlib.sha256(b).hexdigest()
env={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_ALLOW_PROTOCOL':'file','PYTHONDONTWRITEBYTECODE':'1'}
def git(*a):return subprocess.run(['git',*a],cwd=R,env=env,capture_output=True,check=True).stdout
assert git('rev-parse','HEAD').decode().strip()==S and git('rev-parse','HEAD^{tree}').decode().strip()==T and not git('status','--porcelain','--untracked-files=no').strip()
result=json.loads((O/'PREFLIGHT-RESULT.json').read_text());assert result['status']=='PASS'and result['exitCode']==0 and result['inputsUnchanged']and result['sourceCoreReferenceOpsBoundFiles']==426
before=json.loads((O/'PREFLIGHT-INPUTS-BEFORE.json').read_text());assert before==json.loads((O/'PREFLIGHT-INPUTS-AFTER.json').read_text())
amend=json.loads((O/'README-DESCRIPTION-ONLY-AMENDMENT.json').read_text());readme=O/'ops/reconstruction/pump-main/lanes/current-native-control/README.md'
assert sha((O/'README-PREFLIGHT-EXECUTED.md').read_bytes())==amend['oldSha256']and readme.read_bytes()==(O/'README-PREFLIGHT-EXECUTED.md').read_bytes()+amend['exactAppendedText'].encode()and sha(readme.read_bytes())==amend['newSha256']
for row in before:
    p=Path(row['path']);b=os.fsencode(os.readlink(p))if p.is_symlink()else p.read_bytes()
    if p==readme:assert row['sha256']==amend['oldSha256'];continue
    assert len(b)==row['bytes']and sha(b)==row['sha256']
d=json.loads((O/'DERIVATION.json').read_text());pre=json.loads((O/'preflight/evidence/PREFLIGHT.json').read_text())
assert(pre['programGitFiles'],pre['selectedSourceFiles'],pre['workspaceFiles'],pre['coreFiles'])==(141,141,142,236)and pre['preflightOnly']and pre['sourceSha256']==d['selectedSourceSha256']=='9e7f44ab78eb9e87c295ae213f06059a3f226104444e036ad8282e318c6eac6a'
assert pre['linkInputs']['selectors']=={'.text':555,'.rodata':0,'.data.rel.ro':0}
assert json.loads((O/'preflight/evidence/preflight-builder-source-inputs.json').read_text())==json.loads((O/'EXPECTED-SELECTED-SOURCE.json').read_text())
for name in ['program-source-inputs.json','toolchain-source-inputs.json']:assert json.loads((O/'preflight/evidence'/name).read_text())==json.loads((O/name).read_text())
stage=json.loads((O/'preflight/evidence/compiled-workspace-inputs.json').read_text());assert stage==json.loads((O/'EXPECTED-COMPILED-WORKSPACE.json').read_text());stage_sha=sha(json.dumps(stage,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode());assert stage_sha==d['expectedStageVectorSha256']=='7e106be292376426b3f8769d1e651580bf1f1aaffc851555f6ed054576d6f86e'
source=json.loads((O/'program-source-inputs.json').read_text())['files']
for name,rows in [('program-source.tar.gz',{x['path']:{'bytes':x['bytes'],'sha256':x['sha256'],'executable':x['mode']=='100755'}for x in source}),('compiled-workspace.tar.gz',stage)]:
    with tarfile.open(O/'preflight/evidence'/name)as tar:
        mm=tar.getmembers();assert len(mm)==len(rows)and{m.name for m in mm}==set(rows)
        for m in mm:
            b=tar.extractfile(m).read();assert m.isfile()and bool(m.mode&0o111)==rows[m.name]['executable']and len(b)==rows[m.name]['bytes']and sha(b)==rows[m.name]['sha256']
assert git('diff','--no-ext-diff','--no-textconv','--no-renames','--name-only',P,S).decode().splitlines()==['programs/pump/src/creator/admin_cto.rs']
ops=['.github/workflows/qualify-pump-macos-v144.yml','reconstruction/pump-main/lanes/current-native-control/pump_current_control.py','reconstruction/pump-main/lanes/current-native-control/README.md'];meta={}
for raw in git('ls-tree','-rz',S,'--',*ops).split(b'\0'):
    if raw:m,n=raw.split(b'\t',1);mode,kind,oid=m.decode().split();assert kind=='blob';meta[n.decode()]=(mode,oid)
patch=[];changes=[]
for name in ops:
    b=(O/'ops'/name).read_bytes();nb=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();old=git('cat-file','blob',S+':'+name)if name in meta else b'';ob=meta[name][1]if name in meta else'0'*40
    patch.append('diff --git a/'+name+' b/'+name+'\n')
    if name not in meta:patch.append('new file mode 100644\n')
    elif meta[name][0]!='100644':patch+=['old mode '+meta[name][0]+'\n','new mode 100644\n']
    patch.append('index '+ob+'..'+nb+(' 100644'if name in meta and meta[name][0]=='100644'else'')+'\n');patch+=list(difflib.unified_diff(old.decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile='a/'+name if name in meta else'/dev/null',tofile='b/'+name))
    changes.append({'path':name,'mode':'100644','bytes':len(b),'sha256':sha(b),'gitBlob':nb,'baseGitBlob':ob if name in meta else None,'baseMode':meta[name][0]if name in meta else None})
(O/'OPS.patch').write_text(''.join(patch));argv=['git','apply','--cached','--check','--whitespace=error',str(O/'OPS.patch')];check=subprocess.run(argv,cwd=R,env=env,capture_output=True);(O/'GIT-PATCH-CHECK.json').write_text(json.dumps({'argv':argv,'exitCode':check.returncode,'stdout':check.stdout.decode(),'stderr':check.stderr.decode(),'indexMutation':False},indent=2)+'\n');assert check.returncode==0
adapt=json.loads((O/'CONTROLLER-ADAPTATION.json').read_text());assert adapt['wholeModuleASTIdenticalExceptBaseAndFirstDocstring']and adapt['allFunctionsMethodsMainUnchanged']and sha((O/'ops'/ops[1]).read_bytes())==adapt['controllerSha256']
reference=json.loads((O/'REFERENCE-COPY-ADMISSION.json').read_text());assert len(reference['files'])==43and reference['base']==P and reference['sealedM']==2247
(O/'RECEIPT-SCHEMAS.json').write_text(json.dumps({'programCore':'program-source-inputs.json/toolchain-source-inputs.json are {base,files:list} with Git typed modes/blobs/bytes/SHA;141/236.','selectedSource':'EXPECTED-SELECTED-SOURCE.json equals actual preflight/evidence/preflight-builder-source-inputs.json {schema,sha256,files:list}.','stage':'preflight/evidence/compiled-workspace-inputs.json is bare path→{bytes,executable,sha256},142.','reference':'work/current-ebe-reference has EXACT43 native members. REFERENCE-COPY-ADMISSION.json files isDICT43; separateQualificationRecords describe native-prep freshscore/M/root/sourceGO sidecars, not extra reference files.','preflight':'PREFLIGHT-{PROCESS,RESULT,ONCE,EXECUTION}.json plus raw stdout/stderr and426typed BEFORE/AFTER list. README-only append after successful oncepreflight is separately hash-bound; executed README kept.','operational':'PREPARATION-RESULT.opsFiles is3-entry list; FROZEN-MANIFEST.files is list relative native-prep; OPS.patch is exact source-HEAD preimage diff.','futureProvider':'run-final plain fullproviderRun; jobs-final={jobs:fullrawjobs}; steps-final={steps:job0.steps}; artifacts-final={artifacts:fullrawartifacts}; bare ARTIFACT-METADATA; DOWNLOAD.filesDICT.','futureNative':'Plain normal SUCCESS43 domain; authentic FAILURE/partial artifact otherwise. No candidate/noLoss/reference-download output pair. Root external onceofficial1035 against fresh Ebe must save allrow changes before rejection; actual source/native provenance remains distinct from negative qualification.'},indent=2)+'\n')
files=[]
for p in sorted(O.rglob('*')):
    if not p.is_file():continue
    n=p.relative_to(O).as_posix()
    if n.startswith('preflight/cold-work/')or n in ['FROZEN-MANIFEST.json','PREPARATION-RESULT.json']:continue
    b=p.read_bytes();files.append({'path':n,'bytes':len(b),'sha256':sha(b)})
assert not(O/'FROZEN-MANIFEST.json').exists();(O/'FROZEN-MANIFEST.json').write_text(json.dumps({'status':'FROZEN_S4_PLAIN_NORMAL_CONTROL_PREPARATION_ONLY','files':files},indent=2)+'\n')
summary={'status':'READY_FOR_ROOT_AND_INDEPENDENT_REVIEW_NO_NATIVE_RELEASE','sourceCommit':S,'sourceTree':T,'sourceParent':P,'sourceChangedRelativeEbe':True,'unchangedSourceMeans':'Frozen a119 source is unchanged before/after actual build; it is ONE permission-unit candidate, not the same source as main/Ebe.','leafGitBlob':'a4b264bcc460dc2c5b11fe3857c17291e2df123d','leafSha256':'1206b75e470ce58eb84e02f7b077e04ca91effd8ca57f4b0592d9ab617c75ee8','leafBytes':21995,'leafLines':772,'sourceFiles':141,'coreFiles':236,'stageFiles':142,'selectedSourceSha256':d['selectedSourceSha256'],'projectedWorkspaceVectorSha256':stage_sha,'opsFiles':changes,'opsPatchSha256':sha((O/'OPS.patch').read_bytes()),'frozenManifestSha256':sha((O/'FROZEN-MANIFEST.json').read_bytes()),'frozenFileCount':len(files),'actualPreflight':result,'postPreflightReadmeOnlyAmendment':amend,'actualReference':{'source':P,'sourceAggregate':'6b02f60a97777892b9cfb3b93ff40679226e08dca15b8313899df342c68e07e7','run':41176417138,'artifactId':13033007890,'rawZipSha256':reference['rawZipSHA256'],'members':43,'folder':'work/current-ebe-reference','freshFullScore':'work/native-prep/REFERENCE-ROOT-OFFICIAL-SCORE.json','freshFullScoreSha256':'eb31f3f8bac9ae9a31f3f932dd99a952ee57e6c46c876c901bb778c00ab6def5','sealedM':2247,'targetMetricSha256':'e77fa54acbb9a9d90d80a1d2abc74c88a01d7872a70659fda26bd948406c731d','runtimeTransferred':False},'wholePlainControllerASTUnchangedExceptBaseAndDescription':True,'normalNativeSuccessArtifactDomain':43,'SDKCompilerScorerMetricVmDispatchRemoteWrites':0,'trackedGitStatusClean':not git('status','--porcelain','--untracked-files=no').strip(),'CORECacheFilesAbsent':not any(p.name=='__pycache__'for x in ['reconstruction/harness','reconstruction/toolchain']for p in(R/x).rglob('*')),'limits':'Once noSDK genuine source/stage/link preparation only; no native gain, acceptance, emission/inlining/privateUnitABI/runtime/wholeidentity claim. Root publishes exact3OPS and one normalbuild only afterreview. Negative usefulness/noLoss remains distinct from source/native provenance; no automatic repairs/retries/variants.','utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
assert summary['CORECacheFilesAbsent'];(O/'PREPARATION-RESULT.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'status':summary['status'],'frozenFiles':len(files),'freezeSha256':summary['frozenManifestSha256'],'resultSha256':sha((O/'PREPARATION-RESULT.json').read_bytes()),'patchSha256':summary['opsPatchSha256'],'ops':changes,'sourceSha256':d['selectedSourceSha256'],'stageVectorSha256':stage_sha}))
