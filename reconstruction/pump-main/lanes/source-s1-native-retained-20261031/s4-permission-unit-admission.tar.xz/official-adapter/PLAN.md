# Root-owned S4 actual admission: preparation only

This ignored adapter is not executed during preparation. Source is exactly
a119f880c73de06084df27a2b2cbffec09a6f46c, aggregate9e7f44ab..., directEbe;
OP4106295776cc7eb5bb93f1fedd10dfae999d7537/run41180242239/attempt1.
Native provider artifact/job/ZIP/image identities are unknown here and remain
null in ACTUAL-RELEASE.example.json. Root alone supplies actual release bytes
after acquisition and review. The example cannot pass the admission guards.

Schema is permission-s4-normal-control-actual-release-v1, identical to the
independent reader's constructor: source/source_sha256/operational_commit/run/
artifact/job/zip{bytes,sha256}/images{unstripped.so,candidate.so}. No guessed
artifact ID, size or image hash, copied Ebe candidate identity, metadata fetch
or download occurs in this script.

This derives from qualified Ebe admit_ebe.py,22003B/SHA256
dcc028ed281cadb56d50c0127654c79ee5eb2c546e959287604fb733489d7ee9.
ADAPTATION.patch contains the complete diff; ADAPTATIONS.json classifies every
change. All11 helpers and the entire sentinel/Popen/resume/input-stability
block are unchanged. The source/archive141/CORE236/stage142, exact3OPS,
provider/ZIP/normal43, native host/runtime/stack/cold target/registry/SDK full
inventory/target libraries/LLD/local-crate/flags/before-after and ELF guards
remain. Local original SDK installation/rehashing is not claimed.

Reference is actual Ebe run41176417138/artifact13033007890, the exact43 copied
members at work/current-ebe-reference. Before scoring, reference native score
rows must agree with all1035 rows of separately copied root fresh official
score eb31f3f8.... Root Ebe admission47cd5913... and sealed M2247 reference
bytes e77fa54a... are also authenticated. These three additional reference
files join the immutable score input binding; no metric is calculated.

The official CLI remains python3 -B reconstruction/harness/score.py against
the actual new S4 unstripped image, with --baseline pointing to
work/current-ebe-reference/score.json and --json to
work/root/admission/official-score/score.json. It is the unchanged maintained
CLI and normalization method, not a new scorer. Reference native score and
fresh Ebe score are distinct byte files with proven equal reference rows.

Root launch after its explicit actual release:

    env -u PYTHONOPTIMIZE -u PYTHONPATH PYTHONDONTWRITEBYTECODE=1 TMPDIR=/dev/shm python3 -B work/official-admission-prep/admit_s4.py --release work/official-admission-prep/ACTUAL-RELEASE.json

The exclusive SCORE-STARTED marker precedes the only Popen. PID/argv/cwd/time,
raw stdout/stderr/fullJSON and PROCESS receipts are preserved. If a marker
exists, only --resume is accepted, and it never starts a child: it requires
completed exit0 PROCESS/JSON and exact unchanged invocation/input/output
bindings. Failure, interruption, missing outputs or drift stop without retry.
Reviewed parser-only corrections may resume existing JSON; no second score.

Every fresh candidate row must equal its native saved row, all1035 rows must
be present and arithmetic/image bindings must pass. Actual Ebe-to-S4 raw and
normalized gains/losses, their counts and every full changed row are retained
before any no-loss rejection. Both full candidate scores and both complete
reference score files remain untouched. No candidate1034 count, Ebe row
equality, no-loss result, target extent27400 or M outcome is assumed.

CURRENT-ELF-ADMISSION preserves source/native provenance PASS separately from
membershipQualification and unmeasured source usefulness. Loss still publishes
the full report before raising and preserves an attempt record; it does not
become candidate acceptance. Target metric, causal interpretation and VM are
separate unreleased actions. Existing S3 and Unit-family negatives remain.

Only this owned adapter text was syntax/AST-inspected. No project module was
imported/parsed, no adapter/scorer/native/SDK/metric/VM/test was run, and no
Git/remote/source mutation was performed. Root and independent review must
accept these exact prepared bytes before any artifact release/execution.
