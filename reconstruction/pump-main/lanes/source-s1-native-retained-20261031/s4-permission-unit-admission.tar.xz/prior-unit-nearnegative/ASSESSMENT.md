# Permission-only Unit validator: bounded prior answer

A related caller-recompute Unit negative is recorded, but its exact source is
not retained in the inventoried packet. This is neither an exact current
conjunction collision nor evidence that the shape is globally untried.

w12b12-cto-cpi SUMMARY.json (Gitblob f8175f47…) records tgtunit on20a1ae9:
27,024B/ratio0.13909, versus27,400B/0.43919, rejected for size. Its rejected
mechanisms explicitly include 'validate returning Result<()> with target by
out-param or recomputed in execute'. A separate tgtout row is27,264B/0.28202.
However, the exact tgtunit driver/source is omitted; NOTES2903760… explicitly
says private source/IR mutation drivers are not retained. The retained tree has
only NOTES, SUMMARY, scmerge.py and its test. Private fee/error boundaries,
caller selection timing and original-N sharing provenance cannot be certified
from that grouped numerical description. No standalone native artifact/source/
score qualification for tgtunit is established by these records.

Exact w13a18 va/vb/nv2 edits are retained and read. Each returns Result<()> but
writes the target through private *out or *tb. Their caller initializes/reads
that output; it does not independently select K/C/N. Reported raw-IR outcomes
are va27,064B/0.14591, vb27,176B/0.14651 on74b3171, and nv2 26,920B/0.24577
on6af878b. These are useful nearby error/carrier/frame negatives, with different
source and codegen boundaries. They predate both current volatile insertions.

S1 public-caller fees, #3197's two private fee_ok calls, S3's full settings
tuple and e1's ResultKey are separately owned different forms. They are not
counted as permission-only validate evidence here.

Scope is three exact retained edit files and four notes/summaries found by
bounded CTO packet lookup. No global absence or exhaustive private-history claim
is made. The source semantic and targeted causal prediction remain root/review
decisions; lack of an original Unit type or favorable global score prediction
is not used here as an automatic veto. No new proposal, source application,
build, IR/scorer/metric/VM execution or remote write occurred.
