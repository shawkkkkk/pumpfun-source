"""Freeze the authorized S4 negative-retention triple from existing sealed data."""
from pathlib import Path, PurePosixPath
import datetime, hashlib, io, json, os, re, sys, tarfile
assert os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode and sys.flags.optimize==0
R=Path('/dev/shm/pump-cto-permission-s4');O=R/'work/retention-prep';sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
plan=json.loads((O/'PLAN.json').read_text());inventory=json.loads((O/'STAGE-INVENTORY.json').read_text());members={};inputs={}
patterns=[rb'github_pat_[A-Za-z0-9_]{20,}',rb'gh[pousr]_[A-Za-z0-9]{20,}',rb'Bearer [A-Za-z0-9_.-]{20,}',rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
def safe_text(name,b):
    n=PurePosixPath(name);assert not n.is_absolute() and '..'not in n.parts and str(n)==name
    assert not any(x in n.parts for x in ['private-transfer','private-slop'])
    assert n.suffix.lower()not in ['.so','.rlib','.a','.dylib','.ll']and not b.startswith((b'\x7fELF',b'!<arch>\n'))
    assert not any(x in n.name.lower()for x in ['client-version','client_version','auth-state','auth_state','credential','cookie'])
    if not name.endswith(('.tar.xz','.tar.gz')):
        assert not any(re.search(p,b)for p in patterns),('Credential-shaped data',name)
        assert not any(re.search(rb'(?i)[?&](?:x-amz-signature|x-goog-signature|sig)=',u)for u in re.findall(rb'https?://[^\s"<>]+',b)),('Signed URL',name)
def add(name,p,expected=None):
    p=Path(p);assert name not in members and p.is_file()and not p.is_symlink()and not any(x in p.parts for x in ['private-transfer','private-slop'])
    b=p.read_bytes();safe_text(name,b)
    if expected:assert len(b)==expected['bytes']and sha(b)==expected['sha256'],name
    members[name]=b;inputs[name]={'source':str(p),'bytes':len(b),'sha256':sha(b)}
for name,row in inventory['records'].items():add(name,row['source'],row)
assert len(inventory['records'])==252
actual=R/'work/causal-native-plan/actual';am=actual/'MANIFEST.json';assert sha(am.read_bytes())=='c9d01c37edd50a7b32df57666a9ae0ef7b630806d2330a65b3b22869c5866b60'
ad=json.loads(am.read_text());allow=json.loads((actual/'RETENTION-ALLOWLIST.json').read_text());assert len(allow['files'])==15
for name in allow['files']:add('actual-causal-prefix/'+name,actual/name,ad['files'].get(name))
assert ad['primary']=='ABSENT_LATE_KN_TO_C_OVERWRITE'and ad['sourceVariantGo'] is False
loss=R/'work/raw-loss-attribution';lm=loss/'FINAL-MANIFEST.json';assert sha(lm.read_bytes())=='798c4785ffa6aa533ba118a5b04eb14a16215a3e4e9a8703b118ff32991d0ec8'
ld=json.loads(lm.read_text());lp=loss/ld['archive']['path'];assert lp.stat().st_size==413400 and sha(lp.read_bytes())=='16c2d5e0a7baa0b87071a7a78e651dba6528e020aba8aee9e5b64e44d91ae0ea'
# Packaging validation only: preserve this opaque compressed record archive,
# inspect safe membership/hash claims without running its forensic producers.
expected={x['path']:x for x in ld['files']}
with tarfile.open(lp,'r:xz')as t:
    mm=t.getmembers();assert len(mm)==28 and len({m.name for m in mm})==28 and {m.name for m in mm}==set(expected)
    for m in mm:
        assert m.isfile();b=t.extractfile(m).read();safe_text(m.name,b);assert len(b)==expected[m.name]['bytes']and sha(b)==expected[m.name]['sha256']
add('compiled-raw-loss/FINAL-MANIFEST.json',lm)
add('compiled-raw-loss/evidence.tar.xz',lp,ld['archive'])
assert ld['summary']['existentialAddressImmediateOnlyRows']==672 and ld['summary']['unknownRows']==15 and ld['summary']['savedLossRows']==687
for name in ['PLAN.json','STAGE-INVENTORY.json','assemble_retention.py']:add('retention-authoring/'+name,O/name)
root_path=R/'work/root/CURRENT-ELF-ADMISSION.json';root=json.loads(root_path.read_text());root_sha=sha(root_path.read_bytes());assert root_sha=='7b417968d0d26297827672b9596f69a0dc5ccff13ae21c4981606075f5818c92'
assert(root['total'],root['raw'],root['normalized'])==(1035,347,1034)and root['comparison']['rawLossCount']==687 and root['comparison']['normalizedLossCount']==0 and root['CTO']['bytes']==27144
assert root['sourceAndNativeProvenanceConclusion']=='PASS'and root['nativeNoLossConclusion']=='FAIL'
assert sha((R/'work/root/admission/official-score/score.json').read_bytes())=='dafd9b3b5baadffb23bf2705be30717b2fa8fc0ca247645a31e2b9625eba0073'
assert sha((R/'work/native-prep/FROZEN-MANIFEST.json').read_bytes())=='68bb78d4430271f8971fe06348584b02d3aa9028a793bb977a9e05df63d0a8fa'
assert sha((R/'work/independent-admission-reader/FINAL-MANIFEST.json').read_bytes())=='d7015b173b4ffa8999ba79a970c183fc5cff54375ea0c14314eb3a6298ae442b'
for n in ['job.log','job-log-response.json']:
    archived='monitoring/terminal/'+n
    if archived in members:assert members[archived]==(R/'work/native-run/terminal'/n).read_bytes()
raw=R/'work/native-run/raw-artifact.zip';rb=raw.read_bytes();assert len(rb)==2533055 and sha(rb)=='a552a4f04078857199e1d83666b1c215710e8cb53919c5ed80cdf0d023e4773e'
raw_meta={'bodyPath':str(raw),'bytes':len(rb),'sha256':sha(rb),'gitBlob':blob(rb)}
causal={'manifestSHA256':sha(am.read_bytes()),'mechanismSHA256':'3f9fa9279990f8bc8475079a0b50da100d5e38141199202128bc124fa29a052a','lateValidatedKNThenCOverwrite':'ABSENT_IN_AUTHORIZED_PREFIX','completedC32BeforeFeesAndPreservedToOuterPack':True,'originalPhaseOrderReproduced':False,'phaseLimit':'S4 selects C before creator/new validation; original selected nonholder C after supplied-new checks. This realizes the narrower prediction, not full original phase order.','incomingN':'Distinct original-N pre-prepare pack; no S4 tail/CPI/curve/Fees/pool/event consumer inspection claimed.','validationFeePresenceTests':2,'originalUnitABIInferred':False,'newVariantGO':False}
raw_loss={'finalManifestSHA256':sha(lm.read_bytes()),'archive':{'path':'compiled-raw-loss/evidence.tar.xz',**ld['archive']},'archiveMembers':28,'readerEntryPoints':[{'archive':'compiled-raw-loss/evidence.tar.xz','member':n}for n in ld['readerEntryPoints']],'initialPairingBlockerPreserved':ld['originalPairingBlockerPreserved'],'failedAdapterAttempts':2,'savedRawLossRows':687,'existentialAddressImmediateOnlyRows':672,'unknownRows':15,'unboundRepeatedNames':9,'addressOnlyChangedPhysicalPairs':673,'rawEqualPhysicalPairs':44,'originalRawWitnessUniquelyChosen':False,'limits':ld['limits'],'scope':'Existential same-symbol compiled old-Ebe/S4 evidence, not all687 or unique original-witness proof. No pointed-data/runtime/CTO logic/sourcegain/layoutrepair claim.'}
archive_receipt={'schema':'s4-negative-safe-admission-analysis-archive-v1','status':'COMPLETE_TWO_PENDING_FINAL_SEALS_INCLUDED_NO_FURTHER_PACKET_CHURN','source':plan['source'],'native':plan['native'],'facts':plan['factsAlreadySealed'],'actualCausalPrefix':causal,'compiledRawLossForensics':raw_loss,'rawZIP':raw_meta,'scopeCut':'All declared252 staged records plus exactly15 actual-prefix records and raw-forensics FINAL/archive. Live public consumer checker/packet new work is excluded.','preservation':['52prep with executed/final README and post-preflight description proof','42monitor with raw wrappers/canonical mappings/public maskedlog','One full official score, all losses/fullchanged rows/native saved score, expected after-report noLoss failure/ATTEMPT/stdout/stderr','PASS39 identity final19 records plus original actual release in officialprep','Source/proposal/casual controls and priors, originalconsumer883 proof including its failures','Actualprefix source selector history and rawloss initial pairingSTOP/two failedadapters/process receipt in exact28member archive'],'omittedPayloads':inventory['omittedPayloads'],'exclusions':['FullIR','private-transfer/**','private-slop/**','Actual auth/clientversion/session/signedURLs','Extra native ELF/libs/SDK copies outside rawZIP','Step03 rawbackup body','Live publicchecker/newpacketwork'],'actionsHere':{'remoteWrites':0,'newNativeSDKCompilerScorerMetricVmTests':0,'forensicOrAnalysisProducerExecutions':0}}
members['ARCHIVE-RECEIPT.json']=(json.dumps(archive_receipt,indent=2)+'\n').encode()
manifest={n:{'bytes':len(b),'sha256':sha(b)}for n,b in sorted(members.items())};members['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
archive=O/'s4-permission-unit-admission.tar.xz';assert not archive.exists()
with tarfile.open(archive,'w:xz',preset=6)as t:
    for name,b in sorted(members.items()):
        safe_text(name,b);m=tarfile.TarInfo(name);m.size=len(b);m.mode=0o644;m.uid=m.gid=m.mtime=0;m.uname=m.gname='';t.addfile(m,io.BytesIO(b))
with tarfile.open(archive,'r:xz')as t:
    mm=t.getmembers();assert len(mm)==len(members)==len({x.name for x in mm})
    for m in mm:assert m.isfile()and t.extractfile(m).read()==members[m.name]
ab=archive.read_bytes();archive_meta={'bodyPath':str(archive),'bytes':len(ab),'sha256':sha(ab),'gitBlob':blob(ab),'members':len(members)}
receipt={'schema':'s4-permission-unit-negative-retention-receipt-v1','status':'NATIVE_SUCCESS_IDENTITY_PASS39_SOURCE_REJECTED_RAW_LOSS','source':plan['source'],'native':plan['native'],'rawZIP':raw_meta,'admissionAnalysisArchive':archive_meta,'images':root['images'],'official':{'total':1035,'raw':347,'normalized':1034,'rawLosses':687,'normalizedLosses':0,'rawGains':root['comparison']['rawGainCount'],'normalizedGains':root['comparison']['normalizedGainCount'],'fullChangedRows':len(root['comparison']['changedRows']),'rootAdmissionSHA256':root_sha,'freshScoreSHA256':root['officialScore']['jsonSha256'],'nativeSavedScoreSHA256':root['officialScore']['nativeSavedJsonSha256'],'sourceAndNativeProvenance':'PASS','membershipQualification':'REJECTED_RAW_OR_NORMALIZED_LOSS','fullRowAndFailureRecordsRetained':True,'independentOfficialScorerExecutions':1},'CTO':root['CTO'],'independentIdentity':{'status':'FIRST_ONLY_PASS39','finalManifestSHA256':'d7015b173b4ffa8999ba79a970c183fc5cff54375ea0c14314eb3a6298ae442b','reviewSHA256':'36cb9f0938aa84de97f68163bf3e1b0242304e112097fde4c0684d7a7ec0f564'},'actualCausalPrefix':causal,'compiledRawLossForensics':raw_loss,'targetMetric':{'executions':0,'status':'HELD_REJECTED_SOURCE','M':None,'noEbeResultTransferred':True},'VM':{'executions':0,'status':'HELD_REJECTED_SOURCE','noOldRuntimeResultTransferred':True},'retentionAnchor':{k:plan[k]for k in ['repository','branch','expectedParent','expectedBaseTree']},'originalTrueConsumerProofSHA256':'883cea9ee27fc594dc395b67032c577b3ef3ca4867002263a79016ab0b1fe195','claims':{'acceptedSource':False,'newVariantGO':False,'originalUnitABI':False,'all687AddressOnlyExplained':False,'uniqueOriginalWitness':False,'runtimeEquivalence':False,'sourceGainOrNewWindow':False,'newPRorPoints':False},'rawPublicMaskedLogPreserved':True,'allFailedSelectorsAdaptersAndNoLossExitPreserved':True,'livePublicCheckerExcluded':True,'actionsHere':archive_receipt['actionsHere'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
p=O/'S4-RECEIPT.json';assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n');b=p.read_bytes();receipt_meta={'bodyPath':str(p),'bytes':len(b),'sha256':sha(b),'gitBlob':blob(b)}
adds=[]
for dest,body in zip(plan['exactNewPaths'],[raw_meta,archive_meta,receipt_meta]):adds.append({'path':dest['path'],'mode':'100644','type':'blob',**body})
assert len(adds)==3 and len({x['path']for x in adds})==3 and all(not PurePosixPath(x['path']).is_absolute()and x['path'].startswith('reconstruction/pump-main/lanes/source-s1-native-retained-20261031/')for x in adds)
freeze={'schema':'s4-negative-three-path-retention-append-freeze-v1','status':'FROZEN_READY_FOR_ROOT_AND_INDEPENDENT_REVIEW_NO_UPLOAD','repository':plan['repository'],'branch':plan['branch'],'expectedParent':plan['expectedParent'],'expectedBaseTree':plan['expectedBaseTree'],'rootMustFreshlyValidateLease':True,'additions':adds,'exactAddedPaths':3,'modificationsOrDeletions':False,'allInputFiles':inputs,'stagingInventorySHA256':sha((O/'STAGE-INVENTORY.json').read_bytes()),'planSHA256':sha((O/'PLAN.json').read_bytes()),'packagerSHA256':sha(Path(__file__).read_bytes()),'finalProofs':{'actualCausalPrefix':sha(am.read_bytes()),'rawLossFinal':sha(lm.read_bytes()),'rawLossArchive':ld['archive']},'allSafeRegularArchiveMembers':len(members),'rawZIPUntouched':True,'rawForensicsRetainedCompressedOnly':True,'fullRowAndFailureRecordsRetained':True,'sourceRejectedMetricVmHeld0':True,'livePublicCheckerExcluded':True,'actionsHere':archive_receipt['actionsHere']}
p=O/'FROZEN-APPEND.json';assert not p.exists();p.write_text(json.dumps(freeze,indent=2)+'\n')
checks={'status':'PASS_PACKAGING_ONLY','freezeSHA256':sha(p.read_bytes()),'outerMembers':len(members),'outerManifestEntries':len(manifest),'rawForensicMembers':28,'rawForensicBodyHashVerified':True,'original252StagedInputsUnchanged':True,'actual15PrefixRecordsIncluded':True,'canonicalMaskedPublicLogPreserved':True,'noDuplicateExpandedRawForensics':True,'noELFOrFullIROutsideRawZIP':True,'credentialPatternMatches':0,'signedURLs':0,'remoteWrites':0,'newMeasurementsTestsOrProducerExecutions':0};(O/'FINAL-PACKAGING-CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({'freeze':str(p),'freezeSHA256':sha(p.read_bytes()),'archiveMembers':len(members),'additions':adds,'checks':checks}))
