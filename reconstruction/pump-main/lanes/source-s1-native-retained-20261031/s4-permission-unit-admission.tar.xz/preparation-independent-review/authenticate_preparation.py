"""Independent S4 frozen preparation reader; never imports project code."""
from pathlib import Path, PurePosixPath
import ast, copy, hashlib, json, os, re, subprocess, sys, tarfile, zipfile
assert os.environ.get('PYTHONDONTWRITEBYTECODE') == '1' and sys.dont_write_bytecode
ROOT=Path('/dev/shm/pump-cto-permission-s4'); PREP=ROOT/'work/native-prep'; OUT=ROOT/'work/capture-review'
PARENT_ROOT=Path('/dev/shm/pump-cto-ebe5387')
BASE='a119f880c73de06084df27a2b2cbffec09a6f46c'; PARENT='ebe5387e12e948c2534618adf7a3cf0f27d9de51'
SOURCE='9e7f44ab78eb9e87c295ae213f06059a3f226104444e036ad8282e318c6eac6a'
STAGE='7e106be292376426b3f8769d1e651580bf1f1aaffc851555f6ed054576d6f86e'
SHA=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
canonical=lambda x:hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
checks=[]
def check(name, condition):
    assert condition, name
    checks.append(name)

check('exact author final freeze SHA from release', SHA(PREP/'FROZEN-MANIFEST.json') == sys.argv[1])
frozen=load(PREP/'FROZEN-MANIFEST.json'); prepared=load(PREP/'PREPARATION-RESULT.json')
for r in frozen['files']:
    name=PurePosixPath(r['path']); p=PREP/name
    assert not name.is_absolute() and '..' not in name.parts
    assert p.is_file() and not p.is_symlink() and p.stat().st_size==r['bytes'] and SHA(p)==r['sha256']
check('every author frozen file bound', True)
source=load(OUT/'SOURCE-AUTHENTICATION.json')
check('independent genuine source141 and CORE236 sole Ebe parent', source['source']==BASE and source['parent']==PARENT and source['selectedSourceSha256']==SOURCE)
program,core=[x['files'] for x in source['vectors']]
for r in program+core:
    p=ROOT/r['path']; b=os.fsencode(os.readlink(p)) if p.is_symlink() else p.read_bytes()
    assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r['bytes']
check('all377 physical Git source and CORE bytes remain unchanged', len(program)==141 and len(core)==236)
evidence=PREP/'preflight/evidence'; stage=PREP/'preflight/cold-work/ws'
check('actual preflight source and CORE vectors equal independently typed Git', load(evidence/'program-source-inputs.json')==load(PREP/'program-source-inputs.json')=={'base':BASE,'files':program} and load(evidence/'toolchain-source-inputs.json')==load(PREP/'toolchain-source-inputs.json')=={'base':BASE,'files':core})
selected=[{'path':r['path'].removeprefix('programs/pump/'),'bytes':r['bytes'],'executable':r['mode']=='100755','sha256':r['sha256']} for r in program]
snapshot=load(evidence/'preflight-builder-source-inputs.json')
check('selected source canonical vector', snapshot==load(PREP/'EXPECTED-SELECTED-SOURCE.json') and snapshot['files']==selected and snapshot['sha256']==canonical(selected)==SOURCE)
staged={}
for p in sorted(stage.rglob('*')):
    assert not p.is_symlink()
    if p.is_file():staged[p.relative_to(stage).as_posix()]={'bytes':p.stat().st_size,'executable':bool(p.stat().st_mode&0o111),'sha256':SHA(p)}
check('actual maintained142 stage vector', len(staged)==142 and staged==load(evidence/'compiled-workspace-inputs.json')==load(PREP/'EXPECTED-COMPILED-WORKSPACE.json') and canonical(staged)==STAGE)
toml=(ROOT/'programs/pump/Cargo.toml').read_text(); ps=re.search(r'(?m)^\[profile\.release\]',toml).start(); wi=re.search(r'(?m)^\[workspace\]',toml).start()
projection={r['path']:(ROOT/r['path']).read_bytes() for r in program if r['path'] not in ('programs/pump/Cargo.toml','programs/pump/Cargo.lock')}
projection['programs/pump/Cargo.toml']=(toml[:ps].rstrip()+'\n').encode()
projection['Cargo.toml']=('[workspace]\nmembers = ["programs/pump"]\nresolver = "2"\n\n'+toml[ps:wi].strip()+'\n').encode()
projection['Cargo.lock']=(ROOT/'programs/pump/Cargo.lock').read_bytes()
check('all staged bytes exact immutable source and maintained manifest lock projection', set(projection)==set(staged) and all((stage/n).read_bytes()==b for n,b in projection.items()))
for name,folder,expected in [('program-source.tar.gz',ROOT,{r['path'] for r in program}),('compiled-workspace.tar.gz',stage,set(staged))]:
    with tarfile.open(evidence/name) as t:
        members=t.getmembers(); assert len(members)==len(expected)==len({m.name for m in members}) and {m.name for m in members}==expected
        for m in members:assert m.isfile() and t.extractfile(m).read()==(folder/m.name).read_bytes() and bool(m.mode&0o111)==bool((folder/m.name).stat().st_mode&0o111)
check('all283 source and compiled archive members exact bytes modes', True)
lane='reconstruction/pump-main/lanes/current-native-control'; controller=PREP/'ops'/lane/'pump_current_control.py'; prior=PARENT_ROOT/'work/native-prep/ops'/lane/'pump_current_control.py'
ct=ast.parse(controller.read_text()); pt=ast.parse(prior.read_text()); normalized=copy.deepcopy(ct)
for n in normalized.body:
    if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='BASE':n.value=ast.Constant(value=PARENT)
normalized.body[0]=copy.deepcopy(pt.body[0])
check('entire controller including main class methods flags unchanged except BASE docstring', ast.dump(normalized,include_attributes=False)==ast.dump(pt,include_attributes=False))
helpers=[n.name for n in ct.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name!='main']
check('all14 guard helpers and class authenticated',len(helpers)==14)
ops=('.github/workflows/qualify-pump-macos-v144.yml',lane+'/pump_current_control.py',lane+'/README.md')
check('exact normal3OPS inventory',len(prepared['opsFiles'])==3 and {r['path'] for r in prepared['opsFiles']}==set(ops))
for r in prepared['opsFiles']:
    p=PREP/'ops'/r['path']; b=p.read_bytes()
    assert not p.is_symlink() and not p.stat().st_mode&0o111 and len(b)==r['bytes'] and SHA(p)==r['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==r['gitBlob']
check('all3 OPS sizes modes SHA Git blobs bound',True)
workflow=(PREP/'ops'/ops[0]).read_text(); old=(PARENT_ROOT/'work/native-prep/ops'/ops[0]).read_text()
check('workflow source pin and descriptive labels only', workflow.replace(BASE,PARENT).replace('a119f880','ebe5387e')==old)
ref=ROOT/'work/current-ebe-reference'; actual=PARENT_ROOT/'work/native-run/artifact'; reference=load(PREP/'REFERENCE-COPY-ADMISSION.json'); pins=reference['files']
check('actual admitted Ebe43 external reference pins',len(pins)==43 and reference['base']==PARENT and reference['run']==41176417138 and reference['artifactId']==13033007890 and reference['rawZipSHA256']=='b9ad6f1bc76f9b8fdb01e06b65262e3725ded83d544e394c8f0f568da6bfcfe5' and reference['rawZipBytes']==2539553)
check('exact43 external reference domain', {p.relative_to(ref).as_posix() for p in ref.rglob('*') if p.is_file() or p.is_symlink()}==set(pins))
for name,r in pins.items():
    p=ref/name; assert p.is_file() and not p.is_symlink() and p.stat().st_size==r['bytes'] and SHA(p)==r['sha256'] and p.read_bytes()==(actual/name).read_bytes()
with zipfile.ZipFile(actual.parent/'raw-artifact.zip') as z:
    assert z.testzip() is None and len(z.namelist())==43 and set(z.namelist())==set(pins)
    for n in z.namelist():assert z.read(n)==(ref/n).read_bytes()
check('actual Ebe raw ZIP and43 original member bytes unchanged',SHA(actual.parent/'raw-artifact.zip')==reference['rawZipSHA256'])
for name,r in reference['separateQualificationRecords'].items():
    p=PREP/name; assert p.stat().st_size==r['bytes'] and SHA(p)==r['sha256'] and p.read_bytes()==Path(r['source']).read_bytes()
check('root score metric source semantic and publication qualification kept outside43',True)
score=load(ref/'score.json'); official=load(PREP/'REFERENCE-ROOT-OFFICIAL-SCORE.json')
check('saved Ebe1035 official rows and raw norm arithmetic only',len(score['windows'])==len(official['windows'])==1035 and all(score['windows'][k]['raw']==official['windows'][k]['raw'] and score['windows'][k]['normalized']==official['windows'][k]['normalized'] for k in score['windows']) and sum(r['raw'] for r in official['windows'].values())==sum(r['normalized'] for r in official['windows'].values())==1034)
before=load(PREP/'PREFLIGHT-INPUTS-BEFORE.json'); after=load(PREP/'PREFLIGHT-INPUTS-AFTER.json')
check('all426 typed before after bindings unchanged for one real preflight',before==after and len(before)==len({r['path'] for r in before})==426)
amendment=load(PREP/'README-DESCRIPTION-ONLY-AMENDMENT.json')
check('post preflight README amendment exact root requested description only',amendment==prepared['postPreflightReadmeOnlyAmendment'])
executed_readme=PREP/amendment['executedReadme']; final_readme=PREP/'ops'/lane/'README.md'
check('executed old README retained and final is exact appended paragraph',SHA(executed_readme)==amendment['oldSha256'] and SHA(final_readme)==amendment['newSha256'] and final_readme.read_bytes()==executed_readme.read_bytes()+amendment['exactAppendedText'].encode())
for r in after:
    p=Path(r['path']);assert p.is_relative_to(ROOT); st=p.lstat(); b=os.fsencode(os.readlink(p)) if p.is_symlink() else p.read_bytes()
    if p==final_readme:
        assert r['sha256']==amendment['oldSha256'] and r['bytes']==executed_readme.stat().st_size
    else:
        assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'] and st.st_mode==r['mode'] and st.st_ino==r['inode'] and st.st_dev==r['device'] and st.st_mtime_ns==r['mtime_ns']
check('all425 other bound files remain physical identical after documented README-only amendment',True)
execution=load(PREP/'PREFLIGHT-EXECUTION.json'); process=load(PREP/'PREFLIGHT-PROCESS.json'); outcome=load(PREP/'PREFLIGHT-RESULT.json')
check('actual single process731353 exit0 noSDK preflight',process['pid']==outcome['pid']==731353 and outcome['status']=='PASS' and outcome['exitCode']==execution['exitCode']==0 and execution['head']==BASE and execution['controllerSha256']==SHA(controller) and not outcome['SDKBootstrapCargoCompilerScorerVMExecuted'])
check('explicit bytecode off argv original logs and real rsync',process['argv']==outcome['argv']==execution['command'] and process['argv'][1]=='-B' and process['environment']['PYTHONDONTWRITEBYTECODE']=='1' and execution['rsyncSha256']=='a56c05b960beb734169619d5760b43ff495e84f85a93eb1f54fe58118262fb20' and outcome['stderrBytes']==0)
for n in ('stdout','stderr'):
    p=PREP/('preflight.'+n);assert p.stat().st_size==outcome[n+'Bytes'] and SHA(p)==outcome[n+'Sha256']
loader=ast.parse((PREP/'run_preflight.py').read_text()); calls=[n for n in ast.walk(loader) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='main']
attrs=[n.targets[0].attr for n in ast.walk(loader) if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Attribute) and isinstance(n.targets[0].value,ast.Name) and n.targets[0].value.id=='module']
check('loader only binds ROOT EVIDENCE WORK and calls preflight_only true once',attrs==['ROOT','EVIDENCE','WORK'] and len(calls)==1 and len(calls[0].keywords)==1 and calls[0].keywords[0].arg=='preflight_only' and ast.literal_eval(calls[0].keywords[0].value) is True)
pf=load(evidence/'PREFLIGHT.json'); link=load(evidence/'link-inputs.json')
check('maintained preflight ended before SDK bootstrap Cargo compiler link configuration',pf['preflightOnly'] and not pf['sdkInstalledByPreflight'] and not pf['bootstrapRunByPreflight'] and not pf['cargoRunByPreflight'] and not pf['compilerRunByPreflight'] and not link['configureExecutedByPreflight'] and link['selectors']=={'.text':555,'.rodata':0,'.data.rel.ro':0} and not (PREP/'preflight/cold-work/target-identity').exists())
allrows={r['path']:r for r in program+core}
for name,r in {'ordered.ld':link['programScript'],**link['maintainedInputs']}.items():assert r==allrows[r['path']] and SHA(evidence/'pinned-link-inputs'/name)==r['sha256']
check('all5 private link input bindings exact',True)
guides=load(PREP/'INPUT-REVIEW.json')
for name,r in guides['guidesAndManifests'].items():assert SHA(ROOT/name)==r['sha256'] and (ROOT/name).read_bytes()==(PARENT_ROOT/name).read_bytes()
check('instructions manifests lock hooks remain qualified Ebe',True)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1',GIT_ALLOW_PROTOCOL='file')
check('tracked checkout still clean',not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,env=env,stderr=subprocess.PIPE).strip())
report={'status':'PASS','source':BASE,'parent':PARENT,'authorFreezeSha256':sys.argv[1],'frozenFiles':len(frozen['files']),'sourceFiles':141,'coreFiles':236,'stageFiles':142,'sourceAggregateSha256':SOURCE,'stageVectorSha256':STAGE,'operationalFiles':prepared['opsFiles'],'helpers':helpers,'actualPreflight':{'pid':731353,'seconds':outcome['elapsedSeconds'],'receiptSha256':SHA(PREP/'PREFLIGHT-EXECUTION.json')},'checks':checks,'limits':['Independent retained read/hash/AST/Git/archive only; no preflight/project imports/SDK/compiler/scorer/metric/VM repeated.','Preparation GO only; root alone publishes and authorizes one normal build. Actual source/native/scoring acceptance remains pending.','No actual SDK/native closure transferred from Ebe; expected transport/native changes are unmeasured.']}
p=OUT/'AUTHENTICATION.json';assert not p.exists();p.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','checks':len(checks),'authenticationSha256':SHA(p),'source':SOURCE,'stage':STAGE}))
