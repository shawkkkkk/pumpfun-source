"""One root-authorized Ebe producer/common-head/outer-pack inspection.

Only execute bytes before and including prepare+1a88 are decoded. No tail,
error constructor analysis, scorer, metric, compiler, VM, or harness import.
"""
from pathlib import Path
import hashlib
import importlib.util
import json

HERE = Path(__file__).resolve().parent
ELF = HERE.parents[1] / "work/native-run/artifact/unstripped.so"
EXPECTED = "9ac11d9e5692d3ff91d45880d5e442347dac7a76bf7d62870f07fc53247b4fcf"
SOURCE = HERE.parents[1] / "programs/pump/src/creator/admin_cto.rs"
SOURCE_SHA = "a1a0bb06a5a260e13f5824235bbd19b6fa43883f07e3073e1cbcba03ab16601a"
PARSER = Path("/dev/shm/pump-cto-option-c1/work/carrier/native_compare.py")
PARSER_SHA = "2033142ac919d226a4539cc0f25b80066428794d198263dd0a73919c71af81e9"
CTO = "_ZN14pump_recovered9admin_cto7execute17h3bd6d7f34f2e30d7E"
PREPARE = 0x1A88


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert not (HERE / "EXECUTION.json").exists(), "Actual one-shot read already recorded"
    assert sha(PARSER) == PARSER_SHA
    assert sha(SOURCE) == SOURCE_SHA
    spec = importlib.util.spec_from_file_location("owned_native_compare", PARSER)
    parser = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(parser)
    blob, section, symbols = parser.elf(ELF, EXPECTED)
    symbol = next(s for s in symbols if s["name"] == CTO)
    assert symbol["bytes"] >= PREPARE + 8
    offset = section[4] + symbol["address"] - section[3]
    prefix = blob[offset:offset + PREPARE + 8]
    rows = parser.decode(prefix, symbol["address"], symbols)
    assert rows[-1]["offset"] == PREPARE
    assert rows[-1]["raw"] == "8510000016310000"
    assert "prepare_bonding_curve" in rows[-1]["callName"]
    by_offset = {r["offset"]: r for r in rows}
    successors = {}
    predecessors = {p: [] for p in by_offset}
    exits = []
    for row in rows:
        p = row["offset"]
        nxt = p + row["bytes"]
        if row["opcode"] == 0x95:
            candidates = []
        elif "jump" in row:
            candidates = [row["jump"]]
            if row["opcode"] & 0xF0:
                candidates.append(nxt)
        else:
            candidates = [nxt]
        successors[p] = [q for q in candidates if q in by_offset]
        for q in successors[p]:
            predecessors[q].append(p)
        exits.extend({"from": p, "to": q, "reason": "outside authorized prefix"}
                     for q in candidates if q not in by_offset)
    result = {
        "schema": "ebe-authorized-prefix-live-copy-cache-v1",
        "input": {"path": str(ELF), "sha256": EXPECTED},
        "source": {"path": str(SOURCE), "sha256": SOURCE_SHA},
        "execute": symbol,
        "scope": {"firstOffset": 0, "lastOffset": PREPARE, "bytes": len(prefix),
                  "prefixSha256": hashlib.sha256(prefix).hexdigest(),
                  "logicalInstructions": len(rows)},
        "rows": rows,
        "successors": successors,
        "predecessors": predecessors,
        "externalEdges": exits,
        "limits": [
            "Only prefix bytes are decoded. External edges are boundary exits, not analyzed errors or tail.",
            "Raw memory widths and shared FP addresses alone do not establish field or Rust type identity.",
            "No tail, CPI, error body, official score, similarity metric, compiler, or VM analysis.",
            "Further bounded facts may be derived from this cache without another ELF read.",
        ],
    }
    output = HERE / "EBE-PREFIX.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    execution = {"status": "PASS", "readerSha256": sha(Path(__file__)),
                 "parserPath": str(PARSER), "parserSha256": PARSER_SHA,
                 "elfSha256": EXPECTED, "sourceSha256": SOURCE_SHA,
                 "output": {"path": str(output), "sha256": sha(output)},
                 "scope": result["scope"]}
    (HERE / "EXECUTION.json").write_text(json.dumps(execution, indent=2) + "\n")
    print(json.dumps(execution, indent=2))


if __name__ == "__main__":
    main()
