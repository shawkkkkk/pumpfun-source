"""Derive bounded field/copy placement from the one saved Ebe prefix.

This consumes retained records only. It never reads an ELF or the native tail.
"""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
CACHE = HERE / "EBE-PREFIX.json"
CACHE_SHA = "7013b4b1f00ddc002519cb9a80c5ce6b4a9065ebb859aec4f31479350bff7cb2"
ORIGINAL = Path("/dev/shm/pump-cto-option-c1/work/shared-boundary-query/ORIGINAL-SHARED-FLOW.json")
ORIGINAL_SHA = "05e4f56ad4280ae06df4eda4ae7296dd0bb3cadc8c6def1ee068ec1fdc0ae978"
HOLDER = Path("/dev/shm/pump-cto-option-c1/work/shared-boundary-query/causal-gate/ASSESSMENT.md")
WIDTH = {0x7B: 8, 0x73: 1, 0x63: 4, 0x6B: 2,
         0x7A: 8, 0x72: 1, 0x62: 4, 0x6A: 2}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert sha(CACHE) == CACHE_SHA
    assert sha(ORIGINAL) == ORIGINAL_SHA
    data = json.loads(CACHE.read_text())
    original = json.loads(ORIGINAL.read_text())
    rows = data["rows"]
    by = {r["offset"]: r for r in rows}
    pred = {int(k): v for k, v in data["predecessors"].items()}
    succ = {int(k): v for k, v in data["successors"].items()}

    def reg_definition(row, register):
        if row["opcode"] == 0x85:
            return register <= 5
        return (row["dst"] == register and
                (row["opcode"] == 0x18 or row["opcode"] & 7 in (1, 4, 7)))

    def reaching_register(pc, register):
        todo = list(pred[pc])
        seen, definitions = set(), set()
        entry = False
        while todo:
            p = todo.pop()
            if p in seen:
                continue
            seen.add(p)
            if reg_definition(by[p], register):
                definitions.add(p)
                continue
            if not pred[p]:
                entry = True
            todo.extend(pred[p])
        return {"register": register, "at": pc,
                "directDefinitions": [by[p] for p in sorted(definitions)],
                "entryWithoutDefinition": entry}

    def reaching_byte(pc, byte):
        todo = list(pred[pc])
        seen, definitions, calls = set(), set(), set()
        entry = False
        while todo:
            p = todo.pop()
            if p in seen:
                continue
            seen.add(p)
            r = by[p]
            if (r["opcode"] in WIDTH and r["dst"] == 10 and
                    r["displacement"] <= byte < r["displacement"] + WIDTH[r["opcode"]]):
                definitions.add(p)
                continue
            if r["opcode"] == 0x85:
                calls.add(p)
            if not pred[p]:
                entry = True
            todo.extend(pred[p])
        return {"at": pc, "frameByte": byte,
                "directDefinitions": [by[p] for p in sorted(definitions)],
                "entryWithoutDefinition": entry,
                "callsTraversed": [by[p] for p in sorted(calls)]}

    def span(lo, hi):
        return [r for r in rows if lo <= r["offset"] < hi]

    # Literal pointer chains, not type inference from aggregate widths.
    assert by[0x108]["src"] == 9 and by[0x108]["displacement"] == -4088
    assert by[0x110]["displacement"] == -2272
    assert by[0x518]["dst"] == 9 and by[0x518]["displacement"] == -2272
    assert by[0x5B8]["dst"] == 9 and by[0x5B8]["immediate"] == 1
    r9_at_sharing = reaching_register(0x17B8, 9)
    assert [r["offset"] for r in r9_at_sharing["directDefinitions"]] == [0x5B8]
    assert by[0x17B8]["raw"] == "bf92000000000000"
    assert by[0x1828]["raw"] == "bf23000000000000"
    assert by[0x268]["src"] == 8 and by[0x268]["displacement"] == 56
    assert by[0x4A8]["src"] == 7 and by[0x4A8]["displacement"] == -2336
    assert by[0x1810]["raw"] == "79a0e0f600000000"
    assert by[0x1820]["immediate"] == 8

    # The shared, nonholder suffix is straight-line until its branch to outer pack.
    chosen = {0x17A8: 0x17B8, 0x1800: 0x1810}
    path, p = [], 0x1760
    while p != 0x19C0:
        assert p not in path
        path.append(p)
        options = succ[p]
        p = chosen[p] if p in chosen else options[0]
        if len(options) != 1:
            assert path[-1] in chosen
    path.append(0x19C0)
    assert 0x1830 in path and 0x1878 in path and 0x18B8 in path
    after_common_before_outer = [by[p] for p in path if 0x17A0 <= p < 0x19C0]
    target_ranges = [(-1624, -1617), (-1328, -1319)]
    reads_of_common = [r for r in after_common_before_outer
                       if r.get("memoryKind") == "read" and r.get("memoryBase") == 10
                       and any(r["displacement"] < hi and
                               lo < r["displacement"] + r["memoryWidth"]
                               for lo, hi in target_ranges)]
    calls_in_suffix = [r for r in after_common_before_outer if r["opcode"] == 0x85]
    assert not reads_of_common and not calls_in_suffix

    byte_queries = [(0x1760, -1341), (0x1770, -1344), (0x1780, -1256),
                    (0x1790, -1248), (0x1A00, -1624), (0x1A10, -1621),
                    (0x1A20, -1328), (0x1A30, -1320), (0x1810, -2336)]
    byte_definitions = [reaching_byte(pc, byte) for pc, byte in byte_queries]
    assert all(not q["entryWithoutDefinition"] for q in byte_definitions)

    output = {
        "status": "EBE_LIVE_KEY_AND_SHARING_COPY_PLACEMENT_BOUND_TO_PREPARE_ONLY",
        "inputs": [{"path": str(CACHE), "sha256": CACHE_SHA},
                   {"path": str(ORIGINAL), "sha256": ORIGINAL_SHA}],
        "currentImage": data["input"], "currentSource": data["source"],
        "scope": data["scope"],
        "roles": {
            "K": "holder PDA hk.0, bound by separate context-volatile-field producer packet",
            "C": "curve.creator32 at actual accounts+56 pointer+8",
            "N": "validated incoming new Pubkey, public Option payload starts at incoming-new pointer+1",
            "roleBasis": "Exact source and reviewed public input ABI plus actual pointer/byte producer chains below; not a width-to-type rule.",
        },
        "newPointerChain": {"rows": [by[p] for p in (0, 0x108, 0x110, 0x518, 0x5B8, 0x17B8, 0x1828)],
                            "r9At17b8": r9_at_sharing,
                            "meaning": "R9 is incoming-new+1 before its postshared copy; R2 then R3 retain that pointer when R9 is reused as a flag."},
        "curvePointerChain": {"rows": [by[p] for p in (0x28, 0x268, 0x4A8, 0x1810, 0x1818, 0x1820)],
                              "meaning": "accounts+56 curve pointer savedFP-2336, reloadedR0; R1=R0+8 is creator byte0."},
        "currentValidatedKeyBeforeFee": {
            "holderRows": span(0xA50, 0xAA8),
            "nonholderRows": span(0x1410, 0x1468),
            "holder": "first7 K bytes from PDA outputFP-1657; middle8+8 and tail9 from retainedKFP-1696; K source/ABI independently bound",
            "nonholder": "first7 N bytes from R9=new+1; middle8+8/tail9 from saved incoming-new pointer offsets8/16/24/32",
            "commonLiveRegisters": {"r4": "selected K/N bytes7..15", "r5": "selected K/N bytes15..23"},
            "cSelectedYet": False,
        },
        "currentCommonFeeSuccessOrNoneHead": {
            "rows": span(0x1760, 0x17B0),
            "transport": [{"logicalBytes": [0, 7], "sourceFrame": [-1344, -1337], "destinationFrame": [-1624, -1617], "rowOffsets": [0x1760, 0x1768, 0x1770, 0x1778]},
                          {"logicalBytes": [23, 32], "sourceFrame": [-1256, -1247], "destinationFrame": [-1328, -1319], "rowOffsets": [0x1780, 0x1788, 0x1790, 0x1798]}],
            "valueFamily": "validated K/N, before any late C override",
            "bothFeeBranchesReach": "Existing EBE-CONTROL seals feeNone→1760 directly and validSome→1758→1760; no new fee CFG census here.",
        },
        "currentPostsharedNonholder": {
            "guardRows": [by[p] for p in (0x17A0, 0x17A8, 0x17D8, 0x17F0, 0x1800)],
            "chosenDirectPath": path,
            "NcopyRows": span(0x1828, 0x1870),
            "Ncopy": "N bytes0..32 from actual new+1 to FP[-720,-688), separate from the selected-key fragments",
            "CoverrideRows": span(0x1870, 0x18C0),
            "Coverride": "C bytes0..7 overwriteFP[-1624,-1617); C7..15→R4, C15..23→R5; C23..32 overwriteFP[-1328,-1319). All are afterfee shared/nonholder choice.",
            "readsOfCommonKeyFragmentsBeforeOverwriteOrOuter": reads_of_common,
            "callsInThatSuffix": calls_in_suffix,
            "boundedImplication": "On shared-nonholder path the common K/N fragment writes are overwritten by C before a direct local read; no function call occurs in that interval. This is a path-specific native transport fact, not general removal authority.",
        },
        "outerPackBeforePrepare": {
            "sharingScratchCopyRows": span(0x19C0, 0x1A00),
            "sharingScratchDestination": [-1376, -1344],
            "sharingRoleLimit": "Only shared-nonholder has meaningful N32 here. Reset/absent paths reuse other scratch; do not assign them N or Pubkey meaning.",
            "selectedKeyRows": span(0x1A00, 0x1A50),
            "selectedKeyDestination": [-1408, -1376],
            "selectedKeyAssembly": "first7 + R4 bytes7..15 + R5 bytes15..23 + tail9 = selectedK/C/N32; actual producer families above establish role",
            "consumerLimit": "The native outer-pack stores before prepare are the consumers proved here. No Ebe curve/Fees/pool tail or serialized output is inspected or claimed.",
        },
        "directReachingByteWrites": byte_definitions,
        "directReachingKeyRegistersAtOuter": [reaching_register(0x1A40, 5), reaching_register(0x1A48, 4)],
        "originalSealedComparison": {
            "originalBodySha256": original["cto_sha256"],
            "targetOrigins": original["selected_target_origin"],
            "selections": original["two_selections"],
            "selectedTargetPathChecks": original["path_checks"],
            "feeSuccessRows": original["raw_witnesses"]["fee_some_flag_tree"][:6],
            "feeSuccessOutputs": {
                "1800": "Stores already selected target first8 from R4 toFP-2328; C/N source and preservation are in the original path checks; holderK predecessor is retained in the separate historical holder assessment.",
                "1808": "Preserves R3 intoFP-2376. On nonholder path R3 reload1538 reads the earlier c60 spill from publicnew+16 = N[15,23). It is separate from C/N selectedtarget24. Holder's suppliednew isNone, so no meaningfulN Pubkey is assigned to its carried raw bytes.",
                "1810": "Sets actual fee-present scalarR7=1; does not load a key byte.",
                "1818_1820": "Reads/tests saved shared flag at privatefeeSome head; feeNone has separate flags entries.",
            },
            "incomingNMiddleEvidence": {
                "eagerInputRows": original["raw_witnesses"]["new_argument_eager_copy"],
                "registerForwardRows": original["raw_witnesses"]["new_middle_word_forwarding"],
                "inputSpillRows": [r for r in original["raw_witnesses"]["validated_new_payload"] if 0xC60 <= int(r["offset"], 16) <= 0xC68],
                "retainedRegisterCheck": original["additional_register_reaching_definition_checks"]["r3_at_new_middle_store_c60"],
                "scope": "Binds the field value stored/reloaded, not its final original CPI serialization.",
            },
            "historicalHolderAssessment": {"path": str(HOLDER), "sha256": sha(HOLDER),
                "factUsedOnly": "Holder24 selected+ab8/ac8/ad8, firstword+ae8 reaches+10e8/+1800; selected24 survives to outerpack. This is a retained native fact, not adoption of that old Option proposal."},
            "targetReloadRows": original["raw_witnesses"]["fee_success_target_reload"],
            "NpostsharedCopyRows": [r for r in original["raw_witnesses"]["fee_some_flag_tree"] if 0x1850 <= int(r["offset"], 16) <= 0x1890],
            "outerPackRows": original["raw_witnesses"]["selected_target_outer_pack"],
            "difference": "Original K/C/N target is selected beforefee as first8+remaining24 and survives the private feeSome flags head; its later shared-nonholder used7/9 copies are N payload pieces. Current commonhead first7/tail9 transport K/N then late shared-nonholder C overwrites the selected-key object; distinct N32 copy occurs beside that C override.",
        },
        "limits": [
            "No original source helper/type/Result/lifetime uniqueness is inferred from native packing.",
            "No Ebe tail/CPI/error-body inspection. Current downstream observable selected-key or Fees use remains outside this prefix proof.",
            "Direct CFG/register/FP provenance assumes reviewed SBF caller-clobber/callee-save and public argument-frame roles. Opaque callee aliases are not globally closed.",
            "Shared-nonholder no-read interval contains no call and no local target address escape. Public new input and curve pointers have reviewed nonlocal roles, not aliases manufactured from matching values.",
            "Nonshared memcmp1980 has local key-middle spill/restore; the known read-only memcmp contract is required for across-call preservation. No compiler-wide alias theorem is claimed.",
            "Original final sharing payload serializer remains unclosed in the existing original receipt; do not transfer current/S3 consumer identities into it.",
            "This describes missing/reordered live transports, not a source proposal or a metric/gain claim. All previous negatives remain in force; NO_NEW_VARIANT_GO.",
        ],
    }
    (HERE / "LIVE-COPIES.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"status": output["status"], "cacheSha256": CACHE_SHA,
                      "originalReceiptSha256": ORIGINAL_SHA,
                      "outputSha256": sha(HERE / "LIVE-COPIES.json")}, indent=2))


if __name__ == "__main__":
    main()
