import ast, hashlib, json
from pathlib import Path
R=Path('/dev/shm/pump-cto-borrowed-selection-s5');O=R/'work/native-prep';D=Path('/dev/shm/pump-cto-d421-control/work/native-prep')
sha=lambda b:hashlib.sha256(b).hexdigest()
result=json.loads((O/'PREFLIGHT-RESULT.json').read_text());assert result['status']=='PASS' and result['inputsUnchanged'] and result['sourceCoreReferenceOpsBoundFiles']==549
E=O/'preflight/evidence';pre=json.loads((E/'PREFLIGHT.json').read_text());expected=json.loads((O/'EXPECTED-SELECTED-SOURCE.json').read_text())
assert pre['programGitFiles']==pre['selectedSourceFiles']==263 and pre['coreFiles']==279 and pre['workspaceFiles']==264
assert json.loads((E/'preflight-builder-source-inputs.json').read_text())==expected
for name in ['program-source-inputs.json','toolchain-source-inputs.json']:
 assert json.loads((E/name).read_text())==json.loads((O/name).read_text())
ops=[]
for p in sorted((O/'ops').rglob('*')):
 if p.is_file():
  data=p.read_bytes();ops.append({'path':p.relative_to(O/'ops').as_posix(),'mode':'100644','bytes':len(data),'sha256':sha(data),'gitBlob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()})
assert len(ops)==3
stage=sha((E/'compiled-workspace-inputs.json').read_bytes())
prep={'sourceCommit':'bb4a6fcaca179a8a49882a6acac3b503a1206882','sourceTree':'f981d5c90d5137be84c5f5d2438cf96dd3af5f17','sourceFiles':263,'coreFiles':279,'stageFiles':264,'selectedSourceSha256':expected['sha256'],'expectedStageVectorSha256':stage,'opsFiles':ops,'rootOnlyReview':True,'sourceExperiment':True,'nativeReadOrExecution':False}
(O/'PREPARATION-RESULT.json').write_text(json.dumps(prep,indent=2)+'\n')
files={}
for p in sorted(O.rglob('*')):
 if p.is_file() and '/preflight/cold-work/' not in p.as_posix():
  files[p.relative_to(O).as_posix()]={'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
freeze={'source':prep['sourceCommit'],'tree':prep['sourceTree'],'files':files,'sourceFiles':263,'coreFiles':279,'stageFiles':264,'selectedSourceSHA256':expected['sha256'],'stageVectorSHA256':stage,'preflightPID':result['pid'],'independentAgentReview':False,'scope':'One exact borrowed-selection S5 normal cold diagnostic; no source/CORE/flags/SDK recipe variations. Root-only preparation review.'}
(O/'FROZEN-MANIFEST.json').write_text(json.dumps(freeze,indent=2)+'\n')
go={'rootPreparationGO':True,'preparationSHA256':sha((O/'FROZEN-MANIFEST.json').read_bytes()),'source':prep['sourceCommit'],'sourceSHA256':expected['sha256'],'preflightPID':result['pid'],'controllerASTOnlyBaseAndDescriptionChanged':True,'OPS':ops,'dispatchesPermitted':1,'noProgramPRRelease':True,'reference':'D421 actual 1034raw/norm M2248; full loss gate before any metric/VM','independentAgentReview':False}
(R/'work/ROOT-NATIVE-PREPARATION-GO.json').write_text(json.dumps(go,indent=2)+'\n')
print(json.dumps({'preparation':prep,'freezeSHA256':go['preparationSHA256'],'rootNativeGO':sha((R/'work/ROOT-NATIVE-PREPARATION-GO.json').read_bytes())}))
