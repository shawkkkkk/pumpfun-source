"""Derive direct-register/FP facts from the already admitted bounded S5 cache."""
import hashlib,json,os
from pathlib import Path
P=Path('/dev/shm/pump-cto-borrowed-selection-s5/work/native-inspection/actual/S5-PREFIX.json');raw=P.read_bytes();assert hashlib.sha256(raw).hexdigest()=='3633c7c9e64a6c455156910cc9ee50b2b5a17e54ace45b6b80812836e473a817'
d=json.loads(raw);rows=d['rows'];by={r['offset']:r for r in rows};pred={p:[]for p in by}
for r in rows:
 nxt=r['offset']+r['bytes'];targets=[]if r['opcode']==0x95 else [r['jump']]+([nxt]if r['opcode']&0xf0 else [])if'jump'in r else[nxt]
 for q in targets:
  if q in by:pred[q].append(r['offset'])
def query(pc,register=None,byte=None):
 pending=list(pred[pc]);seen=set();found=set();entry=not pending
 while pending:
  p=pending.pop()
  if p in seen:continue
  seen.add(p);r=by[p]
  defines=(register<=5 if r['opcode']in(0x85,0x8d)else r['dst']==register and(r['opcode']==0x18 or r['opcode']&7 in(1,4,7)))if register is not None else r.get('memoryKind')=='write'and r.get('memoryBase')==10 and r['displacement']<=byte<r['displacement']+r['memoryWidth']
  if defines:found.add(p)
  else:entry|=not pred[p];pending.extend(pred[p])
 return dict(at=pc,definitions=sorted(found),entryWithoutDefinition=entry,**({'register':register}if register is not None else{'fpByte':byte}))
qs=[]
for pc,reg in [(0x268,8),(0x3d0,7),(0x4a0,6),(0x4a8,6),(0xb30,6),(0xb78,1),(0xbb8,1),(0xbf8,1),(0x1348,7),(0x1350,1),(0x1358,6),(0xa20,1),(0x1370,1),(0x1460,7),(0x1638,7),(0x1648,7),(0x1920,1)]:qs.append(query(pc,register=reg))
for pc,start,length in [(0xa18,-2312,8),(0x1360,-2312,8),(0x1338,-48,32),(0x1348,-2288,8),(0x1930,-1304,32),(0x1908,-2296,8)]:
 for b in range(start,start+length):qs.append(query(pc,byte=b))
fee_loads=[r for r in rows if r.get('memoryKind')=='read'and r.get('memoryBase')==10 and r['displacement']==-2312]
target_writes=[r for r in rows if r.get('memoryKind')=='write'and r.get('memoryBase')==10 and r['displacement']< -1592 and r['displacement']+r.get('memoryWidth',0)>-1624]
ranges={'curveCreatorSnapshot':[0x3d0,0x408],'incomingOptionAndPayloadStaging':[0x4a0,0x4e0],'keyGuards':[0xb18,0xc18],'COrNPointerChoice':[0x1338,0x1370],'holderSomePointer':[0xa18,0xa48],'noFeeKeyMaterialization':[0x1648,0x1680],'afterFeeKeyMaterialization':[0x1890,0x18e0],'holderNoFeeKeyMaterialization':[0x1990,0x19c8],'sharedNonholderIncomingPayload':[0x1908,0x1988],'outerSharingPayload':[0x1ac0,0x1af8]}
out={'status':'S5_POINTER_SELECTED_BEFORE_FEES_BYTES_STILL_MATERIALIZED_AFTER','source':d['source'],'cacheSHA256':hashlib.sha256(raw).hexdigest(),'queries':qs,'queryCount':len(qs),'feeTagDirectLoads':fee_loads,'selectedTargetDirectWrites':target_writes,'ranges':{n:[r for r in rows if a<=r['offset']<=b]for n,(a,b)in ranges.items()},'directSelectedTargetWriteBlocks':[0x1648,0x18a0,0x1990],'derivedScope':'Conditional direct-FP/register path facts with all returns considered and R0..R5 clobbered at calls; arbitrary alias writes, error callee layouts/Result tag validity and unreachable-edge classification are not established. Role labels additionally use exact tested S5 source and public valid-value premises, not width alone. No original private ABI/lifetime inferred.','candidateQualification':'REJECTED_687_RAW_LOSSES','metricExecutions':0,'VMExecutions':0,'newELFDecodeExecutions':0,'producer':'Root cache-only derivation, not independent agent review.'}
assert P.read_bytes()==raw
(P.parent/'S5-MECHANISM.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'queryCount':len(qs),'registerQueries':qs[:17],'feeTagDirectLoadOffsets':[hex(r['offset'])for r in fee_loads],'targetWriteOffsets':[hex(r['offset'])for r in target_writes],'mechanismSHA256':hashlib.sha256((P.parent/'S5-MECHANISM.json').read_bytes()).hexdigest()},indent=2))
