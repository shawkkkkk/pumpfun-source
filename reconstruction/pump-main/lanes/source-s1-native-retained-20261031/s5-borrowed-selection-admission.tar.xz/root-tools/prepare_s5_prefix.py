"""Bind one bounded actual S5 native-prefix read after root full admission and secondary39."""
import hashlib,json
from pathlib import Path
R=Path('/dev/shm/pump-cto-borrowed-selection-s5');D=Path('/dev/shm/pump-cto-d421-control');O=R/'work/native-inspection';O.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
admission=json.loads((R/'work/root/CURRENT-ELF-ADMISSION.json').read_text());review=json.loads((R/'work/secondary-admission-reader/actual-review/REVIEW.json').read_text())
assert admission['base']=='bb4a6fcaca179a8a49882a6acac3b503a1206882' and admission['sourceAndNativeProvenanceConclusion']=='PASS'
assert len(review['checks'])==39 and all(x['pass']for x in review['checks'])
plan={'source':{'commit':admission['base'],'tree':'f981d5c90d5137be84c5f5d2438cf96dd3af5f17','path':'programs/pump/src/creator/admin_cto.rs','sha256':'ad50857894c6389c706b743b394e8d54dd6de880fbfa0c63c911a5bc15a4220e','gitBlob':'86570b314429c99be189ca2d3b6437aff52bb688'},'scope':'One actual named execute-to-prepare prefix, actual extent derived; no tail, helper body decode, scorer, token metric, compiler or VM. Relevant outlined calls stop attribution.','questions':['Does returning a borrowed validated selected key remove the current owned K/N fragments copied after fee checks and overwritten by C?','Where is C pointer selection versus actual32-byte materialization, relative to incoming-N guards and fee validation?','Are incoming N for sharing and selected K/C/N target still distinct; do not infer original private Result/reference ABI?'],'originalPremise':'Existing original pre-fee selectedC and distinct incomingN evidence credited to PR3639 /05e4/434b; not recomputed here.','membershipQualification':admission['membershipQualification'],'sourceProposalGo':False,'nativeDecodeExecutions':0}
(O/'MANIFEST.json').write_text(json.dumps(plan,indent=2)+'\n')
go={'rootGO':True,'source':admission['base'],'run':admission['run'],'unstrippedSha256':admission['images']['unstripped.so'],'rootAdmissionSha256':sha(R/'work/root/CURRENT-ELF-ADMISSION.json'),'actualRootSecondary39ReviewSha256':sha(R/'work/secondary-admission-reader/actual-review/REVIEW.json'),'actualCTO':{'VA':admission['CTO']['address'],'bytes':admission['CTO']['bytes']},'scope':plan['scope'],'membershipQualification':admission['membershipQualification'],'metricOrRuntimeReleased':False}
(R/'work/root/CAUSAL-PREFIX-GO.json').write_text(json.dumps(go,indent=2)+'\n')
out=O/'actual';out.mkdir()
t=(D/'work/native-inspection/actual/read_actual_prefix.py').read_text().replace('13cf99ecd8031d6bedd45f670f0c325d3cbc10364c3aa4966fb15c3ec339f772',sha(R/'work/root/CAUSAL-PREFIX-GO.json')).replace('2a0ca355f3b54f66d5643d78d65d98d8d2b68404b165dfa91e9a8faa29218d3f',sha(O/'MANIFEST.json')).replace('D421-PREFIX.json','S5-PREFIX.json').replace('current D421 native prefix','S5 borrowed-key native prefix')
(out/'read_actual_prefix.py').write_text(t)
print(json.dumps({'scope':plan['scope'],'readerSHA256':sha(out/'read_actual_prefix.py'),'GOsha256':sha(R/'work/root/CAUSAL-PREFIX-GO.json'),'planSHA256':sha(O/'MANIFEST.json'),'prefixNotExecuted':True,'membership':admission['membershipQualification']}))
