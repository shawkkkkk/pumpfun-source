"""Prepare exact genuine-Git S5 source; no SDK, compiler, score or VM execution."""
import ast, datetime, hashlib, importlib.util, json, os, shutil, subprocess, sys
from pathlib import Path
assert sys.dont_write_bytecode and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1'
R=Path('/dev/shm/pump-cto-borrowed-selection-s5');D=Path('/dev/shm/pump-cto-d421-control');O=R/'work/native-prep';P=Path('/dev/shm/pump-cto-borrowed-selection-s5-plan')
S='bb4a6fcaca179a8a49882a6acac3b503a1206882';B='d4219123cf0fbbefcfc7e77450efeda6684b812b'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=R)
git('sparse-checkout','init','--cone');git('sparse-checkout','set','.github/workflows','programs/pump','reconstruction/harness','reconstruction/toolchain','reconstruction/base','reconstruction/pump-main/baseline','evidence/original/pump','docs','crates');git('checkout','--detach',S)
assert git('rev-parse','HEAD').decode().strip()==S
assert git('rev-parse','HEAD^{tree}').decode().strip()=='f981d5c90d5137be84c5f5d2438cf96dd3af5f17'
assert (R/'programs/pump/src/creator/admin_cto.rs').read_bytes()==(P/'admin_cto.rs').read_bytes()
O.mkdir(parents=True,exist_ok=False)
for name in ['SOURCE.patch','ASSESSMENT.md','SEMANTIC-REVIEW.json','MANIFEST.json','ROOT-SOURCE-GO.json','PROPOSAL.json']:
 shutil.copyfile(P/name,O/('S5-'+name))
ops=O/'ops';oldops=D/'work/native-prep/ops'
controller='reconstruction/pump-main/lanes/current-native-control/pump_current_control.py'
original=(oldops/controller).read_text();modified=original.replace(B,S).replace('exact frozen d4219123 source checkpoint','exact frozen borrowed-selection S5 source checkpoint')
(ops/controller).parent.mkdir(parents=True);(ops/controller).write_text(modified)
oldast=ast.parse(original);newast=ast.parse(modified)
for node in [oldast,newast]:
 node.body.pop(0)
 for item in node.body:
  if isinstance(item,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='BASE' for t in item.targets):item.value=ast.Constant('FROZEN_SOURCE')
assert ast.dump(oldast)==ast.dump(newast)
workflow='.github/workflows/qualify-pump-macos-v144.yml'
text=(oldops/workflow).read_text().replace(B,S).replace('d4219123','s5-bb4a6fca').replace('Qualify current Pump identity control','Qualify S5 borrowed selected-key diagnostic').replace('single cold identity control','single cold S5 diagnostic').replace('One unchanged source build','One exact S5 source build')
(ops/workflow).parent.mkdir(parents=True);(ops/workflow).write_text(text)
readme='reconstruction/pump-main/lanes/current-native-control/README.md'
(ops/readme).write_text('''# S5 borrowed selected-key diagnostic\n\nOne normal cold build of genuine source `'''+S+'''`, a direct child of frozen D421 `'''+B+'''`. The sole program delta is five lines of admin_cto.rs: validate returns a borrowed selected K/C/N key, selecting C only after the required incoming-N guards and before the unchanged fee checks; the caller copies the validated key and preserves distinct incoming N for sharing.\n\nThis is a bounded mechanism hypothesis, not an inferred original private Rust ABI or recovered lifetime. Standard v1.44/macOS26 source recipe, unchanged current CORE279, full SDK guards and cold target. Controller executable AST differs only in BASE from the qualified D421 control. No flag/layout search, original-byte transplant, padding, IR edit or ownership/signature bypass. Public authorization/account/CPI code unchanged.\n\nAll raw and normalized rows must retain D421's 1034/1035 before target measurement; losses reject the source without metric or VM. No-loss must improve the same sealed normalized metric above M2248 before affected runtime validation or a source PR. This diagnostic is frozen to D421; promotion requires a fresh current-main build. The root source/preparation reviews are not independent agent reviews. Prior failed S1-S4/H1 and feephi results remain retained.\n''')
spec=importlib.util.spec_from_file_location('s5_control_prep',ops/controller);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOT=R
source=m.entries(S,('programs/pump',));core=m.entries(S,m.CORE)
assert len(source)==263 and len(core)==279
oldcore=json.loads((D/'work/native-prep/toolchain-source-inputs.json').read_text())['files'];oldsource=json.loads((D/'work/native-prep/program-source-inputs.json').read_text())['files']
assert core==oldcore
diff=[x['path'] for x,y in zip(source,oldsource) if x!=y]
assert diff==['programs/pump/src/creator/admin_cto.rs']
for name,rows in [('program-source-inputs.json',source),('toolchain-source-inputs.json',core)]:
 (O/name).write_text(json.dumps({'base':S,'files':rows},indent=2)+'\n')
snap=json.loads((D/'work/native-prep/EXPECTED-SELECTED-SOURCE.json').read_text());row=next(x for x in snap['files'] if x['path']=='src/creator/admin_cto.rs');data=(P/'admin_cto.rs').read_bytes();row.update(bytes=len(data),sha256=sha(data))
# Obtain the selected aggregate using the unchanged maintained helper; no stage/build yet.
sys.path.insert(0,str(R/'reconstruction/harness'))
spec2=importlib.util.spec_from_file_location('s5_fastbuild_prep',R/'reconstruction/harness/fastbuild.py');fb=importlib.util.module_from_spec(spec2);spec2.loader.exec_module(fb)
actual=fb.snapshot(R/'programs/pump');assert actual['files']==snap['files'];snap=actual
(O/'EXPECTED-SELECTED-SOURCE.json').write_text(json.dumps(snap,indent=2)+'\n')
local_cfg=[str(p) for p in [Path('/home/agent/.cargo/config'),Path('/home/agent/.cargo/config.toml'),Path('/.cargo/config'),Path('/dev/.cargo/config'),Path('/dev/shm/.cargo/config')] if p.exists()];assert not local_cfg
review={'status':'ROOT_STATIC_REVIEW_PREPARATION_ONLY','source':S,'tree':'f981d5c90d5137be84c5f5d2438cf96dd3af5f17','sourceFiles':263,'coreFiles':279,'selectedSourceSHA256':snap['sha256'],'wholeControllerASTSameExceptBaseAndDescription':True,'controllerSHA256':sha(modified.encode()),'workflowSHA256':sha(text.encode()),'sourceAndInstallReview':'Exact sole 5-line private borrowed selected-key source delta statically reviewed; full CORE279, manifests, lockfiles, install and build hooks byte-identical to admitted D421. No new install/download behavior or private credential access.','projectPythonScope':'Project -B and inherited bytecode-off; unchanged maintained isolated compiler-guardian standard-library exception retained.','independentAgentReview':False,'preflightRuns':0,'nativeRuns':0,'scorerMetricVMRuns':0,'localCargoConfigPresence':{}}
(O/'ROOT-PREPARATION-REVIEW.json').write_text(json.dumps(review,indent=2)+'\n')
for name in ['run_preflight.py','execute_preflight_once.py']:
 t=(D/'work/native-prep'/name).read_text().replace('/dev/shm/pump-cto-d421-control',str(R)).replace(B,S).replace('FrozenD4219123','BorrowedSelectionS5').replace('currentD4219123_native_control','borrowedSelectionS5_native_control')
 (O/name).write_text(t)
(O/'GENUINE-SOURCE.json').write_text(json.dumps({'source':S,'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'parent':B,'sourceGitBlob':'86570b314429c99be189ca2d3b6437aff52bb688','fiveLineDelta':diff,'CORE279IdenticalD421':True,'preflightNotRunYet':True},indent=2)+'\n')
print(json.dumps(review))
