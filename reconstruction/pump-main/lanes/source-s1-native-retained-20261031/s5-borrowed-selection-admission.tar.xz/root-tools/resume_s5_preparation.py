"""Resume preparation after missing local RUNNER_TEMP, before any preflight or SDK."""
import ast, datetime, hashlib, importlib.util, json, os, shutil, subprocess, sys
from pathlib import Path
R=Path('/dev/shm/pump-cto-borrowed-selection-s5');D=Path('/dev/shm/pump-cto-d421-control');O=R/'work/native-prep';P=Path('/dev/shm/pump-cto-borrowed-selection-s5-plan')
S='bb4a6fcaca179a8a49882a6acac3b503a1206882';B='d4219123cf0fbbefcfc7e77450efeda6684b812b'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=R)
ops=O/'ops';oldops=D/'work/native-prep/ops';controller='reconstruction/pump-main/lanes/current-native-control/pump_current_control.py';workflow='.github/workflows/qualify-pump-macos-v144.yml'
original=(oldops/controller).read_text();modified=(ops/controller).read_text();text=(ops/workflow).read_text()
first=Path('/dev/shm/prepare_s5.py').read_text()
record={'attempt':1,'status':'LOCAL_PREPARATION_ENVIRONMENT_FAILURE','scriptSHA256':sha(first.encode()),'error':"KeyError: RUNNER_TEMP on import of unchanged controller at prepare_s5.py line31; no preflight, SDK, compiler, scorer, metric or VM started",'correction':'Bind RUNNER_TEMP to this local preparation directory before metadata-only controller import; resume from failed line31. No controller/source/CORE edit.'}
(O/'PREPARATION-ATTEMPT-001.json').write_text(json.dumps(record,indent=2)+'\n')
os.environ['RUNNER_TEMP']=str(O/'runner-temp')
remaining=first[first.index("spec=importlib.util.spec_from_file_location('s5_control_prep'"):]
exec(compile(remaining,'/dev/shm/prepare_s5.py:resume-line31','exec'))
