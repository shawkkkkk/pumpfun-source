import datetime,hashlib,json,os,subprocess,time
from pathlib import Path
R=Path('/dev/shm/pump-cto-borrowed-selection-s5');O=R/'work/native-run';O.mkdir(exist_ok=False)
go=json.loads((R/'work/ROOT-NATIVE-PREPARATION-GO.json').read_text());assert go['rootPreparationGO'] and go['dispatchesPermitted']==1
assert hashlib.sha256((R/'work/native-prep/FROZEN-MANIFEST.json').read_bytes()).hexdigest()==go['preparationSHA256']
request=O/'dispatch-request.json';request.write_text(json.dumps({'ref':'work/cto-borrowed-selection-s5-native-20261031'}))
argv=['gh','api','--method','POST','repos/shawkkkkk/pumpfun-source/actions/workflows/398832206/dispatches','--input',str(request)]
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
start=now();clock=time.monotonic()
with (O/'DISPATCH-STARTED.json').open('x')as f:json.dump({'utc':start,'argv':argv,'source':go['source'],'operationalCommit':'e3d97702e33feb979b94bd7572ec1c9c5468bb55','operationalTree':'141eefe78f7be136b5c0487f84681dead317a516','expectedThreeOPSVerified':True,'rootPreparationSHA256':hashlib.sha256((R/'work/ROOT-NATIVE-PREPARATION-GO.json').read_bytes()).hexdigest()},f,indent=2)
with (O/'dispatch.stdout').open('xb')as out,(O/'dispatch.stderr').open('xb')as err:
 p=subprocess.Popen(argv,stdout=out,stderr=err);pid=p.pid;code=p.wait()
result={'startUtc':start,'endUtc':now(),'pid':pid,'elapsedSeconds':time.monotonic()-clock,'exitCode':code,'stdoutSHA256':hashlib.sha256((O/'dispatch.stdout').read_bytes()).hexdigest(),'stderrSHA256':hashlib.sha256((O/'dispatch.stderr').read_bytes()).hexdigest(),'dispatchAttempts':1}
(O/'DISPATCH-RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result));assert code==0
