"""Root-owned one-score frozen S5 borrowed-selection admission. Preparation does not execute this file."""
from pathlib import Path,PurePosixPath
import argparse,datetime,hashlib,json,os,re,stat,struct,subprocess,sys,tarfile,time,traceback,zipfile

ROOT=Path('/dev/shm/pump-cto-borrowed-selection-s5');RUN=ROOT/'work/native-run';A=RUN/'artifact';PREP=ROOT/'work/native-prep';REFERENCE=ROOT/'work/current-d421-reference'
OUT=ROOT/'work/root/admission';SCORE=OUT/'official-score';ADMISSION=ROOT/'work/root/CURRENT-ELF-ADMISSION.json'
BASE='bb4a6fcaca179a8a49882a6acac3b503a1206882';OP='e3d97702e33feb979b94bd7572ec1c9c5468bb55';RUN_ID=41212621615
SOURCE='54d5eb623f802e693f7f8d784b755005d56169886740d13e5fb7c599b772f172';REFERENCE_BASE='d4219123cf0fbbefcfc7e77450efeda6684b812b'
def need(value,message):
    if not value:raise ValueError(message)
def sha(data):return hashlib.sha256(data).hexdigest()
def digest(path):return sha(path.read_bytes())
def js(path):return json.loads(path.read_text())
def read(name):return js(A/name)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def safe(name):
    p=PurePosixPath(name);return not p.is_absolute() and '..' not in p.parts and str(p)==name
def publish(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
def tar_bind(name,expected):
    with tarfile.open(A/name) as archive:
        members=archive.getmembers();need(len(members)==len({m.name for m in members})==len(expected) and {m.name for m in members}==set(expected),name+' domain')
        for m in members:
            need(m.isfile() and safe(m.name),name+' unsafe member');row=expected[m.name];data=archive.extractfile(m).read()
            need(len(data)==row['bytes'] and sha(data)==row['sha256'] and bool(m.mode&0o111)==row.get('executable',row.get('mode')=='100755'),name+':'+m.name)
def elf_geometry(data):
    need(data[:7]==b'\x7fELF\x02\x01\x01' and len(data)>=64,'ELF64 LE header')
    header=struct.unpack_from('<16sHHIQQQIHHHHHH',data);off,width,count,names_index=header[6],header[11],header[12],header[13]
    need(header[1]==3 and header[2]==263 and width==64 and 0<names_index<count and off+width*count<=len(data),'SBF section table')
    rows=[struct.unpack_from('<IIQQQQIIQQ',data,off+i*width) for i in range(count)]
    def payload(row):
        need(row[4]+row[5]<=len(data),'ELF file section bounds');return data[row[4]:row[4]+row[5]]
    strings=payload(rows[names_index]);sections={};names=[]
    for row in rows:
        need(row[0]<len(strings),'section name offset');end=strings.find(b'\0',row[0]);need(end>=row[0],'section name terminator');name=strings[row[0]:end].decode();need(name not in sections,'duplicate section')
        sections[name]={'type':row[1],'flags':row[2],'address':row[3],'offset':row[4],'bytes':row[5],'link':row[6],'entryBytes':row[9]};names.append(name)
    symbols=[]
    if '.symtab' in sections:
        table=sections['.symtab'];need(table['entryBytes']==24 and table['bytes']%24==0 and table['link']<count,'symbol table shape');text=payload(rows[table['link']])
        for p in range(table['offset'],table['offset']+table['bytes'],24):
            name,info,other,index,address,size=struct.unpack_from('<IBBHQQ',data,p);end=text.find(b'\0',name);need(0<=name<len(text) and end>=name,'symbol name')
            symbols.append({'name':text[name:end].decode(),'info':info,'other':other,'sectionIndex':index,'address':address,'bytes':size})
    return sections,symbols
def bind_files(paths):
    result={}
    for p in sorted(set(paths),key=str):
        st=p.lstat();data=os.fsencode(os.readlink(p)) if p.is_symlink() else p.read_bytes();need(p.is_symlink() or stat.S_ISREG(st.st_mode),'input type')
        result[str(p)]={'bytes':len(data),'sha256':sha(data),'mode':st.st_mode}
    return result

def admit(release_path,resume):
    need(os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode and sys.flags.optimize==0,'explicit -B and inherited bytecode-off required')
    release=js(release_path);need(release['schema']=='s5-borrowed-selection-actual-release-v1' and release['source']==BASE and release['source_sha256']==SOURCE and release['operational_commit']==OP and release['run']==RUN_ID,'root release scope')
    for key in ('artifact','job'):need(type(release[key]) is int and release[key]>0,'released actual '+key)
    for row in [release['zip'],*release['images'].values()]:need(type(row['bytes']) is int and row['bytes']>0 and re.fullmatch(r'[0-9a-f]{64}',row['sha256'] or ''),'released byte/hash pin')
    need(set(release['images'])=={'unstripped.so','candidate.so'},'released images')
    need(digest(PREP/'FROZEN-MANIFEST.json')=='20d5b0bb28b7bc9955184bd7719482f7c33d7d44f3864db66a67ad2bfbe64b3b','frozen preparation')
    frozen=js(PREP/'FROZEN-MANIFEST.json');prepared=js(PREP/'PREPARATION-RESULT.json')
    for name,row in frozen['files'].items():
        path=PREP/name;need(safe(name) and path.is_file() and not path.is_symlink() and path.stat().st_size==row['bytes'] and digest(path)==row['sha256'],'frozen file '+name)
    download=js(RUN/'DOWNLOAD-VERIFIED.json');zip_raw=(RUN/'raw-artifact.zip').read_bytes()
    need(len(zip_raw)==release['zip']['bytes'] and sha(zip_raw)==release['zip']['sha256'],'actual ZIP root pin')
    api=js(RUN/'ARTIFACT-METADATA.json');listed=[x for x in js(RUN/'artifacts-final.json')['artifacts'] if x['id']==release['artifact']]
    need(len(listed)==1 and listed[0]==api and api['id']==release['artifact'] and api['size_in_bytes']==len(zip_raw) and api['digest']=='sha256:'+sha(zip_raw) and api['expired'] is False,'provider artifact pins')
    members={}
    with zipfile.ZipFile(RUN/'raw-artifact.zip') as archive:
        for m in archive.infolist():
            need(safe(m.filename) and m.filename not in members and not m.is_dir() and not m.flag_bits&1 and ((m.external_attr>>16)&0o170000) in (0,0o100000),'regular safe ZIP domain')
            p=A/m.filename;data=archive.read(m);need(p.is_file() and not p.is_symlink() and p.read_bytes()==data,'ZIP/extracted member '+m.filename);members[m.filename]={'bytes':len(data),'sha256':sha(data)}
    need(len(members)==43 and set(members)=={p.relative_to(A).as_posix() for p in A.rglob('*') if p.is_file() or p.is_symlink()},'normal43 exact membership')
    need(download['artifactId']==release['artifact'] and download['run']==RUN_ID and download['operationalCommit']==OP and download['bytes']==len(zip_raw) and download['sha256']==sha(zip_raw) and download['members']==43 and download['CRC']=='PASS' and type(download['files']) is dict and download['files']==members,'root DOWNLOAD files DICT')
    run=js(RUN/'run-final.json');jobs=js(RUN/'jobs-final.json')['jobs'];steps=js(RUN/'steps-final.json')['steps']
    need(run['id']==RUN_ID and run['head_sha']==OP and run['run_attempt']==1 and run['status']=='completed' and run['conclusion']=='success' and run['event']=='workflow_dispatch' and run['path']=='.github/workflows/qualify-pump-macos-v144.yml','provider run identity')
    need(len(jobs)==1 and jobs[0]['id']==release['job'] and jobs[0]['run_id']==RUN_ID and jobs[0]['conclusion']=='success' and jobs[0]['steps']==steps and all(s['status']=='completed' and s['conclusion']=='success' for s in steps),'provider job/steps')
    pre=js(PREP/'preflight/evidence/PREFLIGHT.json');need(read('PREFLIGHT.json')==dict(pre,preflightOnly=False),'native preflight vs genuine local once-preflight')
    for name in ('program-source-inputs.json','toolchain-source-inputs.json','source-selection.json','compiled-workspace-inputs.json'):
        need(read(name)==js(PREP/'preflight/evidence'/name),'native frozen input '+name)
    source=read('source-inputs.json');program=read('program-source-inputs.json');core=read('toolchain-source-inputs.json');stage=read('compiled-workspace-inputs.json')
    need(source==read('preflight-builder-source-inputs.json')==js(PREP/'EXPECTED-SELECTED-SOURCE.json') and source['sha256']==SOURCE and sha(json.dumps(source['files'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())==SOURCE,'selected source binding')
    need(len(program['files'])==len(source['files'])==263 and len(core['files'])==279 and len(stage)==264 and program['base']==core['base']==BASE,'source/core/stage counts')
    for row in program['files']+core['files']:
        p=ROOT/row['path'];need(safe(row['path']),'physical input path');data=os.fsencode(os.readlink(p)) if row['mode']=='120000' else p.read_bytes()
        need((p.is_symlink() if row['mode']=='120000' else p.is_file() and not p.is_symlink()) and len(data)==row['bytes'] and sha(data)==row['sha256'] and hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['gitBlob'],'physical typed input '+row['path'])
    tar_bind('program-source.tar.gz',{r['path']:r for r in program['files']});tar_bind('compiled-workspace.tar.gz',stage)
    ops=read('operational-inputs.json');expected=[{k:r[k] for k in ('path','mode','bytes','sha256','gitBlob')} for r in prepared['opsFiles']]
    need(ops['checkout']==OP and sorted(ops['files'],key=lambda x:x['path'])==sorted(expected,key=lambda x:x['path']),'actual three OPS vs PREPARATION.opsFiles')
    op_by_path={r['path']:r for r in expected};controller=read('controller-inputs.json')
    need(controller['checkout']==OP and controller['runnerSha256']==op_by_path['reconstruction/pump-main/lanes/current-native-control/pump_current_control.py']['sha256'] and controller['workflowSha256']==op_by_path['.github/workflows/qualify-pump-macos-v144.yml']['sha256'],'actual controller/workflow')
    host=read('host.json');build,result=read('build.json'),read('RESULT.json')
    need(host['base']==BASE and host['machine']=='arm64' and host['platform'].startswith('macOS-26.'),'native host')
    need(build['ok'] is True and build['runtime_valid'] is True and build['stack_warnings']==[] and build['recipe']==controller['recipe']=='identity' and build['triple']==controller['triple']=='sbpf-solana-solana','build/stack/recipe')
    need(build['source_sha256']==source['sha256']==result['builderSourceSha256'] and result['base']==BASE and all(result[k] is True for k in ('sourceUnchanged','registrySourceUnchanged','toolInputsUnchanged','coldTarget')),'native final source guards')
    images={name:digest(A/name) for name in ('unstripped.so','candidate.so')}
    for name,row in release['images'].items():need((A/name).stat().st_size==row['bytes'] and images[name]==row['sha256'],'released actual image '+name)
    need(images['unstripped.so']==build['unstripped_sha256']==result['unstrippedSha256'] and images['candidate.so']==build['candidate_sha256']==result['candidateSha256'],'native image hash chain')
    for first,last in [('registry-source-inputs.json','registry-source-inputs-after.json'),('tool-inputs-before.json','tool-inputs-after.json'),('native-lld-input-before.json','native-lld-input-after.json')]:need(read(first)==read(last),'before/after '+first)
    tools=read('tool-inputs-before.json');cold=read('cold-target-inputs.json');need(cold['base']==BASE and cold['sourceSha256']==SOURCE and cold['targetAbsentBeforeBuild'] is True and cold['dependencyTemplatesAbsent'] is True and cold['toolInputs']==tools,'cold target/template source/tools')
    downloads=read('sdk-downloads.json');need(len(downloads)==2 and {r['version']:r['archiveSha256'] for r in downloads}=={'v1.44':'66e20d135fddd70ff519baf7ff320d762957f9aedf93a50e23756db23ad79351','v1.52':'1727dfb31e833ce777d01e70cb4b3cebd26b376bf09d80527f02457d4cf6fd00'} and all(r['archiveSha256']==r['expectedArchiveSha256'] for r in downloads),'native SDK archive roles')
    for name in ('bootstrap-before.log','bootstrap-after.log'):
        text=(A/name).read_text();need('SDK verified (full,' in text and 'Linux v1.44 sbpf target libraries verified (25 rlibs)' in text,'full native SDK/target declaration '+name)
    inventory=js(ROOT/'reconstruction/toolchain/v1.44-macos-inventory.json')['entries'];native=read('native-lld-input-before.json');need(all(native[k]==inventory[native['sdkRelativePath']][k] for k in ('sha256','bytes','mode')),'native LLD published inventory')
    for path,value in tools.items():
        if '/v1.44/platform-tools/' in path:need(inventory[path.split('/v1.44/platform-tools/',1)[1]]['sha256']==value,'native SDK tool inventory')
        elif '/hybrid144/' in path:need(inventory[path.split('/hybrid144/',1)[1]]['sha256']==value,'hybrid SDK tool inventory')
        else:need(path.endswith('/v1.52/platform-tools/llvm/bin/llvm-objdump'),'analysis-only tool role')
    fingerprints=read('cargo-fingerprints.json');need(len(fingerprints)==2 and all(x['rustflags']==['-Zremap-cwd-prefix='] for x in fingerprints.values()),'fresh target flags')
    log=(A/'build.log').read_text()
    for package in ('pump-recovered','pump-token-ext'):need(re.search(r'(?m)^\s*Compiling '+package+r' v',log),'fresh local crate '+package)
    commands=[json.loads(line) for line in (A/'commands.jsonl').read_text().splitlines()];need([r['name'] for r in commands]==['bootstrap-before','fetch-locked','cold-build','bootstrap-after','score'] and all(r['returncode']==0 for r in commands),'native five-command chain')
    ref=js(PREP/'REFERENCE-COPY-ADMISSION.json');need(ref['base']==REFERENCE_BASE and ref['run']==41210896548 and ref['artifactId']==13045424986 and len(ref['files'])==43,'exact actualD421 reference role')
    need(set(ref['files'])=={p.relative_to(REFERENCE).as_posix() for p in REFERENCE.rglob('*') if p.is_file() or p.is_symlink()},'reference43 domain')
    for name,row in ref['files'].items():
        p=REFERENCE/name;need(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and digest(p)==row['sha256'],'reference member '+name)
    reference=js(REFERENCE/'score.json');need(len(reference['windows'])==reference['summary']['total']==1035,'reference full1035 census')

    # Native43 and the root's independently admitted fresh Ebe score are separate
    # byte sets. Their complete reference rows must agree before the sole CLI.
    reference_fresh_path=PREP/'REFERENCE-ROOT-OFFICIAL-SCORE.json';reference_fresh=js(reference_fresh_path)
    need(digest(reference_fresh_path)=='26c8b3fa4dc13372474076b13ae68a62b04446ccb4a275bafb4d66a8b3d5f008' and reference_fresh['windows']==reference['windows'] and reference_fresh['summary']['total']==1035 and reference_fresh['summary']['candidate_sha256']==reference['summary']['candidate_sha256'],'actual D421 fresh official/full43 reference row binding')
    reference_root_path=PREP/'REFERENCE-ROOT-ADMISSION.json';reference_root=js(reference_root_path)
    need(digest(reference_root_path)=='cdd4389fe35f55d994b25d708b576a66a34c4a5e6700f4e7b124bc4a433ec105' and reference_root['base']==REFERENCE_BASE and reference_root['run']==41210896548 and reference_root['images']['unstripped.so']==reference['summary']['candidate_sha256'],'actual D421 root qualification/image role')
    reference_metric_path=PREP/'REFERENCE-TARGET-METRIC.json'
    need(digest(reference_metric_path)=='51e7f8d4fe871d481e235f3d5d7901a3055b81835697b0df6a5d4b5d72680e1b','sealed D421 M2248 reference bytes only; no metric calculation')
    unstripped=(A/'unstripped.so').read_bytes();stripped=(A/'candidate.so').read_bytes();sections,symbols=elf_geometry(unstripped);stripped_sections,_=elf_geometry(stripped)
    for name,row in stripped_sections.items():
        if row['flags']&2:
            need(name in sections,'missing allocated section');other=sections[name];need(row['address']==other['address'] and row['bytes']==other['bytes'] and stripped[row['offset']:row['offset']+row['bytes']]==unstripped[other['offset']:other['offset']+other['bytes']],'allocated stripped/unstripped '+name)
    cto=[s for s in symbols if s['info']&15==2 and re.fullmatch(r'_ZN14pump_recovered9admin_cto7execute17h[0-9a-f]{16}E',s['name']) and s['bytes']>0];need(len(cto)==1,'one actual CTO function symbol');cto=cto[0];text=sections['.text'];start=cto['address']-text['address'];need(start>=0 and cto['bytes']%8==0 and start+cto['bytes']<=text['bytes'],'actual CTO section extent');pos=text['offset']+start;cto['bodySha256']=sha(unstripped[pos:pos+cto['bytes']])
    # Exactly one official child. The immutable binding excludes this reader so
    # a reviewed parser-only correction can resume existing JSON without rescoring.
    paths=[release_path,PREP/'FROZEN-MANIFEST.json',PREP/'PREPARATION-RESULT.json',RUN/'raw-artifact.zip',*[A/n for n in members],*[REFERENCE/n for n in ref['files']],reference_fresh_path,reference_root_path,reference_metric_path,*[ROOT/r['path'] for r in program['files']+core['files']],Path(sys.executable).resolve()]
    binding=bind_files(paths);argv=[sys.executable,'-B',str(ROOT/'reconstruction/harness/score.py'),str(A/'unstripped.so'),'--baseline',str(REFERENCE/'score.json'),'--json',str(SCORE/'score.json')]
    score_env={'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':'/dev/shm'};marker=SCORE/'SCORE-STARTED.json';process_path=SCORE/'PROCESS.json';full_json=SCORE/'score.json'
    OUT.mkdir(parents=True,exist_ok=True);SCORE.mkdir(exist_ok=True)
    if marker.exists():
        need(resume,'score already started; use --resume, never launch again');started=js(marker);need(started['argv']==argv and started['inputBindings']==binding and started['selectedEnvironment']==score_env,'existing score invocation input/argv drift')
        need(process_path.is_file() and full_json.is_file(),'started score has no completed process/JSON; retain and stop without retry')
        process=js(process_path);need(process['exitCode']==0,'existing scorer failed; no automatic rerun')
        for name in ('stdout','stderr','score.json'):need(process['files'][name]=={'bytes':(SCORE/name).stat().st_size,'sha256':digest(SCORE/name)},'saved score output drift '+name)
    else:
        need(not resume,'--resume cannot start a scorer');need(not any((SCORE/n).exists() for n in ('stdout','stderr','score.json','PROCESS.json')),'unowned score outputs')
        publish(marker,{'source':BASE,'operationalCommit':OP,'run':RUN_ID,'argv':argv,'cwd':str(ROOT),'utc':now(),'selectedEnvironment':score_env,'inputBindings':binding,'admissionReaderSha256':digest(Path(__file__)),'scorerLaunchesPermitted':1})
        env=dict(os.environ,**score_env);env.pop('PYTHONOPTIMIZE',None);env.pop('PYTHONPATH',None);clock=time.monotonic();begin=now()
        with (SCORE/'stdout').open('xb') as out,(SCORE/'stderr').open('xb') as err:
            child=subprocess.Popen(argv,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err);rc=child.wait()
        result_files={name:{'bytes':(SCORE/name).stat().st_size,'sha256':digest(SCORE/name)} for name in ('stdout','stderr','score.json') if (SCORE/name).is_file()}
        publish(process_path,{'argv':argv,'cwd':str(ROOT),'pid':child.pid,'startUtc':begin,'endUtc':now(),'elapsedSeconds':time.monotonic()-clock,'exitCode':rc,'files':result_files})
        need(rc==0 and full_json.is_file(),'official scorer failed/missing JSON; raw outputs retained, never rerun')
    need(bind_files(paths)==binding,'score inputs changed during/after invocation')
    fresh=js(full_json);saved=read('score.json');windows=fresh['windows'];summary=fresh['summary'];need(len(windows)==summary['total']==1035 and windows==saved['windows'] and set(windows)==set(reference['windows']),'all1035 fresh rows equal native saved census')
    need(summary['candidate_sha256']==images['unstripped.so']==saved['summary']['candidate_sha256'] and saved['summary']==result['summary'],'exact independently scored/native image and summary')
    need(all(type(x['raw']) is bool and type(x['normalized']) is bool for x in windows.values()) and summary['normalized']==sum(x['normalized'] for x in windows.values()) and summary['raw']==sum(x['raw'] for x in windows.values()) and summary['matched_text_bytes']==sum(x['bytes'] for x in windows.values() if x['normalized']),'fresh row arithmetic')
    changes={k:{'reference':reference['windows'][k],'candidate':v} for k,v in windows.items() if v!=reference['windows'][k]};losses={};gained={}
    for kind,prefix in [('normalized',''),('raw','raw_')]:
        gains=[hex(int(k)) for k in sorted(windows,key=int) if windows[k][kind] and not reference['windows'][k][kind]];lost=[hex(int(k)) for k in sorted(windows,key=int) if not windows[k][kind] and reference['windows'][k][kind]]
        need(summary[prefix+'gains']==gains and summary[prefix+'losses']==lost,'actualD421 '+kind+' gains/losses');losses[kind]=lost;gained[kind]=gains
    no_loss=not losses['normalized'] and not losses['raw'];comparison={'referenceBase':REFERENCE_BASE,'referenceRun':41210896548,'referenceArtifactId':13045424986,'fullRowsCompared':1035,'allRowsEqual':not changes,'changedRows':changes,'noNormalizedLosses':not losses['normalized'],'noRawLosses':not losses['raw'],'normalizedLossCount':len(losses['normalized']),'rawLossCount':len(losses['raw']),'normalizedGains':gained['normalized'],'rawGains':gained['raw'],'normalizedLosses':losses['normalized'],'rawLosses':losses['raw'],'normalizedGainCount':len(gained['normalized']),'rawGainCount':len(gained['raw']),'referenceScoreJson':str(REFERENCE/'score.json'),'referenceScoreJsonSha256':digest(REFERENCE/'score.json'),'referenceFreshOfficialScoreJson':str(reference_fresh_path),'referenceFreshOfficialScoreJsonSha256':digest(reference_fresh_path),'referenceFullRowsAgree':True,'freshSummary':summary}
    report={'base':BASE,'operationalCommit':OP,'run':RUN_ID,'sourceSha256':SOURCE,'sourceFiles':len(source['files']),'images':images,'normalized':summary['normalized'],'raw':summary['raw'],'total':len(windows),'unmatched':[hex(int(k)) for k,v in windows.items() if not v['normalized']],'sourceAndArchiveAdmission':'PASS','independentOfficialScorer':'PASS','nativeNoLossConclusion':'PASS' if no_loss else 'FAIL','sourceAndNativeProvenanceConclusion':'PASS','membershipQualification':'PASS_NO_LOSS' if no_loss else 'REJECTED_RAW_OR_NORMALIZED_LOSS','sourceUsefulness':'CANDIDATE_LOSS_GATE_BEFORE_METRIC_AND_RUNTIME','experiment':'ONE_BORROWED_SELECTION_S5_VS_ADMITTED_D421','comparison':comparison,'CTO':cto,'sectionGeometry':sections,'officialScore':{'argv':argv,'json':str(full_json),'jsonSha256':digest(full_json),'nativeSavedJsonSha256':digest(A/'score.json'),'processReceiptSha256':digest(process_path),'markerSha256':digest(marker)},'limits':'One frozen borrowed selected-key S5 source diagnostic with one independent full official score against exact D42143 reference rows, separately bound to fresh D421 score26c8. All current-control counts, gains/losses, changed rows and CTO extent are actual-derived; provenance PASS is separate from membership qualification and source usefulness. Full1035 fresh/native scores and comparison remain retained before rejection. No target similarity/M gain, runtime, acceptance or whole-original claim from this admission. Native SDK/registry/private linker-copy identities are recorded runner guards, not locally reinstalled/rehashed. Root secondary reader will separately check full native link-map/provenance; no independent-agent review is claimed. No compiler/SDK/VM/native retry or later-main claim.'}
    if ADMISSION.exists():need(resume and js(ADMISSION)==report,'existing admission differs; preserve original instead of overwrite')
    else:publish(ADMISSION,report)
    need(no_loss,'S5 borrowed-key candidate has raw/normalized losses against actualD421; full score/changed rows/gains/losses retained, provenance qualification remains separate')
    print(json.dumps({'status':'PASS','base':BASE,'operationalCommit':OP,'run':RUN_ID,'images':images,'normalized':report['normalized'],'raw':report['raw'],'total':1035,'changedRows':len(changes),'admissionSha256':digest(ADMISSION),'scoreJsonSha256':digest(full_json),'CTO':cto}))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--release',type=Path,required=True);parser.add_argument('--resume',action='store_true');args=parser.parse_args()
    try:admit(args.release.resolve(),args.resume)
    except BaseException as error:
        OUT.mkdir(parents=True,exist_ok=True)
        for number in range(1,1000):
            path=OUT/('ATTEMPT-%03d.json'%number)
            try:publish(path,{'status':'FAILED_ADMISSION_PRESERVED','type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc(),'scoreStarted':(SCORE/'SCORE-STARTED.json').exists(),'existingScoreJsonPreserved':(SCORE/'score.json').exists(),'resumeOnlyNoRescore':True});break
            except FileExistsError:continue
        raise
