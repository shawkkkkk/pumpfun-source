"""Single root-released S5 borrowed-key native prefix inspection; no tail decode."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import struct
import sys
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
GO = ROOT / "work/root/CAUSAL-PREFIX-GO.json"
GO_SHA = "6c28f6a80b36d89be48601e274e07c4247ff706264a6dda9956e4d96ce54f338"
PLAN = HERE.parent / "MANIFEST.json"
PLAN_SHA = "05c86762b7e7e2af7c1cfa6ef5b7abe39ef927f0b941dc60962605196b4530e7"
REVIEW = ROOT / "work/secondary-admission-reader/actual-review/REVIEW.json"
ADMISSION = ROOT / "work/root/CURRENT-ELF-ADMISSION.json"
SOURCE = ROOT / "programs/pump/src/creator/admin_cto.rs"
ELF = ROOT / "work/native-run/artifact/unstripped.so"
PARSER = Path("/dev/shm/pump-cto-option-c1/work/carrier/native_compare.py")
PARSER_SHA = "2033142ac919d226a4539cc0f25b80066428794d198263dd0a73919c71af81e9"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def stamp():
    return datetime.now(timezone.utc).isoformat()


def record(path):
    st = path.stat()
    return {"path": str(path), "bytes": st.st_size, "mtimeNs": st.st_mtime_ns,
            "sha256": digest(path)}


def write(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2) + "\n")


def main():
    assert not (HERE / "STARTED.json").exists(), "One released inspection already started"
    assert sys.dont_write_bytecode and os.environ.get("PYTHONDONTWRITEBYTECODE") == "1"
    assert digest(GO) == GO_SHA
    assert digest(PLAN) == PLAN_SHA
    assert digest(PARSER) == PARSER_SHA
    go = json.loads(GO.read_text())
    plan = json.loads(PLAN.read_text())
    assert go["rootGO"] is True and go["source"] == plan["source"]["commit"]
    assert digest(SOURCE) == plan["source"]["sha256"]
    assert digest(REVIEW) == go["actualRootSecondary39ReviewSha256"]
    assert digest(ADMISSION) == go["rootAdmissionSha256"]
    review = json.loads(REVIEW.read_text())
    assert len(review["checks"]) == 39 and all(c["pass"] for c in review["checks"])
    assert review["base"] == go["source"] and review["run"] == go["run"]
    before = {"utc": stamp(), "pid": os.getpid(), "argv": sys.argv,
              "python": sys.executable, "readerSha256": digest(Path(__file__)),
              "noBytecode": True,
              "metadataInputs": [record(p) for p in (GO, PLAN, REVIEW, ADMISSION, SOURCE)],
              "elf": {"path": str(ELF), "bytes": ELF.stat().st_size,
                      "mtimeNs": ELF.stat().st_mtime_ns,
                      "expectedSha256": go["unstrippedSha256"]}}
    write("BEFORE.json", before)
    write("STARTED.json", {"pid": os.getpid(), "utc": before["utc"],
                            "goSha256": GO_SHA, "readerSha256": before["readerSha256"],
                            "nativeInspectionExecutions": 1})
    spec = importlib.util.spec_from_file_location("owned_native_compare", PARSER)
    parser = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(parser)
    blob, section, symbols = parser.elf(ELF, go["unstrippedSha256"])
    candidates = [s for s in symbols if re.search(r"admin_cto7execute17h[0-9a-f]+E$", s["name"])]
    assert len(candidates) == 1, "Actual execute symbol is ambiguous or absent"
    execute = candidates[0]
    assert execute["address"] == go["actualCTO"]["VA"]
    assert execute["bytes"] == go["actualCTO"]["bytes"]
    body_start = section[4] + execute["address"] - section[3]
    by_address = {}
    for s in symbols:
        by_address.setdefault(s["address"], []).append(s)
    p, end, prepare = 0, None, None
    while p < execute["bytes"]:
        op, reg, disp, imm = struct.unpack_from("<BBhi", blob, body_start + p)
        width = 16 if op == 0x18 else 8
        assert p + width <= execute["bytes"], "Truncated logical instruction"
        if op == 0x85 and reg >> 4 == 1 and imm != -1:
            target = execute["address"] + p + 8 + imm * 8
            names = by_address.get(target, [])
            matched = [s for s in names if "prepare_bonding_curve" in s["name"]]
            if matched:
                assert len(matched) == 1
                end, prepare = p + width, {"offset": p, "target": matched[0]}
                break
        p += width
    assert end is not None, "No named prepare boundary in actual execute extent"
    prefix = blob[body_start:body_start + end]
    rows = parser.decode(prefix, execute["address"], symbols)
    assert rows[-1]["offset"] == prepare["offset"]
    by_offset = {r["offset"]: r for r in rows}
    successors, predecessors = {}, {p: [] for p in by_offset}
    external = []
    for r in rows:
        p, nxt = r["offset"], r["offset"] + r["bytes"]
        if r["opcode"] == 0x95:
            edges = []
        elif "jump" in r:
            edges = [r["jump"]] + ([nxt] if r["opcode"] & 0xF0 else [])
        else:
            edges = [nxt]
        successors[p] = [q for q in edges if q in by_offset]
        for q in successors[p]:
            predecessors[q].append(p)
        external.extend({"from": p, "to": q, "reason": "outside released prefix"}
                        for q in edges if q not in by_offset)
    outlines = {name: [s for s in symbols if "admin_cto" in s["name"] and name in s["name"]]
                for name in ("validate", "sweep")}
    outline_calls = [r for r in rows if r.get("callName") and
                     "admin_cto" in r["callName"] and
                     any(name in r["callName"] for name in ("validate", "sweep"))]
    result = {"status": "STOP_OUTLINED_MECHANISM_BOUNDARY" if outline_calls else "PREFIX_CAPTURE_PASS",
              "source": plan["source"], "admission": {"GO": GO_SHA, "review": digest(REVIEW), "root": digest(ADMISSION)},
              "input": {"path": str(ELF), "sha256": go["unstrippedSha256"]},
              "execute": execute, "prepare": prepare,
              "prefix": {"bytes": len(prefix), "logicalInstructions": len(rows),
                         "sha256": hashlib.sha256(prefix).hexdigest()},
              "scopedOutlineSymbols": outlines, "scopedOutlineCallsInPrefix": outline_calls,
              "rows": rows, "successors": successors, "predecessors": predecessors,
              "externalEdges": external,
              "limits": ["Native decoding stops at actual named prepare call; no fixed Ebe offsets or body size.",
                         "Relevant outlined calls stop mechanism attribution; no callee body is decoded.",
                         "No original ELF, tail, CPI/error constructor semantics, scorer, metric, compiler, or VM analysis."]}
    write("S5-PREFIX.json", result)
    after = {"utc": stamp(), "pid": os.getpid(),
             "metadataInputs": [record(p) for p in (GO, PLAN, REVIEW, ADMISSION, SOURCE)],
             "elf": record(ELF), "prefixOutput": record(HERE / "S5-PREFIX.json"),
             "nativeDecodeExecutions": 1, "elfIntegrityReadPasses": 2}
    assert after["metadataInputs"] == before["metadataInputs"]
    assert after["elf"]["sha256"] == go["unstrippedSha256"]
    assert after["elf"]["bytes"] == before["elf"]["bytes"]
    assert after["elf"]["mtimeNs"] == before["elf"]["mtimeNs"]
    write("AFTER.json", after)
    write("EXECUTION.json", {"status": result["status"], "pid": os.getpid(),
                             "readerSha256": before["readerSha256"],
                             "beforeSha256": digest(HERE / "BEFORE.json"),
                             "afterSha256": digest(HERE / "AFTER.json"),
                             "prefixOutputSha256": digest(HERE / "S5-PREFIX.json"),
                             "actualExecute": execute, "actualPrepare": prepare,
                             "prefix": result["prefix"], "nativeInspectionExecutions": 1,
                             "scopedOutlineCalls": outline_calls})
    print(json.dumps({"status": result["status"], "pid": os.getpid(),
                      "execute": execute, "prepare": prepare, "prefix": result["prefix"],
                      "scopedOutlineSymbols": outlines, "scopedOutlineCalls": outline_calls}, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        write("FAILED.json", {"status": "PRESERVED_FAILURE_NO_AUTO_RETRY", "pid": os.getpid(),
                              "utc": stamp(), "errorType": type(exc).__name__, "error": str(exc),
                              "startedMarkerExists": (HERE / "STARTED.json").exists()})
        raise
