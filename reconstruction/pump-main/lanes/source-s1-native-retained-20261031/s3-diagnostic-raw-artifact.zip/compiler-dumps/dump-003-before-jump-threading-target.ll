define hidden { i64, ptr } @_ZN14pump_recovered9admin_cto7execute17h3bd6d7f34f2e30d7E(ptr noalias nocapture noundef readonly align 8 dereferenceable(48) %ctx, i8 noundef %0, i64 noundef %1, i64 %2, ptr noalias nocapture noundef readonly align 1 dereferenceable(33) %new) unnamed_addr #1 {
start:
  %_11.i288 = alloca [0 x i8], align 1
  %formatter.i289 = alloca [64 x i8], align 8
  %buf.i290 = alloca [24 x i8], align 8
  %formatter.i.i105 = alloca [64 x i8], align 8
  %buf.i.i106 = alloca [24 x i8], align 8
  %_168.i = alloca [288 x i8], align 8
  %_166.i = alloca [376 x i8], align 8
  %_153.i = alloca [160 x i8], align 8
  %_147.i107 = alloca [16 x i8], align 8
  %_141.i = alloca [16 x i8], align 8
  %_117.i = alloca [32 x i8], align 8
  %_116.sroa.5.i = alloca [24 x i8], align 8
  %rent.i = alloca [24 x i8], align 8
  %_113.i = alloca [1 x i8], align 1
  %_108.i = alloca [48 x i8], align 8
  %old.i = alloca [32 x i8], align 1
  %vsigner.i = alloca [16 x i8], align 8
  %_64.sroa.0.sroa.16.sroa.11.i = alloca [5 x i8], align 1
  %_64.sroa.0.sroa.17.sroa.11.i = alloca [5 x i8], align 1
  %_64.sroa.18.i = alloca [5 x i8], align 1
  %_64.sroa.19.sroa.11.i = alloca [5 x i8], align 1
  %_64.sroa.20.sroa.11.i = alloca [5 x i8], align 1
  %_64.sroa.21.sroa.11.i = alloca [5 x i8], align 1
  %_64.sroa.22.sroa.11.i = alloca [5 x i8], align 1
  %_56.sroa.11.i = alloca [5 x i8], align 1
  %_55.i = alloca [664 x i8], align 8
  %_43.i = alloca [160 x i8], align 8
  %_38.i108 = alloca [16 x i8], align 8
  %_32.i109 = alloca [16 x i8], align 8
  %_24.i110 = alloca [64 x i8], align 1
  %_18.i111 = alloca [24 x i8], align 8
  %_17.i = alloca [160 x i8], align 8
  %_14.i = alloca [32 x i8], align 1
  %_10.i112 = alloca [32 x i8], align 8
  %_7.i = alloca [33 x i8], align 1
  %dest.i = alloca [32 x i8], align 1
  %_5.i = alloca [32 x i8], align 1
  %formatter.i.i78 = alloca [64 x i8], align 8
  %buf.i.i79 = alloca [24 x i8], align 8
  %_204.i = alloca [24 x i8], align 8
  %_129.i80 = alloca [384 x i8], align 8
  %_127.i81 = alloca [472 x i8], align 8
  %_116.i = alloca [1 x i8], align 1
  %_112.i = alloca [32 x i8], align 8
  %_109.i = alloca [24 x i8], align 8
  %event_infos.i = alloca [48 x i8], align 8
  %_100.i = alloca [24 x i8], align 8
  %ix.i = alloca [80 x i8], align 8
  %_92.i = alloca [48 x i8], align 8
  %ix_data.i = alloca [24 x i8], align 8
  %inner_data.i = alloca [24 x i8], align 8
  %authority_info.i = alloca [48 x i8], align 8
  %_83.i82 = alloca [24 x i8], align 8
  %_81.i = alloca [16 x i8], align 8
  %_75.i = alloca [48 x i8], align 8
  %e.i = alloca [80 x i8], align 8
  %val.sroa.6.i = alloca [24 x i8], align 8
  %_58.i = alloca [48 x i8], align 8
  %event_signers.i = alloca [16 x i8], align 8
  %_46.i = alloca [288 x i8], align 8
  %_44.i83 = alloca [376 x i8], align 8
  %_38.i = alloca [16 x i8], align 8
  %_32.i = alloca [16 x i8], align 8
  %_24.i84 = alloca [32 x i8], align 1
  %_18.i = alloca [16 x i8], align 8
  %_10.i = alloca [24 x i8], align 8
  %_9.i = alloca [160 x i8], align 8
  %formatter.i = alloca [64 x i8], align 8
  %buf.i = alloca [24 x i8], align 8
  %formatter.i60.i = alloca [64 x i8], align 8
  %buf.i61.i = alloca [24 x i8], align 8
  %formatter.i53.i = alloca [64 x i8], align 8
  %buf.i54.i = alloca [24 x i8], align 8
  %formatter.i46.i = alloca [64 x i8], align 8
  %buf.i47.i = alloca [24 x i8], align 8
  %formatter.i39.i = alloca [64 x i8], align 8
  %buf.i40.i = alloca [24 x i8], align 8
  %formatter.i32.i = alloca [64 x i8], align 8
  %buf.i33.i = alloca [24 x i8], align 8
  %formatter.i25.i = alloca [64 x i8], align 8
  %buf.i26.i = alloca [24 x i8], align 8
  %formatter.i.i = alloca [64 x i8], align 8
  %buf.i.i = alloca [24 x i8], align 8
  %_166.sroa.6.i.sroa.6 = alloca [13 x i8], align 1
  %_147.i = alloca [32 x i8], align 1
  %_129.i = alloca [160 x i8], align 8
  %_118.i = alloca [160 x i8], align 8
  %_105.i = alloca [160 x i8], align 8
  %_95.i = alloca [160 x i8], align 8
  %_83.i = alloca [24 x i8], align 8
  %_82.i = alloca [160 x i8], align 8
  %_76.i = alloca [64 x i8], align 1
  %_69.i = alloca [24 x i8], align 8
  %_68.i = alloca [160 x i8], align 8
  %_65.i = alloca [32 x i8], align 1
  %_57.i = alloca [24 x i8], align 8
  %_56.i = alloca [160 x i8], align 8
  %t.i = alloca [32 x i8], align 1
  %_45.i = alloca [24 x i8], align 8
  %_44.i = alloca [160 x i8], align 8
  %target.i = alloca [32 x i8], align 1
  %_35.i = alloca [24 x i8], align 8
  %_34.i = alloca [160 x i8], align 8
  %_25.i = alloca [24 x i8], align 8
  %_24.i = alloca [160 x i8], align 8
  %_13.i = alloca [24 x i8], align 8
  %_12.i = alloca [160 x i8], align 8
  %sharing_update12.sroa.5 = alloca [13 x i8], align 1
  %target11 = alloca [32 x i8], align 1
  %sharing_update.sroa.4 = alloca [13 x i8], align 1
  %target = alloca [32 x i8], align 1
  %_518 = alloca [24 x i8], align 8
  %_516 = alloca [24 x i8], align 8
  %_493 = alloca [24 x i8], align 8
  %_385.sroa.10 = alloca [45 x i8], align 1
  %_377 = alloca [32 x i8], align 1
  %_242 = alloca [1 x i8], align 1
  %_238 = alloca [32 x i8], align 8
  %_235 = alloca [16 x i8], align 8
  %_232 = alloca [48 x i8], align 8
  %_228 = alloca [24 x i8], align 8
  %_225 = alloca [32 x i8], align 1
  %_224.sroa.0 = alloca [32 x i8], align 1
  %_220 = alloca [24 x i8], align 8
  %ix = alloca [80 x i8], align 8
  %_213 = alloca [48 x i8], align 8
  %ix_data = alloca [24 x i8], align 8
  %inner_data = alloca [24 x i8], align 8
  %authority_info = alloca [48 x i8], align 8
  %_204 = alloca [24 x i8], align 8
  %_202 = alloca [16 x i8], align 8
  %_194 = alloca [32 x i8], align 1
  %_193 = alloca [32 x i8], align 1
  %_192 = alloca [32 x i8], align 1
  %_191 = alloca [32 x i8], align 1
  %_189 = alloca [48 x i8], align 8
  %e = alloca [200 x i8], align 8
  %_184 = alloca [48 x i8], align 8
  %_183 = alloca [48 x i8], align 8
  %_182 = alloca [48 x i8], align 8
  %_181 = alloca [48 x i8], align 8
  %_180 = alloca [48 x i8], align 8
  %_179 = alloca [48 x i8], align 8
  %_178 = alloca [48 x i8], align 8
  %_177 = alloca [336 x i8], align 8
  %_176 = alloca [48 x i8], align 8
  %_175 = alloca [424 x i8], align 8
  %old_creator = alloca [32 x i8], align 1
  %_148.sroa.11 = alloca [5 x i8], align 1
  %_133.sroa.11 = alloca [5 x i8], align 1
  %_132.sroa.11 = alloca [5 x i8], align 1
  %_124.sroa.11 = alloca [5 x i8], align 1
  %_116.sroa.11 = alloca [5 x i8], align 1
  %_108.sroa.11 = alloca [5 x i8], align 1
  %_100.sroa.11 = alloca [5 x i8], align 1
  %_99.sroa.11 = alloca [5 x i8], align 1
  %_99.sroa.12.sroa.11 = alloca [5 x i8], align 1
  %_99.sroa.13.sroa.11 = alloca [5 x i8], align 1
  %_99.sroa.14.sroa.11 = alloca [5 x i8], align 1
  %_99.sroa.15.sroa.11 = alloca [5 x i8], align 1
  %_99.sroa.16.sroa.11 = alloca [5 x i8], align 1
  %_99.sroa.17.sroa.11 = alloca [5 x i8], align 1
  %_98.sroa.11 = alloca [5 x i8], align 1
  %_97 = alloca [424 x i8], align 8
  %val4 = alloca [33 x i8], align 1
  %_91 = alloca [1 x i8], align 1
  %_86 = alloca [48 x i8], align 8
  %_83 = alloca [16 x i8], align 8
  %_66.sroa.4 = alloca [71 x i8], align 1
  %_62 = alloca [24 x i8], align 8
  %_60 = alloca [24 x i8], align 8
  %_59 = alloca [160 x i8], align 8
  %_49.sroa.0.sroa.4 = alloca [13 x i8], align 1
  %_49.sroa.0.sroa.5 = alloca [32 x i8], align 1
  %_48.sroa.3.sroa.6 = alloca [13 x i8], align 1
  %_48.sroa.3.sroa.7 = alloca [32 x i8], align 1
  %_42.sroa.44 = alloca [45 x i8], align 8
  %_41.sroa.14 = alloca [45 x i8], align 8
  %sk = alloca [32 x i8], align 1
  %_32 = alloca [32 x i8], align 1
  %st = alloca [48 x i8], align 8
  %_26 = alloca [32 x i8], align 1
  %q = alloca [32 x i8], align 1
  %_22 = alloca [32 x i8], align 1
  %_18 = alloca [32 x i8], align 8
  %hk = alloca [33 x i8], align 1
  %holder_key = alloca [32 x i8], align 1
  %_9 = alloca [32 x i8], align 1
  %mint = alloca [32 x i8], align 1
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %mint)
  %3 = getelementptr inbounds i8, ptr %ctx, i64 8
  %_247 = load ptr, ptr %3, align 8, !nonnull !2, !align !4, !noundef !2
  %4 = getelementptr inbounds i8, ptr %_247, i64 16
  %_366 = load ptr, ptr %4, align 8, !nonnull !2, !align !4, !noundef !2
  %_367 = load ptr, ptr %_366, align 8, !nonnull !2, !align !237, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %mint, ptr noundef nonnull align 1 dereferenceable(32) %_367, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_9)
  %5 = getelementptr inbounds i8, ptr %_247, i64 144
  %_368 = load ptr, ptr %5, align 8, !nonnull !2, !align !4, !noundef !2
  %_369 = load ptr, ptr %_368, align 8, !nonnull !2, !align !237, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_9, ptr noundef nonnull align 1 dereferenceable(32) %_369, i64 32, i1 false)
  %6 = getelementptr inbounds i8, ptr %_247, i64 56
  %_250 = load ptr, ptr %6, align 8, !nonnull !2, !align !4, !noundef !2
  %_371 = getelementptr inbounds i8, ptr %_250, i64 8
  %7 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_9, ptr noundef nonnull dereferenceable(32) %_371, i64 32)
  %8 = icmp eq i32 %7, 0
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_9)
  br i1 %8, label %bb1, label %bb6

bb1:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_368, i64 24
  %_372 = load ptr, ptr %9, align 8, !nonnull !2, !align !237, !noundef !2
  %10 = tail call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_372, ptr noundef nonnull dereferenceable(32) @alloc_2b8d3cdc77614a2bb48bac191de1dcd1, i64 32)
  %11 = icmp eq i32 %10, 0
  br i1 %11, label %bb2, label %bb6

bb2:                                              ; preds = %bb1
  %_12 = tail call noundef zeroext i1 @_ZN19solana_account_info11AccountInfo13data_is_empty17h4cbad3bc61143bcfE(ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_368) #37
  %12 = xor i1 %_12, true
  br label %bb6

bb6:                                              ; preds = %bb1, %start, %bb2
  %shared.sroa.0.0.off0 = phi i1 [ %12, %bb2 ], [ false, %start ], [ false, %bb1 ]
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %holder_key)
  call void @llvm.lifetime.start.p0(i64 33, ptr nonnull %hk)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_18)
  store ptr @alloc_df68464402562fbf659e5577c3ed192b, ptr %_18, align 8
  %13 = getelementptr inbounds i8, ptr %_18, i64 8
  store i64 14, ptr %13, align 8
  %14 = getelementptr inbounds [2 x { ptr, i64 }], ptr %_18, i64 0, i64 1
  store ptr %mint, ptr %14, align 8
  %15 = getelementptr inbounds [2 x { ptr, i64 }], ptr %_18, i64 0, i64 1, i32 1
  store i64 32, ptr %15, align 8
  call void @_ZN13solana_pubkey6Pubkey20find_program_address17h57945082f260e69dE(ptr noalias nocapture noundef nonnull sret([33 x i8]) align 1 dereferenceable(33) %hk, ptr noalias noundef nonnull readonly align 8 %_18, i64 noundef 2, ptr noalias noundef nonnull readonly align 1 dereferenceable(32) @_ZN14pump_recovered2ID17h8e245cf89cf2c06bE) #37
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_18)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_22)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_22, ptr noundef nonnull align 1 dereferenceable(32) %hk, i64 32, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %holder_key, ptr noundef nonnull align 1 dereferenceable(32) %_22, i64 32, i1 false)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_22)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %q)
  %_254 = load ptr, ptr %6, align 8, !nonnull !2, !align !4, !noundef !2
  %16 = getelementptr inbounds i8, ptr %_254, i64 40
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %q, ptr noundef nonnull align 8 dereferenceable(32) %16, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_26)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_377)
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_377, i8 0, i64 32, i1 false), !alias.scope !1792
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_26, ptr noundef nonnull align 1 dereferenceable(32) %_377, i64 32, i1 false)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_377)
  %17 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %q, ptr noundef nonnull dereferenceable(32) %_26, i64 32)
  %18 = icmp eq i32 %17, 0
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_26)
  br i1 %18, label %bb12, label %bb9

bb9:                                              ; preds = %bb6
  %19 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %q, ptr noundef nonnull dereferenceable(32) @alloc_e953c1d75e6a4349f2dca6892c168ab2, i64 32)
  %20 = icmp eq i32 %19, 0
  br i1 %20, label %bb12, label %bb11

bb11:                                             ; preds = %bb9
  %21 = getelementptr inbounds i8, ptr %_247, i64 8
  %_256 = load ptr, ptr %21, align 8, !nonnull !2, !align !4, !noundef !2
  %_13.i.i2.i.i.ptr = getelementptr inbounds i8, ptr %_256, i64 936
  %22 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_13.i.i2.i.i.ptr, ptr noundef nonnull dereferenceable(32) %q, i64 32), !alias.scope !1795, !noalias !1802
  %23 = icmp eq i32 %22, 0
  br label %bb12

bb12:                                             ; preds = %bb11, %bb9, %bb6
  %quote_locked.sroa.0.0.off0 = phi i1 [ true, %bb6 ], [ true, %bb9 ], [ %23, %bb11 ]
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %q)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %st)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_32)
  %24 = getelementptr inbounds i8, ptr %_254, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_32, ptr noundef nonnull align 8 dereferenceable(32) %24, i64 32, i1 false)
  %25 = getelementptr inbounds i8, ptr %_247, i64 8
  %_260 = load ptr, ptr %25, align 8, !nonnull !2, !align !4, !noundef !2
  %26 = getelementptr inbounds i8, ptr %_260, i64 1072
  %_33 = load i64, ptr %26, align 8, !noundef !2
  %27 = getelementptr inbounds i8, ptr %_254, i64 162
  %28 = load i8, ptr %27, align 2, !range !9, !noundef !2
  %29 = getelementptr inbounds i8, ptr %_254, i64 165
  %30 = load i8, ptr %29, align 1, !range !9, !noundef !2
  %31 = getelementptr inbounds i8, ptr %_254, i64 163
  %32 = load i8, ptr %31, align 1, !range !9, !noundef !2
  %33 = getelementptr inbounds i8, ptr %_260, i64 1087
  %34 = load i8, ptr %33, align 1, !range !9, !noundef !2
  %35 = getelementptr inbounds i8, ptr %_260, i64 1086
  %36 = load i8, ptr %35, align 2, !range !9, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %st, ptr noundef nonnull align 1 dereferenceable(32) %_32, i64 32, i1 false)
  %37 = getelementptr inbounds i8, ptr %st, i64 32
  store i64 %_33, ptr %37, align 8
  %38 = getelementptr inbounds i8, ptr %st, i64 40
  store i8 %28, ptr %38, align 8
  %39 = getelementptr inbounds i8, ptr %st, i64 41
  store i8 %30, ptr %39, align 1
  %40 = getelementptr inbounds i8, ptr %st, i64 42
  store i8 %32, ptr %40, align 2
  %41 = getelementptr inbounds i8, ptr %st, i64 43
  %42 = zext i1 %quote_locked.sroa.0.0.off0 to i8
  store i8 %42, ptr %41, align 1
  %43 = getelementptr inbounds i8, ptr %st, i64 44
  store i8 %34, ptr %43, align 4
  %44 = getelementptr inbounds i8, ptr %st, i64 45
  store i8 %36, ptr %44, align 1
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_32)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %sk)
  %_382 = load ptr, ptr %5, align 8, !nonnull !2, !align !4, !noundef !2
  %_383 = load ptr, ptr %_382, align 8, !nonnull !2, !align !237, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %sk, ptr noundef nonnull align 1 dereferenceable(32) %_383, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 45, ptr nonnull %_41.sroa.14)
  call void @llvm.lifetime.start.p0(i64 45, ptr nonnull %_42.sroa.44)
  call void @llvm.experimental.noalias.scope.decl(metadata !1805)
  call void @llvm.experimental.noalias.scope.decl(metadata !1808)
  call void @llvm.lifetime.start.p0(i64 13, ptr nonnull %_166.sroa.6.i.sroa.6)
  %45 = and i8 %0, -3
  %_0.sroa.0.0.off0.i.i.not = icmp eq i8 %45, 0
  %_10.not.i = icmp eq i8 %28, 0
  br i1 %_10.not.i, label %bb6.i, label %bb2.i

bb6.i:                                            ; preds = %bb12
  %_20.not.i = icmp eq i8 %30, 0
  br i1 %_20.not.i, label %bb14.i, label %bb7.i

bb2.i:                                            ; preds = %bb12
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_12.i), !noalias !1810
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_13.i), !noalias !1810
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_13.i, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_eb4f91695bc6f999067c65f428fcc4d8) #37, !noalias !1810
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i288), !noalias !1810
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i.i), !noalias !1814
  store i64 0, ptr %buf.i.i, align 8, !noalias !1814
  %_9.sroa.4.0.buf.sroa_idx.i.i = getelementptr inbounds i8, ptr %buf.i.i, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i.i, align 8, !noalias !1814
  %_9.sroa.5.0.buf.sroa_idx.i.i = getelementptr inbounds i8, ptr %buf.i.i, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i.i, align 8, !noalias !1814
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i.i), !noalias !1814
  %46 = getelementptr inbounds i8, ptr %formatter.i.i, i64 52
  store i32 0, ptr %46, align 4, !noalias !1814
  %47 = getelementptr inbounds i8, ptr %formatter.i.i, i64 48
  store i32 32, ptr %47, align 8, !noalias !1814
  %48 = getelementptr inbounds i8, ptr %formatter.i.i, i64 56
  store i8 3, ptr %48, align 8, !noalias !1814
  store i64 0, ptr %formatter.i.i, align 8, !noalias !1814
  %49 = getelementptr inbounds i8, ptr %formatter.i.i, i64 16
  store i64 0, ptr %49, align 8, !noalias !1814
  %50 = getelementptr inbounds i8, ptr %formatter.i.i, i64 32
  store ptr %buf.i.i, ptr %50, align 8, !noalias !1814
  %51 = getelementptr inbounds i8, ptr %formatter.i.i, i64 40
  store ptr @vtable.4, ptr %51, align 8, !noalias !1814
  %52 = call noundef zeroext i1 @"_ZN64_$LT$pump_recovered..PumpError$u20$as$u20$core..fmt..Display$GT$3fmt17hbf6a90ed7cf777ebE"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_eb4f91695bc6f999067c65f428fcc4d8, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i.i) #37, !noalias !1818
  br i1 %52, label %bb3.i.i76, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit.i"

bb3.i.i76:                                        ; preds = %bb2.i
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i288, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.5, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #38, !noalias !1814
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit.i": ; preds = %bb2.i
  %53 = getelementptr inbounds i8, ptr %_12.i, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %53, ptr noundef nonnull align 8 dereferenceable(24) %buf.i.i, i64 24, i1 false), !noalias !1810
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i.i), !noalias !1814
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i.i), !noalias !1814
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i288), !noalias !1810
  %54 = getelementptr inbounds i8, ptr %_12.i, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %54, ptr noundef nonnull align 8 dereferenceable(24) %_13.i, i64 24, i1 false), !noalias !1810
  %55 = getelementptr inbounds i8, ptr %_12.i, i64 152
  store i32 6088, ptr %55, align 8, !noalias !1810
  store i64 0, ptr %_12.i, align 8, !noalias !1810
  %_16.sroa.4.0._12.sroa_idx.i = getelementptr inbounds i8, ptr %_12.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_16.sroa.4.0._12.sroa_idx.i, align 8, !noalias !1810
  %_16.sroa.4.sroa.4.0._16.sroa.4.0._12.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_12.i, i64 16
  store i64 38, ptr %_16.sroa.4.sroa.4.0._16.sroa.4.0._12.sroa_idx.sroa_idx.i, align 8, !noalias !1810
  %_16.sroa.4.sroa.5.0._16.sroa.4.0._12.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_12.i, i64 24
  store i32 284, ptr %_16.sroa.4.sroa.5.0._16.sroa.4.0._12.sroa_idx.sroa_idx.i, align 8, !noalias !1810
  %56 = getelementptr inbounds i8, ptr %_12.i, i64 80
  store i8 2, ptr %56, align 8, !noalias !1810
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_13.i), !noalias !1810
  %57 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_12.i) #37, !noalias !1810
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_12.i), !noalias !1810
  br label %bb63

bb14.i:                                           ; preds = %bb6.i
  br i1 %_0.sroa.0.0.off0.i.i.not, label %bb23.i, label %bb16.i

bb7.i:                                            ; preds = %bb6.i
  br i1 %_0.sroa.0.0.off0.i.i.not, label %bb10.i, label %bb22.i

bb16.i:                                           ; preds = %bb14.i
  %_32.not.i = icmp eq i8 %34, 0
  br i1 %_32.not.i, label %bb17.i, label %bb22.i

bb17.i:                                           ; preds = %bb16.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_34.i), !noalias !1810
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_35.i), !noalias !1810
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_35.i, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_f94f166953c814e4161e699857179a1e) #37, !noalias !1810
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i288), !noalias !1810
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i26.i), !noalias !1819
  store i64 0, ptr %buf.i26.i, align 8, !noalias !1819
  %_9.sroa.4.0.buf.sroa_idx.i27.i = getelementptr inbounds i8, ptr %buf.i26.i, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i27.i, align 8, !noalias !1819
  %_9.sroa.5.0.buf.sroa_idx.i28.i = getelementptr inbounds i8, ptr %buf.i26.i, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i28.i, align 8, !noalias !1819
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i25.i), !noalias !1819
  %58 = getelementptr inbounds i8, ptr %formatter.i25.i, i64 52
  store i32 0, ptr %58, align 4, !noalias !1819
  %59 = getelementptr inbounds i8, ptr %formatter.i25.i, i64 48
  store i32 32, ptr %59, align 8, !noalias !1819
  %60 = getelementptr inbounds i8, ptr %formatter.i25.i, i64 56
  store i8 3, ptr %60, align 8, !noalias !1819
  store i64 0, ptr %formatter.i25.i, align 8, !noalias !1819
  %61 = getelementptr inbounds i8, ptr %formatter.i25.i, i64 16
  store i64 0, ptr %61, align 8, !noalias !1819
  %62 = getelementptr inbounds i8, ptr %formatter.i25.i, i64 32
  store ptr %buf.i26.i, ptr %62, align 8, !noalias !1819
  %63 = getelementptr inbounds i8, ptr %formatter.i25.i, i64 40
  store ptr @vtable.4, ptr %63, align 8, !noalias !1819
  %64 = call noundef zeroext i1 @"_ZN64_$LT$pump_recovered..PumpError$u20$as$u20$core..fmt..Display$GT$3fmt17hbf6a90ed7cf777ebE"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_f94f166953c814e4161e699857179a1e, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i25.i) #37, !noalias !1823
  br i1 %64, label %bb3.i29.i, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit30.i"

bb3.i29.i:                                        ; preds = %bb17.i
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i288, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.5, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #38, !noalias !1819
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit30.i": ; preds = %bb17.i
  %65 = getelementptr inbounds i8, ptr %_34.i, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %65, ptr noundef nonnull align 8 dereferenceable(24) %buf.i26.i, i64 24, i1 false), !noalias !1810
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i25.i), !noalias !1819
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i26.i), !noalias !1819
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i288), !noalias !1810
  %66 = getelementptr inbounds i8, ptr %_34.i, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %66, ptr noundef nonnull align 8 dereferenceable(24) %_35.i, i64 24, i1 false), !noalias !1810
  %67 = getelementptr inbounds i8, ptr %_34.i, i64 152
  store i32 6084, ptr %67, align 8, !noalias !1810
  store i64 0, ptr %_34.i, align 8, !noalias !1810
  %_38.sroa.4.0._34.sroa_idx.i = getelementptr inbounds i8, ptr %_34.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_38.sroa.4.0._34.sroa_idx.i, align 8, !noalias !1810
  %_38.sroa.4.sroa.4.0._38.sroa.4.0._34.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_34.i, i64 16
  store i64 38, ptr %_38.sroa.4.sroa.4.0._38.sroa.4.0._34.sroa_idx.sroa_idx.i, align 8, !noalias !1810
  %_38.sroa.4.sroa.5.0._38.sroa.4.0._34.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_34.i, i64 24
  store i32 296, ptr %_38.sroa.4.sroa.5.0._38.sroa.4.0._34.sroa_idx.sroa_idx.i, align 8, !noalias !1810
  %68 = getelementptr inbounds i8, ptr %_34.i, i64 80
  store i8 2, ptr %68, align 8, !noalias !1810
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_35.i), !noalias !1810
  %69 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_34.i) #37, !noalias !1810
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_34.i), !noalias !1810
  br label %bb63

bb10.i:                                           ; preds = %bb7.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_24.i), !noalias !1810
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_25.i), !noalias !1810
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_25.i, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_8f95cb73e89711d65e95d13598508b19) #37, !noalias !1810
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i288), !noalias !1810
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i33.i), !noalias !1824
  store i64 0, ptr %buf.i33.i, align 8, !noalias !1824
  %_9.sroa.4.0.buf.sroa_idx.i34.i = getelementptr inbounds i8, ptr %buf.i33.i, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i34.i, align 8, !noalias !1824
  %_9.sroa.5.0.buf.sroa_idx.i35.i = getelementptr inbounds i8, ptr %buf.i33.i, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i35.i, align 8, !noalias !1824
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i32.i), !noalias !1824
  %70 = getelementptr inbounds i8, ptr %formatter.i32.i, i64 52
  store i32 0, ptr %70, align 4, !noalias !1824
  %71 = getelementptr inbounds i8, ptr %formatter.i32.i, i64 48
  store i32 32, ptr %71, align 8, !noalias !1824
  %72 = getelementptr inbounds i8, ptr %formatter.i32.i, i64 56
  store i8 3, ptr %72, align 8, !noalias !1824
  store i64 0, ptr %formatter.i32.i, align 8, !noalias !1824
  %73 = getelementptr inbounds i8, ptr %formatter.i32.i, i64 16
  store i64 0, ptr %73, align 8, !noalias !1824
  %74 = getelementptr inbounds i8, ptr %formatter.i32.i, i64 32
  store ptr %buf.i33.i, ptr %74, align 8, !noalias !1824
  %75 = getelementptr inbounds i8, ptr %formatter.i32.i, i64 40
  store ptr @vtable.4, ptr %75, align 8, !noalias !1824
  %76 = call noundef zeroext i1 @"_ZN64_$LT$pump_recovered..PumpError$u20$as$u20$core..fmt..Display$GT$3fmt17hbf6a90ed7cf777ebE"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_8f95cb73e89711d65e95d13598508b19, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i32.i) #37, !noalias !1828
  br i1 %76, label %bb3.i36.i, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit37.i"

bb3.i36.i:                                        ; preds = %bb10.i
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i288, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.5, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #38, !noalias !1824
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit37.i": ; preds = %bb10.i
  %77 = getelementptr inbounds i8, ptr %_24.i, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %77, ptr noundef nonnull align 8 dereferenceable(24) %buf.i33.i, i64 24, i1 false), !noalias !1810
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i32.i), !noalias !1824
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i33.i), !noalias !1824
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i288), !noalias !1810
  %78 = getelementptr inbounds i8, ptr %_24.i, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %78, ptr noundef nonnull align 8 dereferenceable(24) %_25.i, i64 24, i1 false), !noalias !1810
  %79 = getelementptr inbounds i8, ptr %_24.i, i64 152
  store i32 6083, ptr %79, align 8, !noalias !1810
  store i64 0, ptr %_24.i, align 8, !noalias !1810
  %_28.sroa.4.0._24.sroa_idx.i = getelementptr inbounds i8, ptr %_24.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_28.sroa.4.0._24.sroa_idx.i, align 8, !noalias !1810
  %_28.sroa.4.sroa.4.0._28.sroa.4.0._24.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_24.i, i64 16
  store i64 38, ptr %_28.sroa.4.sroa.4.0._28.sroa.4.0._24.sroa_idx.sroa_idx.i, align 8, !noalias !1810
  %_28.sroa.4.sroa.5.0._28.sroa.4.0._24.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_24.i, i64 24
  store i32 289, ptr %_28.sroa.4.sroa.5.0._28.sroa.4.0._24.sroa_idx.sroa_idx.i, align 8, !noalias !1810
  %80 = getelementptr inbounds i8, ptr %_24.i, i64 80
  store i8 2, ptr %80, align 8, !noalias !1810
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_25.i), !noalias !1810
  %81 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_24.i) #37, !noalias !1810
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_24.i), !noalias !1810
  br label %bb63

bb23.i:                                           ; preds = %bb14.i
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %target.i)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %t.i), !noalias !1810
  %82 = load i8, ptr %new, align 1, !range !9, !alias.scope !1805, !noalias !1829, !noundef !2
  %trunc.not.not.i = icmp eq i8 %82, 0
  br i1 %trunc.not.not.i, label %bb27.i, label %bb28.i

bb22.i:                                           ; preds = %bb16.i, %bb7.i
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %target.i)
  %83 = load i8, ptr %new, align 1, !range !9, !alias.scope !1805, !noalias !1829, !noundef !2
  %trunc15.not.not.i = icmp eq i8 %83, 0
  br i1 %trunc15.not.not.i, label %bb47.i, label %bb90.i

bb28.i:                                           ; preds = %bb23.i
  %84 = getelementptr inbounds i8, ptr %new, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %t.i, ptr noundef nonnull align 1 dereferenceable(32) %84, i64 32, i1 false), !noalias !1829
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_65.i), !noalias !1810
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_65.i, i8 0, i64 32, i1 false), !noalias !1810
  %85 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %t.i, ptr noundef nonnull dereferenceable(32) %_65.i, i64 32), !noalias !1810
  %86 = icmp eq i32 %85, 0
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_65.i), !noalias !1810
  br i1 %86, label %bb32.i, label %bb37.i

bb27.i:                                           ; preds = %bb23.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_56.i), !noalias !1810
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_57.i), !noalias !1810
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_57.i, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_1ba5e1e397ae92b788c97e688ac0b362) #37, !noalias !1810
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i288), !noalias !1810
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i40.i), !noalias !1830
  store i64 0, ptr %buf.i40.i, align 8, !noalias !1830
  %_9.sroa.4.0.buf.sroa_idx.i41.i = getelementptr inbounds i8, ptr %buf.i40.i, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i41.i, align 8, !noalias !1830
  %_9.sroa.5.0.buf.sroa_idx.i42.i = getelementptr inbounds i8, ptr %buf.i40.i, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i42.i, align 8, !noalias !1830
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i39.i), !noalias !1830
  %87 = getelementptr inbounds i8, ptr %formatter.i39.i, i64 52
  store i32 0, ptr %87, align 4, !noalias !1830
  %88 = getelementptr inbounds i8, ptr %formatter.i39.i, i64 48
  store i32 32, ptr %88, align 8, !noalias !1830
  %89 = getelementptr inbounds i8, ptr %formatter.i39.i, i64 56
  store i8 3, ptr %89, align 8, !noalias !1830
  store i64 0, ptr %formatter.i39.i, align 8, !noalias !1830
  %90 = getelementptr inbounds i8, ptr %formatter.i39.i, i64 16
  store i64 0, ptr %90, align 8, !noalias !1830
  %91 = getelementptr inbounds i8, ptr %formatter.i39.i, i64 32
  store ptr %buf.i40.i, ptr %91, align 8, !noalias !1830
  %92 = getelementptr inbounds i8, ptr %formatter.i39.i, i64 40
  store ptr @vtable.4, ptr %92, align 8, !noalias !1830
  %93 = call noundef zeroext i1 @"_ZN64_$LT$pump_recovered..PumpError$u20$as$u20$core..fmt..Display$GT$3fmt17hbf6a90ed7cf777ebE"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_1ba5e1e397ae92b788c97e688ac0b362, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i39.i) #37, !noalias !1834
  br i1 %93, label %bb3.i43.i, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit44.i"

bb3.i43.i:                                        ; preds = %bb27.i
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i288, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.5, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #38, !noalias !1830
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit44.i": ; preds = %bb27.i
  %94 = getelementptr inbounds i8, ptr %_56.i, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %94, ptr noundef nonnull align 8 dereferenceable(24) %buf.i40.i, i64 24, i1 false), !noalias !1810
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i39.i), !noalias !1830
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i40.i), !noalias !1830
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i288), !noalias !1810
  %95 = getelementptr inbounds i8, ptr %_56.i, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %95, ptr noundef nonnull align 8 dereferenceable(24) %_57.i, i64 24, i1 false), !noalias !1810
  %96 = getelementptr inbounds i8, ptr %_56.i, i64 152
  store i32 6089, ptr %96, align 8, !noalias !1810
  store i64 0, ptr %_56.i, align 8, !noalias !1810
  %_60.sroa.4.0._56.sroa_idx.i = getelementptr inbounds i8, ptr %_56.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_60.sroa.4.0._56.sroa_idx.i, align 8, !noalias !1810
  %_60.sroa.4.sroa.4.0._60.sroa.4.0._56.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_56.i, i64 16
  store i64 38, ptr %_60.sroa.4.sroa.4.0._60.sroa.4.0._56.sroa_idx.sroa_idx.i, align 8, !noalias !1810
  %_60.sroa.4.sroa.5.0._60.sroa.4.0._56.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_56.i, i64 24
  store i32 306, ptr %_60.sroa.4.sroa.5.0._60.sroa.4.0._56.sroa_idx.sroa_idx.i, align 8, !noalias !1810
  %97 = getelementptr inbounds i8, ptr %_56.i, i64 80
  store i8 2, ptr %97, align 8, !noalias !1810
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_57.i), !noalias !1810
  %98 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_56.i) #37, !noalias !1810
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_56.i), !noalias !1810
  br label %bb83.i

bb37.i:                                           ; preds = %bb28.i
  %99 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %t.i, ptr noundef nonnull dereferenceable(32) %sk, i64 32), !noalias !1835
  %100 = icmp eq i32 %99, 0
  br i1 %100, label %bb39.i, label %bb38.i

bb32.i:                                           ; preds = %bb28.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_68.i), !noalias !1810
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_69.i), !noalias !1810
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_69.i, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_0e3505805f4905816c1bd644811a7869) #37, !noalias !1810
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i288), !noalias !1810
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i47.i), !noalias !1836
  store i64 0, ptr %buf.i47.i, align 8, !noalias !1836
  %_9.sroa.4.0.buf.sroa_idx.i48.i = getelementptr inbounds i8, ptr %buf.i47.i, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i48.i, align 8, !noalias !1836
  %_9.sroa.5.0.buf.sroa_idx.i49.i = getelementptr inbounds i8, ptr %buf.i47.i, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i49.i, align 8, !noalias !1836
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i46.i), !noalias !1836
  %101 = getelementptr inbounds i8, ptr %formatter.i46.i, i64 52
  store i32 0, ptr %101, align 4, !noalias !1836
  %102 = getelementptr inbounds i8, ptr %formatter.i46.i, i64 48
  store i32 32, ptr %102, align 8, !noalias !1836
  %103 = getelementptr inbounds i8, ptr %formatter.i46.i, i64 56
  store i8 3, ptr %103, align 8, !noalias !1836
  store i64 0, ptr %formatter.i46.i, align 8, !noalias !1836
  %104 = getelementptr inbounds i8, ptr %formatter.i46.i, i64 16
  store i64 0, ptr %104, align 8, !noalias !1836
  %105 = getelementptr inbounds i8, ptr %formatter.i46.i, i64 32
  store ptr %buf.i47.i, ptr %105, align 8, !noalias !1836
  %106 = getelementptr inbounds i8, ptr %formatter.i46.i, i64 40
  store ptr @vtable.4, ptr %106, align 8, !noalias !1836
  %107 = call noundef zeroext i1 @"_ZN64_$LT$pump_recovered..PumpError$u20$as$u20$core..fmt..Display$GT$3fmt17hbf6a90ed7cf777ebE"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_0e3505805f4905816c1bd644811a7869, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i46.i) #37, !noalias !1840
  br i1 %107, label %bb3.i50.i, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit51.i"

bb3.i50.i:                                        ; preds = %bb32.i
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i288, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.5, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #38, !noalias !1836
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit51.i": ; preds = %bb32.i
  %108 = getelementptr inbounds i8, ptr %_68.i, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %108, ptr noundef nonnull align 8 dereferenceable(24) %buf.i47.i, i64 24, i1 false), !noalias !1810
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i46.i), !noalias !1836
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i47.i), !noalias !1836
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i288), !noalias !1810
  %109 = getelementptr inbounds i8, ptr %_68.i, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %109, ptr noundef nonnull align 8 dereferenceable(24) %_69.i, i64 24, i1 false), !noalias !1810
  %110 = getelementptr inbounds i8, ptr %_68.i, i64 152
  store i32 6030, ptr %110, align 8, !noalias !1810
  store i64 0, ptr %_68.i, align 8, !noalias !1810
  %_72.sroa.4.0._68.sroa_idx.i = getelementptr inbounds i8, ptr %_68.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_72.sroa.4.0._68.sroa_idx.i, align 8, !noalias !1810
  %_72.sroa.4.sroa.4.0._72.sroa.4.0._68.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_68.i, i64 16
  store i64 38, ptr %_72.sroa.4.sroa.4.0._72.sroa.4.0._68.sroa_idx.sroa_idx.i, align 8, !noalias !1810
  %_72.sroa.4.sroa.5.0._72.sroa.4.0._68.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_68.i, i64 24
  store i32 307, ptr %_72.sroa.4.sroa.5.0._72.sroa.4.0._68.sroa_idx.sroa_idx.i, align 8, !noalias !1810
  %111 = getelementptr inbounds i8, ptr %_68.i, i64 80
  store i8 2, ptr %111, align 8, !noalias !1810
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_69.i), !noalias !1810
  %112 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_68.i) #37, !noalias !1810
  %_67.0.i = extractvalue { i64, ptr } %112, 0
  %_67.1.i = extractvalue { i64, ptr } %112, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_68.i), !noalias !1810
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %_76.i), !noalias !1810
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_76.i, ptr noundef nonnull align 1 dereferenceable(32) %84, i64 32, i1 false), !noalias !1829
  %113 = getelementptr inbounds i8, ptr %_76.i, i64 32
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %113, i8 0, i64 32, i1 false), !noalias !1810
  %114 = call { i64, ptr } @_ZN11anchor_lang5error5Error12with_pubkeys17hca6dbbbe6a9a5da7E(i64 noundef %_67.0.i, ptr noundef %_67.1.i, ptr noalias nocapture noundef nonnull readonly align 1 dereferenceable(64) %_76.i) #37
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %_76.i), !noalias !1810
  br label %bb83.i

bb38.i:                                           ; preds = %bb37.i
  %115 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %t.i, ptr noundef nonnull dereferenceable(32) %holder_key, i64 32), !noalias !1841
  %116 = icmp eq i32 %115, 0
  br i1 %116, label %bb39.i, label %bb43.i

bb39.i:                                           ; preds = %bb38.i, %bb37.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_82.i), !noalias !1810
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_83.i), !noalias !1810
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_83.i, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_861c8964bbad6d9cede9df277e628fe9) #37, !noalias !1810
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i288), !noalias !1810
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i54.i), !noalias !1842
  store i64 0, ptr %buf.i54.i, align 8, !noalias !1842
  %_9.sroa.4.0.buf.sroa_idx.i55.i = getelementptr inbounds i8, ptr %buf.i54.i, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i55.i, align 8, !noalias !1842
  %_9.sroa.5.0.buf.sroa_idx.i56.i = getelementptr inbounds i8, ptr %buf.i54.i, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i56.i, align 8, !noalias !1842
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i53.i), !noalias !1842
  %117 = getelementptr inbounds i8, ptr %formatter.i53.i, i64 52
  store i32 0, ptr %117, align 4, !noalias !1842
  %118 = getelementptr inbounds i8, ptr %formatter.i53.i, i64 48
  store i32 32, ptr %118, align 8, !noalias !1842
  %119 = getelementptr inbounds i8, ptr %formatter.i53.i, i64 56
  store i8 3, ptr %119, align 8, !noalias !1842
  store i64 0, ptr %formatter.i53.i, align 8, !noalias !1842
  %120 = getelementptr inbounds i8, ptr %formatter.i53.i, i64 16
  store i64 0, ptr %120, align 8, !noalias !1842
  %121 = getelementptr inbounds i8, ptr %formatter.i53.i, i64 32
  store ptr %buf.i54.i, ptr %121, align 8, !noalias !1842
  %122 = getelementptr inbounds i8, ptr %formatter.i53.i, i64 40
  store ptr @vtable.4, ptr %122, align 8, !noalias !1842
  %123 = call noundef zeroext i1 @"_ZN64_$LT$pump_recovered..PumpError$u20$as$u20$core..fmt..Display$GT$3fmt17hbf6a90ed7cf777ebE"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_861c8964bbad6d9cede9df277e628fe9, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i53.i) #37, !noalias !1846
  br i1 %123, label %bb3.i57.i, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit58.i"

bb3.i57.i:                                        ; preds = %bb39.i
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i288, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.5, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #38, !noalias !1842
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit58.i": ; preds = %bb39.i
  %124 = getelementptr inbounds i8, ptr %_82.i, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %124, ptr noundef nonnull align 8 dereferenceable(24) %buf.i54.i, i64 24, i1 false), !noalias !1810
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i53.i), !noalias !1842
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i54.i), !noalias !1842
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i288), !noalias !1810
  %125 = getelementptr inbounds i8, ptr %_82.i, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %125, ptr noundef nonnull align 8 dereferenceable(24) %_83.i, i64 24, i1 false), !noalias !1810
  %126 = getelementptr inbounds i8, ptr %_82.i, i64 152
  store i32 6019, ptr %126, align 8, !noalias !1810
  store i64 0, ptr %_82.i, align 8, !noalias !1810
  %_86.sroa.4.0._82.sroa_idx.i = getelementptr inbounds i8, ptr %_82.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_86.sroa.4.0._82.sroa_idx.i, align 8, !noalias !1810
  %_86.sroa.4.sroa.4.0._86.sroa.4.0._82.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_82.i, i64 16
  store i64 38, ptr %_86.sroa.4.sroa.4.0._86.sroa.4.0._82.sroa_idx.sroa_idx.i, align 8, !noalias !1810
  %_86.sroa.4.sroa.5.0._86.sroa.4.0._82.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_82.i, i64 24
  store i32 312, ptr %_86.sroa.4.sroa.5.0._86.sroa.4.0._82.sroa_idx.sroa_idx.i, align 8, !noalias !1810
  %127 = getelementptr inbounds i8, ptr %_82.i, i64 80
  store i8 2, ptr %127, align 8, !noalias !1810
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_83.i), !noalias !1810
  %128 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_82.i) #37, !noalias !1810
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_82.i), !noalias !1810
  br label %bb83.i

bb43.i:                                           ; preds = %bb38.i
  %switch20.i = icmp eq i64 %1, 0
  %extract.t17.i = icmp ne i8 %32, 0
  br i1 %shared.sroa.0.0.off0, label %bb48.i, label %bb48.thread.i

bb48.i:                                           ; preds = %bb43.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %target.i, ptr noundef nonnull align 8 dereferenceable(32) %st, i64 32, i1 false), !noalias !1847
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %t.i), !noalias !1810
  br i1 %switch20.i, label %bb76.i, label %bb50.i

bb48.thread.i:                                    ; preds = %bb43.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %target.i, ptr noundef nonnull align 1 dereferenceable(32) %84, i64 32, i1 false), !noalias !1829
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %t.i), !noalias !1810
  br i1 %switch20.i, label %bb78.i, label %bb50.i

bb47.i:                                           ; preds = %bb22.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %target.i, ptr noundef nonnull align 1 dereferenceable(32) %holder_key, i64 32, i1 false), !noalias !1841
  %switch21.i = icmp eq i64 %1, 0
  br i1 %switch21.i, label %bb73.thread76.i, label %bb108.i

bb73.i:                                           ; preds = %bb65.i
  %129 = load volatile i8, ptr %holder_key, align 1, !alias.scope !1808, !noalias !1841
  br i1 %shared.sroa.0.0.off0, label %bb74.i, label %bb77.i

bb73.thread76.i:                                  ; preds = %bb47.i
  br i1 %shared.sroa.0.0.off0, label %bb64, label %bb77.i

bb50.i:                                           ; preds = %bb48.thread.i, %bb48.i
  br i1 %quote_locked.sroa.0.0.off0, label %bb51.i, label %bb55.i

bb55.i:                                           ; preds = %bb50.i
  %.not84.i = icmp eq i8 %32, 0
  br i1 %.not84.i, label %bb57.i, label %bb56.i

bb51.i:                                           ; preds = %bb108.i, %bb50.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_95.i), !noalias !1810
  %130 = getelementptr inbounds i8, ptr %_95.i, i64 32
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %130, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_e75cefee4bb91125af0ea8444b842ed0) #37, !noalias !1810
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i288)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i290), !noalias !1848
  store i64 0, ptr %buf.i290, align 8, !noalias !1848
  %_9.sroa.4.0.buf.sroa_idx.i291 = getelementptr inbounds i8, ptr %buf.i290, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i291, align 8, !noalias !1848
  %_9.sroa.5.0.buf.sroa_idx.i292 = getelementptr inbounds i8, ptr %buf.i290, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i292, align 8, !noalias !1848
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i289), !noalias !1848
  %131 = getelementptr inbounds i8, ptr %formatter.i289, i64 52
  store i32 0, ptr %131, align 4, !noalias !1848
  %132 = getelementptr inbounds i8, ptr %formatter.i289, i64 48
  store i32 32, ptr %132, align 8, !noalias !1848
  %133 = getelementptr inbounds i8, ptr %formatter.i289, i64 56
  store i8 3, ptr %133, align 8, !noalias !1848
  store i64 0, ptr %formatter.i289, align 8, !noalias !1848
  %134 = getelementptr inbounds i8, ptr %formatter.i289, i64 16
  store i64 0, ptr %134, align 8, !noalias !1848
  %135 = getelementptr inbounds i8, ptr %formatter.i289, i64 32
  store ptr %buf.i290, ptr %135, align 8, !noalias !1848
  %136 = getelementptr inbounds i8, ptr %formatter.i289, i64 40
  store ptr @vtable.4, ptr %136, align 8, !noalias !1848
  %137 = call noundef zeroext i1 @"_ZN64_$LT$pump_recovered..PumpError$u20$as$u20$core..fmt..Display$GT$3fmt17hbf6a90ed7cf777ebE"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_e75cefee4bb91125af0ea8444b842ed0, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i289) #37, !noalias !1852
  br i1 %137, label %bb3.i294, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit295"

bb3.i294:                                         ; preds = %bb51.i
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i288, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.5, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #38, !noalias !1848
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit295": ; preds = %bb51.i
  %138 = getelementptr inbounds i8, ptr %_95.i, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %138, ptr noundef nonnull align 8 dereferenceable(24) %buf.i290, i64 24, i1 false), !noalias !1853
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i289), !noalias !1848
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i290), !noalias !1848
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i288)
  %139 = getelementptr inbounds i8, ptr %_95.i, i64 152
  store i32 6091, ptr %139, align 8, !noalias !1810
  store i64 0, ptr %_95.i, align 8, !noalias !1810
  %_99.sroa.4.0._95.sroa_idx.i = getelementptr inbounds i8, ptr %_95.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_99.sroa.4.0._95.sroa_idx.i, align 8, !noalias !1810
  %_99.sroa.4.sroa.4.0._99.sroa.4.0._95.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_95.i, i64 16
  store i64 38, ptr %_99.sroa.4.sroa.4.0._99.sroa.4.0._95.sroa_idx.sroa_idx.i, align 8, !noalias !1810
  %_99.sroa.4.sroa.5.0._99.sroa.4.0._95.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_95.i, i64 24
  store i32 326, ptr %_99.sroa.4.sroa.5.0._99.sroa.4.0._95.sroa_idx.sroa_idx.i, align 8, !noalias !1810
  %140 = getelementptr inbounds i8, ptr %_95.i, i64 80
  store i8 2, ptr %140, align 8, !noalias !1810
  %141 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_95.i) #37, !noalias !1810
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_95.i), !noalias !1810
  br label %bb84.i

bb57.i:                                           ; preds = %bb108.i, %bb55.i
  %_145.sroa.0.0.copyload90.i = phi i32 [ 1, %bb55.i ], [ 0, %bb108.i ]
  %cashback.sroa.0.1.off0.i = phi i1 [ %extract.t17.i, %bb55.i ], [ false, %bb108.i ]
  %142 = load volatile i8, ptr %holder_key, align 1, !alias.scope !1808, !noalias !1841
  %_116.not.i = icmp eq i8 %36, 0
  br i1 %_116.not.i, label %bb61.i, label %bb65.i

bb56.i:                                           ; preds = %bb55.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_105.i), !noalias !1810
  %143 = getelementptr inbounds i8, ptr %_105.i, i64 32
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %143, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_835bb996f1795bf0338da0490417da62) #37, !noalias !1810
  %144 = getelementptr inbounds i8, ptr %_105.i, i64 56
  call fastcc void @"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %144, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_835bb996f1795bf0338da0490417da62) #37, !noalias !1810
  %145 = getelementptr inbounds i8, ptr %_105.i, i64 152
  store i32 6080, ptr %145, align 8, !noalias !1810
  store i64 0, ptr %_105.i, align 8, !noalias !1810
  %_109.sroa.4.0._105.sroa_idx.i = getelementptr inbounds i8, ptr %_105.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_109.sroa.4.0._105.sroa_idx.i, align 8, !noalias !1810
  %_109.sroa.4.sroa.4.0._109.sroa.4.0._105.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_105.i, i64 16
  store i64 38, ptr %_109.sroa.4.sroa.4.0._109.sroa.4.0._105.sroa_idx.sroa_idx.i, align 8, !noalias !1810
  %_109.sroa.4.sroa.5.0._109.sroa.4.0._105.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_105.i, i64 24
  store i32 330, ptr %_109.sroa.4.sroa.5.0._109.sroa.4.0._105.sroa_idx.sroa_idx.i, align 8, !noalias !1810
  %146 = getelementptr inbounds i8, ptr %_105.i, i64 80
  store i8 2, ptr %146, align 8, !noalias !1810
  %147 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_105.i) #37, !noalias !1810
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_105.i), !noalias !1810
  br label %bb84.i

bb83.i:                                           ; preds = %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit58.i", %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit51.i", %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit44.i"
  %.pn.i = phi { i64, ptr } [ %98, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit44.i" ], [ %114, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit51.i" ], [ %128, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit58.i" ]
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %t.i), !noalias !1810
  br label %bb84.i

bb84.i:                                           ; preds = %bb69.i, %bb61.i, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit65.i", %bb83.i, %bb56.i, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit295"
  %.pn316 = phi { i64, ptr } [ %164, %bb61.i ], [ %170, %bb69.i ], [ %141, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit295" ], [ %159, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit65.i" ], [ %.pn.i, %bb83.i ], [ %147, %bb56.i ]
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %target.i)
  br label %bb63

bb90.i:                                           ; preds = %bb22.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_44.i), !noalias !1810
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_45.i), !noalias !1810
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_45.i, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_b5f839a6bda937f2cae73e49fc88071f) #37, !noalias !1810
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i288), !noalias !1810
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i61.i), !noalias !1854
  store i64 0, ptr %buf.i61.i, align 8, !noalias !1854
  %_9.sroa.4.0.buf.sroa_idx.i62.i = getelementptr inbounds i8, ptr %buf.i61.i, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i62.i, align 8, !noalias !1854
  %_9.sroa.5.0.buf.sroa_idx.i63.i = getelementptr inbounds i8, ptr %buf.i61.i, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i63.i, align 8, !noalias !1854
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i60.i), !noalias !1854
  %148 = getelementptr inbounds i8, ptr %formatter.i60.i, i64 52
  store i32 0, ptr %148, align 4, !noalias !1854
  %149 = getelementptr inbounds i8, ptr %formatter.i60.i, i64 48
  store i32 32, ptr %149, align 8, !noalias !1854
  %150 = getelementptr inbounds i8, ptr %formatter.i60.i, i64 56
  store i8 3, ptr %150, align 8, !noalias !1854
  store i64 0, ptr %formatter.i60.i, align 8, !noalias !1854
  %151 = getelementptr inbounds i8, ptr %formatter.i60.i, i64 16
  store i64 0, ptr %151, align 8, !noalias !1854
  %152 = getelementptr inbounds i8, ptr %formatter.i60.i, i64 32
  store ptr %buf.i61.i, ptr %152, align 8, !noalias !1854
  %153 = getelementptr inbounds i8, ptr %formatter.i60.i, i64 40
  store ptr @vtable.4, ptr %153, align 8, !noalias !1854
  %154 = call noundef zeroext i1 @"_ZN64_$LT$pump_recovered..PumpError$u20$as$u20$core..fmt..Display$GT$3fmt17hbf6a90ed7cf777ebE"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_b5f839a6bda937f2cae73e49fc88071f, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i60.i) #37, !noalias !1858
  br i1 %154, label %bb3.i64.i, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit65.i"

bb3.i64.i:                                        ; preds = %bb90.i
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i288, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.5, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #38, !noalias !1854
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit65.i": ; preds = %bb90.i
  %155 = getelementptr inbounds i8, ptr %_44.i, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %155, ptr noundef nonnull align 8 dereferenceable(24) %buf.i61.i, i64 24, i1 false), !noalias !1810
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i60.i), !noalias !1854
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i61.i), !noalias !1854
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i288), !noalias !1810
  %156 = getelementptr inbounds i8, ptr %_44.i, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %156, ptr noundef nonnull align 8 dereferenceable(24) %_45.i, i64 24, i1 false), !noalias !1810
  %157 = getelementptr inbounds i8, ptr %_44.i, i64 152
  store i32 6090, ptr %157, align 8, !noalias !1810
  store i64 0, ptr %_44.i, align 8, !noalias !1810
  %_48.sroa.4.0._44.sroa_idx.i = getelementptr inbounds i8, ptr %_44.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_48.sroa.4.0._44.sroa_idx.i, align 8, !noalias !1810
  %_48.sroa.4.sroa.4.0._48.sroa.4.0._44.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_44.i, i64 16
  store i64 38, ptr %_48.sroa.4.sroa.4.0._48.sroa.4.0._44.sroa_idx.sroa_idx.i, align 8, !noalias !1810
  %_48.sroa.4.sroa.5.0._48.sroa.4.0._44.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_44.i, i64 24
  store i32 298, ptr %_48.sroa.4.sroa.5.0._48.sroa.4.0._44.sroa_idx.sroa_idx.i, align 8, !noalias !1810
  %158 = getelementptr inbounds i8, ptr %_44.i, i64 80
  store i8 2, ptr %158, align 8, !noalias !1810
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_45.i), !noalias !1810
  %159 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_44.i) #37, !noalias !1810
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_44.i), !noalias !1810
  br label %bb84.i

bb108.i:                                          ; preds = %bb47.i
  br i1 %quote_locked.sroa.0.0.off0, label %bb51.i, label %bb57.i

bb61.i:                                           ; preds = %bb57.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_118.i), !noalias !1810
  %160 = getelementptr inbounds i8, ptr %_118.i, i64 32
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %160, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_01eaaa187d2be542d4425f23ab284310) #37, !noalias !1841
  %161 = getelementptr inbounds i8, ptr %_118.i, i64 56
  call fastcc void @"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %161, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_01eaaa187d2be542d4425f23ab284310) #37, !noalias !1841
  %162 = getelementptr inbounds i8, ptr %_118.i, i64 152
  store i32 6077, ptr %162, align 8, !noalias !1810
  store i64 0, ptr %_118.i, align 8, !noalias !1810
  %_122.sroa.4.0._118.sroa_idx.i = getelementptr inbounds i8, ptr %_118.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_122.sroa.4.0._118.sroa_idx.i, align 8, !noalias !1810
  %_122.sroa.4.sroa.4.0._122.sroa.4.0._118.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_118.i, i64 16
  store i64 38, ptr %_122.sroa.4.sroa.4.0._122.sroa.4.0._118.sroa_idx.sroa_idx.i, align 8, !noalias !1810
  %_122.sroa.4.sroa.5.0._122.sroa.4.0._118.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_118.i, i64 24
  store i32 334, ptr %_122.sroa.4.sroa.5.0._122.sroa.4.0._118.sroa_idx.sroa_idx.i, align 8, !noalias !1810
  %163 = getelementptr inbounds i8, ptr %_118.i, i64 80
  store i8 2, ptr %163, align 8, !noalias !1810
  %164 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_118.i) #37, !noalias !1841
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_118.i), !noalias !1810
  br label %bb84.i

bb65.i:                                           ; preds = %bb57.i
  %165 = add i64 %2, -1
  %or.cond.not.i = icmp ult i64 %165, %_33
  br i1 %or.cond.not.i, label %bb73.i, label %bb69.i

bb69.i:                                           ; preds = %bb65.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_129.i), !noalias !1810
  %166 = getelementptr inbounds i8, ptr %_129.i, i64 32
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %166, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_973adb9e8664e25d4750ddb14e0de56a) #37, !noalias !1841
  %167 = getelementptr inbounds i8, ptr %_129.i, i64 56
  call fastcc void @"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %167, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_973adb9e8664e25d4750ddb14e0de56a) #37, !noalias !1841
  %168 = getelementptr inbounds i8, ptr %_129.i, i64 152
  store i32 6078, ptr %168, align 8, !noalias !1810
  store i64 0, ptr %_129.i, align 8, !noalias !1810
  %_133.sroa.4.0._129.sroa_idx.i = getelementptr inbounds i8, ptr %_129.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_133.sroa.4.0._129.sroa_idx.i, align 8, !noalias !1810
  %_133.sroa.4.sroa.4.0._133.sroa.4.0._129.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_129.i, i64 16
  store i64 38, ptr %_133.sroa.4.sroa.4.0._133.sroa.4.0._129.sroa_idx.sroa_idx.i, align 8, !noalias !1810
  %_133.sroa.4.sroa.5.0._133.sroa.4.0._129.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_129.i, i64 24
  store i32 338, ptr %_133.sroa.4.sroa.5.0._133.sroa.4.0._129.sroa_idx.sroa_idx.i, align 8, !noalias !1810
  %169 = getelementptr inbounds i8, ptr %_129.i, i64 80
  store i8 2, ptr %169, align 8, !noalias !1810
  %170 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_129.i) #37, !noalias !1841
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_129.i), !noalias !1810
  br label %bb84.i

bb77.i:                                           ; preds = %bb73.thread76.i, %bb73.i
  %cashback.sroa.0.0.off069.i = phi i1 [ %cashback.sroa.0.1.off0.i, %bb73.i ], [ false, %bb73.thread76.i ]
  br i1 %_20.not.i, label %bb78.i, label %bb64

bb74.i:                                           ; preds = %bb73.i
  br i1 %_0.sroa.0.0.off0.i.i.not, label %bb76.i, label %bb64

bb78.i:                                           ; preds = %bb77.i, %bb48.thread.i
  %cashback.sroa.0.0.off06973.i = phi i1 [ %cashback.sroa.0.0.off069.i, %bb77.i ], [ %extract.t17.i, %bb48.thread.i ]
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_147.i), !noalias !1810
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_147.i, i8 0, i64 32, i1 false), !noalias !1810
  %171 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %st, ptr noundef nonnull dereferenceable(32) %_147.i, i64 32), !noalias !1847
  %172 = icmp ne i32 %171, 0
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_147.i), !noalias !1810
  br label %bb64

bb76.i:                                           ; preds = %bb74.i, %bb48.i
  %_145.sroa.0.0.copyload.i = phi i32 [ %_145.sroa.0.0.copyload90.i, %bb74.i ], [ 1, %bb48.i ]
  %cashback.sroa.0.0.off07075.i = phi i1 [ %cashback.sroa.0.1.off0.i, %bb74.i ], [ %extract.t17.i, %bb48.i ]
  %_145.sroa.4.0.new.sroa_idx.i = getelementptr inbounds i8, ptr %new, i64 1
  %_166.sroa.6.i.sroa.0.0.copyload = load i24, ptr %_145.sroa.4.0.new.sroa_idx.i, align 1, !noalias !1829
  %_166.sroa.6.i.sroa.4.0._145.sroa.4.0.new.sroa_idx.i.sroa_idx = getelementptr inbounds i8, ptr %new, i64 4
  %_166.sroa.6.i.sroa.4.0.copyload = load i64, ptr %_166.sroa.6.i.sroa.4.0._145.sroa.4.0.new.sroa_idx.i.sroa_idx, align 1, !noalias !1829
  %_166.sroa.6.i.sroa.5.0._145.sroa.4.0.new.sroa_idx.i.sroa_idx = getelementptr inbounds i8, ptr %new, i64 12
  %_166.sroa.6.i.sroa.5.0.copyload = load ptr, ptr %_166.sroa.6.i.sroa.5.0._145.sroa.4.0.new.sroa_idx.i.sroa_idx, align 1, !noalias !1829
  %_166.sroa.6.i.sroa.6.0._145.sroa.4.0.new.sroa_idx.i.sroa_idx = getelementptr inbounds i8, ptr %new, i64 20
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(13) %_166.sroa.6.i.sroa.6, ptr noundef nonnull align 1 dereferenceable(13) %_166.sroa.6.i.sroa.6.0._145.sroa.4.0.new.sroa_idx.i.sroa_idx, i64 13, i1 false), !noalias !1829
  br label %bb64

bb64:                                             ; preds = %bb76.i, %bb78.i, %bb74.i, %bb77.i, %bb73.thread76.i
  %_166.sroa.6.i.sroa.0.0 = phi i24 [ undef, %bb73.thread76.i ], [ undef, %bb78.i ], [ undef, %bb77.i ], [ undef, %bb74.i ], [ %_166.sroa.6.i.sroa.0.0.copyload, %bb76.i ]
  %_166.sroa.6.i.sroa.4.0 = phi i64 [ undef, %bb73.thread76.i ], [ undef, %bb78.i ], [ undef, %bb77.i ], [ undef, %bb74.i ], [ %_166.sroa.6.i.sroa.4.0.copyload, %bb76.i ]
  %_166.sroa.6.i.sroa.5.0 = phi ptr [ undef, %bb73.thread76.i ], [ undef, %bb78.i ], [ undef, %bb77.i ], [ undef, %bb74.i ], [ %_166.sroa.6.i.sroa.5.0.copyload, %bb76.i ]
  %cashback.sroa.0.0.off068.i = phi i1 [ false, %bb73.thread76.i ], [ %cashback.sroa.0.0.off06973.i, %bb78.i ], [ %cashback.sroa.0.0.off069.i, %bb77.i ], [ %cashback.sroa.0.1.off0.i, %bb74.i ], [ %cashback.sroa.0.0.off07075.i, %bb76.i ]
  %_165.sroa.0.0.off0.i = phi i1 [ false, %bb73.thread76.i ], [ %172, %bb78.i ], [ false, %bb77.i ], [ false, %bb74.i ], [ false, %bb76.i ]
  %_166.sroa.0.0.i = phi i32 [ 0, %bb73.thread76.i ], [ 2, %bb78.i ], [ 2, %bb77.i ], [ 0, %bb74.i ], [ %_145.sroa.0.0.copyload.i, %bb76.i ]
  %_167.sroa.0.0.off0.i = phi i1 [ true, %bb73.thread76.i ], [ false, %bb78.i ], [ false, %bb77.i ], [ true, %bb74.i ], [ false, %bb76.i ]
  %_42.sroa.44.37.sroa_idx = getelementptr inbounds i8, ptr %_42.sroa.44, i64 13
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_42.sroa.44.37.sroa_idx, ptr noundef nonnull align 1 dereferenceable(32) %target.i, i64 32, i1 false), !noalias !1859
  %173 = zext i1 %cashback.sroa.0.0.off068.i to i8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(13) %_42.sroa.44, ptr noundef nonnull align 1 dereferenceable(13) %_166.sroa.6.i.sroa.6, i64 13, i1 false), !noalias !1859
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %target.i)
  call void @llvm.lifetime.end.p0(i64 13, ptr nonnull %_166.sroa.6.i.sroa.6)
  call void @llvm.lifetime.start.p0(i64 45, ptr nonnull %_385.sroa.10)
  %_42.sroa.19.sroa.5.0.insert.ext = zext i24 %_166.sroa.6.i.sroa.0.0 to i32
  %_42.sroa.19.sroa.5.0.insert.shift = shl nuw i32 %_42.sroa.19.sroa.5.0.insert.ext, 8
  %_42.sroa.19.sroa.0.0.insert.ext = and i32 %_166.sroa.0.0.i, 255
  %_42.sroa.19.sroa.0.0.insert.insert = or disjoint i32 %_42.sroa.19.sroa.0.0.insert.ext, %_42.sroa.19.sroa.5.0.insert.shift
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(45) %_385.sroa.10, ptr noundef nonnull align 8 dereferenceable(45) %_42.sroa.44, i64 45, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(45) %_41.sroa.14, ptr noundef nonnull align 1 dereferenceable(45) %_385.sroa.10, i64 45, i1 false)
  call void @llvm.lifetime.end.p0(i64 45, ptr nonnull %_385.sroa.10)
  call void @llvm.lifetime.end.p0(i64 45, ptr nonnull %_42.sroa.44)
  %_41.sroa.14.37.sroa_idx = getelementptr inbounds i8, ptr %_41.sroa.14, i64 13
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %target, ptr noundef nonnull align 1 dereferenceable(32) %_41.sroa.14.37.sroa_idx, i64 32, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(13) %sharing_update.sroa.4, ptr noundef nonnull align 8 dereferenceable(13) %_41.sroa.14, i64 13, i1 false)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %sk)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %st)
  call void @llvm.lifetime.end.p0(i64 45, ptr nonnull %_41.sroa.14)
  call void @llvm.lifetime.start.p0(i64 13, ptr nonnull %_48.sroa.3.sroa.6)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_48.sroa.3.sroa.7)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_49.sroa.0.sroa.5, ptr noundef nonnull align 1 dereferenceable(32) %target, i64 32, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(13) %_49.sroa.0.sroa.4, ptr noundef nonnull align 1 dereferenceable(13) %sharing_update.sroa.4, i64 13, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(13) %_48.sroa.3.sroa.6, ptr noundef nonnull align 1 dereferenceable(13) %_49.sroa.0.sroa.4, i64 13, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_48.sroa.3.sroa.7, ptr noundef nonnull align 1 dereferenceable(32) %_49.sroa.0.sroa.5, i64 32, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %target11, ptr noundef nonnull align 1 dereferenceable(32) %_48.sroa.3.sroa.7, i64 32, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(13) %sharing_update12.sroa.5, ptr noundef nonnull align 1 dereferenceable(13) %_48.sroa.3.sroa.6, i64 13, i1 false)
  call void @llvm.lifetime.end.p0(i64 13, ptr nonnull %_48.sroa.3.sroa.6)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_48.sroa.3.sroa.7)
  %_54 = getelementptr inbounds i8, ptr %_247, i64 48
  %174 = call { i64, ptr } @_ZN14pump_recovered6extend21prepare_bonding_curve17hd9c6422a7455e9efE(ptr noalias noundef nonnull readonly align 8 dereferenceable(168) %_254, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %_54, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %_247) #37
  %175 = extractvalue { i64, ptr } %174, 0
  %176 = icmp eq i64 %175, 2
  br i1 %176, label %bb66, label %bb65

bb63:                                             ; preds = %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit30.i", %bb84.i, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit37.i", %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit.i"
  %.pn318 = phi { i64, ptr } [ %57, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit.i" ], [ %81, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit37.i" ], [ %.pn316, %bb84.i ], [ %69, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit30.i" ]
  %_42.sroa.22.1.ph = extractvalue { i64, ptr } %.pn318, 0
  %_42.sroa.33.1.ph = extractvalue { i64, ptr } %.pn318, 1
  call void @llvm.lifetime.end.p0(i64 13, ptr nonnull %_166.sroa.6.i.sroa.6)
  call void @llvm.lifetime.end.p0(i64 45, ptr nonnull %_42.sroa.44)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %sk)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %st)
  call void @llvm.lifetime.end.p0(i64 45, ptr nonnull %_41.sroa.14)
  br label %bb55

bb66:                                             ; preds = %bb64
  %_277 = load ptr, ptr %6, align 8, !nonnull !2, !align !4, !noundef !2
  %177 = getelementptr inbounds i8, ptr %_277, i64 120
  %_57 = load i64, ptr %177, align 8, !noundef !2
  %178 = icmp eq i64 %_57, 0
  br i1 %178, label %bb16, label %bb17

bb65:                                             ; preds = %bb64
  %179 = extractvalue { i64, ptr } %174, 1
  br label %bb55

bb16:                                             ; preds = %bb66
  br i1 %_165.sroa.0.0.off0.i, label %bb21, label %bb23

bb17:                                             ; preds = %bb66
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_59)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_60)
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_60, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_8c4fa5903d7de618e7d31a64bef65c37) #37
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_62)
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i288)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i), !noalias !1860
  store i64 0, ptr %buf.i, align 8, !noalias !1860
  %_9.sroa.4.0.buf.sroa_idx.i = getelementptr inbounds i8, ptr %buf.i, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i, align 8, !noalias !1860
  %_9.sroa.5.0.buf.sroa_idx.i = getelementptr inbounds i8, ptr %buf.i, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i, align 8, !noalias !1860
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i), !noalias !1860
  %180 = getelementptr inbounds i8, ptr %formatter.i, i64 52
  store i32 0, ptr %180, align 4, !noalias !1860
  %181 = getelementptr inbounds i8, ptr %formatter.i, i64 48
  store i32 32, ptr %181, align 8, !noalias !1860
  %182 = getelementptr inbounds i8, ptr %formatter.i, i64 56
  store i8 3, ptr %182, align 8, !noalias !1860
  store i64 0, ptr %formatter.i, align 8, !noalias !1860
  %183 = getelementptr inbounds i8, ptr %formatter.i, i64 16
  store i64 0, ptr %183, align 8, !noalias !1860
  %184 = getelementptr inbounds i8, ptr %formatter.i, i64 32
  store ptr %buf.i, ptr %184, align 8, !noalias !1860
  %185 = getelementptr inbounds i8, ptr %formatter.i, i64 40
  store ptr @vtable.4, ptr %185, align 8, !noalias !1860
  %186 = call noundef zeroext i1 @"_ZN64_$LT$pump_recovered..PumpError$u20$as$u20$core..fmt..Display$GT$3fmt17hbf6a90ed7cf777ebE"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_8c4fa5903d7de618e7d31a64bef65c37, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i) #37, !noalias !1864
  br i1 %186, label %bb3.i, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit"

bb3.i:                                            ; preds = %bb17
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i288, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.5, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #38, !noalias !1860
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit": ; preds = %bb17
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_62, ptr noundef nonnull align 8 dereferenceable(24) %buf.i, i64 24, i1 false), !noalias !1865
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i), !noalias !1860
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i), !noalias !1860
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i288)
  call void @llvm.lifetime.start.p0(i64 71, ptr nonnull %_66.sroa.4)
  %187 = getelementptr inbounds i8, ptr %_59, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %187, ptr noundef nonnull align 8 dereferenceable(24) %_60, i64 24, i1 false)
  %188 = getelementptr inbounds i8, ptr %_59, i64 152
  store i32 6095, ptr %188, align 8
  %189 = getelementptr inbounds i8, ptr %_59, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %189, ptr noundef nonnull align 8 dereferenceable(24) %_62, i64 24, i1 false)
  store i64 0, ptr %_59, align 8
  %_63.sroa.4.0._59.sroa_idx = getelementptr inbounds i8, ptr %_59, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_63.sroa.4.0._59.sroa_idx, align 8
  %_63.sroa.4.sroa.4.0._63.sroa.4.0._59.sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_59, i64 16
  store i64 38, ptr %_63.sroa.4.sroa.4.0._63.sroa.4.0._59.sroa_idx.sroa_idx, align 8
  %_63.sroa.4.sroa.5.0._63.sroa.4.0._59.sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_59, i64 24
  store i32 410, ptr %_63.sroa.4.sroa.5.0._63.sroa.4.0._59.sroa_idx.sroa_idx, align 8
  %190 = getelementptr inbounds i8, ptr %_59, i64 80
  store i8 2, ptr %190, align 8
  %_66.sroa.4.0..sroa_idx = getelementptr inbounds i8, ptr %_59, i64 81
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(71) %_66.sroa.4.0..sroa_idx, ptr noundef nonnull align 1 dereferenceable(71) %_66.sroa.4, i64 71, i1 false)
  call void @llvm.lifetime.end.p0(i64 71, ptr nonnull %_66.sroa.4)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_62)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_60)
  %191 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_59) #37
  %_58.0 = extractvalue { i64, ptr } %191, 0
  %_58.1 = extractvalue { i64, ptr } %191, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_59)
  br label %bb55

bb23:                                             ; preds = %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread, %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit, %bb16
  br i1 %_167.sroa.0.0.off0.i, label %bb70, label %bb75

bb21:                                             ; preds = %bb16
  call void @llvm.experimental.noalias.scope.decl(metadata !1866)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_109.i)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_92.i)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %inner_data.i)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %authority_info.i)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %val.sroa.6.i)
  %192 = getelementptr inbounds i8, ptr %_247, i64 168
  %193 = getelementptr inbounds i8, ptr %_247, i64 210
  %194 = load i8, ptr %193, align 2, !range !9, !noalias !1866, !noundef !2
  %_3.not.i = icmp eq i8 %194, 0
  br i1 %_3.not.i, label %bb2.i85, label %bb1.i

bb2.i85:                                          ; preds = %bb21
  %195 = getelementptr inbounds i8, ptr %_247, i64 192
  %_156.i = load ptr, ptr %195, align 8, !noalias !1866, !nonnull !2, !align !237, !noundef !2
  %196 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_156.i, ptr noundef nonnull dereferenceable(32) @alloc_6ca8591423d98ecbd315de1d1a6fea68, i64 32), !noalias !1866
  %.not.i = icmp eq i32 %196, 0
  br i1 %.not.i, label %bb4.i, label %bb3.i86

bb1.i:                                            ; preds = %bb21
  call void @sol_log_(ptr noundef nonnull @alloc_39e806604c4c413eab24b47c5266f52c, i64 noundef 45) #37, !noalias !1866
  br label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread

bb4.i:                                            ; preds = %bb2.i85
  %197 = getelementptr inbounds i8, ptr %_247, i64 209
  %198 = load i8, ptr %197, align 1, !range !9, !noalias !1866, !noundef !2
  %_7.not.i = icmp eq i8 %198, 0
  br i1 %_7.not.i, label %bb5.i, label %bb9.i

bb3.i86:                                          ; preds = %bb2.i85
  call void @sol_log_(ptr noundef nonnull @alloc_84e4dd413cb0e2cff6ff4abdd65f9f92, i64 noundef 61) #37, !noalias !1866
  br label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread

bb5.i:                                            ; preds = %bb4.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_9.i), !noalias !1866
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_10.i), !noalias !1866
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_10.i, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_ee8d284dcc9255c78333f4d983077741) #37, !noalias !1866
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i288), !noalias !1866
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i.i79), !noalias !1869
  store i64 0, ptr %buf.i.i79, align 8, !noalias !1869
  %_9.sroa.4.0.buf.sroa_idx.i.i100 = getelementptr inbounds i8, ptr %buf.i.i79, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i.i100, align 8, !noalias !1869
  %_9.sroa.5.0.buf.sroa_idx.i.i101 = getelementptr inbounds i8, ptr %buf.i.i79, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i.i101, align 8, !noalias !1869
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i.i78), !noalias !1869
  %199 = getelementptr inbounds i8, ptr %formatter.i.i78, i64 52
  store i32 0, ptr %199, align 4, !noalias !1869
  %200 = getelementptr inbounds i8, ptr %formatter.i.i78, i64 48
  store i32 32, ptr %200, align 8, !noalias !1869
  %201 = getelementptr inbounds i8, ptr %formatter.i.i78, i64 56
  store i8 3, ptr %201, align 8, !noalias !1869
  store i64 0, ptr %formatter.i.i78, align 8, !noalias !1869
  %202 = getelementptr inbounds i8, ptr %formatter.i.i78, i64 16
  store i64 0, ptr %202, align 8, !noalias !1869
  %203 = getelementptr inbounds i8, ptr %formatter.i.i78, i64 32
  store ptr %buf.i.i79, ptr %203, align 8, !noalias !1869
  %204 = getelementptr inbounds i8, ptr %formatter.i.i78, i64 40
  store ptr @vtable.4, ptr %204, align 8, !noalias !1869
  %205 = call noundef zeroext i1 @"_ZN64_$LT$pump_recovered..PumpError$u20$as$u20$core..fmt..Display$GT$3fmt17hbf6a90ed7cf777ebE"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_ee8d284dcc9255c78333f4d983077741, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i.i78) #37, !noalias !1873
  br i1 %205, label %bb3.i.i103, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit.i102"

bb3.i.i103:                                       ; preds = %bb5.i
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i288, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.5, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #38, !noalias !1869
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit.i102": ; preds = %bb5.i
  %206 = getelementptr inbounds i8, ptr %_9.i, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %206, ptr noundef nonnull align 8 dereferenceable(24) %buf.i.i79, i64 24, i1 false), !noalias !1866
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i.i78), !noalias !1869
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i.i79), !noalias !1869
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i288), !noalias !1866
  %207 = getelementptr inbounds i8, ptr %_9.i, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %207, ptr noundef nonnull align 8 dereferenceable(24) %_10.i, i64 24, i1 false), !noalias !1866
  %208 = getelementptr inbounds i8, ptr %_9.i, i64 152
  store i32 6092, ptr %208, align 8, !noalias !1866
  store i64 0, ptr %_9.i, align 8, !noalias !1866
  %_13.sroa.4.0._9.sroa_idx.i = getelementptr inbounds i8, ptr %_9.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_13.sroa.4.0._9.sroa_idx.i, align 8, !noalias !1866
  %_13.sroa.4.sroa.4.0._13.sroa.4.0._9.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_9.i, i64 16
  store i64 38, ptr %_13.sroa.4.sroa.4.0._13.sroa.4.0._9.sroa_idx.sroa_idx.i, align 8, !noalias !1866
  %_13.sroa.4.sroa.5.0._13.sroa.4.0._9.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_9.i, i64 24
  store i32 556, ptr %_13.sroa.4.sroa.5.0._13.sroa.4.0._9.sroa_idx.sroa_idx.i, align 8, !noalias !1866
  %209 = getelementptr inbounds i8, ptr %_9.i, i64 80
  store i8 2, ptr %209, align 8, !noalias !1866
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_10.i), !noalias !1866
  %210 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_9.i) #37, !noalias !1866
  %_8.0.i = extractvalue { i64, ptr } %210, 0
  %_8.1.i = extractvalue { i64, ptr } %210, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_9.i), !noalias !1866
  br label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit

bb9.i:                                            ; preds = %bb4.i
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_18.i), !noalias !1866
  %211 = getelementptr inbounds i8, ptr %_247, i64 64
  %_19.i = load ptr, ptr %211, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  call fastcc void @_ZN14pump_recovered9admin_cto12token_frozen17h1658d4a62a0640cfE(ptr noalias nocapture noundef nonnull align 8 dereferenceable(16) %_18.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_19.i) #37, !noalias !1866
  %212 = load i64, ptr %_18.i, align 8, !range !239, !noalias !1866, !noundef !2
  %213 = icmp eq i64 %212, 2
  %214 = getelementptr inbounds i8, ptr %_18.i, i64 8
  br i1 %213, label %bb66.i, label %bb65.i87

bb66.i:                                           ; preds = %bb9.i
  %215 = load i8, ptr %214, align 8, !range !9, !noalias !1866, !noundef !2
  %_165.not.i = icmp eq i8 %215, 0
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_18.i), !noalias !1866
  br i1 %_165.not.i, label %bb60.i, label %bb59.i

bb65.i87:                                         ; preds = %bb9.i
  %_166.1.i = load ptr, ptr %214, align 8, !noalias !1866, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_18.i), !noalias !1866
  br label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread311

bb60.i:                                           ; preds = %bb66.i
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_24.i84), !noalias !1866
  %216 = getelementptr inbounds i8, ptr %_247, i64 24
  %_143.i = load ptr, ptr %216, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  %217 = getelementptr inbounds i8, ptr %_143.i, i64 88
  %_248.i = load ptr, ptr %217, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  %_249.i = load ptr, ptr %_248.i, align 8, !noalias !1866, !nonnull !2, !align !237, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_24.i84, ptr noundef nonnull align 1 dereferenceable(32) %_249.i, i64 32, i1 false), !noalias !1866
  %218 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_24.i84, ptr noundef nonnull dereferenceable(32) @alloc_e953c1d75e6a4349f2dca6892c168ab2, i64 32), !noalias !1866
  %219 = icmp eq i32 %218, 0
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_24.i84), !noalias !1866
  %220 = getelementptr inbounds i8, ptr %_247, i64 136
  %_27.i = load ptr, ptr %220, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  %_26.i = call noundef zeroext i1 @_ZN19solana_account_info11AccountInfo13data_is_empty17h4cbad3bc61143bcfE(ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_27.i) #37, !noalias !1866
  %coin_present.i = xor i1 %_26.i, true
  br i1 %219, label %bb13.i, label %bb14.i88

bb59.i:                                           ; preds = %bb66.i
  call void @sol_log_(ptr noundef nonnull @alloc_deddac2d627577b5c14e9bbeacabf74e, i64 noundef 62) #37, !noalias !1866
  br label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread

bb14.i88:                                         ; preds = %bb60.i
  %221 = getelementptr inbounds i8, ptr %_247, i64 72
  %_30.i = load ptr, ptr %221, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  %_29.i = call noundef zeroext i1 @_ZN19solana_account_info11AccountInfo13data_is_empty17h4cbad3bc61143bcfE(ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_30.i) #37, !noalias !1866
  br i1 %_29.i, label %bb19.i, label %bb17.i89

bb13.i:                                           ; preds = %bb60.i
  br i1 %_26.i, label %bb27.i93, label %bb20.i

bb17.i89:                                         ; preds = %bb14.i88
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_32.i), !noalias !1866
  %_33.i = load ptr, ptr %221, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  call fastcc void @_ZN14pump_recovered9admin_cto12token_frozen17h1658d4a62a0640cfE(ptr noalias nocapture noundef nonnull align 8 dereferenceable(16) %_32.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_33.i) #37, !noalias !1866
  %222 = load i64, ptr %_32.i, align 8, !range !239, !noalias !1866, !noundef !2
  %223 = icmp eq i64 %222, 2
  %224 = getelementptr inbounds i8, ptr %_32.i, i64 8
  br i1 %223, label %bb69.i90, label %bb68.i

bb69.i90:                                         ; preds = %bb17.i89
  %225 = load i8, ptr %224, align 8, !range !9, !noalias !1866, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_32.i), !noalias !1866
  %extract.t37.i = icmp eq i8 %225, 0
  br label %bb19.i

bb68.i:                                           ; preds = %bb17.i89
  %_173.1.i = load ptr, ptr %224, align 8, !noalias !1866, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_32.i), !noalias !1866
  br label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread311

bb19.i:                                           ; preds = %bb69.i90, %bb14.i88
  %do_collect.sroa.0.0.off0.i = phi i1 [ %extract.t37.i, %bb69.i90 ], [ false, %bb14.i88 ]
  br i1 %_26.i, label %bb24.i, label %bb20.i

bb20.i:                                           ; preds = %bb19.i, %bb13.i
  %do_collect.sroa.0.1.off0.i = phi i1 [ true, %bb13.i ], [ %do_collect.sroa.0.0.off0.i, %bb19.i ]
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_38.i), !noalias !1866
  %_39.i = load ptr, ptr %220, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  call fastcc void @_ZN14pump_recovered9admin_cto12token_frozen17h1658d4a62a0640cfE(ptr noalias nocapture noundef nonnull align 8 dereferenceable(16) %_38.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_39.i) #37, !noalias !1866
  %226 = load i64, ptr %_38.i, align 8, !range !239, !noalias !1866, !noundef !2
  %227 = icmp eq i64 %226, 2
  %228 = getelementptr inbounds i8, ptr %_38.i, i64 8
  br i1 %227, label %bb71.i, label %bb70.i

bb24.i:                                           ; preds = %bb71.i, %bb19.i
  %do_collect.sroa.0.2.off0.i = phi i1 [ %do_collect.sroa.0.1.off0.i, %bb71.i ], [ %do_collect.sroa.0.0.off0.i, %bb19.i ]
  %do_coin.sroa.0.0.off0.i = phi i1 [ %extract.t39.i, %bb71.i ], [ false, %bb19.i ]
  call void @llvm.lifetime.start.p0(i64 376, ptr nonnull %_44.i83), !noalias !1866
  %229 = getelementptr inbounds i8, ptr %_247, i64 40
  %_181.i = load ptr, ptr %229, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  %230 = getelementptr inbounds i8, ptr %_44.i83, i64 24
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %230, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_181.i) #37, !noalias !1866
  call void @llvm.lifetime.start.p0(i64 288, ptr nonnull %_46.i), !noalias !1866
  %_182.i = load ptr, ptr %_247, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %_46.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_182.i) #37, !noalias !1866
  %_183.i = load ptr, ptr %211, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  %231 = getelementptr inbounds i8, ptr %_46.i, i64 48
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %231, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_183.i) #37, !noalias !1866
  %232 = getelementptr inbounds i8, ptr %_46.i, i64 96
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %232, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %192) #37, !noalias !1866
  %_144.i = load ptr, ptr %216, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  %233 = getelementptr inbounds i8, ptr %_144.i, i64 88
  %_184.i = load ptr, ptr %233, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  %234 = getelementptr inbounds i8, ptr %_46.i, i64 144
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %234, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_184.i) #37, !noalias !1866
  %_185.i = load ptr, ptr %_54, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  %235 = getelementptr inbounds i8, ptr %_46.i, i64 192
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %235, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_185.i) #37, !noalias !1866
  %236 = getelementptr inbounds i8, ptr %_247, i64 32
  %_186.i = load ptr, ptr %236, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  %237 = getelementptr inbounds i8, ptr %_46.i, i64 240
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %237, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_186.i) #37, !noalias !1866
  %238 = getelementptr inbounds i8, ptr %_44.i83, i64 72
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(288) %238, ptr noundef nonnull align 8 dereferenceable(288) %_46.i, i64 288, i1 false), !noalias !1866
  store i64 0, ptr %_44.i83, align 8, !noalias !1866
  %_187.sroa.4.0._44.sroa_idx.i = getelementptr inbounds i8, ptr %_44.i83, i64 8
  store ptr inttoptr (i64 8 to ptr), ptr %_187.sroa.4.0._44.sroa_idx.i, align 8, !noalias !1866
  %_187.sroa.5.0._44.sroa_idx.i = getelementptr inbounds i8, ptr %_44.i83, i64 16
  store i64 0, ptr %_187.sroa.5.0._44.sroa_idx.i, align 8, !noalias !1866
  %239 = getelementptr inbounds i8, ptr %_44.i83, i64 360
  store ptr inttoptr (i64 8 to ptr), ptr %239, align 8, !noalias !1866
  %240 = getelementptr inbounds i8, ptr %_44.i83, i64 368
  store i64 0, ptr %240, align 8, !noalias !1866
  call void @llvm.lifetime.end.p0(i64 288, ptr nonnull %_46.i), !noalias !1866
  %241 = call { i64, ptr } @_ZN10anchor_spl16associated_token17create_idempotent17h6d66b04320e05cf1E(ptr noalias nocapture noundef nonnull align 8 dereferenceable(376) %_44.i83) #37, !noalias !1866
  %242 = extractvalue { i64, ptr } %241, 0
  call void @llvm.lifetime.end.p0(i64 376, ptr nonnull %_44.i83), !noalias !1866
  %243 = icmp eq i64 %242, 2
  br i1 %243, label %bb26.i, label %bb79.i

bb26.i:                                           ; preds = %bb24.i
  br i1 %do_collect.sroa.0.2.off0.i, label %bb27.i93, label %bb43.i91

bb71.i:                                           ; preds = %bb20.i
  %244 = load i8, ptr %228, align 8, !range !9, !noalias !1866, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_38.i), !noalias !1866
  %extract.t39.i = icmp eq i8 %244, 0
  br label %bb24.i

bb70.i:                                           ; preds = %bb20.i
  %_178.1.i = load ptr, ptr %228, align 8, !noalias !1866, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_38.i), !noalias !1866
  br label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread311

bb79.i:                                           ; preds = %bb24.i
  %245 = extractvalue { i64, ptr } %241, 1
  br label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread311

bb43.i91:                                         ; preds = %bb42.i, %bb26.i
  %do_coin.sroa.0.1.off076.i = phi i1 [ %do_coin.sroa.0.1.off077.i, %bb42.i ], [ %do_coin.sroa.0.0.off0.i, %bb26.i ]
  %_123.i = and i1 %do_coin.sroa.0.1.off076.i, %coin_present.i
  br i1 %_123.i, label %bb44.i, label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread

bb27.i93:                                         ; preds = %bb26.i, %bb13.i
  %do_coin.sroa.0.1.off077.i = phi i1 [ %do_coin.sroa.0.0.off0.i, %bb26.i ], [ false, %bb13.i ]
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %event_signers.i), !noalias !1866
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_58.i), !noalias !1866
  %_60.i = load ptr, ptr %211, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  %_61.i = getelementptr inbounds i8, ptr %_247, i64 216
  %246 = getelementptr inbounds i8, ptr %ctx, i64 35
  %_62.i = load i8, ptr %246, align 1, !alias.scope !1866, !noundef !2
  %247 = getelementptr inbounds i8, ptr %_247, i64 72
  %_63.i = load ptr, ptr %247, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  %_145.i = load ptr, ptr %216, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  %248 = getelementptr inbounds i8, ptr %_145.i, i64 48
  %_64.i = load i8, ptr %248, align 8, !noalias !1866, !noundef !2
  %249 = getelementptr inbounds i8, ptr %_145.i, i64 88
  %_65.i94 = load ptr, ptr %249, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  %_66.i = getelementptr inbounds i8, ptr %_247, i64 32
  %_67.i = load ptr, ptr %_54, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  call void @_ZN14pump_recovered7creator19collect_creator_fee7collect17h70ccda2c71c42078E(ptr noalias nocapture noundef nonnull sret([48 x i8]) align 8 dereferenceable(48) %_58.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %192, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_60.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_61.i, i8 noundef %_62.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_63.i, i8 noundef %_64.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_65.i94, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %_66.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_67.i) #37, !noalias !1866
  %250 = load i64, ptr %_58.i, align 8, !range !239, !noalias !1866, !noundef !2
  %251 = icmp eq i64 %250, 2
  %252 = getelementptr inbounds i8, ptr %_58.i, i64 8
  %_196.0.i = load i64, ptr %252, align 8, !noalias !1866
  %253 = getelementptr inbounds i8, ptr %_58.i, i64 16
  %_196.1.i = load ptr, ptr %253, align 8, !noalias !1866
  br i1 %251, label %bb81.i99, label %bb82.i

bb82.i:                                           ; preds = %bb27.i93
  %_195.sroa.7.0._58.sroa_idx.i = getelementptr inbounds i8, ptr %_58.i, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %val.sroa.6.i, ptr noundef nonnull align 8 dereferenceable(24) %_195.sroa.7.0._58.sroa_idx.i, i64 24, i1 false), !noalias !1866
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_58.i), !noalias !1866
  %switch.i = icmp eq i64 %250, 1
  br i1 %switch.i, label %bb29.i, label %bb42.i

bb81.i99:                                         ; preds = %bb27.i93
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_58.i), !noalias !1866
  br label %bb54.i

bb29.i:                                           ; preds = %bb82.i
  call void @llvm.lifetime.start.p0(i64 80, ptr nonnull %e.i), !noalias !1866
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_75.i), !noalias !1866
  call void @"_ZN13solana_sysvar5clock71_$LT$impl$u20$solana_sysvar..Sysvar$u20$for$u20$solana_clock..Clock$GT$3get17hf864a57fc372ac1bE"(ptr noalias nocapture noundef nonnull sret([48 x i8]) align 8 dereferenceable(48) %_75.i) #37, !noalias !1866
  %_199.i = load i64, ptr %_75.i, align 8, !range !5, !noalias !1866, !noundef !2
  %trunc.not.i = icmp eq i64 %_199.i, 0
  br i1 %trunc.not.i, label %bb84.i97, label %bb83.i95

bb42.i:                                           ; preds = %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit.i", %bb82.i
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %event_signers.i), !noalias !1866
  br label %bb43.i91

bb84.i97:                                         ; preds = %bb29.i
  %_200.sroa.8.0..sroa_idx.i = getelementptr inbounds i8, ptr %_75.i, i64 40
  %_200.sroa.8.0.copyload.i = load i64, ptr %_200.sroa.8.0..sroa_idx.i, align 8, !noalias !1866
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_75.i), !noalias !1866
  %_203.i = load ptr, ptr %192, align 8, !noalias !1866, !nonnull !2, !align !237, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %e.i, ptr noundef nonnull align 1 dereferenceable(32) %_203.i, i64 32, i1 false), !noalias !1866
  %254 = getelementptr inbounds i8, ptr %e.i, i64 64
  store i64 %_200.sroa.8.0.copyload.i, ptr %254, align 8, !noalias !1866
  %255 = getelementptr inbounds i8, ptr %e.i, i64 72
  store i64 %_196.0.i, ptr %255, align 8, !noalias !1866
  %256 = getelementptr inbounds i8, ptr %e.i, i64 32
  store ptr %_196.1.i, ptr %256, align 8, !noalias !1866
  %quote_mint.sroa.2.0..sroa_idx.i = getelementptr inbounds i8, ptr %e.i, i64 40
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %quote_mint.sroa.2.0..sroa_idx.i, ptr noundef nonnull align 8 dereferenceable(24) %val.sroa.6.i, i64 24, i1 false), !noalias !1866
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_81.i), !noalias !1866
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_83.i82), !noalias !1866
  call void @"_ZN107_$LT$pump_recovered..creator..collect_creator_fee..CollectCreatorFeeEvent$u20$as$u20$anchor_lang..Event$GT$4data17hf265883adc14d6aaE"(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_83.i82, ptr noalias noundef nonnull readonly align 8 dereferenceable(80) %e.i) #37, !noalias !1866
  %257 = getelementptr inbounds i8, ptr %_83.i82, i64 8
  %_208.i = load ptr, ptr %257, align 8, !noalias !1866, !nonnull !2, !noundef !2
  %258 = getelementptr inbounds i8, ptr %_83.i82, i64 16
  %_207.i = load i64, ptr %258, align 8, !noalias !1866, !noundef !2
  store ptr %_208.i, ptr %_81.i, align 8, !noalias !1866
  %259 = getelementptr inbounds i8, ptr %_81.i, i64 8
  store i64 %_207.i, ptr %259, align 8, !noalias !1866
  call void @_ZN14solana_program3log12sol_log_data17h1e024b73f122854fE(ptr noalias noundef nonnull readonly align 8 %_81.i, i64 noundef 1) #37, !noalias !1866
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_83.i82), !noalias !1866
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_81.i), !noalias !1866
  %_86.i = getelementptr inbounds i8, ptr %_247, i64 312
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %authority_info.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_86.i) #37, !noalias !1866
  %260 = getelementptr inbounds i8, ptr %ctx, i64 46
  %authority_bump.i = load i8, ptr %260, align 2, !alias.scope !1866, !noundef !2
  call void @"_ZN107_$LT$pump_recovered..creator..collect_creator_fee..CollectCreatorFeeEvent$u20$as$u20$anchor_lang..Event$GT$4data17hf265883adc14d6aaE"(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %inner_data.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(80) %e.i) #37, !noalias !1866
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %ix_data.i), !noalias !1866
  %me.sroa.0.0.copyload.i.i = load i64, ptr %inner_data.i, align 8, !alias.scope !1874, !noalias !1877
  %me.sroa.4.0.self.sroa_idx.i.i = getelementptr inbounds i8, ptr %inner_data.i, i64 8
  %me.sroa.4.0.copyload.i.i = load ptr, ptr %me.sroa.4.0.self.sroa_idx.i.i, align 8, !alias.scope !1874, !noalias !1877, !nonnull !2, !noundef !2
  %me.sroa.5.0.self.sroa_idx.i.i = getelementptr inbounds i8, ptr %inner_data.i, i64 16
  %me.sroa.5.0.copyload.i.i = load i64, ptr %me.sroa.5.0.self.sroa_idx.i.i, align 8, !alias.scope !1874, !noalias !1877
  %_18.i.i = getelementptr inbounds i8, ptr %me.sroa.4.0.copyload.i.i, i64 %me.sroa.5.0.copyload.i.i
  %261 = getelementptr inbounds i8, ptr %_92.i, i64 32
  store ptr @alloc_d1e50873cb16f1fc41ca481a2a657dfa, ptr %261, align 8, !noalias !1866
  %262 = getelementptr inbounds i8, ptr %_92.i, i64 40
  store ptr getelementptr inbounds (<{ [8 x i8] }>, ptr @alloc_d1e50873cb16f1fc41ca481a2a657dfa, i64 1, i32 0, i64 0), ptr %262, align 8, !noalias !1866
  store ptr %me.sroa.4.0.copyload.i.i, ptr %_92.i, align 8, !noalias !1866
  %_218.sroa.4.0._92.sroa_idx.i = getelementptr inbounds i8, ptr %_92.i, i64 8
  store ptr %me.sroa.4.0.copyload.i.i, ptr %_218.sroa.4.0._92.sroa_idx.i, align 8, !noalias !1866
  %_218.sroa.5.0._92.sroa_idx.i = getelementptr inbounds i8, ptr %_92.i, i64 16
  store i64 %me.sroa.0.0.copyload.i.i, ptr %_218.sroa.5.0._92.sroa_idx.i, align 8, !noalias !1866
  %_218.sroa.6.0._92.sroa_idx.i = getelementptr inbounds i8, ptr %_92.i, i64 24
  store ptr %_18.i.i, ptr %_218.sroa.6.0._92.sroa_idx.i, align 8, !noalias !1866
  call fastcc void @"_ZN98_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter..SpecFromIter$LT$T$C$I$GT$$GT$9from_iter17h0e046d6f43e74065E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %ix_data.i, ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %_92.i) #37, !noalias !1866
  call void @llvm.lifetime.start.p0(i64 80, ptr nonnull %ix.i), !noalias !1866
  %263 = getelementptr inbounds i8, ptr %ix_data.i, i64 8
  %_221.i = load ptr, ptr %263, align 8, !noalias !1866, !nonnull !2, !noundef !2
  %264 = getelementptr inbounds i8, ptr %ix_data.i, i64 16
  %_220.i = load i64, ptr %264, align 8, !noalias !1866, !noundef !2
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_100.i), !noalias !1866
  %_102.i = call fastcc noundef ptr @_ZN5alloc5alloc15exchange_malloc17h6cd8dd11b0e3424eE(i64 noundef 34, i64 noundef 1) #37, !noalias !1866
  %_146.i = load ptr, ptr %authority_info.i, align 8, !noalias !1866, !nonnull !2, !align !237, !noundef !2
  call void @llvm.memmove.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_102.i, ptr noundef nonnull align 1 dereferenceable(32) %_146.i, i64 32, i1 false), !noalias !1866
  %_104.sroa.4.0..sroa_idx.i = getelementptr inbounds i8, ptr %_102.i, i64 32
  store i8 1, ptr %_104.sroa.4.0..sroa_idx.i, align 1, !noalias !1866
  %_104.sroa.5.0..sroa_idx.i = getelementptr inbounds i8, ptr %_102.i, i64 33
  store i8 0, ptr %_104.sroa.5.0..sroa_idx.i, align 1, !noalias !1866
  store i64 1, ptr %_100.i, align 8, !alias.scope !1879, !noalias !1882
  %265 = getelementptr inbounds i8, ptr %_100.i, i64 8
  store ptr %_102.i, ptr %265, align 8, !alias.scope !1879, !noalias !1882
  %266 = getelementptr inbounds i8, ptr %_100.i, i64 16
  store i64 1, ptr %266, align 8, !alias.scope !1879, !noalias !1882
  call void @_ZN18solana_instruction11Instruction14new_with_bytes17h836fab8fb6401158E(ptr noalias nocapture noundef nonnull sret([80 x i8]) align 8 dereferenceable(80) %ix.i, ptr noalias nocapture noundef nonnull readonly align 1 dereferenceable(32) @_ZN14pump_recovered2ID17h8e245cf89cf2c06bE, ptr noalias noundef nonnull readonly align 1 %_221.i, i64 noundef %_220.i, ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(24) %_100.i) #37, !noalias !1866
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_100.i), !noalias !1866
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %event_infos.i), !noalias !1866
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %event_infos.i, ptr noundef nonnull align 8 dereferenceable(48) %authority_info.i, i64 48, i1 false), !noalias !1866
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_112.i), !noalias !1866
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %_116.i), !noalias !1866
  store i8 %authority_bump.i, ptr %_116.i, align 1, !noalias !1866
  store ptr @alloc_7a7952b5e0d15f2b72d0341cef6d4739, ptr %_112.i, align 8, !noalias !1866
  %267 = getelementptr inbounds i8, ptr %_112.i, i64 8
  store i64 17, ptr %267, align 8, !noalias !1866
  %268 = getelementptr inbounds [2 x { ptr, i64 }], ptr %_112.i, i64 0, i64 1
  store ptr %_116.i, ptr %268, align 8, !noalias !1866
  %269 = getelementptr inbounds [2 x { ptr, i64 }], ptr %_112.i, i64 0, i64 1, i32 1
  store i64 1, ptr %269, align 8, !noalias !1866
  store ptr %_112.i, ptr %event_signers.i, align 8, !noalias !1866
  %270 = getelementptr inbounds i8, ptr %event_signers.i, i64 8
  store i64 2, ptr %270, align 8, !noalias !1866
  call void @_ZN14solana_program7program13invoke_signed17h01c3b84bc1fc491eE(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_109.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(80) %ix.i, ptr noalias noundef nonnull readonly align 8 %event_infos.i, i64 noundef 1, ptr noalias noundef nonnull readonly align 8 %event_signers.i, i64 noundef 1) #37, !noalias !1866
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %_116.i), !noalias !1866
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_112.i), !noalias !1866
  %271 = load i64, ptr %_109.i, align 8, !range !236, !noalias !1866, !noundef !2
  %272 = icmp eq i64 %271, -9223372036854775782
  br i1 %272, label %bb90.i98, label %bb89.i

bb83.i95:                                         ; preds = %bb29.i
  %273 = getelementptr inbounds i8, ptr %_75.i, i64 8
  %_201.sroa.0.0.copyload.i = load i64, ptr %273, align 8, !noalias !1866
  %_201.sroa.5.0..sroa_idx.i = getelementptr inbounds i8, ptr %_75.i, i64 16
  %_201.sroa.5.0.copyload.i = load i64, ptr %_201.sroa.5.0..sroa_idx.i, align 8, !noalias !1866
  %_201.sroa.6.0..sroa_idx.i = getelementptr inbounds i8, ptr %_75.i, i64 24
  %_201.sroa.6.0.copyload.i = load i64, ptr %_201.sroa.6.0..sroa_idx.i, align 8, !noalias !1866
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_75.i), !noalias !1866
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_204.i), !noalias !1866
  store i64 %_201.sroa.0.0.copyload.i, ptr %_204.i, align 8, !noalias !1866
  %residual5.sroa.2.0._204.sroa_idx.i = getelementptr inbounds i8, ptr %_204.i, i64 8
  store i64 %_201.sroa.5.0.copyload.i, ptr %residual5.sroa.2.0._204.sroa_idx.i, align 8, !noalias !1866
  %residual5.sroa.3.0._204.sroa_idx.i = getelementptr inbounds i8, ptr %_204.i, i64 16
  store i64 %_201.sroa.6.0.copyload.i, ptr %residual5.sroa.3.0._204.sroa_idx.i, align 8, !noalias !1866
  %274 = call { i64, ptr } @"_ZN107_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$solana_program_error..ProgramError$GT$$GT$4from17ha4865197be4b9a2fE"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(24) %_204.i) #37, !noalias !1866
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_204.i), !noalias !1866
  br label %bb53.i

bb90.i98:                                         ; preds = %bb84.i97
  %275 = getelementptr inbounds i8, ptr %event_infos.i, i64 8
  %event_infos.val48.i = load ptr, ptr %275, align 8, !noalias !1866, !nonnull !2, !noundef !2
  %276 = getelementptr inbounds i8, ptr %event_infos.i, i64 16
  %event_infos.val49.i = load ptr, ptr %276, align 8, !noalias !1866
  %self1.val.i.i.i.i.i = load i64, ptr %event_infos.val48.i, align 8, !noalias !1866, !noundef !2
  %val.i.i.i.i.i = add i64 %self1.val.i.i.i.i.i, -1
  store i64 %val.i.i.i.i.i, ptr %event_infos.val48.i, align 8, !noalias !1866
  %277 = icmp eq i64 %val.i.i.i.i.i, 0
  br i1 %277, label %bb1.i.i.i.i.i, label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i.i"

bb1.i.i.i.i.i:                                    ; preds = %bb90.i98
  %278 = getelementptr i8, ptr %event_infos.val48.i, i64 8
  %self2.val.i.i.i.i.i = load i64, ptr %278, align 8, !noalias !1866, !noundef !2
  %val6.i.i.i.i.i = add i64 %self2.val.i.i.i.i.i, -1
  store i64 %val6.i.i.i.i.i, ptr %278, align 8, !noalias !1866
  br label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i.i"

"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i.i": ; preds = %bb1.i.i.i.i.i, %bb90.i98
  %279 = icmp ne ptr %event_infos.val49.i, null
  call void @llvm.assume(i1 %279)
  %self1.val.i.i2.i.i.i = load i64, ptr %event_infos.val49.i, align 8, !noalias !1866, !noundef !2
  %val.i.i3.i.i.i = add i64 %self1.val.i.i2.i.i.i, -1
  store i64 %val.i.i3.i.i.i, ptr %event_infos.val49.i, align 8, !noalias !1866
  %280 = icmp eq i64 %val.i.i3.i.i.i, 0
  br i1 %280, label %bb1.i.i4.i.i.i, label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit.i"

bb1.i.i4.i.i.i:                                   ; preds = %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i.i"
  %281 = getelementptr i8, ptr %event_infos.val49.i, i64 8
  %self2.val.i.i5.i.i.i = load i64, ptr %281, align 8, !noalias !1866, !noundef !2
  %val6.i.i6.i.i.i = add i64 %self2.val.i.i5.i.i.i, -1
  store i64 %val6.i.i6.i.i.i, ptr %281, align 8, !noalias !1866
  br label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit.i"

"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit.i": ; preds = %bb1.i.i4.i.i.i, %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i.i"
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %event_infos.i), !noalias !1866
  %_1.val.i.i = load i64, ptr %ix.i, align 8, !alias.scope !1884, !noalias !1866, !noundef !2
  %282 = icmp eq i64 %_1.val.i.i, 0
  br i1 %282, label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i.i", label %bb2.i.i.i.i.i

bb2.i.i.i.i.i:                                    ; preds = %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit.i"
  %283 = getelementptr inbounds i8, ptr %ix.i, i64 8
  %_1.val2.i.i = load ptr, ptr %283, align 8, !alias.scope !1884, !noalias !1866
  %284 = icmp ne ptr %_1.val2.i.i, null
  call void @llvm.assume(i1 %284)
  br label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i.i"

"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i.i": ; preds = %bb2.i.i.i.i.i, %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit.i"
  %285 = getelementptr inbounds i8, ptr %ix.i, i64 24
  %.val.i.i = load i64, ptr %285, align 8, !alias.scope !1884, !noalias !1866, !noundef !2
  %286 = icmp eq i64 %.val.i.i, 0
  br i1 %286, label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit.i", label %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i.i"

"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i.i": ; preds = %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i.i"
  %287 = getelementptr inbounds i8, ptr %ix.i, i64 32
  %.val1.i.i = load ptr, ptr %287, align 8, !alias.scope !1884, !noalias !1866
  %288 = icmp ne ptr %.val1.i.i, null
  call void @llvm.assume(i1 %288)
  br label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit.i"

"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit.i": ; preds = %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i.i", %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i.i"
  call void @llvm.lifetime.end.p0(i64 80, ptr nonnull %ix.i), !noalias !1866
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %ix_data.i), !noalias !1866
  call void @llvm.lifetime.end.p0(i64 80, ptr nonnull %e.i), !noalias !1866
  br label %bb42.i

bb89.i:                                           ; preds = %bb84.i97
  %289 = call { i64, ptr } @"_ZN107_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$solana_program_error..ProgramError$GT$$GT$4from17ha4865197be4b9a2fE"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(24) %_109.i) #37, !noalias !1866
  %290 = getelementptr inbounds i8, ptr %event_infos.i, i64 8
  %event_infos.val.i = load ptr, ptr %290, align 8, !noalias !1866, !nonnull !2, !noundef !2
  %291 = getelementptr inbounds i8, ptr %event_infos.i, i64 16
  %event_infos.val47.i = load ptr, ptr %291, align 8, !noalias !1866
  %self1.val.i.i.i.i52.i = load i64, ptr %event_infos.val.i, align 8, !noalias !1866, !noundef !2
  %val.i.i.i.i53.i = add i64 %self1.val.i.i.i.i52.i, -1
  store i64 %val.i.i.i.i53.i, ptr %event_infos.val.i, align 8, !noalias !1866
  %292 = icmp eq i64 %val.i.i.i.i53.i, 0
  br i1 %292, label %bb1.i.i.i.i60.i, label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i54.i"

bb1.i.i.i.i60.i:                                  ; preds = %bb89.i
  %293 = getelementptr i8, ptr %event_infos.val.i, i64 8
  %self2.val.i.i.i.i61.i = load i64, ptr %293, align 8, !noalias !1866, !noundef !2
  %val6.i.i.i.i62.i = add i64 %self2.val.i.i.i.i61.i, -1
  store i64 %val6.i.i.i.i62.i, ptr %293, align 8, !noalias !1866
  br label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i54.i"

"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i54.i": ; preds = %bb1.i.i.i.i60.i, %bb89.i
  %294 = icmp ne ptr %event_infos.val47.i, null
  call void @llvm.assume(i1 %294)
  %self1.val.i.i2.i.i55.i = load i64, ptr %event_infos.val47.i, align 8, !noalias !1866, !noundef !2
  %val.i.i3.i.i56.i = add i64 %self1.val.i.i2.i.i55.i, -1
  store i64 %val.i.i3.i.i56.i, ptr %event_infos.val47.i, align 8, !noalias !1866
  %295 = icmp eq i64 %val.i.i3.i.i56.i, 0
  br i1 %295, label %bb1.i.i4.i.i57.i, label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit63.i"

bb1.i.i4.i.i57.i:                                 ; preds = %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i54.i"
  %296 = getelementptr i8, ptr %event_infos.val47.i, i64 8
  %self2.val.i.i5.i.i58.i = load i64, ptr %296, align 8, !noalias !1866, !noundef !2
  %val6.i.i6.i.i59.i = add i64 %self2.val.i.i5.i.i58.i, -1
  store i64 %val6.i.i6.i.i59.i, ptr %296, align 8, !noalias !1866
  br label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit63.i"

"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit63.i": ; preds = %bb1.i.i4.i.i57.i, %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i54.i"
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %event_infos.i), !noalias !1866
  %_1.val.i64.i = load i64, ptr %ix.i, align 8, !alias.scope !1887, !noalias !1866, !noundef !2
  %297 = icmp eq i64 %_1.val.i64.i, 0
  br i1 %297, label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i67.i", label %bb2.i.i.i.i65.i

bb2.i.i.i.i65.i:                                  ; preds = %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit63.i"
  %298 = getelementptr inbounds i8, ptr %ix.i, i64 8
  %_1.val2.i66.i = load ptr, ptr %298, align 8, !alias.scope !1887, !noalias !1866
  %299 = icmp ne ptr %_1.val2.i66.i, null
  call void @llvm.assume(i1 %299)
  br label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i67.i"

"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i67.i": ; preds = %bb2.i.i.i.i65.i, %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit63.i"
  %300 = getelementptr inbounds i8, ptr %ix.i, i64 24
  %.val.i68.i = load i64, ptr %300, align 8, !alias.scope !1887, !noalias !1866, !noundef !2
  %301 = icmp eq i64 %.val.i68.i, 0
  br i1 %301, label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit71.i", label %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i69.i"

"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i69.i": ; preds = %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i67.i"
  %302 = getelementptr inbounds i8, ptr %ix.i, i64 32
  %.val1.i70.i = load ptr, ptr %302, align 8, !alias.scope !1887, !noalias !1866
  %303 = icmp ne ptr %.val1.i70.i, null
  call void @llvm.assume(i1 %303)
  br label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit71.i"

"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit71.i": ; preds = %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i69.i", %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i67.i"
  call void @llvm.lifetime.end.p0(i64 80, ptr nonnull %ix.i), !noalias !1866
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %ix_data.i), !noalias !1866
  br label %bb53.i

bb53.i:                                           ; preds = %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit71.i", %bb83.i95
  %.pn.i96 = phi { i64, ptr } [ %274, %bb83.i95 ], [ %289, %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit71.i" ]
  %_0.sroa.0.1.i = extractvalue { i64, ptr } %.pn.i96, 0
  %_0.sroa.11.1.i = extractvalue { i64, ptr } %.pn.i96, 1
  call void @llvm.lifetime.end.p0(i64 80, ptr nonnull %e.i), !noalias !1866
  br label %bb54.i

bb54.i:                                           ; preds = %bb53.i, %bb81.i99
  %_0.sroa.11.2.i = phi ptr [ %_196.1.i, %bb81.i99 ], [ %_0.sroa.11.1.i, %bb53.i ]
  %_0.sroa.0.2.i = phi i64 [ %_196.0.i, %bb81.i99 ], [ %_0.sroa.0.1.i, %bb53.i ]
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %event_signers.i), !noalias !1866
  br label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit

bb44.i:                                           ; preds = %bb43.i91
  call void @llvm.lifetime.start.p0(i64 472, ptr nonnull %_127.i81), !noalias !1866
  %304 = getelementptr inbounds i8, ptr %_247, i64 88
  %_231.i = load ptr, ptr %304, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  %305 = getelementptr inbounds i8, ptr %_127.i81, i64 24
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %305, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_231.i) #37, !noalias !1866
  call void @llvm.lifetime.start.p0(i64 384, ptr nonnull %_129.i80), !noalias !1866
  %_147.i92 = load ptr, ptr %216, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  %306 = getelementptr inbounds i8, ptr %_147.i92, i64 88
  %_232.i = load ptr, ptr %306, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %_129.i80, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_232.i) #37, !noalias !1866
  %307 = getelementptr inbounds i8, ptr %_247, i64 32
  %_233.i = load ptr, ptr %307, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  %308 = getelementptr inbounds i8, ptr %_129.i80, i64 48
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %308, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_233.i) #37, !noalias !1866
  %309 = getelementptr inbounds i8, ptr %_129.i80, i64 96
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %309, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %192) #37, !noalias !1866
  %310 = getelementptr inbounds i8, ptr %_247, i64 128
  %_234.i = load ptr, ptr %310, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  %311 = getelementptr inbounds i8, ptr %_129.i80, i64 144
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %311, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_234.i) #37, !noalias !1866
  %_235.i = load ptr, ptr %220, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  %312 = getelementptr inbounds i8, ptr %_129.i80, i64 192
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %312, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_235.i) #37, !noalias !1866
  %_236.i = load ptr, ptr %211, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  %313 = getelementptr inbounds i8, ptr %_129.i80, i64 240
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %313, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_236.i) #37, !noalias !1866
  %314 = getelementptr inbounds i8, ptr %_247, i64 120
  %_237.i = load ptr, ptr %314, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  %315 = getelementptr inbounds i8, ptr %_129.i80, i64 288
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %315, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_237.i) #37, !noalias !1866
  %_238.i = load ptr, ptr %304, align 8, !noalias !1866, !nonnull !2, !align !4, !noundef !2
  %316 = getelementptr inbounds i8, ptr %_129.i80, i64 336
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %316, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_238.i) #37, !noalias !1866
  %317 = getelementptr inbounds i8, ptr %_127.i81, i64 72
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(384) %317, ptr noundef nonnull align 8 dereferenceable(384) %_129.i80, i64 384, i1 false), !noalias !1866
  store i64 0, ptr %_127.i81, align 8, !noalias !1866
  %_239.sroa.4.0._127.sroa_idx.i = getelementptr inbounds i8, ptr %_127.i81, i64 8
  store ptr inttoptr (i64 8 to ptr), ptr %_239.sroa.4.0._127.sroa_idx.i, align 8, !noalias !1866
  %_239.sroa.5.0._127.sroa_idx.i = getelementptr inbounds i8, ptr %_127.i81, i64 16
  store i64 0, ptr %_239.sroa.5.0._127.sroa_idx.i, align 8, !noalias !1866
  %318 = getelementptr inbounds i8, ptr %_127.i81, i64 456
  store ptr inttoptr (i64 8 to ptr), ptr %318, align 8, !noalias !1866
  %319 = getelementptr inbounds i8, ptr %_127.i81, i64 464
  store i64 0, ptr %319, align 8, !noalias !1866
  call void @llvm.lifetime.end.p0(i64 384, ptr nonnull %_129.i80), !noalias !1866
  %320 = call { i64, ptr } @_ZN14pump_recovered8pump_amm3cpi24collect_coin_creator_fee17h3c275eaedaa4ba35E(ptr noalias nocapture noundef nonnull align 8 dereferenceable(472) %_127.i81) #37, !noalias !1866
  %321 = extractvalue { i64, ptr } %320, 0
  call void @llvm.lifetime.end.p0(i64 472, ptr nonnull %_127.i81), !noalias !1866
  %322 = icmp eq i64 %321, 2
  br i1 %322, label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread, label %bb101.i

bb101.i:                                          ; preds = %bb44.i
  %323 = extractvalue { i64, ptr } %320, 1
  br label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread311

_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread: ; preds = %bb44.i, %bb43.i91, %bb59.i, %bb3.i86, %bb1.i
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_109.i)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_92.i)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %inner_data.i)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %authority_info.i)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %val.sroa.6.i)
  br label %bb23

_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread311: ; preds = %bb65.i87, %bb68.i, %bb101.i, %bb79.i, %bb70.i
  %_0.sroa.11.4.i.ph = phi ptr [ %_178.1.i, %bb70.i ], [ %245, %bb79.i ], [ %323, %bb101.i ], [ %_173.1.i, %bb68.i ], [ %_166.1.i, %bb65.i87 ]
  %_0.sroa.0.4.i.ph = phi i64 [ %226, %bb70.i ], [ %242, %bb79.i ], [ %321, %bb101.i ], [ %222, %bb68.i ], [ %212, %bb65.i87 ]
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_109.i)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_92.i)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %inner_data.i)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %authority_info.i)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %val.sroa.6.i)
  br label %bb55

_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit: ; preds = %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit.i102", %bb54.i
  %_0.sroa.11.4.i = phi ptr [ %_8.1.i, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit.i102" ], [ %_0.sroa.11.2.i, %bb54.i ]
  %_0.sroa.0.4.i = phi i64 [ %_8.0.i, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit.i102" ], [ %_0.sroa.0.2.i, %bb54.i ]
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_109.i)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_92.i)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %inner_data.i)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %authority_info.i)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %val.sroa.6.i)
  %324 = icmp eq i64 %_0.sroa.0.4.i, 2
  br i1 %324, label %bb23, label %bb55

bb70:                                             ; preds = %bb23
  %325 = getelementptr inbounds i8, ptr %ctx, i64 35
  %ctx.val75 = load i8, ptr %325, align 1
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_116.sroa.5.i)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_5.i), !noalias !1890
  %326 = getelementptr inbounds i8, ptr %_247, i64 24
  %_188.i = load ptr, ptr %326, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  %327 = getelementptr inbounds i8, ptr %_188.i, i64 88
  %_202.i = load ptr, ptr %327, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  %_203.i113 = load ptr, ptr %_202.i, align 8, !noalias !1890, !nonnull !2, !align !237, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_5.i, ptr noundef nonnull align 1 dereferenceable(32) %_203.i113, i64 32, i1 false), !noalias !1890
  %328 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_5.i, ptr noundef nonnull dereferenceable(32) @alloc_e953c1d75e6a4349f2dca6892c168ab2, i64 32), !noalias !1890
  %329 = icmp eq i32 %328, 0
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_5.i), !noalias !1890
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %dest.i), !noalias !1890
  call void @llvm.lifetime.start.p0(i64 33, ptr nonnull %_7.i), !noalias !1890
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_10.i112), !noalias !1890
  store ptr @alloc_ed0c7b53f6fd188c408cb80c27c2e0f7, ptr %_10.i112, align 8, !noalias !1890
  %330 = getelementptr inbounds i8, ptr %_10.i112, i64 8
  store i64 13, ptr %330, align 8, !noalias !1890
  %331 = getelementptr inbounds [2 x { ptr, i64 }], ptr %_10.i112, i64 0, i64 1
  store ptr %holder_key, ptr %331, align 8, !noalias !1890
  %332 = getelementptr inbounds [2 x { ptr, i64 }], ptr %_10.i112, i64 0, i64 1, i32 1
  store i64 32, ptr %332, align 8, !noalias !1890
  call void @_ZN13solana_pubkey6Pubkey20find_program_address17h57945082f260e69dE(ptr noalias nocapture noundef nonnull sret([33 x i8]) align 1 dereferenceable(33) %_7.i, ptr noalias noundef nonnull readonly align 8 %_10.i112, i64 noundef 2, ptr noalias noundef nonnull readonly align 1 dereferenceable(32) @_ZN14pump_recovered2ID17h8e245cf89cf2c06bE) #37, !noalias !1894
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %dest.i, ptr noundef nonnull align 1 dereferenceable(32) %_7.i, i64 32, i1 false), !noalias !1890
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_10.i112), !noalias !1890
  call void @llvm.lifetime.end.p0(i64 33, ptr nonnull %_7.i), !noalias !1890
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_14.i), !noalias !1890
  %333 = getelementptr inbounds i8, ptr %_247, i64 264
  %_207.i114 = load ptr, ptr %333, align 8, !noalias !1890, !nonnull !2, !align !237, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_14.i, ptr noundef nonnull align 1 dereferenceable(32) %_207.i114, i64 32, i1 false), !noalias !1894
  %334 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_14.i, ptr noundef nonnull dereferenceable(32) %dest.i, i64 32), !noalias !1890
  %.not.i115 = icmp eq i32 %334, 0
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_14.i), !noalias !1890
  br i1 %.not.i115, label %bb7.i122, label %bb2.i116

bb7.i122:                                         ; preds = %bb70
  %335 = getelementptr inbounds i8, ptr %_247, i64 136
  %_29.i123 = load ptr, ptr %335, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  %_28.i = call noundef zeroext i1 @_ZN19solana_account_info11AccountInfo13data_is_empty17h4cbad3bc61143bcfE(ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_29.i123) #37, !noalias !1894
  br i1 %_28.i, label %bb20.i146, label %bb9.i124

bb2.i116:                                         ; preds = %bb70
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_17.i), !noalias !1890
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_18.i111), !noalias !1890
  call void @_ZN11anchor_lang5error9ErrorCode4name17h4f8143ac990f2107E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_18.i111, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_2f475e84d260dce0bf2e60beae6b9ec7) #37, !noalias !1894
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i288), !noalias !1890
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i.i106), !noalias !1895
  store i64 0, ptr %buf.i.i106, align 8, !noalias !1895
  %_9.sroa.4.0.buf.sroa_idx.i.i117 = getelementptr inbounds i8, ptr %buf.i.i106, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i.i117, align 8, !noalias !1895
  %_9.sroa.5.0.buf.sroa_idx.i.i118 = getelementptr inbounds i8, ptr %buf.i.i106, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i.i118, align 8, !noalias !1895
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i.i105), !noalias !1895
  %336 = getelementptr inbounds i8, ptr %formatter.i.i105, i64 52
  store i32 0, ptr %336, align 4, !noalias !1895
  %337 = getelementptr inbounds i8, ptr %formatter.i.i105, i64 48
  store i32 32, ptr %337, align 8, !noalias !1895
  %338 = getelementptr inbounds i8, ptr %formatter.i.i105, i64 56
  store i8 3, ptr %338, align 8, !noalias !1895
  store i64 0, ptr %formatter.i.i105, align 8, !noalias !1895
  %339 = getelementptr inbounds i8, ptr %formatter.i.i105, i64 16
  store i64 0, ptr %339, align 8, !noalias !1895
  %340 = getelementptr inbounds i8, ptr %formatter.i.i105, i64 32
  store ptr %buf.i.i106, ptr %340, align 8, !noalias !1895
  %341 = getelementptr inbounds i8, ptr %formatter.i.i105, i64 40
  store ptr @vtable.4, ptr %341, align 8, !noalias !1895
  %342 = call noundef zeroext i1 @"_ZN68_$LT$anchor_lang..error..ErrorCode$u20$as$u20$core..fmt..Display$GT$3fmt17h3149de8d83148b03E"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_2f475e84d260dce0bf2e60beae6b9ec7, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i.i105) #37, !noalias !1899
  br i1 %342, label %bb3.i.i121, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h4b386cbefe3ebd9eE.exit.i"

bb3.i.i121:                                       ; preds = %bb2.i116
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i288, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.5, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #38, !noalias !1899
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h4b386cbefe3ebd9eE.exit.i": ; preds = %bb2.i116
  %343 = getelementptr inbounds i8, ptr %_17.i, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %343, ptr noundef nonnull align 8 dereferenceable(24) %buf.i.i106, i64 24, i1 false), !noalias !1890
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i.i105), !noalias !1895
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i.i106), !noalias !1895
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i288), !noalias !1890
  %344 = getelementptr inbounds i8, ptr %_17.i, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %344, ptr noundef nonnull align 8 dereferenceable(24) %_18.i111, i64 24, i1 false), !noalias !1890
  %345 = getelementptr inbounds i8, ptr %_17.i, i64 152
  store i32 2006, ptr %345, align 8, !noalias !1890
  store i64 0, ptr %_17.i, align 8, !noalias !1890
  %_20.sroa.4.0._17.sroa_idx.i = getelementptr inbounds i8, ptr %_17.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_20.sroa.4.0._17.sroa_idx.i, align 8, !noalias !1890
  %_20.sroa.4.sroa.4.0._20.sroa.4.0._17.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_17.i, i64 16
  store i64 38, ptr %_20.sroa.4.sroa.4.0._20.sroa.4.0._17.sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_20.sroa.4.sroa.5.0._20.sroa.4.0._17.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_17.i, i64 24
  store i32 648, ptr %_20.sroa.4.sroa.5.0._20.sroa.4.0._17.sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %346 = getelementptr inbounds i8, ptr %_17.i, i64 80
  store i8 2, ptr %346, align 8, !noalias !1890
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_18.i111), !noalias !1890
  %347 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_17.i) #37, !noalias !1894
  %_16.0.i = extractvalue { i64, ptr } %347, 0
  %_16.1.i = extractvalue { i64, ptr } %347, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_17.i), !noalias !1890
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %_24.i110), !noalias !1890
  %_211.i = load ptr, ptr %333, align 8, !noalias !1890, !nonnull !2, !align !237, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_24.i110, ptr noundef nonnull align 1 dereferenceable(32) %_211.i, i64 32, i1 false), !noalias !1894
  %348 = getelementptr inbounds i8, ptr %_24.i110, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %348, ptr noundef nonnull align 1 dereferenceable(32) %dest.i, i64 32, i1 false), !noalias !1890
  %349 = call { i64, ptr } @_ZN11anchor_lang5error5Error12with_pubkeys17hca6dbbbe6a9a5da7E(i64 noundef %_16.0.i, ptr noundef %_16.1.i, ptr noalias nocapture noundef nonnull readonly align 1 dereferenceable(64) %_24.i110) #37
  %_15.0.i = extractvalue { i64, ptr } %349, 0
  %_15.1.i = extractvalue { i64, ptr } %349, 1
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %_24.i110), !noalias !1890
  %350 = ptrtoint ptr %_15.1.i to i64
  br label %bb56.i119

bb9.i124:                                         ; preds = %bb7.i122
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_32.i109), !noalias !1890
  %_33.i125 = load ptr, ptr %335, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  call fastcc void @_ZN14pump_recovered9admin_cto12token_frozen17h1658d4a62a0640cfE(ptr noalias nocapture noundef nonnull align 8 dereferenceable(16) %_32.i109, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_33.i125) #37, !noalias !1894
  %351 = load i64, ptr %_32.i109, align 8, !range !239, !noalias !1890, !noundef !2
  %352 = icmp eq i64 %351, 2
  %353 = getelementptr inbounds i8, ptr %_32.i109, i64 8
  br i1 %352, label %bb61.i127, label %bb60.i126

bb20.i146:                                        ; preds = %bb61.i127, %bb7.i122
  %_52.i = load ptr, ptr %335, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  %_51.i = call noundef zeroext i1 @_ZN19solana_account_info11AccountInfo13data_is_empty17h4cbad3bc61143bcfE(ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_52.i) #37, !noalias !1894
  br i1 %_51.i, label %bb25.i, label %bb22.i147

bb61.i127:                                        ; preds = %bb9.i124
  %354 = load i8, ptr %353, align 8, !range !9, !noalias !1890, !noundef !2
  %_213.not.i = icmp eq i8 %354, 0
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_32.i109), !noalias !1890
  br i1 %_213.not.i, label %bb20.i146, label %bb13.i128

bb60.i126:                                        ; preds = %bb9.i124
  %_214.1.i = load ptr, ptr %353, align 8, !noalias !1890, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_32.i109), !noalias !1890
  %355 = ptrtoint ptr %_214.1.i to i64
  br label %bb56.i119

bb13.i128:                                        ; preds = %bb61.i127
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_38.i108), !noalias !1890
  %_39.i129 = load ptr, ptr %335, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  call fastcc void @_ZN14pump_recovered9admin_cto16token_raw_amount17h5c5bab1f81c4ceb2E(ptr noalias nocapture noundef nonnull align 8 dereferenceable(16) %_38.i108, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_39.i129) #37, !noalias !1894
  %356 = load i64, ptr %_38.i108, align 8, !range !239, !noalias !1890, !noundef !2
  %357 = icmp eq i64 %356, 2
  %358 = getelementptr inbounds i8, ptr %_38.i108, i64 8
  br i1 %357, label %bb63.i, label %bb62.i

bb22.i147:                                        ; preds = %bb20.i146
  call void @llvm.lifetime.start.p0(i64 664, ptr nonnull %_55.i), !noalias !1890
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_56.sroa.11.i)
  %359 = getelementptr inbounds i8, ptr %_247, i64 88
  %x.i = load ptr, ptr %359, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  %360 = getelementptr inbounds i8, ptr %x.i, i64 24
  %_189.i = load ptr, ptr %360, align 8, !noalias !1894, !nonnull !2, !align !237, !noundef !2
  %_190.i = load ptr, ptr %x.i, align 8, !noalias !1894, !nonnull !2, !align !237, !noundef !2
  %361 = getelementptr inbounds i8, ptr %x.i, i64 8
  %_224.i = load ptr, ptr %361, align 8, !noalias !1894, !nonnull !2, !noundef !2
  %self.val.i.i = load i64, ptr %_224.i, align 8, !noalias !1894, !noundef !2
  %cond.i.i = icmp ne i64 %self.val.i.i, 0
  call void @llvm.assume(i1 %cond.i.i)
  %strong1.i.i = add i64 %self.val.i.i, 1
  store i64 %strong1.i.i, ptr %_224.i, align 8, !noalias !1894
  %_7.i.i = icmp eq i64 %strong1.i.i, 0
  br i1 %_7.i.i, label %bb4.i.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i

bb4.i.i:                                          ; preds = %bb22.i147
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i: ; preds = %bb22.i147
  %362 = getelementptr inbounds i8, ptr %x.i, i64 16
  %_228.i = load ptr, ptr %362, align 8, !noalias !1894, !nonnull !2, !noundef !2
  %self.val.i36.i = load i64, ptr %_228.i, align 8, !noalias !1894, !noundef !2
  %cond.i37.i = icmp ne i64 %self.val.i36.i, 0
  call void @llvm.assume(i1 %cond.i37.i)
  %strong1.i38.i = add i64 %self.val.i36.i, 1
  store i64 %strong1.i38.i, ptr %_228.i, align 8, !noalias !1894
  %_7.i39.i = icmp eq i64 %strong1.i38.i, 0
  br i1 %_7.i39.i, label %bb4.i40.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit.i

bb4.i40.i:                                        ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit.i: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i
  %363 = getelementptr inbounds i8, ptr %x.i, i64 32
  %_60.i148 = load i64, ptr %363, align 8, !noalias !1894, !noundef !2
  %364 = getelementptr inbounds i8, ptr %x.i, i64 42
  %365 = load i8, ptr %364, align 2, !range !9, !noalias !1894, !noundef !2
  %366 = getelementptr inbounds i8, ptr %x.i, i64 41
  %367 = load i8, ptr %366, align 1, !range !9, !noalias !1894, !noundef !2
  %368 = getelementptr inbounds i8, ptr %x.i, i64 40
  %369 = load i8, ptr %368, align 8, !range !9, !noalias !1894, !noundef !2
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_64.sroa.0.sroa.16.sroa.11.i)
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_64.sroa.0.sroa.17.sroa.11.i)
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_64.sroa.18.i)
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_64.sroa.19.sroa.11.i)
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_64.sroa.20.sroa.11.i)
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_64.sroa.21.sroa.11.i)
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_64.sroa.22.sroa.11.i)
  %_230.i = load ptr, ptr %_247, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  call void @llvm.experimental.noalias.scope.decl(metadata !1900)
  %_2.i.i = load ptr, ptr %_230.i, align 8, !alias.scope !1900, !noalias !1903, !nonnull !2, !align !237, !noundef !2
  %370 = getelementptr inbounds i8, ptr %_230.i, i64 8
  %_12.i.i = load ptr, ptr %370, align 8, !alias.scope !1900, !noalias !1903, !nonnull !2, !noundef !2
  %self.val.i.i.i = load i64, ptr %_12.i.i, align 8, !noalias !1905, !noundef !2
  %cond.i.i.i = icmp ne i64 %self.val.i.i.i, 0
  call void @llvm.assume(i1 %cond.i.i.i)
  %strong1.i.i.i = add i64 %self.val.i.i.i, 1
  store i64 %strong1.i.i.i, ptr %_12.i.i, align 8, !noalias !1905
  %_7.i.i.i = icmp eq i64 %strong1.i.i.i, 0
  br i1 %_7.i.i.i, label %bb4.i.i.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i.i

bb4.i.i.i:                                        ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit.i
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i.i: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit.i
  %371 = getelementptr inbounds i8, ptr %_230.i, i64 16
  %_16.i.i = load ptr, ptr %371, align 8, !alias.scope !1900, !noalias !1903, !nonnull !2, !noundef !2
  %self.val.i1.i.i = load i64, ptr %_16.i.i, align 8, !noalias !1905, !noundef !2
  %cond.i2.i.i = icmp ne i64 %self.val.i1.i.i, 0
  call void @llvm.assume(i1 %cond.i2.i.i)
  %strong1.i3.i.i = add i64 %self.val.i1.i.i, 1
  store i64 %strong1.i3.i.i, ptr %_16.i.i, align 8, !noalias !1905
  %_7.i4.i.i = icmp eq i64 %strong1.i3.i.i, 0
  br i1 %_7.i4.i.i, label %bb4.i5.i.i, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit.i"

bb4.i5.i.i:                                       ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i.i
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit.i": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i.i
  %372 = getelementptr inbounds i8, ptr %_230.i, i64 24
  %_5.i.i = load ptr, ptr %372, align 8, !alias.scope !1900, !noalias !1903, !nonnull !2, !align !237, !noundef !2
  %373 = getelementptr inbounds i8, ptr %_230.i, i64 32
  %_6.i.i = load i64, ptr %373, align 8, !alias.scope !1900, !noalias !1903, !noundef !2
  %374 = getelementptr inbounds i8, ptr %_230.i, i64 40
  %375 = load i8, ptr %374, align 8, !range !9, !alias.scope !1900, !noalias !1903, !noundef !2
  %376 = getelementptr inbounds i8, ptr %_230.i, i64 41
  %377 = load i8, ptr %376, align 1, !range !9, !alias.scope !1900, !noalias !1903, !noundef !2
  %378 = getelementptr inbounds i8, ptr %_230.i, i64 42
  %379 = load i8, ptr %378, align 2, !range !9, !alias.scope !1900, !noalias !1903, !noundef !2
  %_191.i = load ptr, ptr %326, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  %380 = getelementptr inbounds i8, ptr %_191.i, i64 88
  %_231.i149 = load ptr, ptr %380, align 8, !noalias !1894, !nonnull !2, !align !4, !noundef !2
  call void @llvm.experimental.noalias.scope.decl(metadata !1906)
  %_2.i41.i = load ptr, ptr %_231.i149, align 8, !alias.scope !1906, !noalias !1909, !nonnull !2, !align !237, !noundef !2
  %381 = getelementptr inbounds i8, ptr %_231.i149, i64 8
  %_12.i42.i = load ptr, ptr %381, align 8, !alias.scope !1906, !noalias !1909, !nonnull !2, !noundef !2
  %self.val.i.i43.i = load i64, ptr %_12.i42.i, align 8, !noalias !1911, !noundef !2
  %cond.i.i44.i = icmp ne i64 %self.val.i.i43.i, 0
  call void @llvm.assume(i1 %cond.i.i44.i)
  %strong1.i.i45.i = add i64 %self.val.i.i43.i, 1
  store i64 %strong1.i.i45.i, ptr %_12.i42.i, align 8, !noalias !1911
  %_7.i.i46.i = icmp eq i64 %strong1.i.i45.i, 0
  br i1 %_7.i.i46.i, label %bb4.i.i56.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i47.i

bb4.i.i56.i:                                      ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit.i"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i47.i: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit.i"
  %382 = getelementptr inbounds i8, ptr %_231.i149, i64 16
  %_16.i48.i = load ptr, ptr %382, align 8, !alias.scope !1906, !noalias !1909, !nonnull !2, !noundef !2
  %self.val.i1.i49.i = load i64, ptr %_16.i48.i, align 8, !noalias !1911, !noundef !2
  %cond.i2.i50.i = icmp ne i64 %self.val.i1.i49.i, 0
  call void @llvm.assume(i1 %cond.i2.i50.i)
  %strong1.i3.i51.i = add i64 %self.val.i1.i49.i, 1
  store i64 %strong1.i3.i51.i, ptr %_16.i48.i, align 8, !noalias !1911
  %_7.i4.i52.i = icmp eq i64 %strong1.i3.i51.i, 0
  br i1 %_7.i4.i52.i, label %bb4.i5.i55.i, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit57.i"

bb4.i5.i55.i:                                     ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i47.i
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit57.i": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i47.i
  %383 = getelementptr inbounds i8, ptr %_231.i149, i64 24
  %_5.i53.i = load ptr, ptr %383, align 8, !alias.scope !1906, !noalias !1909, !nonnull !2, !align !237, !noundef !2
  %384 = getelementptr inbounds i8, ptr %_231.i149, i64 32
  %_6.i54.i = load i64, ptr %384, align 8, !alias.scope !1906, !noalias !1909, !noundef !2
  %385 = getelementptr inbounds i8, ptr %_231.i149, i64 40
  %386 = load i8, ptr %385, align 8, !range !9, !alias.scope !1906, !noalias !1909, !noundef !2
  %387 = getelementptr inbounds i8, ptr %_231.i149, i64 41
  %388 = load i8, ptr %387, align 1, !range !9, !alias.scope !1906, !noalias !1909, !noundef !2
  %389 = getelementptr inbounds i8, ptr %_231.i149, i64 42
  %390 = load i8, ptr %389, align 2, !range !9, !alias.scope !1906, !noalias !1909, !noundef !2
  %391 = getelementptr inbounds i8, ptr %_247, i64 32
  %_232.i150 = load ptr, ptr %391, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  call void @llvm.experimental.noalias.scope.decl(metadata !1912)
  %_2.i58.i = load ptr, ptr %_232.i150, align 8, !alias.scope !1912, !noalias !1915, !nonnull !2, !align !237, !noundef !2
  %392 = getelementptr inbounds i8, ptr %_232.i150, i64 8
  %_12.i59.i = load ptr, ptr %392, align 8, !alias.scope !1912, !noalias !1915, !nonnull !2, !noundef !2
  %self.val.i.i60.i = load i64, ptr %_12.i59.i, align 8, !noalias !1917, !noundef !2
  %cond.i.i61.i = icmp ne i64 %self.val.i.i60.i, 0
  call void @llvm.assume(i1 %cond.i.i61.i)
  %strong1.i.i62.i = add i64 %self.val.i.i60.i, 1
  store i64 %strong1.i.i62.i, ptr %_12.i59.i, align 8, !noalias !1917
  %_7.i.i63.i = icmp eq i64 %strong1.i.i62.i, 0
  br i1 %_7.i.i63.i, label %bb4.i.i73.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i64.i

bb4.i.i73.i:                                      ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit57.i"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i64.i: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit57.i"
  %393 = getelementptr inbounds i8, ptr %_232.i150, i64 16
  %_16.i65.i = load ptr, ptr %393, align 8, !alias.scope !1912, !noalias !1915, !nonnull !2, !noundef !2
  %self.val.i1.i66.i = load i64, ptr %_16.i65.i, align 8, !noalias !1917, !noundef !2
  %cond.i2.i67.i = icmp ne i64 %self.val.i1.i66.i, 0
  call void @llvm.assume(i1 %cond.i2.i67.i)
  %strong1.i3.i68.i = add i64 %self.val.i1.i66.i, 1
  store i64 %strong1.i3.i68.i, ptr %_16.i65.i, align 8, !noalias !1917
  %_7.i4.i69.i = icmp eq i64 %strong1.i3.i68.i, 0
  br i1 %_7.i4.i69.i, label %bb4.i5.i72.i, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit74.i"

bb4.i5.i72.i:                                     ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i64.i
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit74.i": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i64.i
  %394 = getelementptr inbounds i8, ptr %_232.i150, i64 24
  %_5.i70.i = load ptr, ptr %394, align 8, !alias.scope !1912, !noalias !1915, !nonnull !2, !align !237, !noundef !2
  %395 = getelementptr inbounds i8, ptr %_232.i150, i64 32
  %_6.i71.i = load i64, ptr %395, align 8, !alias.scope !1912, !noalias !1915, !noundef !2
  %396 = getelementptr inbounds i8, ptr %_232.i150, i64 40
  %397 = load i8, ptr %396, align 8, !range !9, !alias.scope !1912, !noalias !1915, !noundef !2
  %398 = getelementptr inbounds i8, ptr %_232.i150, i64 41
  %399 = load i8, ptr %398, align 1, !range !9, !alias.scope !1912, !noalias !1915, !noundef !2
  %400 = getelementptr inbounds i8, ptr %_232.i150, i64 42
  %401 = load i8, ptr %400, align 2, !range !9, !alias.scope !1912, !noalias !1915, !noundef !2
  %_233.i151 = load ptr, ptr %_54, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  call void @llvm.experimental.noalias.scope.decl(metadata !1918)
  %_2.i75.i = load ptr, ptr %_233.i151, align 8, !alias.scope !1918, !noalias !1921, !nonnull !2, !align !237, !noundef !2
  %402 = getelementptr inbounds i8, ptr %_233.i151, i64 8
  %_12.i76.i = load ptr, ptr %402, align 8, !alias.scope !1918, !noalias !1921, !nonnull !2, !noundef !2
  %self.val.i.i77.i = load i64, ptr %_12.i76.i, align 8, !noalias !1923, !noundef !2
  %cond.i.i78.i = icmp ne i64 %self.val.i.i77.i, 0
  call void @llvm.assume(i1 %cond.i.i78.i)
  %strong1.i.i79.i = add i64 %self.val.i.i77.i, 1
  store i64 %strong1.i.i79.i, ptr %_12.i76.i, align 8, !noalias !1923
  %_7.i.i80.i = icmp eq i64 %strong1.i.i79.i, 0
  br i1 %_7.i.i80.i, label %bb4.i.i90.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i81.i

bb4.i.i90.i:                                      ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit74.i"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i81.i: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit74.i"
  %403 = getelementptr inbounds i8, ptr %_233.i151, i64 16
  %_16.i82.i = load ptr, ptr %403, align 8, !alias.scope !1918, !noalias !1921, !nonnull !2, !noundef !2
  %self.val.i1.i83.i = load i64, ptr %_16.i82.i, align 8, !noalias !1923, !noundef !2
  %cond.i2.i84.i = icmp ne i64 %self.val.i1.i83.i, 0
  call void @llvm.assume(i1 %cond.i2.i84.i)
  %strong1.i3.i85.i = add i64 %self.val.i1.i83.i, 1
  store i64 %strong1.i3.i85.i, ptr %_16.i82.i, align 8, !noalias !1923
  %_7.i4.i86.i = icmp eq i64 %strong1.i3.i85.i, 0
  br i1 %_7.i4.i86.i, label %bb4.i5.i89.i, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit91.i"

bb4.i5.i89.i:                                     ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i81.i
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit91.i": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i81.i
  %404 = getelementptr inbounds i8, ptr %_233.i151, i64 24
  %_5.i87.i = load ptr, ptr %404, align 8, !alias.scope !1918, !noalias !1921, !nonnull !2, !align !237, !noundef !2
  %405 = getelementptr inbounds i8, ptr %_233.i151, i64 32
  %_6.i88.i = load i64, ptr %405, align 8, !alias.scope !1918, !noalias !1921, !noundef !2
  %406 = getelementptr inbounds i8, ptr %_233.i151, i64 40
  %407 = load i8, ptr %406, align 8, !range !9, !alias.scope !1918, !noalias !1921, !noundef !2
  %408 = getelementptr inbounds i8, ptr %_233.i151, i64 41
  %409 = load i8, ptr %408, align 1, !range !9, !alias.scope !1918, !noalias !1921, !noundef !2
  %410 = getelementptr inbounds i8, ptr %_233.i151, i64 42
  %411 = load i8, ptr %410, align 2, !range !9, !alias.scope !1918, !noalias !1921, !noundef !2
  %412 = getelementptr inbounds i8, ptr %_247, i64 40
  %_234.i152 = load ptr, ptr %412, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  call void @llvm.experimental.noalias.scope.decl(metadata !1924)
  %_2.i92.i = load ptr, ptr %_234.i152, align 8, !alias.scope !1924, !noalias !1927, !nonnull !2, !align !237, !noundef !2
  %413 = getelementptr inbounds i8, ptr %_234.i152, i64 8
  %_12.i93.i = load ptr, ptr %413, align 8, !alias.scope !1924, !noalias !1927, !nonnull !2, !noundef !2
  %self.val.i.i94.i = load i64, ptr %_12.i93.i, align 8, !noalias !1929, !noundef !2
  %cond.i.i95.i = icmp ne i64 %self.val.i.i94.i, 0
  call void @llvm.assume(i1 %cond.i.i95.i)
  %strong1.i.i96.i = add i64 %self.val.i.i94.i, 1
  store i64 %strong1.i.i96.i, ptr %_12.i93.i, align 8, !noalias !1929
  %_7.i.i97.i = icmp eq i64 %strong1.i.i96.i, 0
  br i1 %_7.i.i97.i, label %bb4.i.i107.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i98.i

bb4.i.i107.i:                                     ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit91.i"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i98.i: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit91.i"
  %414 = getelementptr inbounds i8, ptr %_234.i152, i64 16
  %_16.i99.i = load ptr, ptr %414, align 8, !alias.scope !1924, !noalias !1927, !nonnull !2, !noundef !2
  %self.val.i1.i100.i = load i64, ptr %_16.i99.i, align 8, !noalias !1929, !noundef !2
  %cond.i2.i101.i = icmp ne i64 %self.val.i1.i100.i, 0
  call void @llvm.assume(i1 %cond.i2.i101.i)
  %strong1.i3.i102.i = add i64 %self.val.i1.i100.i, 1
  store i64 %strong1.i3.i102.i, ptr %_16.i99.i, align 8, !noalias !1929
  %_7.i4.i103.i = icmp eq i64 %strong1.i3.i102.i, 0
  br i1 %_7.i4.i103.i, label %bb4.i5.i106.i, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit108.i"

bb4.i5.i106.i:                                    ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i98.i
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit108.i": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i98.i
  %415 = getelementptr inbounds i8, ptr %_234.i152, i64 24
  %_5.i104.i = load ptr, ptr %415, align 8, !alias.scope !1924, !noalias !1927, !nonnull !2, !align !237, !noundef !2
  %416 = getelementptr inbounds i8, ptr %_234.i152, i64 32
  %_6.i105.i = load i64, ptr %416, align 8, !alias.scope !1924, !noalias !1927, !noundef !2
  %417 = getelementptr inbounds i8, ptr %_234.i152, i64 40
  %418 = load i8, ptr %417, align 8, !range !9, !alias.scope !1924, !noalias !1927, !noundef !2
  %419 = getelementptr inbounds i8, ptr %_234.i152, i64 41
  %420 = load i8, ptr %419, align 1, !range !9, !alias.scope !1924, !noalias !1927, !noundef !2
  %421 = getelementptr inbounds i8, ptr %_234.i152, i64 42
  %422 = load i8, ptr %421, align 2, !range !9, !alias.scope !1924, !noalias !1927, !noundef !2
  %_71.i = getelementptr inbounds i8, ptr %_247, i64 168
  call void @llvm.experimental.noalias.scope.decl(metadata !1930)
  %_2.i109.i = load ptr, ptr %_71.i, align 8, !alias.scope !1930, !noalias !1933, !nonnull !2, !align !237, !noundef !2
  %423 = getelementptr inbounds i8, ptr %_247, i64 176
  %_12.i110.i = load ptr, ptr %423, align 8, !alias.scope !1930, !noalias !1933, !nonnull !2, !noundef !2
  %self.val.i.i111.i = load i64, ptr %_12.i110.i, align 8, !noalias !1935, !noundef !2
  %cond.i.i112.i = icmp ne i64 %self.val.i.i111.i, 0
  call void @llvm.assume(i1 %cond.i.i112.i)
  %strong1.i.i113.i = add i64 %self.val.i.i111.i, 1
  store i64 %strong1.i.i113.i, ptr %_12.i110.i, align 8, !noalias !1935
  %_7.i.i114.i = icmp eq i64 %strong1.i.i113.i, 0
  br i1 %_7.i.i114.i, label %bb4.i.i124.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i115.i

bb4.i.i124.i:                                     ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit108.i"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i115.i: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit108.i"
  %424 = getelementptr inbounds i8, ptr %_247, i64 184
  %_16.i116.i = load ptr, ptr %424, align 8, !alias.scope !1930, !noalias !1933, !nonnull !2, !noundef !2
  %self.val.i1.i117.i = load i64, ptr %_16.i116.i, align 8, !noalias !1935, !noundef !2
  %cond.i2.i118.i = icmp ne i64 %self.val.i1.i117.i, 0
  call void @llvm.assume(i1 %cond.i2.i118.i)
  %strong1.i3.i119.i = add i64 %self.val.i1.i117.i, 1
  store i64 %strong1.i3.i119.i, ptr %_16.i116.i, align 8, !noalias !1935
  %_7.i4.i120.i = icmp eq i64 %strong1.i3.i119.i, 0
  br i1 %_7.i4.i120.i, label %bb4.i5.i123.i, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit125.i"

bb4.i5.i123.i:                                    ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i115.i
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit125.i": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i115.i
  %425 = getelementptr inbounds i8, ptr %_247, i64 192
  %_5.i121.i = load ptr, ptr %425, align 8, !alias.scope !1930, !noalias !1933, !nonnull !2, !align !237, !noundef !2
  %426 = getelementptr inbounds i8, ptr %_247, i64 200
  %_6.i122.i = load i64, ptr %426, align 8, !alias.scope !1930, !noalias !1933, !noundef !2
  %427 = getelementptr inbounds i8, ptr %_247, i64 208
  %428 = load i8, ptr %427, align 8, !range !9, !alias.scope !1930, !noalias !1933, !noundef !2
  %429 = getelementptr inbounds i8, ptr %_247, i64 209
  %430 = load i8, ptr %429, align 1, !range !9, !alias.scope !1930, !noalias !1933, !noundef !2
  %431 = getelementptr inbounds i8, ptr %_247, i64 210
  %432 = load i8, ptr %431, align 2, !range !9, !alias.scope !1930, !noalias !1933, !noundef !2
  %433 = getelementptr inbounds i8, ptr %_247, i64 128
  %_235.i153 = load ptr, ptr %433, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  call void @llvm.experimental.noalias.scope.decl(metadata !1936)
  %_2.i126.i = load ptr, ptr %_235.i153, align 8, !alias.scope !1936, !noalias !1939, !nonnull !2, !align !237, !noundef !2
  %434 = getelementptr inbounds i8, ptr %_235.i153, i64 8
  %_12.i127.i = load ptr, ptr %434, align 8, !alias.scope !1936, !noalias !1939, !nonnull !2, !noundef !2
  %self.val.i.i128.i = load i64, ptr %_12.i127.i, align 8, !noalias !1941, !noundef !2
  %cond.i.i129.i = icmp ne i64 %self.val.i.i128.i, 0
  call void @llvm.assume(i1 %cond.i.i129.i)
  %strong1.i.i130.i = add i64 %self.val.i.i128.i, 1
  store i64 %strong1.i.i130.i, ptr %_12.i127.i, align 8, !noalias !1941
  %_7.i.i131.i = icmp eq i64 %strong1.i.i130.i, 0
  br i1 %_7.i.i131.i, label %bb4.i.i141.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i132.i

bb4.i.i141.i:                                     ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit125.i"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i132.i: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit125.i"
  %435 = getelementptr inbounds i8, ptr %_235.i153, i64 16
  %_16.i133.i = load ptr, ptr %435, align 8, !alias.scope !1936, !noalias !1939, !nonnull !2, !noundef !2
  %self.val.i1.i134.i = load i64, ptr %_16.i133.i, align 8, !noalias !1941, !noundef !2
  %cond.i2.i135.i = icmp ne i64 %self.val.i1.i134.i, 0
  call void @llvm.assume(i1 %cond.i2.i135.i)
  %strong1.i3.i136.i = add i64 %self.val.i1.i134.i, 1
  store i64 %strong1.i3.i136.i, ptr %_16.i133.i, align 8, !noalias !1941
  %_7.i4.i137.i = icmp eq i64 %strong1.i3.i136.i, 0
  br i1 %_7.i4.i137.i, label %bb4.i5.i140.i, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit142.i"

bb4.i5.i140.i:                                    ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i132.i
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit142.i": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i132.i
  %436 = getelementptr inbounds i8, ptr %_235.i153, i64 24
  %_5.i138.i = load ptr, ptr %436, align 8, !alias.scope !1936, !noalias !1939, !nonnull !2, !align !237, !noundef !2
  %437 = getelementptr inbounds i8, ptr %_235.i153, i64 32
  %_6.i139.i = load i64, ptr %437, align 8, !alias.scope !1936, !noalias !1939, !noundef !2
  %438 = getelementptr inbounds i8, ptr %_235.i153, i64 40
  %439 = load i8, ptr %438, align 8, !range !9, !alias.scope !1936, !noalias !1939, !noundef !2
  %440 = getelementptr inbounds i8, ptr %_235.i153, i64 41
  %441 = load i8, ptr %440, align 1, !range !9, !alias.scope !1936, !noalias !1939, !noundef !2
  %442 = getelementptr inbounds i8, ptr %_235.i153, i64 42
  %443 = load i8, ptr %442, align 2, !range !9, !alias.scope !1936, !noalias !1939, !noundef !2
  %x10.i = load ptr, ptr %335, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  %444 = getelementptr inbounds i8, ptr %x10.i, i64 8
  %_238.i154 = load ptr, ptr %444, align 8, !noalias !1894, !nonnull !2, !noundef !2
  %self.val.i143.i = load i64, ptr %_238.i154, align 8, !noalias !1894, !noundef !2
  %cond.i144.i = icmp ne i64 %self.val.i143.i, 0
  call void @llvm.assume(i1 %cond.i144.i)
  %strong1.i145.i = add i64 %self.val.i143.i, 1
  store i64 %strong1.i145.i, ptr %_238.i154, align 8, !noalias !1894
  %_7.i146.i = icmp eq i64 %strong1.i145.i, 0
  br i1 %_7.i146.i, label %bb4.i147.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit148.i

bb4.i147.i:                                       ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit142.i"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit148.i: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit142.i"
  %_192.i = load ptr, ptr %x10.i, align 8, !noalias !1894, !nonnull !2, !align !237, !noundef !2
  %445 = getelementptr inbounds i8, ptr %x10.i, i64 16
  %_242.i = load ptr, ptr %445, align 8, !noalias !1894, !nonnull !2, !noundef !2
  %self.val.i149.i = load i64, ptr %_242.i, align 8, !noalias !1894, !noundef !2
  %cond.i150.i = icmp ne i64 %self.val.i149.i, 0
  call void @llvm.assume(i1 %cond.i150.i)
  %strong1.i151.i = add i64 %self.val.i149.i, 1
  store i64 %strong1.i151.i, ptr %_242.i, align 8, !noalias !1894
  %_7.i152.i = icmp eq i64 %strong1.i151.i, 0
  br i1 %_7.i152.i, label %bb4.i153.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit154.i

bb4.i153.i:                                       ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit148.i
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit154.i: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit148.i
  %446 = getelementptr inbounds i8, ptr %x10.i, i64 24
  %_193.i = load ptr, ptr %446, align 8, !noalias !1894, !nonnull !2, !align !237, !noundef !2
  %447 = getelementptr inbounds i8, ptr %x10.i, i64 32
  %_77.i = load i64, ptr %447, align 8, !noalias !1894, !noundef !2
  %448 = getelementptr inbounds i8, ptr %x10.i, i64 40
  %449 = load i8, ptr %448, align 8, !range !9, !noalias !1894, !noundef !2
  %450 = getelementptr inbounds i8, ptr %x10.i, i64 41
  %451 = load i8, ptr %450, align 1, !range !9, !noalias !1894, !noundef !2
  %452 = getelementptr inbounds i8, ptr %x10.i, i64 42
  %453 = load i8, ptr %452, align 2, !range !9, !noalias !1894, !noundef !2
  %_82.i155 = getelementptr inbounds i8, ptr %_247, i64 216
  call void @llvm.experimental.noalias.scope.decl(metadata !1942)
  %_2.i155.i = load ptr, ptr %_82.i155, align 8, !alias.scope !1942, !noalias !1945, !nonnull !2, !align !237, !noundef !2
  %454 = getelementptr inbounds i8, ptr %_247, i64 224
  %_12.i156.i = load ptr, ptr %454, align 8, !alias.scope !1942, !noalias !1945, !nonnull !2, !noundef !2
  %self.val.i.i157.i = load i64, ptr %_12.i156.i, align 8, !noalias !1947, !noundef !2
  %cond.i.i158.i = icmp ne i64 %self.val.i.i157.i, 0
  call void @llvm.assume(i1 %cond.i.i158.i)
  %strong1.i.i159.i = add i64 %self.val.i.i157.i, 1
  store i64 %strong1.i.i159.i, ptr %_12.i156.i, align 8, !noalias !1947
  %_7.i.i160.i = icmp eq i64 %strong1.i.i159.i, 0
  br i1 %_7.i.i160.i, label %bb4.i.i170.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i161.i

bb4.i.i170.i:                                     ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit154.i
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i161.i: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit154.i
  %455 = getelementptr inbounds i8, ptr %_247, i64 232
  %_16.i162.i = load ptr, ptr %455, align 8, !alias.scope !1942, !noalias !1945, !nonnull !2, !noundef !2
  %self.val.i1.i163.i = load i64, ptr %_16.i162.i, align 8, !noalias !1947, !noundef !2
  %cond.i2.i164.i = icmp ne i64 %self.val.i1.i163.i, 0
  call void @llvm.assume(i1 %cond.i2.i164.i)
  %strong1.i3.i165.i = add i64 %self.val.i1.i163.i, 1
  store i64 %strong1.i3.i165.i, ptr %_16.i162.i, align 8, !noalias !1947
  %_7.i4.i166.i = icmp eq i64 %strong1.i3.i165.i, 0
  br i1 %_7.i4.i166.i, label %bb4.i5.i169.i, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit171.i"

bb4.i5.i169.i:                                    ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i161.i
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit171.i": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i161.i
  %456 = getelementptr inbounds i8, ptr %_247, i64 240
  %_5.i167.i = load ptr, ptr %456, align 8, !alias.scope !1942, !noalias !1945, !nonnull !2, !align !237, !noundef !2
  %457 = getelementptr inbounds i8, ptr %_247, i64 248
  %_6.i168.i = load i64, ptr %457, align 8, !alias.scope !1942, !noalias !1945, !noundef !2
  %458 = getelementptr inbounds i8, ptr %_247, i64 256
  %459 = load i8, ptr %458, align 8, !range !9, !alias.scope !1942, !noalias !1945, !noundef !2
  %460 = getelementptr inbounds i8, ptr %_247, i64 257
  %461 = load i8, ptr %460, align 1, !range !9, !alias.scope !1942, !noalias !1945, !noundef !2
  %462 = getelementptr inbounds i8, ptr %_247, i64 258
  %463 = load i8, ptr %462, align 2, !range !9, !alias.scope !1942, !noalias !1945, !noundef !2
  %464 = getelementptr inbounds i8, ptr %_247, i64 72
  %x11.i = load ptr, ptr %464, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  %_194.i = load ptr, ptr %x11.i, align 8, !noalias !1894, !nonnull !2, !align !237, !noundef !2
  %465 = getelementptr inbounds i8, ptr %x11.i, i64 16
  %_246.i = load ptr, ptr %465, align 8, !noalias !1894, !nonnull !2, !noundef !2
  %self.val.i172.i = load i64, ptr %_246.i, align 8, !noalias !1894, !noundef !2
  %cond.i173.i = icmp ne i64 %self.val.i172.i, 0
  call void @llvm.assume(i1 %cond.i173.i)
  %strong1.i174.i = add i64 %self.val.i172.i, 1
  store i64 %strong1.i174.i, ptr %_246.i, align 8, !noalias !1894
  %_7.i175.i = icmp eq i64 %strong1.i174.i, 0
  br i1 %_7.i175.i, label %bb4.i176.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit177.i

bb4.i176.i:                                       ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit171.i"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit177.i: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit171.i"
  %_87.i = load ptr, ptr %464, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  %466 = getelementptr inbounds i8, ptr %_87.i, i64 24
  %_195.i = load ptr, ptr %466, align 8, !noalias !1894, !nonnull !2, !align !237, !noundef !2
  %467 = getelementptr inbounds i8, ptr %x11.i, i64 8
  %_250.i = load ptr, ptr %467, align 8, !noalias !1894, !nonnull !2, !noundef !2
  %self.val.i178.i = load i64, ptr %_250.i, align 8, !noalias !1894, !noundef !2
  %cond.i179.i = icmp ne i64 %self.val.i178.i, 0
  call void @llvm.assume(i1 %cond.i179.i)
  %strong1.i180.i = add i64 %self.val.i178.i, 1
  store i64 %strong1.i180.i, ptr %_250.i, align 8, !noalias !1894
  %_7.i181.i = icmp eq i64 %strong1.i180.i, 0
  br i1 %_7.i181.i, label %bb4.i182.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit183.i

bb4.i182.i:                                       ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit177.i
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit183.i: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit177.i
  %468 = getelementptr inbounds i8, ptr %x11.i, i64 32
  %_89.i = load i64, ptr %468, align 8, !noalias !1894, !noundef !2
  %469 = getelementptr inbounds i8, ptr %x11.i, i64 40
  %470 = load i8, ptr %469, align 8, !range !9, !noalias !1894, !noundef !2
  %471 = getelementptr inbounds i8, ptr %x11.i, i64 41
  %472 = load i8, ptr %471, align 1, !range !9, !noalias !1894, !noundef !2
  %473 = getelementptr inbounds i8, ptr %x11.i, i64 42
  %474 = load i8, ptr %473, align 2, !range !9, !noalias !1894, !noundef !2
  %475 = getelementptr inbounds i8, ptr %_247, i64 120
  %_252.i = load ptr, ptr %475, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  call void @llvm.experimental.noalias.scope.decl(metadata !1948)
  %_2.i184.i = load ptr, ptr %_252.i, align 8, !alias.scope !1948, !noalias !1951, !nonnull !2, !align !237, !noundef !2
  %476 = getelementptr inbounds i8, ptr %_252.i, i64 8
  %_12.i185.i = load ptr, ptr %476, align 8, !alias.scope !1948, !noalias !1951, !nonnull !2, !noundef !2
  %self.val.i.i186.i = load i64, ptr %_12.i185.i, align 8, !noalias !1953, !noundef !2
  %cond.i.i187.i = icmp ne i64 %self.val.i.i186.i, 0
  call void @llvm.assume(i1 %cond.i.i187.i)
  %strong1.i.i188.i = add i64 %self.val.i.i186.i, 1
  store i64 %strong1.i.i188.i, ptr %_12.i185.i, align 8, !noalias !1953
  %_7.i.i189.i = icmp eq i64 %strong1.i.i188.i, 0
  br i1 %_7.i.i189.i, label %bb4.i.i199.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i190.i

bb4.i.i199.i:                                     ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit183.i
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i190.i: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit183.i
  %477 = getelementptr inbounds i8, ptr %_252.i, i64 16
  %_16.i191.i = load ptr, ptr %477, align 8, !alias.scope !1948, !noalias !1951, !nonnull !2, !noundef !2
  %self.val.i1.i192.i = load i64, ptr %_16.i191.i, align 8, !noalias !1953, !noundef !2
  %cond.i2.i193.i = icmp ne i64 %self.val.i1.i192.i, 0
  call void @llvm.assume(i1 %cond.i2.i193.i)
  %strong1.i3.i194.i = add i64 %self.val.i1.i192.i, 1
  store i64 %strong1.i3.i194.i, ptr %_16.i191.i, align 8, !noalias !1953
  %_7.i4.i195.i = icmp eq i64 %strong1.i3.i194.i, 0
  br i1 %_7.i4.i195.i, label %bb4.i5.i198.i, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit200.i"

bb4.i5.i198.i:                                    ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i190.i
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit200.i": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i190.i
  %478 = getelementptr inbounds i8, ptr %_252.i, i64 24
  %_5.i196.i = load ptr, ptr %478, align 8, !alias.scope !1948, !noalias !1951, !nonnull !2, !align !237, !noundef !2
  %479 = getelementptr inbounds i8, ptr %_252.i, i64 32
  %_6.i197.i = load i64, ptr %479, align 8, !alias.scope !1948, !noalias !1951, !noundef !2
  %480 = getelementptr inbounds i8, ptr %_252.i, i64 40
  %481 = load i8, ptr %480, align 8, !range !9, !alias.scope !1948, !noalias !1951, !noundef !2
  %482 = getelementptr inbounds i8, ptr %_252.i, i64 41
  %483 = load i8, ptr %482, align 1, !range !9, !alias.scope !1948, !noalias !1951, !noundef !2
  %484 = getelementptr inbounds i8, ptr %_252.i, i64 42
  %485 = load i8, ptr %484, align 2, !range !9, !alias.scope !1948, !noalias !1951, !noundef !2
  %x12.i = load ptr, ptr %359, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  %_196.i = load ptr, ptr %x12.i, align 8, !noalias !1894, !nonnull !2, !align !237, !noundef !2
  %486 = getelementptr inbounds i8, ptr %x12.i, i64 24
  %_197.i = load ptr, ptr %486, align 8, !noalias !1894, !nonnull !2, !align !237, !noundef !2
  %487 = getelementptr inbounds i8, ptr %x12.i, i64 8
  %_255.i = load ptr, ptr %487, align 8, !noalias !1894, !nonnull !2, !noundef !2
  %self.val.i201.i = load i64, ptr %_255.i, align 8, !noalias !1894, !noundef !2
  %cond.i202.i = icmp ne i64 %self.val.i201.i, 0
  call void @llvm.assume(i1 %cond.i202.i)
  %strong1.i203.i = add i64 %self.val.i201.i, 1
  store i64 %strong1.i203.i, ptr %_255.i, align 8, !noalias !1894
  %_7.i204.i = icmp eq i64 %strong1.i203.i, 0
  br i1 %_7.i204.i, label %bb4.i205.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit206.i

bb4.i205.i:                                       ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit200.i"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit206.i: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit200.i"
  %488 = getelementptr inbounds i8, ptr %x12.i, i64 16
  %_259.i = load ptr, ptr %488, align 8, !noalias !1894, !nonnull !2, !noundef !2
  %self.val.i207.i = load i64, ptr %_259.i, align 8, !noalias !1894, !noundef !2
  %cond.i208.i = icmp ne i64 %self.val.i207.i, 0
  call void @llvm.assume(i1 %cond.i208.i)
  %strong1.i209.i = add i64 %self.val.i207.i, 1
  store i64 %strong1.i209.i, ptr %_259.i, align 8, !noalias !1894
  %_7.i210.i = icmp eq i64 %strong1.i209.i, 0
  br i1 %_7.i210.i, label %bb4.i211.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit212.i

bb4.i211.i:                                       ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit206.i
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit212.i: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit206.i
  %489 = getelementptr inbounds i8, ptr %x12.i, i64 32
  %_98.i = load i64, ptr %489, align 8, !noalias !1894, !noundef !2
  %490 = getelementptr inbounds i8, ptr %x12.i, i64 40
  %491 = load i8, ptr %490, align 8, !range !9, !noalias !1894, !noundef !2
  %492 = getelementptr inbounds i8, ptr %x12.i, i64 41
  %493 = load i8, ptr %492, align 1, !range !9, !noalias !1894, !noundef !2
  %494 = getelementptr inbounds i8, ptr %x12.i, i64 42
  %495 = load i8, ptr %494, align 2, !range !9, !noalias !1894, !noundef !2
  %496 = getelementptr inbounds i8, ptr %_55.i, i64 72
  store ptr %_2.i.i, ptr %496, align 8, !noalias !1890
  %_64.sroa.0.sroa.4.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 80
  store ptr %_12.i.i, ptr %_64.sroa.0.sroa.4.0..sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.5.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 88
  store ptr %_16.i.i, ptr %_64.sroa.0.sroa.5.0..sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.6.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 96
  store ptr %_5.i.i, ptr %_64.sroa.0.sroa.6.0..sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.7.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 104
  store i64 %_6.i.i, ptr %_64.sroa.0.sroa.7.0..sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.8.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 112
  store i8 %375, ptr %_64.sroa.0.sroa.8.0..sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.9.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 113
  store i8 %377, ptr %_64.sroa.0.sroa.9.0..sroa_idx.i, align 1, !noalias !1890
  %_64.sroa.0.sroa.10.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 114
  store i8 %379, ptr %_64.sroa.0.sroa.10.0..sroa_idx.i, align 2, !noalias !1890
  %_64.sroa.0.sroa.12.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 120
  store ptr %_2.i41.i, ptr %_64.sroa.0.sroa.12.0..sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.12.sroa.4.0._64.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 128
  store ptr %_12.i42.i, ptr %_64.sroa.0.sroa.12.sroa.4.0._64.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.12.sroa.5.0._64.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 136
  store ptr %_16.i48.i, ptr %_64.sroa.0.sroa.12.sroa.5.0._64.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.12.sroa.6.0._64.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 144
  store ptr %_5.i53.i, ptr %_64.sroa.0.sroa.12.sroa.6.0._64.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.12.sroa.7.0._64.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 152
  store i64 %_6.i54.i, ptr %_64.sroa.0.sroa.12.sroa.7.0._64.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.12.sroa.8.0._64.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 160
  store i8 %386, ptr %_64.sroa.0.sroa.12.sroa.8.0._64.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.12.sroa.9.0._64.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 161
  store i8 %388, ptr %_64.sroa.0.sroa.12.sroa.9.0._64.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i, align 1, !noalias !1890
  %_64.sroa.0.sroa.12.sroa.10.0._64.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 162
  store i8 %390, ptr %_64.sroa.0.sroa.12.sroa.10.0._64.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i, align 2, !noalias !1890
  %_64.sroa.0.sroa.13.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 168
  store ptr %_2.i58.i, ptr %_64.sroa.0.sroa.13.0..sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.13.sroa.4.0._64.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 176
  store ptr %_12.i59.i, ptr %_64.sroa.0.sroa.13.sroa.4.0._64.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.13.sroa.5.0._64.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 184
  store ptr %_16.i65.i, ptr %_64.sroa.0.sroa.13.sroa.5.0._64.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.13.sroa.6.0._64.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 192
  store ptr %_5.i70.i, ptr %_64.sroa.0.sroa.13.sroa.6.0._64.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.13.sroa.7.0._64.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 200
  store i64 %_6.i71.i, ptr %_64.sroa.0.sroa.13.sroa.7.0._64.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.13.sroa.8.0._64.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 208
  store i8 %397, ptr %_64.sroa.0.sroa.13.sroa.8.0._64.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.13.sroa.9.0._64.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 209
  store i8 %399, ptr %_64.sroa.0.sroa.13.sroa.9.0._64.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i, align 1, !noalias !1890
  %_64.sroa.0.sroa.13.sroa.10.0._64.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 210
  store i8 %401, ptr %_64.sroa.0.sroa.13.sroa.10.0._64.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i, align 2, !noalias !1890
  %_64.sroa.0.sroa.14.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 216
  store ptr %_2.i75.i, ptr %_64.sroa.0.sroa.14.0..sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.14.sroa.4.0._64.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 224
  store ptr %_12.i76.i, ptr %_64.sroa.0.sroa.14.sroa.4.0._64.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.14.sroa.5.0._64.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 232
  store ptr %_16.i82.i, ptr %_64.sroa.0.sroa.14.sroa.5.0._64.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.14.sroa.6.0._64.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 240
  store ptr %_5.i87.i, ptr %_64.sroa.0.sroa.14.sroa.6.0._64.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.14.sroa.7.0._64.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 248
  store i64 %_6.i88.i, ptr %_64.sroa.0.sroa.14.sroa.7.0._64.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.14.sroa.8.0._64.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 256
  store i8 %407, ptr %_64.sroa.0.sroa.14.sroa.8.0._64.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.14.sroa.9.0._64.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 257
  store i8 %409, ptr %_64.sroa.0.sroa.14.sroa.9.0._64.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i, align 1, !noalias !1890
  %_64.sroa.0.sroa.14.sroa.10.0._64.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 258
  store i8 %411, ptr %_64.sroa.0.sroa.14.sroa.10.0._64.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i, align 2, !noalias !1890
  %_64.sroa.0.sroa.15.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 264
  store ptr %_2.i92.i, ptr %_64.sroa.0.sroa.15.0..sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.15.sroa.4.0._64.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 272
  store ptr %_12.i93.i, ptr %_64.sroa.0.sroa.15.sroa.4.0._64.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.15.sroa.5.0._64.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 280
  store ptr %_16.i99.i, ptr %_64.sroa.0.sroa.15.sroa.5.0._64.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.15.sroa.6.0._64.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 288
  store ptr %_5.i104.i, ptr %_64.sroa.0.sroa.15.sroa.6.0._64.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.15.sroa.7.0._64.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 296
  store i64 %_6.i105.i, ptr %_64.sroa.0.sroa.15.sroa.7.0._64.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.15.sroa.8.0._64.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 304
  store i8 %418, ptr %_64.sroa.0.sroa.15.sroa.8.0._64.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.15.sroa.9.0._64.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 305
  store i8 %420, ptr %_64.sroa.0.sroa.15.sroa.9.0._64.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i, align 1, !noalias !1890
  %_64.sroa.0.sroa.15.sroa.10.0._64.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 306
  store i8 %422, ptr %_64.sroa.0.sroa.15.sroa.10.0._64.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i, align 2, !noalias !1890
  %_64.sroa.0.sroa.16.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 312
  store ptr %_2.i109.i, ptr %_64.sroa.0.sroa.16.0..sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.16.sroa.4.0._64.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 320
  store ptr %_12.i110.i, ptr %_64.sroa.0.sroa.16.sroa.4.0._64.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.16.sroa.5.0._64.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 328
  store ptr %_16.i116.i, ptr %_64.sroa.0.sroa.16.sroa.5.0._64.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.16.sroa.6.0._64.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 336
  store ptr %_5.i121.i, ptr %_64.sroa.0.sroa.16.sroa.6.0._64.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.16.sroa.7.0._64.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 344
  store i64 %_6.i122.i, ptr %_64.sroa.0.sroa.16.sroa.7.0._64.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.16.sroa.8.0._64.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 352
  store i8 %428, ptr %_64.sroa.0.sroa.16.sroa.8.0._64.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.16.sroa.9.0._64.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 353
  store i8 %430, ptr %_64.sroa.0.sroa.16.sroa.9.0._64.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i, align 1, !noalias !1890
  %_64.sroa.0.sroa.16.sroa.10.0._64.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 354
  store i8 %432, ptr %_64.sroa.0.sroa.16.sroa.10.0._64.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i, align 2, !noalias !1890
  %_64.sroa.0.sroa.16.sroa.11.0._64.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 355
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_64.sroa.0.sroa.16.sroa.11.0._64.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i, ptr noundef nonnull align 1 dereferenceable(5) %_64.sroa.0.sroa.16.sroa.11.i, i64 5, i1 false), !noalias !1890
  %_64.sroa.0.sroa.17.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 360
  store ptr %_2.i126.i, ptr %_64.sroa.0.sroa.17.0..sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.17.sroa.4.0._64.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 368
  store ptr %_12.i127.i, ptr %_64.sroa.0.sroa.17.sroa.4.0._64.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.17.sroa.5.0._64.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 376
  store ptr %_16.i133.i, ptr %_64.sroa.0.sroa.17.sroa.5.0._64.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.17.sroa.6.0._64.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 384
  store ptr %_5.i138.i, ptr %_64.sroa.0.sroa.17.sroa.6.0._64.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.17.sroa.7.0._64.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 392
  store i64 %_6.i139.i, ptr %_64.sroa.0.sroa.17.sroa.7.0._64.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.17.sroa.8.0._64.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 400
  store i8 %439, ptr %_64.sroa.0.sroa.17.sroa.8.0._64.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.0.sroa.17.sroa.9.0._64.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 401
  store i8 %441, ptr %_64.sroa.0.sroa.17.sroa.9.0._64.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i, align 1, !noalias !1890
  %_64.sroa.0.sroa.17.sroa.10.0._64.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 402
  store i8 %443, ptr %_64.sroa.0.sroa.17.sroa.10.0._64.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i, align 2, !noalias !1890
  %_64.sroa.0.sroa.17.sroa.11.0._64.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 403
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_64.sroa.0.sroa.17.sroa.11.0._64.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i, ptr noundef nonnull align 1 dereferenceable(5) %_64.sroa.0.sroa.17.sroa.11.i, i64 5, i1 false), !noalias !1890
  %_64.sroa.10.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 408
  store ptr %_192.i, ptr %_64.sroa.10.0..sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.11.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 416
  store ptr %_238.i154, ptr %_64.sroa.11.0..sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.12.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 424
  store ptr %_242.i, ptr %_64.sroa.12.0..sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.13.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 432
  store ptr %_193.i, ptr %_64.sroa.13.0..sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.14.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 440
  store i64 %_77.i, ptr %_64.sroa.14.0..sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.15.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 448
  store i8 %449, ptr %_64.sroa.15.0..sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.16.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 449
  store i8 %451, ptr %_64.sroa.16.0..sroa_idx.i, align 1, !noalias !1890
  %_64.sroa.17.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 450
  store i8 %453, ptr %_64.sroa.17.0..sroa_idx.i, align 2, !noalias !1890
  %_64.sroa.18.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 451
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_64.sroa.18.0..sroa_idx.i, ptr noundef nonnull align 1 dereferenceable(5) %_64.sroa.18.i, i64 5, i1 false), !noalias !1890
  %_64.sroa.19.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 456
  store ptr %_2.i155.i, ptr %_64.sroa.19.0..sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.19.sroa.4.0._64.sroa.19.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 464
  store ptr %_12.i156.i, ptr %_64.sroa.19.sroa.4.0._64.sroa.19.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.19.sroa.5.0._64.sroa.19.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 472
  store ptr %_16.i162.i, ptr %_64.sroa.19.sroa.5.0._64.sroa.19.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.19.sroa.6.0._64.sroa.19.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 480
  store ptr %_5.i167.i, ptr %_64.sroa.19.sroa.6.0._64.sroa.19.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.19.sroa.7.0._64.sroa.19.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 488
  store i64 %_6.i168.i, ptr %_64.sroa.19.sroa.7.0._64.sroa.19.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.19.sroa.8.0._64.sroa.19.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 496
  store i8 %459, ptr %_64.sroa.19.sroa.8.0._64.sroa.19.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.19.sroa.9.0._64.sroa.19.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 497
  store i8 %461, ptr %_64.sroa.19.sroa.9.0._64.sroa.19.0..sroa_idx.sroa_idx.i, align 1, !noalias !1890
  %_64.sroa.19.sroa.10.0._64.sroa.19.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 498
  store i8 %463, ptr %_64.sroa.19.sroa.10.0._64.sroa.19.0..sroa_idx.sroa_idx.i, align 2, !noalias !1890
  %_64.sroa.19.sroa.11.0._64.sroa.19.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 499
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_64.sroa.19.sroa.11.0._64.sroa.19.0..sroa_idx.sroa_idx.i, ptr noundef nonnull align 1 dereferenceable(5) %_64.sroa.19.sroa.11.i, i64 5, i1 false), !noalias !1890
  %_64.sroa.20.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 504
  store ptr %_194.i, ptr %_64.sroa.20.0..sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.20.sroa.4.0._64.sroa.20.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 512
  store ptr %_250.i, ptr %_64.sroa.20.sroa.4.0._64.sroa.20.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.20.sroa.5.0._64.sroa.20.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 520
  store ptr %_246.i, ptr %_64.sroa.20.sroa.5.0._64.sroa.20.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.20.sroa.6.0._64.sroa.20.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 528
  store ptr %_195.i, ptr %_64.sroa.20.sroa.6.0._64.sroa.20.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.20.sroa.7.0._64.sroa.20.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 536
  store i64 %_89.i, ptr %_64.sroa.20.sroa.7.0._64.sroa.20.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.20.sroa.8.0._64.sroa.20.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 544
  store i8 %470, ptr %_64.sroa.20.sroa.8.0._64.sroa.20.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.20.sroa.9.0._64.sroa.20.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 545
  store i8 %472, ptr %_64.sroa.20.sroa.9.0._64.sroa.20.0..sroa_idx.sroa_idx.i, align 1, !noalias !1890
  %_64.sroa.20.sroa.10.0._64.sroa.20.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 546
  store i8 %474, ptr %_64.sroa.20.sroa.10.0._64.sroa.20.0..sroa_idx.sroa_idx.i, align 2, !noalias !1890
  %_64.sroa.20.sroa.11.0._64.sroa.20.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 547
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_64.sroa.20.sroa.11.0._64.sroa.20.0..sroa_idx.sroa_idx.i, ptr noundef nonnull align 1 dereferenceable(5) %_64.sroa.20.sroa.11.i, i64 5, i1 false), !noalias !1890
  %_64.sroa.21.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 552
  store ptr %_2.i184.i, ptr %_64.sroa.21.0..sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.21.sroa.4.0._64.sroa.21.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 560
  store ptr %_12.i185.i, ptr %_64.sroa.21.sroa.4.0._64.sroa.21.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.21.sroa.5.0._64.sroa.21.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 568
  store ptr %_16.i191.i, ptr %_64.sroa.21.sroa.5.0._64.sroa.21.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.21.sroa.6.0._64.sroa.21.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 576
  store ptr %_5.i196.i, ptr %_64.sroa.21.sroa.6.0._64.sroa.21.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.21.sroa.7.0._64.sroa.21.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 584
  store i64 %_6.i197.i, ptr %_64.sroa.21.sroa.7.0._64.sroa.21.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.21.sroa.8.0._64.sroa.21.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 592
  store i8 %481, ptr %_64.sroa.21.sroa.8.0._64.sroa.21.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.21.sroa.9.0._64.sroa.21.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 593
  store i8 %483, ptr %_64.sroa.21.sroa.9.0._64.sroa.21.0..sroa_idx.sroa_idx.i, align 1, !noalias !1890
  %_64.sroa.21.sroa.10.0._64.sroa.21.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 594
  store i8 %485, ptr %_64.sroa.21.sroa.10.0._64.sroa.21.0..sroa_idx.sroa_idx.i, align 2, !noalias !1890
  %_64.sroa.21.sroa.11.0._64.sroa.21.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 595
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_64.sroa.21.sroa.11.0._64.sroa.21.0..sroa_idx.sroa_idx.i, ptr noundef nonnull align 1 dereferenceable(5) %_64.sroa.21.sroa.11.i, i64 5, i1 false), !noalias !1890
  %_64.sroa.22.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 600
  store ptr %_196.i, ptr %_64.sroa.22.0..sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.22.sroa.4.0._64.sroa.22.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 608
  store ptr %_255.i, ptr %_64.sroa.22.sroa.4.0._64.sroa.22.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.22.sroa.5.0._64.sroa.22.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 616
  store ptr %_259.i, ptr %_64.sroa.22.sroa.5.0._64.sroa.22.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.22.sroa.6.0._64.sroa.22.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 624
  store ptr %_197.i, ptr %_64.sroa.22.sroa.6.0._64.sroa.22.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.22.sroa.7.0._64.sroa.22.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 632
  store i64 %_98.i, ptr %_64.sroa.22.sroa.7.0._64.sroa.22.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.22.sroa.8.0._64.sroa.22.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 640
  store i8 %491, ptr %_64.sroa.22.sroa.8.0._64.sroa.22.0..sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_64.sroa.22.sroa.9.0._64.sroa.22.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 641
  store i8 %493, ptr %_64.sroa.22.sroa.9.0._64.sroa.22.0..sroa_idx.sroa_idx.i, align 1, !noalias !1890
  %_64.sroa.22.sroa.10.0._64.sroa.22.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 642
  store i8 %495, ptr %_64.sroa.22.sroa.10.0._64.sroa.22.0..sroa_idx.sroa_idx.i, align 2, !noalias !1890
  %_64.sroa.22.sroa.11.0._64.sroa.22.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 643
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_64.sroa.22.sroa.11.0._64.sroa.22.0..sroa_idx.sroa_idx.i, ptr noundef nonnull align 1 dereferenceable(5) %_64.sroa.22.sroa.11.i, i64 5, i1 false), !noalias !1890
  store i64 0, ptr %_55.i, align 8, !noalias !1890
  %_261.sroa.4.0._55.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 8
  store ptr inttoptr (i64 8 to ptr), ptr %_261.sroa.4.0._55.sroa_idx.i, align 8, !noalias !1890
  %_261.sroa.5.0._55.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 16
  store i64 0, ptr %_261.sroa.5.0._55.sroa_idx.i, align 8, !noalias !1890
  %497 = getelementptr inbounds i8, ptr %_55.i, i64 24
  store ptr %_190.i, ptr %497, align 8, !noalias !1890
  %_56.sroa.4.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 32
  store ptr %_224.i, ptr %_56.sroa.4.0..sroa_idx.i, align 8, !noalias !1890
  %_56.sroa.5.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 40
  store ptr %_228.i, ptr %_56.sroa.5.0..sroa_idx.i, align 8, !noalias !1890
  %_56.sroa.6.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 48
  store ptr %_189.i, ptr %_56.sroa.6.0..sroa_idx.i, align 8, !noalias !1890
  %_56.sroa.7.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 56
  store i64 %_60.i148, ptr %_56.sroa.7.0..sroa_idx.i, align 8, !noalias !1890
  %_56.sroa.8.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 64
  store i8 %369, ptr %_56.sroa.8.0..sroa_idx.i, align 8, !noalias !1890
  %_56.sroa.9.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 65
  store i8 %367, ptr %_56.sroa.9.0..sroa_idx.i, align 1, !noalias !1890
  %_56.sroa.10.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 66
  store i8 %365, ptr %_56.sroa.10.0..sroa_idx.i, align 2, !noalias !1890
  %_56.sroa.11.0..sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 67
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_56.sroa.11.0..sroa_idx.i, ptr noundef nonnull align 1 dereferenceable(5) %_56.sroa.11.i, i64 5, i1 false), !noalias !1890
  %498 = getelementptr inbounds i8, ptr %_55.i, i64 648
  store ptr inttoptr (i64 8 to ptr), ptr %498, align 8, !noalias !1890
  %499 = getelementptr inbounds i8, ptr %_55.i, i64 656
  store i64 0, ptr %499, align 8, !noalias !1890
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_64.sroa.0.sroa.16.sroa.11.i)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_64.sroa.0.sroa.17.sroa.11.i)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_64.sroa.18.i)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_64.sroa.19.sroa.11.i)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_64.sroa.20.sroa.11.i)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_64.sroa.21.sroa.11.i)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_64.sroa.22.sroa.11.i)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_56.sroa.11.i)
  %500 = call { i64, ptr } @_ZN14pump_recovered8pump_amm3cpi32transfer_creator_fees_to_pump_v217he7f9c8783c313da6E(ptr noalias nocapture noundef nonnull align 8 dereferenceable(664) %_55.i) #37, !noalias !1894
  %501 = extractvalue { i64, ptr } %500, 0
  call void @llvm.lifetime.end.p0(i64 664, ptr nonnull %_55.i), !noalias !1890
  %502 = icmp eq i64 %501, 2
  br i1 %502, label %bb25.i, label %bb82.i156

bb82.i156:                                        ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit212.i
  %503 = extractvalue { i64, ptr } %500, 1
  %504 = ptrtoint ptr %503 to i64
  br label %bb56.i119

bb25.i:                                           ; preds = %bb63.i, %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit212.i, %bb20.i146
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %vsigner.i), !noalias !1890
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %old.i), !noalias !1890
  %505 = getelementptr inbounds i8, ptr %_247, i64 168
  %_267.i = load ptr, ptr %505, align 8, !noalias !1890, !nonnull !2, !align !237, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %old.i, ptr noundef nonnull align 1 dereferenceable(32) %_267.i, i64 32, i1 false), !noalias !1894
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_108.i), !noalias !1890
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %_113.i), !noalias !1890
  store i8 %ctx.val75, ptr %_113.i, align 1, !noalias !1890
  store ptr @alloc_ed0c7b53f6fd188c408cb80c27c2e0f7, ptr %_108.i, align 8, !noalias !1890
  %506 = getelementptr inbounds i8, ptr %_108.i, i64 8
  store i64 13, ptr %506, align 8, !noalias !1890
  %507 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_108.i, i64 0, i64 1
  store ptr %old.i, ptr %507, align 8, !noalias !1890
  %508 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_108.i, i64 0, i64 1, i32 1
  store i64 32, ptr %508, align 8, !noalias !1890
  %509 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_108.i, i64 0, i64 2
  store ptr %_113.i, ptr %509, align 8, !noalias !1890
  %510 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_108.i, i64 0, i64 2, i32 1
  store i64 1, ptr %510, align 8, !noalias !1890
  store ptr %_108.i, ptr %vsigner.i, align 8, !noalias !1890
  %511 = getelementptr inbounds i8, ptr %vsigner.i, i64 8
  store i64 3, ptr %511, align 8, !noalias !1890
  br i1 %329, label %bb26.i140, label %bb34.i

bb63.i:                                           ; preds = %bb13.i128
  %_218.i = load i64, ptr %358, align 8, !noalias !1890, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_38.i108), !noalias !1890
  %512 = icmp eq i64 %_218.i, 0
  br i1 %512, label %bb25.i, label %bb16.i130

bb62.i:                                           ; preds = %bb13.i128
  %_219.1.i = load ptr, ptr %358, align 8, !noalias !1890, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_38.i108), !noalias !1890
  %513 = ptrtoint ptr %_219.1.i to i64
  br label %bb56.i119

bb16.i130:                                        ; preds = %bb63.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_43.i), !noalias !1890
  %514 = getelementptr inbounds i8, ptr %_43.i, i64 32
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %514, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_cd7b816cab57a667caebec1ad637a70c) #37, !noalias !1894
  %515 = getelementptr inbounds i8, ptr %_43.i, i64 56
  call fastcc void @"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %515, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_cd7b816cab57a667caebec1ad637a70c) #37, !noalias !1894
  %516 = getelementptr inbounds i8, ptr %_43.i, i64 152
  store i32 6093, ptr %516, align 8, !noalias !1890
  store i64 0, ptr %_43.i, align 8, !noalias !1890
  %_47.sroa.4.0._43.sroa_idx.i = getelementptr inbounds i8, ptr %_43.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_47.sroa.4.0._43.sroa_idx.i, align 8, !noalias !1890
  %_47.sroa.4.sroa.4.0._47.sroa.4.0._43.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_43.i, i64 16
  store i64 38, ptr %_47.sroa.4.sroa.4.0._47.sroa.4.0._43.sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_47.sroa.4.sroa.5.0._47.sroa.4.0._43.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_43.i, i64 24
  store i32 660, ptr %_47.sroa.4.sroa.5.0._47.sroa.4.0._43.sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %517 = getelementptr inbounds i8, ptr %_43.i, i64 80
  store i8 2, ptr %517, align 8, !noalias !1890
  %518 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_43.i) #37, !noalias !1894
  %_42.0.i = extractvalue { i64, ptr } %518, 0
  %_42.1.i = extractvalue { i64, ptr } %518, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_43.i), !noalias !1890
  %519 = ptrtoint ptr %_42.1.i to i64
  br label %bb56.i119

bb34.i:                                           ; preds = %bb25.i
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_141.i), !noalias !1890
  %520 = getelementptr inbounds i8, ptr %_247, i64 72
  %_142.i131 = load ptr, ptr %520, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  call fastcc void @_ZN14pump_recovered9admin_cto12token_frozen17h1658d4a62a0640cfE(ptr noalias nocapture noundef nonnull align 8 dereferenceable(16) %_141.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_142.i131) #37, !noalias !1894
  %521 = load i64, ptr %_141.i, align 8, !range !239, !noalias !1890, !noundef !2
  %522 = icmp eq i64 %521, 2
  %523 = getelementptr inbounds i8, ptr %_141.i, i64 8
  br i1 %522, label %bb94.i, label %bb93.i

bb26.i140:                                        ; preds = %bb25.i
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %rent.i), !noalias !1890
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_117.i), !noalias !1890
  call void @"_ZN13solana_sysvar4rent69_$LT$impl$u20$solana_sysvar..Sysvar$u20$for$u20$solana_rent..Rent$GT$3get17hd4b89a48ea901882E"(ptr noalias nocapture noundef nonnull sret([32 x i8]) align 8 dereferenceable(32) %_117.i) #37, !noalias !1894
  %_269.i = load i64, ptr %_117.i, align 8, !range !5, !noalias !1890, !noundef !2
  %trunc.not.i141 = icmp eq i64 %_269.i, 0
  %524 = getelementptr inbounds i8, ptr %_117.i, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_116.sroa.5.i, ptr noundef nonnull align 8 dereferenceable(24) %524, i64 24, i1 false), !noalias !1890
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_117.i), !noalias !1890
  br i1 %trunc.not.i141, label %bb85.i, label %bb84.i142

bb94.i:                                           ; preds = %bb34.i
  %525 = load i8, ptr %523, align 8, !range !9, !noalias !1890, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_141.i), !noalias !1890
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_147.i107), !noalias !1890
  %_148.i = load ptr, ptr %520, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  call fastcc void @_ZN14pump_recovered9admin_cto16token_raw_amount17h5c5bab1f81c4ceb2E(ptr noalias nocapture noundef nonnull align 8 dereferenceable(16) %_147.i107, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_148.i) #37, !noalias !1894
  %526 = load i64, ptr %_147.i107, align 8, !range !239, !noalias !1890, !noundef !2
  %527 = icmp eq i64 %526, 2
  br i1 %527, label %bb96.i, label %bb95.i

bb93.i:                                           ; preds = %bb34.i
  %_284.1.i = load ptr, ptr %523, align 8, !noalias !1890, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_141.i), !noalias !1890
  %528 = ptrtoint ptr %_284.1.i to i64
  br label %bb52.i

bb96.i:                                           ; preds = %bb94.i
  %_283.not.i = icmp eq i8 %525, 0
  %529 = getelementptr inbounds i8, ptr %_147.i107, i64 8
  %_288.i = load i64, ptr %529, align 8, !noalias !1890, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_147.i107), !noalias !1890
  %_161.not.i = icmp eq i64 %_288.i, 0
  br i1 %_283.not.i, label %bb43.i136, label %bb37.i132

bb95.i:                                           ; preds = %bb94.i
  %530 = getelementptr inbounds i8, ptr %_147.i107, i64 8
  %_289.1.i = load ptr, ptr %530, align 8, !noalias !1890, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_147.i107), !noalias !1890
  %531 = ptrtoint ptr %_289.1.i to i64
  br label %bb52.i

bb43.i136:                                        ; preds = %bb96.i
  br i1 %_161.not.i, label %bb48.i135, label %bb44.i137

bb37.i132:                                        ; preds = %bb96.i
  br i1 %_161.not.i, label %bb48.i135, label %bb39.i133

bb44.i137:                                        ; preds = %bb43.i136
  call void @llvm.lifetime.start.p0(i64 376, ptr nonnull %_166.i), !noalias !1890
  %532 = getelementptr inbounds i8, ptr %_247, i64 40
  %_292.i = load ptr, ptr %532, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  %533 = getelementptr inbounds i8, ptr %_166.i, i64 24
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %533, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_292.i) #37, !noalias !1894
  call void @llvm.lifetime.start.p0(i64 288, ptr nonnull %_168.i), !noalias !1890
  %_293.i = load ptr, ptr %_247, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %_168.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_293.i) #37, !noalias !1894
  %534 = getelementptr inbounds i8, ptr %_247, i64 80
  %_294.i = load ptr, ptr %534, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  %535 = getelementptr inbounds i8, ptr %_168.i, i64 48
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %535, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_294.i) #37, !noalias !1894
  %536 = getelementptr inbounds i8, ptr %_168.i, i64 96
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %536, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %333) #37, !noalias !1894
  %_198.i = load ptr, ptr %326, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  %537 = getelementptr inbounds i8, ptr %_198.i, i64 88
  %_295.i = load ptr, ptr %537, align 8, !noalias !1894, !nonnull !2, !align !4, !noundef !2
  %538 = getelementptr inbounds i8, ptr %_168.i, i64 144
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %538, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_295.i) #37, !noalias !1894
  %_296.i = load ptr, ptr %_54, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  %539 = getelementptr inbounds i8, ptr %_168.i, i64 192
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %539, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_296.i) #37, !noalias !1894
  %540 = getelementptr inbounds i8, ptr %_247, i64 32
  %_297.i = load ptr, ptr %540, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  %541 = getelementptr inbounds i8, ptr %_168.i, i64 240
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %541, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_297.i) #37, !noalias !1894
  %542 = getelementptr inbounds i8, ptr %_166.i, i64 72
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(288) %542, ptr noundef nonnull align 8 dereferenceable(288) %_168.i, i64 288, i1 false), !noalias !1890
  store i64 0, ptr %_166.i, align 8, !noalias !1890
  %_298.sroa.4.0._166.sroa_idx.i = getelementptr inbounds i8, ptr %_166.i, i64 8
  store ptr inttoptr (i64 8 to ptr), ptr %_298.sroa.4.0._166.sroa_idx.i, align 8, !noalias !1890
  %_298.sroa.5.0._166.sroa_idx.i = getelementptr inbounds i8, ptr %_166.i, i64 16
  store i64 0, ptr %_298.sroa.5.0._166.sroa_idx.i, align 8, !noalias !1890
  %543 = getelementptr inbounds i8, ptr %_166.i, i64 360
  store ptr inttoptr (i64 8 to ptr), ptr %543, align 8, !noalias !1890
  %544 = getelementptr inbounds i8, ptr %_166.i, i64 368
  store i64 0, ptr %544, align 8, !noalias !1890
  call void @llvm.lifetime.end.p0(i64 288, ptr nonnull %_168.i), !noalias !1890
  %545 = call { i64, ptr } @_ZN10anchor_spl16associated_token17create_idempotent17h6d66b04320e05cf1E(ptr noalias nocapture noundef nonnull align 8 dereferenceable(376) %_166.i) #37, !noalias !1894
  %546 = extractvalue { i64, ptr } %545, 0
  call void @llvm.lifetime.end.p0(i64 376, ptr nonnull %_166.i), !noalias !1890
  %547 = icmp eq i64 %546, 2
  br i1 %547, label %bb106.i, label %bb108.i138

bb106.i:                                          ; preds = %bb44.i137
  %_178.i = getelementptr inbounds i8, ptr %_247, i64 216
  %_310.i = load ptr, ptr %326, align 8, !noalias !1890, !nonnull !2, !noundef !2
  %548 = getelementptr inbounds i8, ptr %_310.i, i64 48
  %_302.i = load i8, ptr %548, align 8, !noalias !1894, !noundef !2
  %549 = getelementptr inbounds i8, ptr %_310.i, i64 88
  %_303.i = load ptr, ptr %549, align 8, !noalias !1894, !nonnull !2, !align !4, !noundef !2
  %550 = call { i64, ptr } @_ZN14pump_recovered8payments29collect_transfer_vault_tokens17hc9f594ce95aedac6E(ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %540, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %520, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %534, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_178.i, i8 noundef %_302.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_303.i, i64 noundef %_288.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(16) %vsigner.i) #37, !noalias !1894
  %551 = extractvalue { i64, ptr } %550, 0
  %552 = icmp eq i64 %551, 2
  br i1 %552, label %bb52.i, label %bb108.i138

bb108.i138:                                       ; preds = %bb106.i, %bb44.i137
  %_164.sroa.0.0.i = phi i64 [ %551, %bb106.i ], [ %546, %bb44.i137 ]
  %.pn.i139 = phi { i64, ptr } [ %550, %bb106.i ], [ %545, %bb44.i137 ]
  %_164.sroa.7.0.i = extractvalue { i64, ptr } %.pn.i139, 1
  %553 = ptrtoint ptr %_164.sroa.7.0.i to i64
  br label %bb52.i

bb39.i133:                                        ; preds = %bb37.i132
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_153.i), !noalias !1890
  %554 = getelementptr inbounds i8, ptr %_153.i, i64 32
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %554, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_cd7b816cab57a667caebec1ad637a70c) #37, !noalias !1894
  %555 = getelementptr inbounds i8, ptr %_153.i, i64 56
  call fastcc void @"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %555, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_cd7b816cab57a667caebec1ad637a70c) #37, !noalias !1894
  %556 = getelementptr inbounds i8, ptr %_153.i, i64 152
  store i32 6093, ptr %556, align 8, !noalias !1890
  store i64 0, ptr %_153.i, align 8, !noalias !1890
  %_157.sroa.4.0._153.sroa_idx.i = getelementptr inbounds i8, ptr %_153.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_157.sroa.4.0._153.sroa_idx.i, align 8, !noalias !1890
  %_157.sroa.4.sroa.4.0._157.sroa.4.0._153.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_153.i, i64 16
  store i64 38, ptr %_157.sroa.4.sroa.4.0._157.sroa.4.0._153.sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %_157.sroa.4.sroa.5.0._157.sroa.4.0._153.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_153.i, i64 24
  store i32 719, ptr %_157.sroa.4.sroa.5.0._157.sroa.4.0._153.sroa_idx.sroa_idx.i, align 8, !noalias !1890
  %557 = getelementptr inbounds i8, ptr %_153.i, i64 80
  store i8 2, ptr %557, align 8, !noalias !1890
  %558 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_153.i) #37, !noalias !1894
  %_152.0.i = extractvalue { i64, ptr } %558, 0
  %_152.1.i = extractvalue { i64, ptr } %558, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_153.i), !noalias !1890
  %559 = ptrtoint ptr %_152.1.i to i64
  br label %bb52.i

bb48.i135:                                        ; preds = %bb85.i, %bb89.i145, %bb43.i136, %bb37.i132, %bb91.i
  %_397.sroa.0.0 = phi i64 [ %567, %bb91.i ], [ 2, %bb37.i132 ], [ 2, %bb43.i136 ], [ 2, %bb89.i145 ], [ 2, %bb85.i ]
  %_397.sroa.18.0 = phi i64 [ %572, %bb91.i ], [ 0, %bb37.i132 ], [ 0, %bb43.i136 ], [ %560, %bb89.i145 ], [ %560, %bb85.i ]
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %_113.i), !noalias !1890
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_108.i), !noalias !1890
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %old.i), !noalias !1890
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %vsigner.i), !noalias !1890
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %dest.i), !noalias !1890
  br label %_ZN14pump_recovered9admin_cto7execute5sweep17h9943ff4781c7e018E.exit

bb52.i:                                           ; preds = %bb106.i, %bb88.i, %bb84.i142, %bb39.i133, %bb108.i138, %bb95.i, %bb93.i
  %_397.sroa.0.1 = phi i64 [ %564, %bb88.i ], [ %_274.0.i, %bb84.i142 ], [ %_164.sroa.0.0.i, %bb108.i138 ], [ %_152.0.i, %bb39.i133 ], [ %526, %bb95.i ], [ %521, %bb93.i ], [ 2, %bb106.i ]
  %_397.sroa.18.1 = phi i64 [ %570, %bb88.i ], [ %562, %bb84.i142 ], [ %553, %bb108.i138 ], [ %559, %bb39.i133 ], [ %531, %bb95.i ], [ %528, %bb93.i ], [ %_288.i, %bb106.i ]
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %_113.i), !noalias !1890
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_108.i), !noalias !1890
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %old.i), !noalias !1890
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %vsigner.i), !noalias !1890
  br label %bb56.i119

bb85.i:                                           ; preds = %bb26.i140
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %rent.i, ptr noundef nonnull align 8 dereferenceable(24) %_116.sroa.5.i, i64 24, i1 false), !noalias !1890
  %min.i = call noundef i64 @_ZN11solana_rent4Rent15minimum_balance17h06f7367e702730e1E(ptr noalias noundef nonnull readonly align 8 dereferenceable(24) %rent.i, i64 noundef 0) #37, !noalias !1894
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %rent.i), !noalias !1890
  %_123.i143 = getelementptr inbounds i8, ptr %_247, i64 216
  %_122.i = call noundef i64 @_ZN19solana_account_info11AccountInfo8lamports17h0ca2b04e77f2c7d8E(ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_123.i143) #37, !noalias !1894
  %560 = call i64 @llvm.usub.sat.i64(i64 %_122.i, i64 %min.i)
  %_125.not.not.i = icmp ugt i64 %_122.i, %min.i
  br i1 %_125.not.not.i, label %bb30.i, label %bb48.i135

bb84.i142:                                        ; preds = %bb26.i140
  %561 = call { i64, ptr } @"_ZN107_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$solana_program_error..ProgramError$GT$$GT$4from17ha4865197be4b9a2fE"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(24) %_116.sroa.5.i) #37, !noalias !1894
  %_274.0.i = extractvalue { i64, ptr } %561, 0
  %_274.1.i = extractvalue { i64, ptr } %561, 1
  %562 = ptrtoint ptr %_274.1.i to i64
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %rent.i), !noalias !1890
  br label %bb52.i

bb30.i:                                           ; preds = %bb85.i
  %563 = call { i64, ptr } @_ZN14pump_recovered22legacy_native_payments18ensure_rent_exempt17h8f9b2dcab7b02290E(ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %_54, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %_247, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %333) #37, !noalias !1894
  %564 = extractvalue { i64, ptr } %563, 0
  %565 = icmp eq i64 %564, 2
  br i1 %565, label %bb89.i145, label %bb88.i

bb89.i145:                                        ; preds = %bb30.i
  %_133.i = load ptr, ptr %_54, align 8, !noalias !1890, !nonnull !2, !align !4, !noundef !2
  %566 = call fastcc { i64, ptr } @_ZN14pump_recovered8payments23collect_transfer_native17h5f701d700d8b4137E(ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_133.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_123.i143, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %333, i64 noundef %560, ptr noalias noundef nonnull readonly align 8 %vsigner.i, i64 noundef 1) #37, !noalias !1894
  %567 = extractvalue { i64, ptr } %566, 0
  %568 = icmp eq i64 %567, 2
  br i1 %568, label %bb48.i135, label %bb91.i

bb88.i:                                           ; preds = %bb30.i
  %569 = extractvalue { i64, ptr } %563, 1
  %570 = ptrtoint ptr %569 to i64
  br label %bb52.i

bb91.i:                                           ; preds = %bb89.i145
  %571 = extractvalue { i64, ptr } %566, 1
  %572 = ptrtoint ptr %571 to i64
  br label %bb48.i135

bb56.i119:                                        ; preds = %bb52.i, %bb16.i130, %bb62.i, %bb82.i156, %bb60.i126, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h4b386cbefe3ebd9eE.exit.i"
  %_397.sroa.0.2 = phi i64 [ %_397.sroa.0.1, %bb52.i ], [ %501, %bb82.i156 ], [ %_42.0.i, %bb16.i130 ], [ %356, %bb62.i ], [ %351, %bb60.i126 ], [ %_15.0.i, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h4b386cbefe3ebd9eE.exit.i" ]
  %_397.sroa.18.2 = phi i64 [ %_397.sroa.18.1, %bb52.i ], [ %504, %bb82.i156 ], [ %519, %bb16.i130 ], [ %513, %bb62.i ], [ %355, %bb60.i126 ], [ %350, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h4b386cbefe3ebd9eE.exit.i" ]
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %dest.i), !noalias !1890
  br label %_ZN14pump_recovered9admin_cto7execute5sweep17h9943ff4781c7e018E.exit

_ZN14pump_recovered9admin_cto7execute5sweep17h9943ff4781c7e018E.exit: ; preds = %bb48.i135, %bb56.i119
  %_397.sroa.0.3 = phi i64 [ %_397.sroa.0.0, %bb48.i135 ], [ %_397.sroa.0.2, %bb56.i119 ]
  %_397.sroa.18.3 = phi i64 [ %_397.sroa.18.0, %bb48.i135 ], [ %_397.sroa.18.2, %bb56.i119 ]
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_116.sroa.5.i)
  %573 = icmp eq i64 %_397.sroa.0.3, 2
  br i1 %573, label %bb75, label %bb74

bb75:                                             ; preds = %_ZN14pump_recovered9admin_cto7execute5sweep17h9943ff4781c7e018E.exit, %bb23
  %_72.sroa.0.0 = phi i64 [ 0, %bb23 ], [ %_397.sroa.18.3, %_ZN14pump_recovered9admin_cto7execute5sweep17h9943ff4781c7e018E.exit ]
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_83)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_86)
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %_91)
  %574 = getelementptr inbounds i8, ptr %ctx, i64 39
  %_92 = load i8, ptr %574, align 1, !noundef !2
  store i8 %_92, ptr %_91, align 1
  store ptr @alloc_837d2dfc2ca6132d7e624d246f381ca4, ptr %_86, align 8
  %575 = getelementptr inbounds i8, ptr %_86, i64 8
  store i64 14, ptr %575, align 8
  %576 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_86, i64 0, i64 1
  store ptr %mint, ptr %576, align 8
  %577 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_86, i64 0, i64 1, i32 1
  store i64 32, ptr %577, align 8
  %578 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_86, i64 0, i64 2
  store ptr %_91, ptr %578, align 8
  %579 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_86, i64 0, i64 2, i32 1
  store i64 1, ptr %579, align 8
  store ptr %_86, ptr %_83, align 8
  %580 = getelementptr inbounds i8, ptr %_83, i64 8
  store i64 3, ptr %580, align 8
  %581 = icmp ne i32 %_42.sroa.19.sroa.0.0.insert.ext, 2
  br i1 %581, label %bb24, label %bb26

bb74:                                             ; preds = %_ZN14pump_recovered9admin_cto7execute5sweep17h9943ff4781c7e018E.exit
  %582 = inttoptr i64 %_397.sroa.18.3 to ptr
  br label %bb55

bb26:                                             ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit262, %bb75
  %_308 = load ptr, ptr %6, align 8, !nonnull !2, !align !4, !noundef !2
  %583 = getelementptr inbounds i8, ptr %_308, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %old_creator, ptr noundef nonnull align 8 dereferenceable(32) %583, i64 32, i1 false)
  %584 = getelementptr inbounds i8, ptr %_308, i64 112
  %old_fee = load i64, ptr %584, align 8, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %583, ptr noundef nonnull align 1 dereferenceable(32) %target11, i64 32, i1 false)
  %585 = and i8 %0, 1
  %_311 = load ptr, ptr %6, align 8, !nonnull !2, !align !4, !noundef !2
  %586 = getelementptr inbounds i8, ptr %_311, i64 165
  store i8 %585, ptr %586, align 1
  %_312 = load ptr, ptr %6, align 8, !nonnull !2, !align !4, !noundef !2
  %587 = getelementptr inbounds i8, ptr %_312, i64 163
  store i8 %173, ptr %587, align 1
  %switch66 = icmp eq i64 %1, 1
  br i1 %switch66, label %bb27, label %bb28

bb24:                                             ; preds = %bb75
  store i32 %_42.sroa.19.sroa.0.0.insert.insert, ptr %val4, align 1
  %sharing_update12.sroa.3.0.val4.sroa_idx = getelementptr inbounds i8, ptr %val4, i64 4
  store i64 %_166.sroa.6.i.sroa.4.0, ptr %sharing_update12.sroa.3.0.val4.sroa_idx, align 1
  %sharing_update12.sroa.4.0.val4.sroa_idx = getelementptr inbounds i8, ptr %val4, i64 12
  store ptr %_166.sroa.6.i.sroa.5.0, ptr %sharing_update12.sroa.4.0.val4.sroa_idx, align 1
  %sharing_update12.sroa.5.0.val4.sroa_idx = getelementptr inbounds i8, ptr %val4, i64 20
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(13) %sharing_update12.sroa.5.0.val4.sroa_idx, ptr noundef nonnull align 1 dereferenceable(13) %sharing_update12.sroa.5, i64 13, i1 false)
  call void @llvm.lifetime.start.p0(i64 424, ptr nonnull %_97)
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_98.sroa.11)
  %588 = getelementptr inbounds i8, ptr %_247, i64 152
  %_409 = load ptr, ptr %588, align 8, !nonnull !2, !align !4, !noundef !2
  call void @llvm.experimental.noalias.scope.decl(metadata !1954)
  %_2.i = load ptr, ptr %_409, align 8, !alias.scope !1954, !noalias !1957, !nonnull !2, !align !237, !noundef !2
  %589 = getelementptr inbounds i8, ptr %_409, i64 8
  %_12.i157 = load ptr, ptr %589, align 8, !alias.scope !1954, !noalias !1957, !nonnull !2, !noundef !2
  %self.val.i.i158 = load i64, ptr %_12.i157, align 8, !noalias !1959, !noundef !2
  %cond.i.i159 = icmp ne i64 %self.val.i.i158, 0
  call void @llvm.assume(i1 %cond.i.i159)
  %strong1.i.i160 = add i64 %self.val.i.i158, 1
  store i64 %strong1.i.i160, ptr %_12.i157, align 8, !noalias !1959
  %_7.i.i161 = icmp eq i64 %strong1.i.i160, 0
  br i1 %_7.i.i161, label %bb4.i.i165, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i162

bb4.i.i165:                                       ; preds = %bb24
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i162: ; preds = %bb24
  %590 = getelementptr inbounds i8, ptr %_409, i64 16
  %_16.i = load ptr, ptr %590, align 8, !alias.scope !1954, !noalias !1957, !nonnull !2, !noundef !2
  %self.val.i1.i = load i64, ptr %_16.i, align 8, !noalias !1959, !noundef !2
  %cond.i2.i = icmp ne i64 %self.val.i1.i, 0
  call void @llvm.assume(i1 %cond.i2.i)
  %strong1.i3.i = add i64 %self.val.i1.i, 1
  store i64 %strong1.i3.i, ptr %_16.i, align 8, !noalias !1959
  %_7.i4.i = icmp eq i64 %strong1.i3.i, 0
  br i1 %_7.i4.i, label %bb4.i5.i, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit"

bb4.i5.i:                                         ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i162
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i162
  %591 = getelementptr inbounds i8, ptr %_409, i64 24
  %_5.i164 = load ptr, ptr %591, align 8, !alias.scope !1954, !noalias !1957, !nonnull !2, !align !237, !noundef !2
  %592 = getelementptr inbounds i8, ptr %_409, i64 32
  %_6.i = load i64, ptr %592, align 8, !alias.scope !1954, !noalias !1957, !noundef !2
  %593 = getelementptr inbounds i8, ptr %_409, i64 40
  %594 = load i8, ptr %593, align 8, !range !9, !alias.scope !1954, !noalias !1957, !noundef !2
  %595 = getelementptr inbounds i8, ptr %_409, i64 41
  %596 = load i8, ptr %595, align 1, !range !9, !alias.scope !1954, !noalias !1957, !noundef !2
  %597 = getelementptr inbounds i8, ptr %_409, i64 42
  %598 = load i8, ptr %597, align 2, !range !9, !alias.scope !1954, !noalias !1957, !noundef !2
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_99.sroa.11)
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_99.sroa.12.sroa.11)
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_99.sroa.13.sroa.11)
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_99.sroa.14.sroa.11)
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_99.sroa.15.sroa.11)
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_99.sroa.16.sroa.11)
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_99.sroa.17.sroa.11)
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_100.sroa.11)
  %599 = getelementptr inbounds i8, ptr %_247, i64 104
  %x = load ptr, ptr %599, align 8, !nonnull !2, !align !4, !noundef !2
  %600 = getelementptr inbounds i8, ptr %x, i64 24
  %_280 = load ptr, ptr %600, align 8, !nonnull !2, !align !237, !noundef !2
  %601 = getelementptr inbounds i8, ptr %x, i64 8
  %_412 = load ptr, ptr %601, align 8, !nonnull !2, !noundef !2
  %self.val.i = load i64, ptr %_412, align 8, !noundef !2
  %cond.i = icmp ne i64 %self.val.i, 0
  call void @llvm.assume(i1 %cond.i)
  %strong1.i = add i64 %self.val.i, 1
  store i64 %strong1.i, ptr %_412, align 8
  %_7.i166 = icmp eq i64 %strong1.i, 0
  br i1 %_7.i166, label %bb4.i168, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit

bb4.i168:                                         ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit"
  %602 = getelementptr inbounds i8, ptr %x, i64 16
  %_416 = load ptr, ptr %602, align 8, !nonnull !2, !noundef !2
  %self.val.i169 = load i64, ptr %_416, align 8, !noundef !2
  %cond.i170 = icmp ne i64 %self.val.i169, 0
  call void @llvm.assume(i1 %cond.i170)
  %strong1.i171 = add i64 %self.val.i169, 1
  store i64 %strong1.i171, ptr %_416, align 8
  %_7.i172 = icmp eq i64 %strong1.i171, 0
  br i1 %_7.i172, label %bb4.i174, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit

bb4.i174:                                         ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit
  %603 = getelementptr inbounds i8, ptr %x, i64 32
  %_104 = load i64, ptr %603, align 8, !noundef !2
  %604 = getelementptr inbounds i8, ptr %x, i64 40
  %605 = load i8, ptr %604, align 8, !range !9, !noundef !2
  %606 = getelementptr inbounds i8, ptr %x, i64 41
  %607 = load i8, ptr %606, align 1, !range !9, !noundef !2
  %_281 = load ptr, ptr %x, align 8, !nonnull !2, !align !237, !noundef !2
  %608 = getelementptr inbounds i8, ptr %x, i64 42
  %609 = load i8, ptr %608, align 2, !range !9, !noundef !2
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_108.sroa.11)
  %x14 = load ptr, ptr %_247, align 8, !nonnull !2, !align !4, !noundef !2
  %610 = getelementptr inbounds i8, ptr %x14, i64 41
  %611 = load i8, ptr %610, align 1, !range !9, !noundef !2
  %612 = getelementptr inbounds i8, ptr %x14, i64 42
  %613 = load i8, ptr %612, align 2, !range !9, !noundef !2
  %614 = getelementptr inbounds i8, ptr %x14, i64 40
  %615 = load i8, ptr %614, align 8, !range !9, !noundef !2
  %616 = getelementptr inbounds i8, ptr %x14, i64 32
  %_113 = load i64, ptr %616, align 8, !noundef !2
  %617 = getelementptr inbounds i8, ptr %x14, i64 8
  %_420 = load ptr, ptr %617, align 8, !nonnull !2, !noundef !2
  %self.val.i175 = load i64, ptr %_420, align 8, !noundef !2
  %cond.i176 = icmp ne i64 %self.val.i175, 0
  call void @llvm.assume(i1 %cond.i176)
  %strong1.i177 = add i64 %self.val.i175, 1
  store i64 %strong1.i177, ptr %_420, align 8
  %_7.i178 = icmp eq i64 %strong1.i177, 0
  br i1 %_7.i178, label %bb4.i180, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit181

bb4.i180:                                         ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit181: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit
  %618 = getelementptr inbounds i8, ptr %x14, i64 16
  %_424 = load ptr, ptr %618, align 8, !nonnull !2, !noundef !2
  %self.val.i182 = load i64, ptr %_424, align 8, !noundef !2
  %cond.i183 = icmp ne i64 %self.val.i182, 0
  call void @llvm.assume(i1 %cond.i183)
  %strong1.i184 = add i64 %self.val.i182, 1
  store i64 %strong1.i184, ptr %_424, align 8
  %_7.i185 = icmp eq i64 %strong1.i184, 0
  br i1 %_7.i185, label %bb4.i187, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit188

bb4.i187:                                         ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit181
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit188: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit181
  %619 = getelementptr inbounds i8, ptr %x14, i64 24
  %_283 = load ptr, ptr %619, align 8, !nonnull !2, !align !237, !noundef !2
  %_284 = load ptr, ptr %x14, align 8, !nonnull !2, !align !237, !noundef !2
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_116.sroa.11)
  %_539 = load ptr, ptr %25, align 8, !nonnull !2, !noundef !2
  %x15 = load ptr, ptr %_539, align 8, !nonnull !2, !align !4, !noundef !2
  %620 = getelementptr inbounds i8, ptr %x15, i64 41
  %621 = load i8, ptr %620, align 1, !range !9, !noundef !2
  %622 = getelementptr inbounds i8, ptr %x15, i64 42
  %623 = load i8, ptr %622, align 2, !range !9, !noundef !2
  %624 = getelementptr inbounds i8, ptr %x15, i64 40
  %625 = load i8, ptr %624, align 8, !range !9, !noundef !2
  %626 = getelementptr inbounds i8, ptr %x15, i64 32
  %_121 = load i64, ptr %626, align 8, !noundef !2
  %627 = getelementptr inbounds i8, ptr %x15, i64 8
  %_429 = load ptr, ptr %627, align 8, !nonnull !2, !noundef !2
  %self.val.i189 = load i64, ptr %_429, align 8, !noundef !2
  %cond.i190 = icmp ne i64 %self.val.i189, 0
  call void @llvm.assume(i1 %cond.i190)
  %strong1.i191 = add i64 %self.val.i189, 1
  store i64 %strong1.i191, ptr %_429, align 8
  %_7.i192 = icmp eq i64 %strong1.i191, 0
  br i1 %_7.i192, label %bb4.i194, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit195

bb4.i194:                                         ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit188
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit195: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit188
  %628 = getelementptr inbounds i8, ptr %x15, i64 16
  %_433 = load ptr, ptr %628, align 8, !nonnull !2, !noundef !2
  %self.val.i196 = load i64, ptr %_433, align 8, !noundef !2
  %cond.i197 = icmp ne i64 %self.val.i196, 0
  call void @llvm.assume(i1 %cond.i197)
  %strong1.i198 = add i64 %self.val.i196, 1
  store i64 %strong1.i198, ptr %_433, align 8
  %_7.i199 = icmp eq i64 %strong1.i198, 0
  br i1 %_7.i199, label %bb4.i201, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit202

bb4.i201:                                         ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit195
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit202: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit195
  %629 = getelementptr inbounds i8, ptr %x15, i64 24
  %_286 = load ptr, ptr %629, align 8, !nonnull !2, !align !237, !noundef !2
  %_287 = load ptr, ptr %x15, align 8, !nonnull !2, !align !237, !noundef !2
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_124.sroa.11)
  %x16 = load ptr, ptr %4, align 8, !nonnull !2, !align !4, !noundef !2
  %630 = getelementptr inbounds i8, ptr %x16, i64 32
  %_126 = load i64, ptr %630, align 8, !noundef !2
  %631 = getelementptr inbounds i8, ptr %x16, i64 40
  %632 = load i8, ptr %631, align 8, !range !9, !noundef !2
  %633 = getelementptr inbounds i8, ptr %x16, i64 41
  %634 = load i8, ptr %633, align 1, !range !9, !noundef !2
  %635 = getelementptr inbounds i8, ptr %x16, i64 42
  %636 = load i8, ptr %635, align 2, !range !9, !noundef !2
  %637 = getelementptr inbounds i8, ptr %x16, i64 8
  %_437 = load ptr, ptr %637, align 8, !nonnull !2, !noundef !2
  %self.val.i203 = load i64, ptr %_437, align 8, !noundef !2
  %cond.i204 = icmp ne i64 %self.val.i203, 0
  call void @llvm.assume(i1 %cond.i204)
  %strong1.i205 = add i64 %self.val.i203, 1
  store i64 %strong1.i205, ptr %_437, align 8
  %_7.i206 = icmp eq i64 %strong1.i205, 0
  br i1 %_7.i206, label %bb4.i208, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit209

bb4.i208:                                         ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit202
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit209: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit202
  %638 = getelementptr inbounds i8, ptr %x16, i64 24
  %_289 = load ptr, ptr %638, align 8, !nonnull !2, !align !237, !noundef !2
  %639 = getelementptr inbounds i8, ptr %x16, i64 16
  %_441 = load ptr, ptr %639, align 8, !nonnull !2, !noundef !2
  %self.val.i210 = load i64, ptr %_441, align 8, !noundef !2
  %cond.i211 = icmp ne i64 %self.val.i210, 0
  call void @llvm.assume(i1 %cond.i211)
  %strong1.i212 = add i64 %self.val.i210, 1
  store i64 %strong1.i212, ptr %_441, align 8
  %_7.i213 = icmp eq i64 %strong1.i212, 0
  br i1 %_7.i213, label %bb4.i215, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit216

bb4.i215:                                         ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit209
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit216: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit209
  %_290 = load ptr, ptr %x16, align 8, !nonnull !2, !align !237, !noundef !2
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_132.sroa.11)
  %_443 = load ptr, ptr %5, align 8, !nonnull !2, !align !4, !noundef !2
  call void @llvm.experimental.noalias.scope.decl(metadata !1960)
  %_2.i217 = load ptr, ptr %_443, align 8, !alias.scope !1960, !noalias !1963, !nonnull !2, !align !237, !noundef !2
  %640 = getelementptr inbounds i8, ptr %_443, i64 8
  %_12.i218 = load ptr, ptr %640, align 8, !alias.scope !1960, !noalias !1963, !nonnull !2, !noundef !2
  %self.val.i.i219 = load i64, ptr %_12.i218, align 8, !noalias !1965, !noundef !2
  %cond.i.i220 = icmp ne i64 %self.val.i.i219, 0
  call void @llvm.assume(i1 %cond.i.i220)
  %strong1.i.i221 = add i64 %self.val.i.i219, 1
  store i64 %strong1.i.i221, ptr %_12.i218, align 8, !noalias !1965
  %_7.i.i222 = icmp eq i64 %strong1.i.i221, 0
  br i1 %_7.i.i222, label %bb4.i.i233, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i223

bb4.i.i233:                                       ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit216
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i223: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit216
  %641 = getelementptr inbounds i8, ptr %_443, i64 16
  %_16.i224 = load ptr, ptr %641, align 8, !alias.scope !1960, !noalias !1963, !nonnull !2, !noundef !2
  %self.val.i1.i225 = load i64, ptr %_16.i224, align 8, !noalias !1965, !noundef !2
  %cond.i2.i226 = icmp ne i64 %self.val.i1.i225, 0
  call void @llvm.assume(i1 %cond.i2.i226)
  %strong1.i3.i227 = add i64 %self.val.i1.i225, 1
  store i64 %strong1.i3.i227, ptr %_16.i224, align 8, !noalias !1965
  %_7.i4.i228 = icmp eq i64 %strong1.i3.i227, 0
  br i1 %_7.i4.i228, label %bb4.i5.i232, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit234"

bb4.i5.i232:                                      ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i223
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit234": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i223
  %642 = getelementptr inbounds i8, ptr %_443, i64 24
  %_5.i230 = load ptr, ptr %642, align 8, !alias.scope !1960, !noalias !1963, !nonnull !2, !align !237, !noundef !2
  %643 = getelementptr inbounds i8, ptr %_443, i64 32
  %_6.i231 = load i64, ptr %643, align 8, !alias.scope !1960, !noalias !1963, !noundef !2
  %644 = getelementptr inbounds i8, ptr %_443, i64 40
  %645 = load i8, ptr %644, align 8, !range !9, !alias.scope !1960, !noalias !1963, !noundef !2
  %646 = getelementptr inbounds i8, ptr %_443, i64 41
  %647 = load i8, ptr %646, align 1, !range !9, !alias.scope !1960, !noalias !1963, !noundef !2
  %648 = getelementptr inbounds i8, ptr %_443, i64 42
  %649 = load i8, ptr %648, align 2, !range !9, !alias.scope !1960, !noalias !1963, !noundef !2
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_133.sroa.11)
  %650 = getelementptr inbounds i8, ptr %_247, i64 160
  %_135 = load ptr, ptr %650, align 8, !nonnull !2, !align !4, !noundef !2
  %651 = getelementptr inbounds i8, ptr %_135, i64 16
  %_446 = load ptr, ptr %651, align 8, !nonnull !2, !noundef !2
  %self.val.i235 = load i64, ptr %_446, align 8, !noundef !2
  %cond.i236 = icmp ne i64 %self.val.i235, 0
  call void @llvm.assume(i1 %cond.i236)
  %strong1.i237 = add i64 %self.val.i235, 1
  store i64 %strong1.i237, ptr %_446, align 8
  %_7.i238 = icmp eq i64 %strong1.i237, 0
  br i1 %_7.i238, label %bb4.i240, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit241

bb4.i240:                                         ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit234"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit241: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit234"
  %_137 = load ptr, ptr %650, align 8, !nonnull !2, !align !4, !noundef !2
  %652 = getelementptr inbounds i8, ptr %_137, i64 8
  %_450 = load ptr, ptr %652, align 8, !nonnull !2, !noundef !2
  %self.val.i242 = load i64, ptr %_450, align 8, !noundef !2
  %cond.i243 = icmp ne i64 %self.val.i242, 0
  call void @llvm.assume(i1 %cond.i243)
  %strong1.i244 = add i64 %self.val.i242, 1
  store i64 %strong1.i244, ptr %_450, align 8
  %_7.i245 = icmp eq i64 %strong1.i244, 0
  br i1 %_7.i245, label %bb4.i247, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit248

bb4.i247:                                         ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit241
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit248: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit241
  %_138 = load ptr, ptr %650, align 8, !nonnull !2, !align !4, !noundef !2
  %_295 = load ptr, ptr %_138, align 8, !nonnull !2, !align !237, !noundef !2
  %653 = getelementptr inbounds i8, ptr %_138, i64 24
  %_297 = load ptr, ptr %653, align 8, !nonnull !2, !align !237, !noundef !2
  %654 = getelementptr inbounds i8, ptr %_138, i64 32
  %_140 = load i64, ptr %654, align 8, !noundef !2
  %655 = getelementptr inbounds i8, ptr %_138, i64 40
  %656 = load i8, ptr %655, align 8, !range !9, !noundef !2
  %657 = getelementptr inbounds i8, ptr %_138, i64 41
  %658 = load i8, ptr %657, align 1, !range !9, !noundef !2
  %659 = getelementptr inbounds i8, ptr %_138, i64 42
  %660 = load i8, ptr %659, align 2, !range !9, !noundef !2
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_148.sroa.11)
  %x17 = load ptr, ptr %588, align 8, !nonnull !2, !align !4, !noundef !2
  %661 = getelementptr inbounds i8, ptr %x17, i64 16
  %_454 = load ptr, ptr %661, align 8, !nonnull !2, !noundef !2
  %self.val.i249 = load i64, ptr %_454, align 8, !noundef !2
  %cond.i250 = icmp ne i64 %self.val.i249, 0
  call void @llvm.assume(i1 %cond.i250)
  %strong1.i251 = add i64 %self.val.i249, 1
  store i64 %strong1.i251, ptr %_454, align 8
  %_7.i252 = icmp eq i64 %strong1.i251, 0
  br i1 %_7.i252, label %bb4.i254, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit255

bb4.i254:                                         ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit248
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit255: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit248
  %_304 = load ptr, ptr %x17, align 8, !nonnull !2, !align !237, !noundef !2
  %_153 = load ptr, ptr %588, align 8, !nonnull !2, !align !4, !noundef !2
  %662 = getelementptr inbounds i8, ptr %_153, i64 8
  %_458 = load ptr, ptr %662, align 8, !nonnull !2, !noundef !2
  %self.val.i256 = load i64, ptr %_458, align 8, !noundef !2
  %cond.i257 = icmp ne i64 %self.val.i256, 0
  call void @llvm.assume(i1 %cond.i257)
  %strong1.i258 = add i64 %self.val.i256, 1
  store i64 %strong1.i258, ptr %_458, align 8
  %_7.i259 = icmp eq i64 %strong1.i258, 0
  br i1 %_7.i259, label %bb4.i261, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit262

bb4.i261:                                         ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit255
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit262: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit255
  %663 = getelementptr inbounds i8, ptr %x17, i64 24
  %_306 = load ptr, ptr %663, align 8, !nonnull !2, !align !237, !noundef !2
  %664 = getelementptr inbounds i8, ptr %x17, i64 32
  %_154 = load i64, ptr %664, align 8, !noundef !2
  %665 = getelementptr inbounds i8, ptr %x17, i64 40
  %666 = load i8, ptr %665, align 8, !range !9, !noundef !2
  %667 = getelementptr inbounds i8, ptr %x17, i64 41
  %668 = load i8, ptr %667, align 1, !range !9, !noundef !2
  %669 = getelementptr inbounds i8, ptr %x17, i64 42
  %670 = load i8, ptr %669, align 2, !range !9, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_99.sroa.11, ptr noundef nonnull align 1 dereferenceable(5) %_100.sroa.11, i64 5, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_99.sroa.12.sroa.11, ptr noundef nonnull align 1 dereferenceable(5) %_108.sroa.11, i64 5, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_99.sroa.13.sroa.11, ptr noundef nonnull align 1 dereferenceable(5) %_116.sroa.11, i64 5, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_99.sroa.14.sroa.11, ptr noundef nonnull align 1 dereferenceable(5) %_124.sroa.11, i64 5, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_99.sroa.15.sroa.11, ptr noundef nonnull align 1 dereferenceable(5) %_132.sroa.11, i64 5, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_99.sroa.16.sroa.11, ptr noundef nonnull align 1 dereferenceable(5) %_133.sroa.11, i64 5, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_99.sroa.17.sroa.11, ptr noundef nonnull align 1 dereferenceable(5) %_148.sroa.11, i64 5, i1 false)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_148.sroa.11)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_133.sroa.11)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_132.sroa.11)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_124.sroa.11)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_116.sroa.11)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_108.sroa.11)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_100.sroa.11)
  %671 = getelementptr inbounds i8, ptr %_97, i64 72
  store ptr %_281, ptr %671, align 8
  %_99.sroa.4.0..sroa_idx = getelementptr inbounds i8, ptr %_97, i64 80
  store ptr %_412, ptr %_99.sroa.4.0..sroa_idx, align 8
  %_99.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %_97, i64 88
  store ptr %_416, ptr %_99.sroa.5.0..sroa_idx, align 8
  %_99.sroa.6.0..sroa_idx = getelementptr inbounds i8, ptr %_97, i64 96
  store ptr %_280, ptr %_99.sroa.6.0..sroa_idx, align 8
  %_99.sroa.7.0..sroa_idx = getelementptr inbounds i8, ptr %_97, i64 104
  store i64 %_104, ptr %_99.sroa.7.0..sroa_idx, align 8
  %_99.sroa.8.0..sroa_idx = getelementptr inbounds i8, ptr %_97, i64 112
  store i8 %605, ptr %_99.sroa.8.0..sroa_idx, align 8
  %_99.sroa.9.0..sroa_idx = getelementptr inbounds i8, ptr %_97, i64 113
  store i8 %607, ptr %_99.sroa.9.0..sroa_idx, align 1
  %_99.sroa.10.0..sroa_idx = getelementptr inbounds i8, ptr %_97, i64 114
  store i8 %609, ptr %_99.sroa.10.0..sroa_idx, align 2
  %_99.sroa.11.0..sroa_idx = getelementptr inbounds i8, ptr %_97, i64 115
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_99.sroa.11.0..sroa_idx, ptr noundef nonnull align 1 dereferenceable(5) %_99.sroa.11, i64 5, i1 false)
  %_99.sroa.12.0..sroa_idx = getelementptr inbounds i8, ptr %_97, i64 120
  store ptr %_284, ptr %_99.sroa.12.0..sroa_idx, align 8
  %_99.sroa.12.sroa.4.0._99.sroa.12.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 128
  store ptr %_420, ptr %_99.sroa.12.sroa.4.0._99.sroa.12.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.12.sroa.5.0._99.sroa.12.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 136
  store ptr %_424, ptr %_99.sroa.12.sroa.5.0._99.sroa.12.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.12.sroa.6.0._99.sroa.12.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 144
  store ptr %_283, ptr %_99.sroa.12.sroa.6.0._99.sroa.12.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.12.sroa.7.0._99.sroa.12.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 152
  store i64 %_113, ptr %_99.sroa.12.sroa.7.0._99.sroa.12.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.12.sroa.8.0._99.sroa.12.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 160
  store i8 %615, ptr %_99.sroa.12.sroa.8.0._99.sroa.12.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.12.sroa.9.0._99.sroa.12.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 161
  store i8 %611, ptr %_99.sroa.12.sroa.9.0._99.sroa.12.0..sroa_idx.sroa_idx, align 1
  %_99.sroa.12.sroa.10.0._99.sroa.12.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 162
  store i8 %613, ptr %_99.sroa.12.sroa.10.0._99.sroa.12.0..sroa_idx.sroa_idx, align 2
  %_99.sroa.12.sroa.11.0._99.sroa.12.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 163
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_99.sroa.12.sroa.11.0._99.sroa.12.0..sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(5) %_99.sroa.12.sroa.11, i64 5, i1 false)
  %_99.sroa.13.0..sroa_idx = getelementptr inbounds i8, ptr %_97, i64 168
  store ptr %_287, ptr %_99.sroa.13.0..sroa_idx, align 8
  %_99.sroa.13.sroa.4.0._99.sroa.13.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 176
  store ptr %_429, ptr %_99.sroa.13.sroa.4.0._99.sroa.13.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.13.sroa.5.0._99.sroa.13.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 184
  store ptr %_433, ptr %_99.sroa.13.sroa.5.0._99.sroa.13.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.13.sroa.6.0._99.sroa.13.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 192
  store ptr %_286, ptr %_99.sroa.13.sroa.6.0._99.sroa.13.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.13.sroa.7.0._99.sroa.13.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 200
  store i64 %_121, ptr %_99.sroa.13.sroa.7.0._99.sroa.13.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.13.sroa.8.0._99.sroa.13.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 208
  store i8 %625, ptr %_99.sroa.13.sroa.8.0._99.sroa.13.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.13.sroa.9.0._99.sroa.13.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 209
  store i8 %621, ptr %_99.sroa.13.sroa.9.0._99.sroa.13.0..sroa_idx.sroa_idx, align 1
  %_99.sroa.13.sroa.10.0._99.sroa.13.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 210
  store i8 %623, ptr %_99.sroa.13.sroa.10.0._99.sroa.13.0..sroa_idx.sroa_idx, align 2
  %_99.sroa.13.sroa.11.0._99.sroa.13.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 211
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_99.sroa.13.sroa.11.0._99.sroa.13.0..sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(5) %_99.sroa.13.sroa.11, i64 5, i1 false)
  %_99.sroa.14.0..sroa_idx = getelementptr inbounds i8, ptr %_97, i64 216
  store ptr %_290, ptr %_99.sroa.14.0..sroa_idx, align 8
  %_99.sroa.14.sroa.4.0._99.sroa.14.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 224
  store ptr %_437, ptr %_99.sroa.14.sroa.4.0._99.sroa.14.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.14.sroa.5.0._99.sroa.14.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 232
  store ptr %_441, ptr %_99.sroa.14.sroa.5.0._99.sroa.14.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.14.sroa.6.0._99.sroa.14.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 240
  store ptr %_289, ptr %_99.sroa.14.sroa.6.0._99.sroa.14.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.14.sroa.7.0._99.sroa.14.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 248
  store i64 %_126, ptr %_99.sroa.14.sroa.7.0._99.sroa.14.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.14.sroa.8.0._99.sroa.14.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 256
  store i8 %632, ptr %_99.sroa.14.sroa.8.0._99.sroa.14.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.14.sroa.9.0._99.sroa.14.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 257
  store i8 %634, ptr %_99.sroa.14.sroa.9.0._99.sroa.14.0..sroa_idx.sroa_idx, align 1
  %_99.sroa.14.sroa.10.0._99.sroa.14.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 258
  store i8 %636, ptr %_99.sroa.14.sroa.10.0._99.sroa.14.0..sroa_idx.sroa_idx, align 2
  %_99.sroa.14.sroa.11.0._99.sroa.14.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 259
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_99.sroa.14.sroa.11.0._99.sroa.14.0..sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(5) %_99.sroa.14.sroa.11, i64 5, i1 false)
  %_99.sroa.15.0..sroa_idx = getelementptr inbounds i8, ptr %_97, i64 264
  store ptr %_2.i217, ptr %_99.sroa.15.0..sroa_idx, align 8
  %_99.sroa.15.sroa.4.0._99.sroa.15.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 272
  store ptr %_12.i218, ptr %_99.sroa.15.sroa.4.0._99.sroa.15.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.15.sroa.5.0._99.sroa.15.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 280
  store ptr %_16.i224, ptr %_99.sroa.15.sroa.5.0._99.sroa.15.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.15.sroa.6.0._99.sroa.15.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 288
  store ptr %_5.i230, ptr %_99.sroa.15.sroa.6.0._99.sroa.15.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.15.sroa.7.0._99.sroa.15.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 296
  store i64 %_6.i231, ptr %_99.sroa.15.sroa.7.0._99.sroa.15.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.15.sroa.8.0._99.sroa.15.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 304
  store i8 %645, ptr %_99.sroa.15.sroa.8.0._99.sroa.15.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.15.sroa.9.0._99.sroa.15.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 305
  store i8 %647, ptr %_99.sroa.15.sroa.9.0._99.sroa.15.0..sroa_idx.sroa_idx, align 1
  %_99.sroa.15.sroa.10.0._99.sroa.15.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 306
  store i8 %649, ptr %_99.sroa.15.sroa.10.0._99.sroa.15.0..sroa_idx.sroa_idx, align 2
  %_99.sroa.15.sroa.11.0._99.sroa.15.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 307
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_99.sroa.15.sroa.11.0._99.sroa.15.0..sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(5) %_99.sroa.15.sroa.11, i64 5, i1 false)
  %_99.sroa.16.0..sroa_idx = getelementptr inbounds i8, ptr %_97, i64 312
  store ptr %_295, ptr %_99.sroa.16.0..sroa_idx, align 8
  %_99.sroa.16.sroa.4.0._99.sroa.16.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 320
  store ptr %_450, ptr %_99.sroa.16.sroa.4.0._99.sroa.16.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.16.sroa.5.0._99.sroa.16.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 328
  store ptr %_446, ptr %_99.sroa.16.sroa.5.0._99.sroa.16.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.16.sroa.6.0._99.sroa.16.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 336
  store ptr %_297, ptr %_99.sroa.16.sroa.6.0._99.sroa.16.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.16.sroa.7.0._99.sroa.16.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 344
  store i64 %_140, ptr %_99.sroa.16.sroa.7.0._99.sroa.16.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.16.sroa.8.0._99.sroa.16.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 352
  store i8 %656, ptr %_99.sroa.16.sroa.8.0._99.sroa.16.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.16.sroa.9.0._99.sroa.16.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 353
  store i8 %658, ptr %_99.sroa.16.sroa.9.0._99.sroa.16.0..sroa_idx.sroa_idx, align 1
  %_99.sroa.16.sroa.10.0._99.sroa.16.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 354
  store i8 %660, ptr %_99.sroa.16.sroa.10.0._99.sroa.16.0..sroa_idx.sroa_idx, align 2
  %_99.sroa.16.sroa.11.0._99.sroa.16.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 355
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_99.sroa.16.sroa.11.0._99.sroa.16.0..sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(5) %_99.sroa.16.sroa.11, i64 5, i1 false)
  %_99.sroa.17.0..sroa_idx = getelementptr inbounds i8, ptr %_97, i64 360
  store ptr %_304, ptr %_99.sroa.17.0..sroa_idx, align 8
  %_99.sroa.17.sroa.4.0._99.sroa.17.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 368
  store ptr %_458, ptr %_99.sroa.17.sroa.4.0._99.sroa.17.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.17.sroa.5.0._99.sroa.17.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 376
  store ptr %_454, ptr %_99.sroa.17.sroa.5.0._99.sroa.17.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.17.sroa.6.0._99.sroa.17.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 384
  store ptr %_306, ptr %_99.sroa.17.sroa.6.0._99.sroa.17.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.17.sroa.7.0._99.sroa.17.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 392
  store i64 %_154, ptr %_99.sroa.17.sroa.7.0._99.sroa.17.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.17.sroa.8.0._99.sroa.17.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 400
  store i8 %666, ptr %_99.sroa.17.sroa.8.0._99.sroa.17.0..sroa_idx.sroa_idx, align 8
  %_99.sroa.17.sroa.9.0._99.sroa.17.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 401
  store i8 %668, ptr %_99.sroa.17.sroa.9.0._99.sroa.17.0..sroa_idx.sroa_idx, align 1
  %_99.sroa.17.sroa.10.0._99.sroa.17.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 402
  store i8 %670, ptr %_99.sroa.17.sroa.10.0._99.sroa.17.0..sroa_idx.sroa_idx, align 2
  %_99.sroa.17.sroa.11.0._99.sroa.17.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 403
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_99.sroa.17.sroa.11.0._99.sroa.17.0..sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(5) %_99.sroa.17.sroa.11, i64 5, i1 false)
  store i64 0, ptr %_97, align 8
  %_460.sroa.4.0._97.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 8
  store ptr inttoptr (i64 8 to ptr), ptr %_460.sroa.4.0._97.sroa_idx, align 8
  %_460.sroa.5.0._97.sroa_idx = getelementptr inbounds i8, ptr %_97, i64 16
  store i64 0, ptr %_460.sroa.5.0._97.sroa_idx, align 8
  %672 = getelementptr inbounds i8, ptr %_97, i64 24
  store ptr %_2.i, ptr %672, align 8
  %_98.sroa.4.0..sroa_idx = getelementptr inbounds i8, ptr %_97, i64 32
  store ptr %_12.i157, ptr %_98.sroa.4.0..sroa_idx, align 8
  %_98.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %_97, i64 40
  store ptr %_16.i, ptr %_98.sroa.5.0..sroa_idx, align 8
  %_98.sroa.6.0..sroa_idx = getelementptr inbounds i8, ptr %_97, i64 48
  store ptr %_5.i164, ptr %_98.sroa.6.0..sroa_idx, align 8
  %_98.sroa.7.0..sroa_idx = getelementptr inbounds i8, ptr %_97, i64 56
  store i64 %_6.i, ptr %_98.sroa.7.0..sroa_idx, align 8
  %_98.sroa.8.0..sroa_idx = getelementptr inbounds i8, ptr %_97, i64 64
  store i8 %594, ptr %_98.sroa.8.0..sroa_idx, align 8
  %_98.sroa.9.0..sroa_idx = getelementptr inbounds i8, ptr %_97, i64 65
  store i8 %596, ptr %_98.sroa.9.0..sroa_idx, align 1
  %_98.sroa.10.0..sroa_idx = getelementptr inbounds i8, ptr %_97, i64 66
  store i8 %598, ptr %_98.sroa.10.0..sroa_idx, align 2
  %_98.sroa.11.0..sroa_idx = getelementptr inbounds i8, ptr %_97, i64 67
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_98.sroa.11.0..sroa_idx, ptr noundef nonnull align 1 dereferenceable(5) %_98.sroa.11, i64 5, i1 false)
  %673 = getelementptr inbounds i8, ptr %_97, i64 408
  store ptr %_83, ptr %673, align 8
  %674 = getelementptr inbounds i8, ptr %_97, i64 416
  store i64 1, ptr %674, align 8
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_99.sroa.11)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_99.sroa.12.sroa.11)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_99.sroa.13.sroa.11)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_99.sroa.14.sroa.11)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_99.sroa.15.sroa.11)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_99.sroa.16.sroa.11)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_99.sroa.17.sroa.11)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_98.sroa.11)
  %675 = call { i64, ptr } @_ZN14pump_recovered9pump_fees3cpi24admin_cto_sharing_config17hb339d2894fd16ae6E(ptr noalias nocapture noundef nonnull align 8 dereferenceable(424) %_97, ptr noalias nocapture noundef nonnull readonly align 1 dereferenceable(33) %val4) #37
  %676 = extractvalue { i64, ptr } %675, 0
  call void @llvm.lifetime.end.p0(i64 424, ptr nonnull %_97)
  %677 = icmp eq i64 %676, 2
  br i1 %677, label %bb26, label %bb53

bb27:                                             ; preds = %bb26
  %_313 = load ptr, ptr %6, align 8, !nonnull !2, !align !4, !noundef !2
  %678 = getelementptr inbounds i8, ptr %_313, i64 112
  store i64 %2, ptr %678, align 8
  br label %bb28

bb28:                                             ; preds = %bb26, %bb27
  %_314 = load ptr, ptr %6, align 8, !nonnull !2, !align !4, !noundef !2
  %679 = getelementptr inbounds i8, ptr %_314, i64 164
  store i8 0, ptr %679, align 4
  %_316 = load ptr, ptr %6, align 8, !nonnull !2, !align !4, !noundef !2
  %680 = getelementptr inbounds i8, ptr %_316, i64 112
  %nf = load i64, ptr %680, align 8, !noundef !2
  %681 = getelementptr inbounds i8, ptr %_247, i64 112
  %_169 = load ptr, ptr %681, align 8, !nonnull !2, !align !4, !noundef !2
  %_168 = call noundef zeroext i1 @_ZN19solana_account_info11AccountInfo13data_is_empty17h4cbad3bc61143bcfE(ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_169) #37
  br i1 %_168, label %bb34, label %bb31

bb31:                                             ; preds = %bb28
  %_170 = load ptr, ptr %681, align 8, !nonnull !2, !align !4, !noundef !2
  %682 = getelementptr inbounds i8, ptr %_170, i64 24
  %_467 = load ptr, ptr %682, align 8, !nonnull !2, !align !237, !noundef !2
  %683 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_467, ptr noundef nonnull dereferenceable(32) @alloc_a71df2dcdcd27e225580acd7d3af0248, i64 32)
  %684 = icmp eq i32 %683, 0
  br i1 %684, label %bb32, label %bb34

bb34:                                             ; preds = %bb28, %bb31
  call void @sol_log_(ptr noundef nonnull @alloc_f1e0cbbc2b934c2f02dd0c84a052221d, i64 noundef 48) #37
  br label %bb35

bb32:                                             ; preds = %bb31
  %685 = load ptr, ptr %6, align 8, !nonnull !2, !align !4, !noundef !2
  %686 = getelementptr inbounds i8, ptr %685, i64 165
  %687 = load i8, ptr %686, align 1, !range !9, !noundef !2
  %688 = icmp ne i8 %687, 0
  call void @llvm.lifetime.start.p0(i64 424, ptr nonnull %_175)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_176)
  %689 = getelementptr inbounds i8, ptr %_247, i64 88
  %_471 = load ptr, ptr %689, align 8, !nonnull !2, !align !4, !noundef !2
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %_176, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_471) #37
  call void @llvm.lifetime.start.p0(i64 336, ptr nonnull %_177)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_178)
  %_472 = load ptr, ptr %_247, align 8, !nonnull !2, !align !4, !noundef !2
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %_178, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_472) #37
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_179)
  %690 = getelementptr inbounds i8, ptr %_247, i64 96
  %_473 = load ptr, ptr %690, align 8, !nonnull !2, !align !4, !noundef !2
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %_179, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_473) #37
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_180)
  %_474 = load ptr, ptr %681, align 8, !nonnull !2, !align !4, !noundef !2
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %_180, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_474) #37
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_181)
  %691 = getelementptr inbounds i8, ptr %_247, i64 104
  %_475 = load ptr, ptr %691, align 8, !nonnull !2, !align !4, !noundef !2
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %_181, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_475) #37
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_182)
  %_476 = load ptr, ptr %_54, align 8, !nonnull !2, !align !4, !noundef !2
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %_182, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_476) #37
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_183)
  %692 = getelementptr inbounds i8, ptr %_247, i64 120
  %_477 = load ptr, ptr %692, align 8, !nonnull !2, !align !4, !noundef !2
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %_183, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_477) #37
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_184)
  %_478 = load ptr, ptr %689, align 8, !nonnull !2, !align !4, !noundef !2
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %_184, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_478) #37
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %_177, ptr noundef nonnull align 8 dereferenceable(48) %_178, i64 48, i1 false)
  %693 = getelementptr inbounds i8, ptr %_177, i64 48
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %693, ptr noundef nonnull align 8 dereferenceable(48) %_179, i64 48, i1 false)
  %694 = getelementptr inbounds i8, ptr %_177, i64 96
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %694, ptr noundef nonnull align 8 dereferenceable(48) %_180, i64 48, i1 false)
  %695 = getelementptr inbounds i8, ptr %_177, i64 144
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %695, ptr noundef nonnull align 8 dereferenceable(48) %_181, i64 48, i1 false)
  %696 = getelementptr inbounds i8, ptr %_177, i64 192
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %696, ptr noundef nonnull align 8 dereferenceable(48) %_182, i64 48, i1 false)
  %697 = getelementptr inbounds i8, ptr %_177, i64 240
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %697, ptr noundef nonnull align 8 dereferenceable(48) %_183, i64 48, i1 false)
  %698 = getelementptr inbounds i8, ptr %_177, i64 288
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %698, ptr noundef nonnull align 8 dereferenceable(48) %_184, i64 48, i1 false)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_184)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_183)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_182)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_181)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_180)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_179)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_178)
  %699 = getelementptr inbounds i8, ptr %_175, i64 72
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(336) %699, ptr noundef nonnull align 8 dereferenceable(336) %_177, i64 336, i1 false)
  store i64 0, ptr %_175, align 8
  %_479.sroa.4.0._175.sroa_idx = getelementptr inbounds i8, ptr %_175, i64 8
  store ptr inttoptr (i64 8 to ptr), ptr %_479.sroa.4.0._175.sroa_idx, align 8
  %_479.sroa.5.0._175.sroa_idx = getelementptr inbounds i8, ptr %_175, i64 16
  store i64 0, ptr %_479.sroa.5.0._175.sroa_idx, align 8
  %700 = getelementptr inbounds i8, ptr %_175, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %700, ptr noundef nonnull align 8 dereferenceable(48) %_176, i64 48, i1 false)
  %701 = getelementptr inbounds i8, ptr %_175, i64 408
  store ptr %_83, ptr %701, align 8
  %702 = getelementptr inbounds i8, ptr %_175, i64 416
  store i64 1, ptr %702, align 8
  call void @llvm.lifetime.end.p0(i64 336, ptr nonnull %_177)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_176)
  %703 = call { i64, ptr } @_ZN14pump_recovered8pump_amm3cpi14admin_cto_pool17h6db7cfeb87b39219E(ptr noalias nocapture noundef nonnull align 8 dereferenceable(424) %_175, ptr noalias nocapture noundef nonnull readonly align 1 dereferenceable(32) %target11, i1 noundef zeroext %688, i64 noundef %1, i64 %2) #37
  %704 = extractvalue { i64, ptr } %703, 0
  call void @llvm.lifetime.end.p0(i64 424, ptr nonnull %_175)
  %705 = icmp eq i64 %704, 2
  br i1 %705, label %bb35, label %bb53

bb35:                                             ; preds = %bb32, %bb34
  %pool_updated.sroa.0.1.off0 = phi i1 [ false, %bb34 ], [ true, %bb32 ]
  call void @llvm.lifetime.start.p0(i64 200, ptr nonnull %e)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_189)
  call void @"_ZN13solana_sysvar5clock71_$LT$impl$u20$solana_sysvar..Sysvar$u20$for$u20$solana_clock..Clock$GT$3get17hf864a57fc372ac1bE"(ptr noalias nocapture noundef nonnull sret([48 x i8]) align 8 dereferenceable(48) %_189) #37
  %_487 = load i64, ptr %_189, align 8, !range !5, !noundef !2
  %trunc63.not = icmp eq i64 %_487, 0
  br i1 %trunc63.not, label %bb111, label %bb110

bb111:                                            ; preds = %bb35
  %_488.sroa.8.0..sroa_idx = getelementptr inbounds i8, ptr %_189, i64 40
  %_488.sroa.8.0.copyload = load i64, ptr %_488.sroa.8.0..sroa_idx, align 8
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_189)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_191)
  %_491 = load ptr, ptr %_247, align 8, !nonnull !2, !align !4, !noundef !2
  %_492 = load ptr, ptr %_491, align 8, !nonnull !2, !align !237, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_191, ptr noundef nonnull align 1 dereferenceable(32) %_492, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_192)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_192, ptr noundef nonnull align 1 dereferenceable(32) %mint, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_193)
  %_331 = load ptr, ptr %6, align 8, !nonnull !2, !align !4, !noundef !2
  %_495 = load ptr, ptr %_331, align 8, !nonnull !2, !align !4, !noundef !2
  %_496 = load ptr, ptr %_495, align 8, !nonnull !2, !align !237, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_193, ptr noundef nonnull align 1 dereferenceable(32) %_496, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_194)
  %706 = getelementptr inbounds i8, ptr %_331, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_194, ptr noundef nonnull align 8 dereferenceable(32) %706, i64 32, i1 false)
  %707 = getelementptr inbounds i8, ptr %_331, i64 165
  %708 = load i8, ptr %707, align 1, !range !9, !noundef !2
  %709 = getelementptr inbounds i8, ptr %_331, i64 163
  %710 = load i8, ptr %709, align 1, !range !9, !noundef !2
  %711 = getelementptr inbounds i8, ptr %e, i64 160
  store i64 %_488.sroa.8.0.copyload, ptr %711, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %e, ptr noundef nonnull align 1 dereferenceable(32) %_191, i64 32, i1 false)
  %712 = getelementptr inbounds i8, ptr %e, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %712, ptr noundef nonnull align 1 dereferenceable(32) %_192, i64 32, i1 false)
  %713 = getelementptr inbounds i8, ptr %e, i64 64
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %713, ptr noundef nonnull align 1 dereferenceable(32) %_193, i64 32, i1 false)
  %714 = getelementptr inbounds i8, ptr %e, i64 96
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %714, ptr noundef nonnull align 1 dereferenceable(32) %old_creator, i64 32, i1 false)
  %715 = getelementptr inbounds i8, ptr %e, i64 128
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %715, ptr noundef nonnull align 1 dereferenceable(32) %_194, i64 32, i1 false)
  %716 = getelementptr inbounds i8, ptr %e, i64 192
  store i8 %708, ptr %716, align 8
  %717 = getelementptr inbounds i8, ptr %e, i64 193
  store i8 %710, ptr %717, align 1
  %718 = getelementptr inbounds i8, ptr %e, i64 168
  store i64 %old_fee, ptr %718, align 8
  %719 = getelementptr inbounds i8, ptr %e, i64 176
  store i64 %nf, ptr %719, align 8
  %720 = getelementptr inbounds i8, ptr %e, i64 194
  %721 = zext i1 %581 to i8
  store i8 %721, ptr %720, align 2
  %722 = getelementptr inbounds i8, ptr %e, i64 184
  store i64 %_72.sroa.0.0, ptr %722, align 8
  %723 = getelementptr inbounds i8, ptr %e, i64 195
  %724 = zext i1 %pool_updated.sroa.0.1.off0 to i8
  store i8 %724, ptr %723, align 1
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_194)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_193)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_192)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_191)
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_202)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_204)
  call void @"_ZN79_$LT$pump_recovered..admin_cto..AdminCtoEvent$u20$as$u20$anchor_lang..Event$GT$4data17h2de1473225a7d978E"(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_204, ptr noalias noundef nonnull readonly align 8 dereferenceable(200) %e) #37
  %725 = getelementptr inbounds i8, ptr %_204, i64 8
  %_499 = load ptr, ptr %725, align 8, !nonnull !2, !noundef !2
  %726 = getelementptr inbounds i8, ptr %_204, i64 16
  %_498 = load i64, ptr %726, align 8, !noundef !2
  store ptr %_499, ptr %_202, align 8
  %727 = getelementptr inbounds i8, ptr %_202, i64 8
  store i64 %_498, ptr %727, align 8
  call void @_ZN14solana_program3log12sol_log_data17h1e024b73f122854fE(ptr noalias noundef nonnull readonly align 8 %_202, i64 noundef 1) #37
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_204)
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_202)
  %_207 = getelementptr inbounds i8, ptr %_247, i64 312
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %authority_info, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_207) #37
  %728 = getelementptr inbounds i8, ptr %ctx, i64 46
  %authority_bump = load i8, ptr %728, align 2, !noundef !2
  call void @"_ZN79_$LT$pump_recovered..admin_cto..AdminCtoEvent$u20$as$u20$anchor_lang..Event$GT$4data17h2de1473225a7d978E"(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %inner_data, ptr noalias noundef nonnull readonly align 8 dereferenceable(200) %e) #37
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %ix_data)
  %me.sroa.0.0.copyload.i = load i64, ptr %inner_data, align 8, !alias.scope !1966, !noalias !1969
  %me.sroa.4.0.self.sroa_idx.i = getelementptr inbounds i8, ptr %inner_data, i64 8
  %me.sroa.4.0.copyload.i = load ptr, ptr %me.sroa.4.0.self.sroa_idx.i, align 8, !alias.scope !1966, !noalias !1969, !nonnull !2, !noundef !2
  %me.sroa.5.0.self.sroa_idx.i = getelementptr inbounds i8, ptr %inner_data, i64 16
  %me.sroa.5.0.copyload.i = load i64, ptr %me.sroa.5.0.self.sroa_idx.i, align 8, !alias.scope !1966, !noalias !1969
  %_18.i263 = getelementptr inbounds i8, ptr %me.sroa.4.0.copyload.i, i64 %me.sroa.5.0.copyload.i
  %729 = getelementptr inbounds i8, ptr %_213, i64 32
  store ptr @alloc_d1e50873cb16f1fc41ca481a2a657dfa, ptr %729, align 8
  %730 = getelementptr inbounds i8, ptr %_213, i64 40
  store ptr getelementptr inbounds (<{ [8 x i8] }>, ptr @alloc_d1e50873cb16f1fc41ca481a2a657dfa, i64 1, i32 0, i64 0), ptr %730, align 8
  store ptr %me.sroa.4.0.copyload.i, ptr %_213, align 8
  %_509.sroa.4.0._213.sroa_idx = getelementptr inbounds i8, ptr %_213, i64 8
  store ptr %me.sroa.4.0.copyload.i, ptr %_509.sroa.4.0._213.sroa_idx, align 8
  %_509.sroa.5.0._213.sroa_idx = getelementptr inbounds i8, ptr %_213, i64 16
  store i64 %me.sroa.0.0.copyload.i, ptr %_509.sroa.5.0._213.sroa_idx, align 8
  %_509.sroa.6.0._213.sroa_idx = getelementptr inbounds i8, ptr %_213, i64 24
  store ptr %_18.i263, ptr %_509.sroa.6.0._213.sroa_idx, align 8
  call fastcc void @"_ZN98_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter..SpecFromIter$LT$T$C$I$GT$$GT$9from_iter17hfacb5ed38c39aa2dE"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %ix_data, ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %_213) #37
  call void @llvm.lifetime.start.p0(i64 80, ptr nonnull %ix)
  %731 = getelementptr inbounds i8, ptr %ix_data, i64 8
  %_512 = load ptr, ptr %731, align 8, !nonnull !2, !noundef !2
  %732 = getelementptr inbounds i8, ptr %ix_data, i64 16
  %_511 = load i64, ptr %732, align 8, !noundef !2
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_220)
  %_222 = call fastcc noundef ptr @_ZN5alloc5alloc15exchange_malloc17h6cd8dd11b0e3424eE(i64 noundef 34, i64 noundef 1) #37
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_224.sroa.0)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_225)
  %_339 = load ptr, ptr %authority_info, align 8, !nonnull !2, !align !237, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_225, ptr noundef nonnull align 1 dereferenceable(32) %_339, i64 32, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_224.sroa.0, ptr noundef nonnull align 1 dereferenceable(32) %_225, i64 32, i1 false)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_225)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_222, ptr noundef nonnull align 1 dereferenceable(32) %_224.sroa.0, i64 32, i1 false)
  %_224.sroa.4.0..sroa_idx = getelementptr inbounds i8, ptr %_222, i64 32
  store i8 1, ptr %_224.sroa.4.0..sroa_idx, align 1
  %_224.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %_222, i64 33
  store i8 0, ptr %_224.sroa.5.0..sroa_idx, align 1
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_224.sroa.0)
  store i64 1, ptr %_220, align 8, !alias.scope !1971, !noalias !1974
  %733 = getelementptr inbounds i8, ptr %_220, i64 8
  store ptr %_222, ptr %733, align 8, !alias.scope !1971, !noalias !1974
  %734 = getelementptr inbounds i8, ptr %_220, i64 16
  store i64 1, ptr %734, align 8, !alias.scope !1971, !noalias !1974
  call void @_ZN18solana_instruction11Instruction14new_with_bytes17h836fab8fb6401158E(ptr noalias nocapture noundef nonnull sret([80 x i8]) align 8 dereferenceable(80) %ix, ptr noalias nocapture noundef nonnull readonly align 1 dereferenceable(32) @_ZN14pump_recovered2ID17h8e245cf89cf2c06bE, ptr noalias noundef nonnull readonly align 1 %_512, i64 noundef %_511, ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(24) %_220) #37
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_220)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_228)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_232)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %_232, ptr noundef nonnull align 8 dereferenceable(48) %authority_info, i64 48, i1 false)
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_235)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_238)
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %_242)
  store i8 %authority_bump, ptr %_242, align 1
  store ptr @alloc_7a7952b5e0d15f2b72d0341cef6d4739, ptr %_238, align 8
  %735 = getelementptr inbounds i8, ptr %_238, i64 8
  store i64 17, ptr %735, align 8
  %736 = getelementptr inbounds [2 x { ptr, i64 }], ptr %_238, i64 0, i64 1
  store ptr %_242, ptr %736, align 8
  %737 = getelementptr inbounds [2 x { ptr, i64 }], ptr %_238, i64 0, i64 1, i32 1
  store i64 1, ptr %737, align 8
  store ptr %_238, ptr %_235, align 8
  %738 = getelementptr inbounds i8, ptr %_235, i64 8
  store i64 2, ptr %738, align 8
  call void @_ZN14solana_program7program13invoke_signed17h01c3b84bc1fc491eE(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_228, ptr noalias noundef nonnull readonly align 8 dereferenceable(80) %ix, ptr noalias noundef nonnull readonly align 8 %_232, i64 noundef 1, ptr noalias noundef nonnull readonly align 8 %_235, i64 noundef 1) #37
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_516)
  %739 = load i64, ptr %_228, align 8, !range !236, !noundef !2
  %740 = icmp eq i64 %739, -9223372036854775782
  br i1 %740, label %bb120, label %bb119

bb110:                                            ; preds = %bb35
  %741 = getelementptr inbounds i8, ptr %_189, i64 8
  %_489.sroa.0.0.copyload = load i64, ptr %741, align 8
  %_489.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %_189, i64 16
  %_489.sroa.5.0.copyload = load i64, ptr %_489.sroa.5.0..sroa_idx, align 8
  %_489.sroa.6.0..sroa_idx = getelementptr inbounds i8, ptr %_189, i64 24
  %_489.sroa.6.0.copyload = load i64, ptr %_489.sroa.6.0..sroa_idx, align 8
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_189)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_493)
  store i64 %_489.sroa.0.0.copyload, ptr %_493, align 8
  %residual7.sroa.2.0._493.sroa_idx = getelementptr inbounds i8, ptr %_493, i64 8
  store i64 %_489.sroa.5.0.copyload, ptr %residual7.sroa.2.0._493.sroa_idx, align 8
  %residual7.sroa.3.0._493.sroa_idx = getelementptr inbounds i8, ptr %_493, i64 16
  store i64 %_489.sroa.6.0.copyload, ptr %residual7.sroa.3.0._493.sroa_idx, align 8
  %742 = call { i64, ptr } @"_ZN107_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$solana_program_error..ProgramError$GT$$GT$4from17ha4865197be4b9a2fE"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(24) %_493) #37
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_493)
  br label %bb51

bb120:                                            ; preds = %bb111
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_516)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_228)
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %_242)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_238)
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_235)
  %743 = getelementptr inbounds i8, ptr %_232, i64 8
  %_232.val73 = load ptr, ptr %743, align 8, !nonnull !2, !noundef !2
  %744 = getelementptr inbounds i8, ptr %_232, i64 16
  %_232.val74 = load ptr, ptr %744, align 8
  %self1.val.i.i.i.i = load i64, ptr %_232.val73, align 8, !noundef !2
  %val.i.i.i.i = add i64 %self1.val.i.i.i.i, -1
  store i64 %val.i.i.i.i, ptr %_232.val73, align 8
  %745 = icmp eq i64 %val.i.i.i.i, 0
  br i1 %745, label %bb1.i.i.i.i, label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i"

bb1.i.i.i.i:                                      ; preds = %bb120
  %746 = getelementptr i8, ptr %_232.val73, i64 8
  %self2.val.i.i.i.i = load i64, ptr %746, align 8, !noundef !2
  %val6.i.i.i.i = add i64 %self2.val.i.i.i.i, -1
  store i64 %val6.i.i.i.i, ptr %746, align 8
  br label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i"

"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i": ; preds = %bb1.i.i.i.i, %bb120
  %747 = icmp ne ptr %_232.val74, null
  call void @llvm.assume(i1 %747)
  %self1.val.i.i2.i.i = load i64, ptr %_232.val74, align 8, !noundef !2
  %val.i.i3.i.i = add i64 %self1.val.i.i2.i.i, -1
  store i64 %val.i.i3.i.i, ptr %_232.val74, align 8
  %748 = icmp eq i64 %val.i.i3.i.i, 0
  br i1 %748, label %bb1.i.i4.i.i, label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit"

bb1.i.i4.i.i:                                     ; preds = %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i"
  %749 = getelementptr i8, ptr %_232.val74, i64 8
  %self2.val.i.i5.i.i = load i64, ptr %749, align 8, !noundef !2
  %val6.i.i6.i.i = add i64 %self2.val.i.i5.i.i, -1
  store i64 %val6.i.i6.i.i, ptr %749, align 8
  br label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit"

"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit": ; preds = %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i", %bb1.i.i4.i.i
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_232)
  %_1.val.i = load i64, ptr %ix, align 8, !alias.scope !1976, !noundef !2
  %750 = icmp eq i64 %_1.val.i, 0
  br i1 %750, label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i", label %bb2.i.i.i.i

bb2.i.i.i.i:                                      ; preds = %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit"
  %751 = getelementptr inbounds i8, ptr %ix, i64 8
  %_1.val2.i = load ptr, ptr %751, align 8, !alias.scope !1976
  %752 = icmp ne ptr %_1.val2.i, null
  call void @llvm.assume(i1 %752)
  br label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i"

"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i": ; preds = %bb2.i.i.i.i, %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit"
  %753 = getelementptr inbounds i8, ptr %ix, i64 24
  %.val.i = load i64, ptr %753, align 8, !alias.scope !1976, !noundef !2
  %754 = icmp eq i64 %.val.i, 0
  br i1 %754, label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit", label %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i"

"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i": ; preds = %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i"
  %755 = getelementptr inbounds i8, ptr %ix, i64 32
  %.val1.i = load ptr, ptr %755, align 8, !alias.scope !1976
  %756 = icmp ne ptr %.val1.i, null
  call void @llvm.assume(i1 %756)
  br label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit"

"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit": ; preds = %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i", %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i"
  call void @llvm.lifetime.end.p0(i64 80, ptr nonnull %ix)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %ix_data)
  call void @llvm.lifetime.end.p0(i64 200, ptr nonnull %e)
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %_91)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_86)
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_83)
  call void @llvm.lifetime.end.p0(i64 33, ptr nonnull %hk)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %holder_key)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %mint)
  br label %bb56

bb119:                                            ; preds = %bb111
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_516, ptr noundef nonnull align 8 dereferenceable(24) %_228, i64 24, i1 false)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_518)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_518, ptr noundef nonnull align 8 dereferenceable(24) %_516, i64 24, i1 false)
  %757 = call { i64, ptr } @"_ZN107_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$solana_program_error..ProgramError$GT$$GT$4from17ha4865197be4b9a2fE"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(24) %_518) #37
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_518)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_516)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_228)
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %_242)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_238)
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_235)
  %758 = getelementptr inbounds i8, ptr %_232, i64 8
  %_232.val = load ptr, ptr %758, align 8, !nonnull !2, !noundef !2
  %759 = getelementptr inbounds i8, ptr %_232, i64 16
  %_232.val72 = load ptr, ptr %759, align 8
  %self1.val.i.i.i.i266 = load i64, ptr %_232.val, align 8, !noundef !2
  %val.i.i.i.i267 = add i64 %self1.val.i.i.i.i266, -1
  store i64 %val.i.i.i.i267, ptr %_232.val, align 8
  %760 = icmp eq i64 %val.i.i.i.i267, 0
  br i1 %760, label %bb1.i.i.i.i274, label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i268"

bb1.i.i.i.i274:                                   ; preds = %bb119
  %761 = getelementptr i8, ptr %_232.val, i64 8
  %self2.val.i.i.i.i275 = load i64, ptr %761, align 8, !noundef !2
  %val6.i.i.i.i276 = add i64 %self2.val.i.i.i.i275, -1
  store i64 %val6.i.i.i.i276, ptr %761, align 8
  br label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i268"

"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i268": ; preds = %bb1.i.i.i.i274, %bb119
  %762 = icmp ne ptr %_232.val72, null
  call void @llvm.assume(i1 %762)
  %self1.val.i.i2.i.i269 = load i64, ptr %_232.val72, align 8, !noundef !2
  %val.i.i3.i.i270 = add i64 %self1.val.i.i2.i.i269, -1
  store i64 %val.i.i3.i.i270, ptr %_232.val72, align 8
  %763 = icmp eq i64 %val.i.i3.i.i270, 0
  br i1 %763, label %bb1.i.i4.i.i271, label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit277"

bb1.i.i4.i.i271:                                  ; preds = %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i268"
  %764 = getelementptr i8, ptr %_232.val72, i64 8
  %self2.val.i.i5.i.i272 = load i64, ptr %764, align 8, !noundef !2
  %val6.i.i6.i.i273 = add i64 %self2.val.i.i5.i.i272, -1
  store i64 %val6.i.i6.i.i273, ptr %764, align 8
  br label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit277"

"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit277": ; preds = %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i268", %bb1.i.i4.i.i271
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_232)
  %_1.val.i278 = load i64, ptr %ix, align 8, !alias.scope !1979, !noundef !2
  %765 = icmp eq i64 %_1.val.i278, 0
  br i1 %765, label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i281", label %bb2.i.i.i.i279

bb2.i.i.i.i279:                                   ; preds = %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit277"
  %766 = getelementptr inbounds i8, ptr %ix, i64 8
  %_1.val2.i280 = load ptr, ptr %766, align 8, !alias.scope !1979
  %767 = icmp ne ptr %_1.val2.i280, null
  call void @llvm.assume(i1 %767)
  br label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i281"

"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i281": ; preds = %bb2.i.i.i.i279, %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit277"
  %768 = getelementptr inbounds i8, ptr %ix, i64 24
  %.val.i282 = load i64, ptr %768, align 8, !alias.scope !1979, !noundef !2
  %769 = icmp eq i64 %.val.i282, 0
  br i1 %769, label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit285", label %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i283"

"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i283": ; preds = %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i281"
  %770 = getelementptr inbounds i8, ptr %ix, i64 32
  %.val1.i284 = load ptr, ptr %770, align 8, !alias.scope !1979
  %771 = icmp ne ptr %.val1.i284, null
  call void @llvm.assume(i1 %771)
  br label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit285"

"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit285": ; preds = %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i281", %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i283"
  call void @llvm.lifetime.end.p0(i64 80, ptr nonnull %ix)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %ix_data)
  br label %bb51

bb56:                                             ; preds = %bb55, %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit"
  %_0.sroa.11.1 = phi ptr [ %_0.sroa.11.4, %bb55 ], [ undef, %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit" ]
  %_0.sroa.0.1 = phi i64 [ %_0.sroa.0.4, %bb55 ], [ 2, %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit" ]
  %772 = insertvalue { i64, ptr } poison, i64 %_0.sroa.0.1, 0
  %773 = insertvalue { i64, ptr } %772, ptr %_0.sroa.11.1, 1
  ret { i64, ptr } %773

bb51:                                             ; preds = %bb110, %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit285"
  %.pn = phi { i64, ptr } [ %742, %bb110 ], [ %757, %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit285" ]
  %_0.sroa.0.2 = extractvalue { i64, ptr } %.pn, 0
  call void @llvm.lifetime.end.p0(i64 200, ptr nonnull %e)
  br label %bb53

bb53:                                             ; preds = %bb51, %bb32, %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit262
  %.pn.pn.pn = phi { i64, ptr } [ %675, %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit262 ], [ %.pn, %bb51 ], [ %703, %bb32 ]
  %_0.sroa.0.3 = phi i64 [ %676, %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit262 ], [ %_0.sroa.0.2, %bb51 ], [ %704, %bb32 ]
  %_0.sroa.11.3 = extractvalue { i64, ptr } %.pn.pn.pn, 1
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %_91)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_86)
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_83)
  br label %bb55

bb55:                                             ; preds = %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit, %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread311, %bb53, %bb74, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit", %bb65, %bb63
  %_0.sroa.11.4 = phi ptr [ %_42.sroa.33.1.ph, %bb63 ], [ %_0.sroa.11.3, %bb53 ], [ %582, %bb74 ], [ %_58.1, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit" ], [ %179, %bb65 ], [ %_0.sroa.11.4.i.ph, %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread311 ], [ %_0.sroa.11.4.i, %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit ]
  %_0.sroa.0.4 = phi i64 [ %_42.sroa.22.1.ph, %bb63 ], [ %_0.sroa.0.3, %bb53 ], [ %_397.sroa.0.3, %bb74 ], [ %_58.0, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit" ], [ %175, %bb65 ], [ %_0.sroa.0.4.i.ph, %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread311 ], [ %_0.sroa.0.4.i, %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit ]
  call void @llvm.lifetime.end.p0(i64 33, ptr nonnull %hk)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %holder_key)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %mint)
  br label %bb56
}