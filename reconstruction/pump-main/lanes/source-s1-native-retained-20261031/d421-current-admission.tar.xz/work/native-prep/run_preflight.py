"""FrozenD4219123 actual-controller path binding for real no-SDK preflight only."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys

ROOT=Path(__file__).resolve().parents[2]
FOLDER=ROOT/'work/native-prep'
CONTROLLER=FOLDER/'ops/reconstruction/pump-main/lanes/current-native-control/pump_current_control.py'
RSYNC=Path('/workspace/pumpfun-source-workers/pump-lifecycle/work/host-tools/rsync-debian-13/extracted/usr/bin/rsync')
assert hashlib.sha256(RSYNC.read_bytes()).hexdigest()=='a56c05b960beb734169619d5760b43ff495e84f85a93eb1f54fe58118262fb20'
os.environ.update(PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1',GIT_ALLOW_PROTOCOL='file',RUNNER_TEMP=str(FOLDER/'runner-temp'))
os.environ['PATH']=str(RSYNC.parent)+os.pathsep+os.environ['PATH']
os.environ['LD_LIBRARY_PATH']=str(RSYNC.parents[1]/'lib/x86_64-linux-gnu')
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('currentD4219123_native_control',CONTROLLER)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.ROOT=ROOT;module.EVIDENCE=FOLDER/'preflight/evidence';module.WORK=FOLDER/'preflight/cold-work'
# Real frozen Git vectors, maintained snapshot/stage with qualified real rsync,
# and pure link-script admission. No source/stage/authentication substitutions.
module.main(preflight_only=True)
(FOLDER/'PREFLIGHT-EXECUTION.json').write_text(json.dumps({
 'command':[sys.executable,'-B','work/native-prep/run_preflight.py'],'exitCode':0,
 'sourceRoot':str(ROOT),'head':module.git('rev-parse','HEAD').decode().strip(),
 'controllerSha256':hashlib.sha256(CONTROLLER.read_bytes()).hexdigest(),
 'rsyncSha256':hashlib.sha256(RSYNC.read_bytes()).hexdigest(),
 'evidence':str(module.EVIDENCE),'work':str(module.WORK),
 'sdkRun':False,'bootstrapRun':False,'cargoRun':False,'compilerRun':False,
 'fullNativeOperationalParentAdmissionExercised':False},indent=2)+'\n')
