"""One normalized CTO measurement using the previously sealed Ebe metric."""
from pathlib import Path
import datetime, difflib, hashlib, importlib.util, json, os, sys, time

R=Path('/dev/shm/pump-cto-d421-control')
O=R/'work/current-target-metric'
HELPER=Path('/dev/shm/pump-cto-ebe5387/work/target-token-metric/read_target.py')
OLD=Path('/dev/shm/pump-cto-ebe5387/work/target-token-metric/stdout')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path,value):
    with path.open('x') as stream:stream.write(json.dumps(value,indent=2)+'\n')
def identity(path):
    s=path.stat();return {'path':str(path),'bytes':s.st_size,'sha256':sha(path),'mode':s.st_mode,'device':s.st_dev,'inode':s.st_ino,'mtimeNs':s.st_mtime_ns}
assert sys.dont_write_bytecode and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1'
assert not O.exists()
assert sha(HELPER)=='6eccf05c2b37ec55d519e606731273c1621a13afbf6bdf06e5da5493a03b43b6'
assert sha(OLD)=='e77fa54acbb9a9d90d80a1d2abc74c88a01d7872a70659fda26bd948406c731d'
admission=R/'work/root/CURRENT-ELF-ADMISSION.json';review=R/'work/secondary-admission-reader/actual-review/REVIEW.json'
assert sha(admission)=='cdd4389fe35f55d994b25d708b576a66a34c4a5e6700f4e7b124bc4a433ec105'
assert sha(review)=='c27957a10e4e9ecc38d9a714a2cf1c306e1ebafa19437b856198ec7186226998'
a=json.loads(admission.read_text());v=json.loads(review.read_text());old=json.loads(OLD.read_text())
assert a['base']=='d4219123cf0fbbefcfc7e77450efeda6684b812b' and a['raw']==a['normalized']==1034 and a['nativeNoLossConclusion']=='PASS'
assert len(v['checks'])==39 and all(r['pass'] for r in v['checks'])
assert old['Ebe']['normalizedMatchingLogicalInstructionsM']==2247
spec=importlib.util.spec_from_file_location('sealed_ebe_metric_functions',HELPER);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
method_root=Path('/dev/shm/pump-cto-ebe5387/reconstruction/harness')
for name,expected in module.METHOD.items():assert sha(method_root/name)==expected
original=R/'evidence/original/pump/deployed.so';candidate=R/'work/native-run/artifact/unstripped.so';archive=R/'work/native-run/raw-artifact.zip'
assert sha(original)==module.ORIGINAL and sha(candidate)==a['images']['unstripped.so']=='e9df54086dcfc8ca1a4833d3577bc5092e3e23eae2c4492d52bdea661ba82a85'
assert sha(archive)=='6ce20ac22fa9d7d2852d0e2c47d129c5c72936a5664592bf1b17db0871ea73e7'
paths=[Path(__file__),HELPER,OLD,admission,review,original,candidate,archive,R/'programs/pump/src/creator/admin_cto.rs',Path(sys.executable).resolve(),*[method_root/n for n in module.METHOD]]
before=[identity(p) for p in paths];O.mkdir();dump(O/'BEFORE.json',before)
dump(O/'STARTED.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'readerSHA256':sha(Path(__file__)),'source':a['base'],'nativeQualification':sha(admission),'rootSecondaryQualification':sha(review),'method':'Same sealed Ebe normalizer/SequenceMatcher; no current method substitution or old Ebe ELF read.','measurementsPermitted':1})
clock=time.monotonic()
try:
    ob=original.read_bytes();cb=candidate.read_bytes();os_,_=module.elf(ob);cs,syms=module.elf(cb)
    original_body=module.body(os_,old['original']['start'],old['original']['bytes'])
    assert hashlib.sha256(original_body).hexdigest()==old['original']['bodySha256']
    symbols=[s for s in syms if s[0]==a['CTO']['name'] and s[1]&15==2 and s[2]==cs['.text'][2]];assert len(symbols)==1;s=symbols[0]
    current_body=module.body(cs,s[3],s[4]);assert hashlib.sha256(current_body).hexdigest()==a['CTO']['bodySha256']
    original_tokens=module.normalized_tokens(original_body,os_);tokens=module.normalized_tokens(current_body,cs)
    matcher=difflib.SequenceMatcher(None,original_tokens,tokens,autojunk=False)
    matching=sum(b.size for b in matcher.get_matching_blocks())
    result={'status':'CURRENT_D421_TARGET_TOKEN_MEASUREMENT_COMPLETE','source':a['base'],'provider':{'run':41210896548,'artifact':13045424986,'operational':'5b09cc4f3afb11eaba2479700ac67411ce976750'},'images':{'unstripped':sha(candidate),'original':sha(original)},'methodFiles':module.METHOD,'original':old['original'],'current':{'symbol':s[0],'start':s[3],'bytes':s[4],'bodySHA256':hashlib.sha256(current_body).hexdigest(),'logicalInstructions':len(tokens),'M':matching,'ratio':matcher.ratio()},'sealedEbe':{'M':2247,'receiptSHA256':sha(OLD),'recomputed':False},'currentMinusSealedEbeM':matching-2247,'reportedPlusOneConfirmed':matching-2247==1,'limits':'One target-token similarity measurement on qualified current source. No new official score, compiler, VM, raw metric, source variant, original Rust signature/lifetime or whole-window equality claim. Root secondary39 review is not an independent agent review.'}
    dump(O/'RESULT.json',result)
    after=[identity(p) for p in paths];assert after==before;dump(O/'AFTER.json',after)
    dump(O/'EXECUTION.json',{'pid':os.getpid(),'elapsedSeconds':time.monotonic()-clock,'exitCode':0,'inputsUnchanged':True,'inputCount':len(paths),'resultSHA256':sha(O/'RESULT.json'),'metricExecutions':1,'otherCompilerScorerVMExecutions':0})
    print(json.dumps(result,indent=2))
except BaseException as error:
    dump(O/'FAILURE.json',{'type':type(error).__name__,'message':str(error),'retryAuthorized':False});raise
