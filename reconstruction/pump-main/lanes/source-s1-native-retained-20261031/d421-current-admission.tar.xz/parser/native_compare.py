"""Read-only CTO-local native diagnostics; never an official/full scorer.

Run without --candidate to bind the original/control anchors. After root admits
the raw candidate, supply its path and exact expected SHA. No compiler or
maintained harness module is imported.
"""
from pathlib import Path
from collections import Counter
import argparse
import difflib
import hashlib
import json
import struct

ROOT=Path('/dev/shm/pump-cto-option-c1')
ORIGINAL=Path('/dev/shm/pump-cto-faf9962/evidence/original/pump/deployed.so')
CONTROL=ROOT/'work/current39eb-reference/unstripped.so'
ORIGINAL_SHA='7a19affaa2c6187e04a5fe0ea298cee81fa5eb8c24cfcc30d85f615e89f7b02d'
CONTROL_SHA='289b7d63122fb1f8a64213df1b781b49aa596448e2f33256fa85365d9f7ed4f4'
SOURCE_SHA='b174dbe371579ab43b00cf1fe0711cdaed4e8e0b6e3c737267884b7c127afa79'
CTO='_ZN14pump_recovered9admin_cto7execute17h3bd6d7f34f2e30d7E'
WIDTH={0x60:4,0x68:2,0x70:1,0x78:8}


def sha(b):return hashlib.sha256(b).hexdigest()


def elf(path,expected):
    b=path.read_bytes();assert sha(b)==expected,(path,sha(b))
    assert b[:7]==b'\x7fELF\x02\x01\x01'
    assert struct.unpack_from('<I',b,48)[0] in (0,1)
    off=struct.unpack_from('<Q',b,40)[0];size,n,ni=struct.unpack_from('<HHH',b,58)
    assert size==64
    ss=[struct.unpack_from('<IIQQQQIIQQ',b,off+i*size) for i in range(n)]
    names=ss[ni];names=b[names[4]:names[4]+names[5]]
    text=next(s for s in ss if names[s[0]:names.find(b'\0',s[0])]==b'.text')
    symbols=[]
    for s in ss:
        if s[1]!=2:continue
        st=ss[s[6]];st=b[st[4]:st[4]+st[5]]
        for p in range(s[4],s[4]+s[5],24):
            name,info,other,idx,address,length=struct.unpack_from('<IBBHQQ',b,p)
            if info&15==2 and length:
                symbols.append({'address':address,'bytes':length,'name':st[name:st.find(b'\0',name)].decode()})
    return b,text,symbols


def decode(raw,start,symbols):
    byname={x['address']:x['name'] for x in symbols}
    rows=[];p=0
    while p<len(raw):
        op,reg,disp,imm=struct.unpack_from('<BBhi',raw,p);z=16 if op==0x18 else 8
        assert p+z<=len(raw)
        d,s=reg&15,reg>>4
        r={'offset':p,'va':start+p,'opcode':op,'dst':d,'src':s,'displacement':disp,
           'immediate':imm,'bytes':z,'raw':raw[p:p+z].hex()}
        if op==0x85 and s==1 and imm!=-1:
            r['callTarget']=start+p+8+imm*8;r['callName']=byname.get(r['callTarget'])
        elif op==0x85:r['opaqueCall']=True
        elif op&7 in (5,6) and op&0xf0 not in (0x80,0x90):r['jump']=p+8+disp*8
        if op&7 in (1,2,3) and op&0xf8 in WIDTH:
            r['memoryWidth']=WIDTH[op&0xf8];r['memoryKind']='read' if op&7==1 else 'write'
            r['memoryBase']=s if op&7==1 else d
        rows.append(r);p+=z
    assert p==len(raw)
    return rows


def cfg(rows,length):
    by={r['offset']:r for r in rows};leaders={0}
    for r in rows:
        q=r['offset']+r['bytes']
        if 'jump' in r:
            assert r['jump'] in by,'branch enters continuation/outside body'
            leaders.add(r['jump'])
            if q in by:leaders.add(q)
        elif r['opcode']==0x95 and q in by:leaders.add(q)
    starts=sorted(leaders);blocks=[]
    for i,p in enumerate(starts):
        end=starts[i+1] if i+1<len(starts) else length
        rr=[r for r in rows if p<=r['offset']<end];last=rr[-1]
        if 'jump' in last:
            succ=[last['jump']]
            if last['opcode']&0xf0 and end in by:succ.append(end)
        elif last['opcode']==0x95:succ=[]
        else:succ=[end] if end in by else []
        blocks.append({'start':p,'end':end,'successors':succ})
    for b in blocks:b['predecessors']=[p['start'] for p in blocks if b['start'] in p['successors']]
    return blocks


def new_argument_flow(rows,blocks):
    """Must-fact pointer/data provenance on the static CFG, never scalar execution.

    Calls clobber r0-r5. The known memcmp and PDA ABI contracts preserve input
    bytes / write only the33-byte PDA sret. Every other escaped FP address
    conservatively kills saved stack facts. Every CFG edge joins.
    Consequently reported new-byte origins are lower bounds, not alias closure.
    """
    byblock={b['start']:[r for r in rows if b['start']<=r['offset']<b['end']] for b in blocks}
    bycfg={b['start']:b for b in blocks}
    initial={'registers':{5:('arg_frame',0),10:('fp',0)},'pointers':{},'newBytes':{}}
    def clone(s):return {k:dict(v) for k,v in s.items()}
    def meet(states):
        out=clone(states[0])
        for s in states[1:]:
            for key in out:out[key]={k:v for k,v in out[key].items() if s[key].get(k)==v}
        return out
    def transfer(code,state,events=None):
        state=clone(state);regs=state['registers'];ptrs=state['pointers'];mem=state['newBytes']
        for r in code:
            op,d,s,disp=r['opcode'],r['dst'],r['src'],r['displacement'];cls=op&7
            if r.get('memoryKind'):
                width=r['memoryWidth'];base=regs.get(r['memoryBase']);addr=base[1]+disp if base and base[0] in ('fp','arg_frame','new') else None
                if r['memoryKind']=='read':
                    value=None
                    if base and base[0]=='new':
                        value=('new_data',addr,width)
                        if events is not None:events['loads'].append({'instruction':r,'newByteRange':[addr,addr+width]})
                    elif base and base[0]=='arg_frame' and addr==-4088 and width==8:
                        value=('new',0)
                        if events is not None:events['pointerDefinitions'].append(r)
                    elif base and base[0]=='fp':
                        value=ptrs.get(addr) if width==8 else None
                        data=[mem.get(addr+i) for i in range(width)]
                        if value is None and data[0] is not None and data==list(range(data[0],data[0]+width)):value=('new_data',data[0],width)
                    if value is None:regs.pop(d,None)
                    else:regs[d]=value
                elif base and base[0]=='fp':
                    for p in list(ptrs):
                        if p<addr+width and addr<p+8:ptrs.pop(p)
                    for p in range(addr,addr+width):mem.pop(p,None)
                    value=regs.get(s) if cls==3 else None
                    if value and value[0] in ('fp','arg_frame','new') and width==8:ptrs[addr]=value
                    elif value and value[0]=='new_data' and value[2]==width:
                        for i in range(width):mem[addr+i]=value[1]+i
                        if events is not None:events['copies'].append({'instruction':r,'newByteRange':[value[1],value[1]+width],'destinationFpRange':[addr,addr+width]})
                elif base and base[0]=='new' and events is not None:events['writesThroughNew'].append(r)
            elif op==0xbf:
                if s in regs:regs[d]=regs[s]
                else:regs.pop(d,None)
            elif op==0x07:
                value=regs.get(d)
                if value and value[0] in ('fp','arg_frame','new'):regs[d]=(value[0],value[1]+r['immediate'])
                else:regs.pop(d,None)
            elif op in (0x85,0x8d):
                name=r.get('callName') or ''
                if name=='memcmp':pass
                elif 'find_program_address' in name:
                    output=regs.get(1)
                    if output and output[0]=='fp':
                        addr=output[1]
                        for p in list(ptrs):
                            if p<addr+33 and addr<p+8:ptrs.pop(p)
                        for p in range(addr,addr+33):mem.pop(p,None)
                    else:ptrs.clear();mem.clear()
                elif any(regs.get(x,('',))[0]=='fp' for x in range(1,6)):ptrs.clear();mem.clear()
                for x in range(6):regs.pop(x,None)
            elif cls in (0,4,7):regs.pop(d,None)
        return state
    incoming={0:initial};outgoing={};pending=[0];updates=0
    while pending:
        p=pending.pop();out=transfer(byblock[p],incoming[p])
        if outgoing.get(p)==out:continue
        outgoing[p]=out;updates+=1;assert updates<100000,'static fact analysis failed to converge'
        for q in bycfg[p]['successors']:
            states=[outgoing[x] for x in bycfg[q]['predecessors'] if x in outgoing]
            if q==0:states.append(initial)
            joined=meet(states)
            if incoming.get(q)!=joined:incoming[q]=joined;pending.append(q)
    events={'pointerDefinitions':[],'loads':[],'copies':[],'writesThroughNew':[]}
    for p,state in sorted(incoming.items()):transfer(byblock[p],state,events)
    events.update(reachableBlocks=len(incoming),factUpdates=updates,
                  abiContracts=['memcmp reads its caller input ranges; its result scratch belongs to its own frame.',
                                'find_program_address writes33 bytes to r1; its seed/program-id inputs are read-only.'],
                  limits='Must-fact affine new-pointer provenance under the two explicit standard helper ABI contracts only. Every branch joins; FP facts are killed on any other call receiving an FP alias. No scalar inputs, syscalls or bytecode are executed. Missing origins remain unknown; this is not arbitrary opaque-callee alias closure.')
    return events


def selected_report(path,expected,original=False,attribution_symbols=None):
    blob,text,symbols=elf(path,expected)
    if original:start,length=0x22a10,27400
    else:
        candidates=[x for x in symbols if x['name']==CTO]
        assert len(candidates)==1,candidates
        start,length=candidates[0]['address'],candidates[0]['bytes']
    off=text[4]+start-text[3];raw=blob[off:off+length]
    assert len(raw)==length and text[3]<=start<start+length<=text[3]+text[5]
    rows=decode(raw,start,attribution_symbols if original else symbols)
    blocks=cfg(rows,length);by={r['offset']:r for r in rows}
    # First PDA return copy: recognize only direct load/store pairs, no opaque alias inference.
    pdas=[i for i,r in enumerate(rows) if r.get('callName') and 'find_program_address' in r['callName']]
    first_pda=pdas[0] if pdas else None;copies=[]
    if first_pda is not None:
        for i in range(first_pda+1,min(first_pda+17,len(rows)-1)):
            a,b=rows[i:i+2]
            if a['opcode']==0x79 and a['src']==10 and b['opcode']==0x7b and b['dst']==10 and b['src']==a['dst']:
                copies.append({'load':a,'store':b})
    destinations=sorted({x['store']['displacement'] for x in copies})
    holder_base=destinations[0] if len(destinations)>=4 and destinations[:4]==list(range(destinations[0],destinations[0]+32,8)) else None
    holder_loads=[r for r in rows if holder_base is not None and r['opcode']==0x71 and r['src']==10 and r['displacement']==holder_base]
    fee_blocks=[]
    for r in holder_loads:
        b=next(b for b in blocks if b['start']<=r['offset']<b['end'])
        related=set([b['start'],*b['successors'],*b['predecessors']])
        fee_blocks.append({'possiblePlaceholderRead':r,'block':b,
                           'adjacentBlocks':[{'cfg':x,'instructions':[z for z in rows if x['start']<=z['offset']<x['end']]} for x in blocks if x['start'] in related]})
    # Exact local copy pairs are evidence of data movement, not Rust alloca identities.
    direct_copies=[]
    for a,b in zip(rows,rows[1:]):
        if a.get('memoryKind')=='read' and b.get('memoryKind')=='write' and a['dst']==b['src'] and b['opcode']&7==3:
            if a['memoryWidth']==b['memoryWidth'] and b.get('memoryBase')==10 and a['offset']<0x2200:
                direct_copies.append({'load':a,'store':b})
    calls=[]
    for i,r in enumerate(rows):
        if 'callTarget' in r or r.get('opaqueCall'):
            calls.append({'instruction':r,'before':rows[max(0,i-6):i]})
    error_sources=[r for r in rows if r['opcode']==0x62 and r['dst']==10 and r['immediate'] in [284,289,296,298,306,307,312,326,330,334,338,410]]
    explicit_original_success=None
    if original:
        assert by[0x1800]['opcode']==0x7b and by[0x1800]['src']==4 and by[0x1800]['displacement']==-2328
        assert by[0x1808]['opcode']==0x7b and by[0x1808]['src']==3 and by[0x1808]['displacement']==-2376
        assert by[0x1810]['opcode']==0xb7 and by[0x1810]['dst']==7 and by[0x1810]['immediate']==1
        explicit_original_success={'instructions':[by[p] for p in range(0x1800,0x18b0,8)],'scope':'Exact original fee-Some private exit/shared-test/copy boundary, not a placeholder-byte-load match.'}
    return {'input':{'path':str(path),'sha256':sha(blob),'symbol':CTO,'start':start,'bytes':length,'bodySha256':sha(raw),'logicalInstructions':len(rows)},
            'firstPda':rows[first_pda] if first_pda is not None else None,'firstPdaCopyPairs':copies,
            'retainedHolderKeyFpBase':holder_base,'holderFirstByteLoads':holder_loads,
            'possibleFeeSuccessBlocks':fee_blocks,'originalFeeSomeBoundary':explicit_original_success,
            'newArgumentFlow':new_argument_flow(rows,blocks),'earlyDirectCopyPairs':direct_copies,
            'sourceCoordinateStoresInPhysicalOrder':error_sources,'calls':calls,
            'outlinedValidateCalls':[r for r in rows if r.get('callName') and 'admin_cto8validate' in r['callName']],
            'tokens':[r['raw'] for r in rows],
            'limits':['Candidate source types and volatile qualifiers cannot be recovered from raw encoding alone.',
                      'Direct copy pairs and possible placeholder reads do not resolve arbitrary FP aliases or lifetime identity.',
                      'Original call names use exact control symbol addresses as explicit attribution; original is stripped.']}


def pair(left,right):
    a,b=left['tokens'],right['tokens']
    matcher=difflib.SequenceMatcher(None,a,b,autojunk=False)
    return {'rawLogicalInstructionSequenceRatio':matcher.ratio(),
            'matchingLogicalInstructions':sum(x.size for x in matcher.get_matching_blocks()),
            'leftInstructions':len(a),'rightInstructions':len(b),
            'bodyByteEqual':left['input']['bodySha256']==right['input']['bodySha256'],
            'callNameSequenceEqual':[x['instruction'].get('callName') for x in left['calls']]==[x['instruction'].get('callName') for x in right['calls']],
            'scope':'CTO-local raw logical instruction diagnostic; no normalization, official score, whole-program acceptance or source uniqueness.'}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--candidate',type=Path);p.add_argument('--candidate-sha');p.add_argument('--out',type=Path,required=True)
    args=p.parse_args();assert bool(args.candidate)==bool(args.candidate_sha)
    assert not args.out.exists(),'preserve existing comparison receipt'
    source=(ROOT/'programs/pump/src/creator/admin_cto.rs').read_bytes();assert sha(source)==SOURCE_SHA
    _,_,symbols=elf(CONTROL,CONTROL_SHA)
    control=selected_report(CONTROL,CONTROL_SHA)
    original=selected_report(ORIGINAL,ORIGINAL_SHA,True,symbols)
    assert control['input']['bodySha256']=='93976802fdb77e14e35c8bcf7d4a52d87aacd2b3399adb69aade2e942838c247'
    assert original['input']['bodySha256']=='6a7659fd34097683cbfdae56187f5f73a3ecae20e52ac06a3fd25837e4137a96'
    result={'schema':'cto-option-c1-native-causal-diagnostic-v1','sourceCommit':'0fc50efbc599fa1e025169c8db06fceb25c9c192','sourceLeafSha256':SOURCE_SHA,
            'original':original,'control39eb':control,'originalVsControl':pair(original,control),
            'officialScorerExecuted':False,'compilerIrOrVmExecuted':False,'producerSha256':sha(Path(__file__).read_bytes())}
    if args.candidate:
        candidate=selected_report(args.candidate,args.candidate_sha)
        result.update(candidate=candidate,originalVsCandidate=pair(original,candidate),controlVsCandidate=pair(control,candidate))
    for key in ['original','control39eb','candidate']:
        if key in result:result[key].pop('tokens')
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['originalVsControl','originalVsCandidate','controlVsCandidate'] if k in result}))


if __name__=='__main__':main()
