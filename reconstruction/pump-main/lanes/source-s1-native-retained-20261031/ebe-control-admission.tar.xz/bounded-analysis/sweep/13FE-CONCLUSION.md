First actual13fe fee-control qualification: two incoming fee-tag tests and a
common shared head. This is a newly asked baseline question, not a rerun of a
previously sealed13fe feeCFG. Earlier S3 comparisons did not establish its
parent's control structure.

Image is root-admitted13fe SHA
cec841bd60cc002213829e3149e7c170dbb7f5bbc47a9887cef1ab7e0193319e.
Execute is0x22a10/27400B, body SHA
18f30b0dd11d7ea300af781bb3b958d0ecf341b4f469fabd0942b66f643ba9e2.
Its actual prepare_bonding_curve call is+1a88; only the preceding validation
control is qualified here. No full tail/error-constructor/typed-consumer
analysis or byte-progress metric was performed.

Incoming public-ABI fee tag R4 is copied at+8 to actualFP-2320. Direct-FP
backward reaching-write checks bind two validation-region reads to this spill:
read+aa0/test+aa8 and read+1468/test+1480. Both tests are JEQ0, and both feeNone
edges go directly to+1760. FeeSome entries+ab0 and+1488 have recorded successful
direct CFG routes through the fee checks and block+1758 to+1760.

Actual shared provenance is data_is_empty+188→MOV R6,R0+190→XOR1+198→STX+1a0
toFP-2344. The observed direct slot read is+17a0 with branch+17a8. Its containing
block+1760..17b0 has predecessor block starts {+a50,+1410,+1758}. The first two
contain the explicit feeNone branches; the last has sole successor+1760.
This head is therefore shared by no-fee and successful-fee paths in the bounded
direct CFG. It is not a private feeSome-only head.

No nonzero validate/sweep symbol or corresponding direct outline call is
observed. This does not identify an inliner reason or an original Rust helper.
The source/R4 role and candidate shared-flag chain are explicit premises;
opaque-callee alias closure and input feasibility beyond the recorded direct
routes are not claimed. Native byte reads are not independently labelled
volatile or Source338, and nearby copy widths are not assigned Rust types.

Existing receipt comparison is explicit: original has three validation tag
tests and a bounded private feeSome shared test; S1/S2 each have one tag test
and a common head with a9096B outlined sweep; S3 has three and a private
valid-fee head without a separate settings/sweep outline witness.13fe has two
and a common head, with no separate validate/sweep outline witness.
13FE-COMPARISON.json binds the unchanged reference receipt hashes rather than
reopening their images. These are different source/base measurements, not a
controlled one-factor experiment.

The first reader's initial receipt is retained. A bounded completion added
only the missing head rows and successful-fee route witnesses within the same
baseline question; no metric/scorer/compiler/VM/source operation occurred.
The future Ebe reader now retains these head/route facts in its initial output
to avoid another baseline read after this seal.

Ebe run41176417138 remains uninspected pending root admission. Its actual
extent/frames/tests will be derived independently; an unchanged source line339
does not establish unchanged native control. No original three-test/private
head expectation, accepted-current gain or S4/retrial GO follows here.
