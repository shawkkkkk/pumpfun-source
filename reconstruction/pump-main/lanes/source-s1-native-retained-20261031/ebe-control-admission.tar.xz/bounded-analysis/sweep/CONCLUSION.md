The admitted Ebe current-normal image independently has two validation
incoming-fee-tag tests and one common feeNone/feeSome shared head. These
selected control facts match the newly sealed13fe parent facts. This conclusion
was measured from the admitted image, not assumed from source line339.

Exact Ebe sourceebe5387e12e948c2534618adf7a3cf0f27d9de51, operational
1bb7326cbccd7773f9accba45b9b6379b76ceb12, run41176417138. Independent37-check
review hash is5c30f7461c57f28183ed87f0f83e71a321550251ab65722cd9c9ae22af4fe653;
root current admission hash is
47cd591397090a3fcd3e8dc80e2a1900e0b7ac45dae257d55bf28ec8e181df5e.
Unstripped image SHA256 is
9ac11d9e5692d3ff91d45880d5e442347dac7a76bf7d62870f07fc53247b4fcf.

The unique execute STT_FUNC supplies actual0x22a10/27400B extent. Its body hash
is c8039d904d1c31d837317bce16bc0e08ac1cebfefcb099756ecf8f719213520c,
different from13fe's18f30b0d…. No whole-body byte equality or progress metric is
claimed by matching this selected control slice.

| Actual Ebe fact | Bound witness |
| --- | --- |
| Incoming public-ABI fee tag | R4→FP-2320 at+8; actual destination derived from the entry copy |
| Validation tag tests | Reads+aa0/+1468; JEQ0 tests+aa8/+1480 before actual prepare+1a88 |
| FeeNone edges | Both tests jump directly to+1760 |
| FeeSome continuations | +ab0/+1488 have retained direct CFG routes through the checks and+1758→+1760 |
| Shared flag | data_is_empty+188→MOV R6,R0+190→XOR1+198→spillFP-2344 at+1a0 |
| Shared head | +1760..17b0, predecessors{+a50,+1410,+1758}; loadFP-2344+17a0/test+17a8 |
| Scoped outlines | No nonzero validate/sweep symbols or corresponding direct outline calls |

The common-head raw rows, incoming spill and tests, and head CFG sets equal
the first13fe receipts exactly. EBE-VS-13FE.json retains that cached comparison,
including direct Some/None route operands. Ebe's whole body differs; unchanged
native behavior outside this slice is not inferred. Symbol absence does not
identify a compiler inlining reason or source helper history.

The earlier original/S1/S2/S3 comparison remains bounded: original and S3
have three validation tag tests/private feeSome shared-head witnesses;
S1/S2 have one and a common head with9096B outlined sweep.13fe and Ebe have
two and a common head without separate validate/sweep outline witnesses.
These different source/base observations do not isolate a universal carrier,
inliner or allocator rule. In particular, Ebe is not assumed to recover the
original three-test/private-head structure.

The public source/ABI role, direct-FP entry-copy reaching writes and explicit
direct CFG establish these facts. Static routes establish graph connectivity,
not all-input feasibility or arbitrary opaque-callee alias closure. No native
byte read is independently relabelled Source338/volatile here; no nearby copy
width is identified as Result/Try/target/sharing payload. Typed consumer roles
remain with context. Event owns the Ebe metric and root owns official scoring.

One Ebe reader invocation produced the scoped facts; its cached output alone
produced the comparison. No Ebe ELF reopen, generic full-CTO/tail/error analysis,
metric, compiler, scorer, VM or source variant occurred. The first13fe question
had a successful narrow initial extraction followed by a bounded head/route
completion; both receipts and the original reader version are retained. There
was no failed13fe reader execution to reclassify or hide.

This qualifies the accepted-current normal control only. It creates no S4,
source-gain, new hypothesis or retrial GO. Historical preparation documents
retain their pre-admission wording; this result records the subsequent actual
admission and read.
