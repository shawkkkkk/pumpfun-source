"""One admitted normal-image fee/shared-control slice; no metric or tail analysis."""
from pathlib import Path
import argparse
import importlib.util
import json
import re

READER = Path('/dev/shm/pump-cto-13fe453/work/settings-s3-native-analysis/read_native.py')
spec = importlib.util.spec_from_file_location('bounded_copy_provenance', READER)
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
CTO = re.compile(r'^_ZN14pump_recovered9admin_cto7execute17h[0-9a-f]+E$')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--elf', type=Path, required=True); p.add_argument('--sha256', required=True)
    p.add_argument('--admission', type=Path, required=True); p.add_argument('--label', required=True)
    p.add_argument('--source', type=Path, required=True); p.add_argument('--out', type=Path, required=True)
    a = p.parse_args(); assert not a.out.exists()
    admission = json.loads(a.admission.read_text())
    assert admission['images']['unstripped.so'] == a.sha256
    assert admission['sourceAndArchiveAdmission'] == admission['independentOfficialScorer'] == 'PASS'
    source = a.source.read_bytes(); text_source = source.decode()
    assert 'pub fn execute(ctx:Context<AdminCto>,holder:Option<bool>,fee:Option<u64>,new:Option<Pubkey>)' in text_source
    blob, text, symbols = m.nc.elf(a.elf, a.sha256)
    picks = [s for s in symbols if CTO.fullmatch(s['name'])]; assert len(picks) == 1
    fn = picks[0]; offset = text[4]+fn['address']-text[3]; raw = blob[offset:offset+fn['bytes']]
    rows = m.nc.decode(raw, fn['address'], symbols); blocks, by, pred, succ = m.graph(rows, len(raw))
    prepare = [r for r in rows if 'prepare_bonding_curve' in (r.get('callName') or '')]; assert len(prepare) == 1
    stop = prepare[0]['offset']; prefix = [r for r in rows if r['offset'] < stop]
    spills = m.entry_fee_spills(rows, blocks, {'register': 4})
    reads = [r for r in m.fee_reads(rows, blocks, by, pred, spills['spills']) if r['read']['offset'] < stop]
    fee_tests = [t for r in reads for t in r['sameBlockConditionalTestCandidates']]
    def blockof(pc): return next(b for b in blocks if b['start'] <= pc < b['end'])
    def around(pc, before=4, after=8):
        index = next(i for i, r in enumerate(rows) if r['offset'] == pc)
        return rows[max(0, index-before):index+after+1]
    shared_candidates = []
    for i, call in enumerate(prefix):
        if 'data_is_empty' not in (call.get('callName') or ''): continue
        for j in range(i+1, min(i+5, len(prefix))):
            move = prefix[j]
            if move['opcode'] != 0xbf or move['src'] != 0: continue
            reg = move['dst']; inverse = prefix[j+1] if j+1 < len(prefix) else None
            if not inverse or inverse['opcode'] not in (0xa7, 0xa4) or inverse['dst'] != reg or inverse['immediate'] != 1: continue
            stores, calls, stop_definition = [], [], None
            for r in prefix[j+2:]:
                if r.get('memoryKind') == 'write' and r.get('memoryBase') == 10 and r['opcode'] & 7 == 3 and r['src'] == reg: stores.append(r)
                elif r['opcode'] in (0x85, 0x8d):
                    calls.append(r)
                    if reg < 6: stop_definition = r; break
                elif r['dst'] == reg and (r.get('memoryKind') == 'read' or r['opcode'] & 7 in (0, 4, 7)):
                    stop_definition = r; break
            for store in stores:
                slot = store['displacement']
                uses = [r for r in prefix if r.get('memoryKind') == 'read' and r.get('memoryBase') == 10 and r['displacement'] == slot]
                shared_candidates.append({'call': call, 'callArgumentContext': around(call['offset'], 8, 0), 'returnMove': move, 'inverse': inverse, 'actualSpill': store, 'interveningCalls': calls, 'trackingStopDefinition': stop_definition, 'slotReadContexts': [{'read': r, 'block': blockof(r['offset']), 'rows': around(r['offset'], 2, 12)} for r in uses]})
    outlined = {role: [s for s in symbols if re.search(pattern, s['name'])] for role, pattern in [('validate', r'admin_cto8validate17h'), ('sweep', r'admin_cto7execute5sweep17h')]}
    out = {'schema': 'current-normal-fee-shared-control-slice-v1', 'label': a.label,
           'input': {'path': str(a.elf), 'sha256': a.sha256}, 'admissionSha256': m.nc.sha(a.admission.read_bytes()),
           'source': {'path': str(a.source), 'sha256': m.nc.sha(source), 'commit': admission['base']},
           'execute': fn, 'bodySha256': m.nc.sha(raw), 'logicalInstructions': len(rows),
           'reviewedPublicFeeTagRegister': 4, 'incomingFeeSpills': spills,
           'actualPrepareBoundary': prepare[0], 'validationFeeReads': reads,
           'validationFeeTests': fee_tests, 'feeReadContexts': [{'read': r['read'], 'block': blockof(r['read']['offset']), 'rows': around(r['read']['offset'], 10, 9)} for r in reads],
           'sharedInversionSpillCandidates': shared_candidates,
           'scopedOutlinedSymbols': outlined,
           'scopedOutlineCallWitnesses': [r for r in rows if any(s['address'] == r.get('callTarget') for group in outlined.values() for s in group)],
           'limits': ['One new bounded control question, no scorer/metric/compiler/VM or source variant.', 'Fee provenance is direct entry-copy/FP reaching-write evidence, with reviewed public ABI root; arbitrary opaque-callee alias closure is not established.', 'Shared inversion candidates need source/account/control role review; neither first-call position nor encoded source fields alone authenticate shared.', 'Symbol absence alone does not identify an inliner decision; no full tail/error/typed-consumer analysis is performed.'],
           'producerSha256': m.nc.sha(Path(__file__).read_bytes())}
    a.out.write_text(json.dumps(out, indent=2)+'\n')
    print(json.dumps({'label': a.label, 'execute': fn, 'incomingFeeSpills': spills, 'validationReadPcs': [hex(x['read']['offset']) for x in reads], 'validationTestPcs': [hex(x['offset']) for x in fee_tests], 'prepare': hex(stop), 'sharedCandidateSpills': [x['actualSpill'] for x in shared_candidates], 'outlineCounts': {k: len(v) for k, v in outlined.items()}}))


if __name__ == '__main__': main()
