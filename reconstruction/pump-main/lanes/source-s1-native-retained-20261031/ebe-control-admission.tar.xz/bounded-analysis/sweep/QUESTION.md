Current-normal Ebe structural question, prepared before Ebe admission.

Expected current run41176417138/OP1bb7326c. This is accepted-current normal
qualification, not S4 or a source experiment. Do not inspect its image before
root codeIdentityGO pins exact source, image hashes and admitted input scope.

Derive the actual execute STT_FUNC extent/address and incoming fee-tag
transport from the reviewed public ABI. Determine all validation-region direct
incoming-tag reads/tests before the actual prepare_bonding_curve call. Locate
the actual shared-flag producer/spill and test heads; compare feeSome and
feeNone successor reachability and immediate CFG predecessors. Do not infer
semantic order from physical placement, an unchanged source line339, prior FP
offsets, or expected original three-test/private-head geometry.

The first bounded13fe fee-control inspection is separately authorized now.
There was no previously sealed13fe feeCFG comparator: existing S3 claims compare
original/S1/S2 rather than proving the parent's structure. Seal that first
actual baseline question once from admitted13fe cec841bd…; reuse the receipt
for Ebe comparison. Do not reread the baseline for later adaptive joins.

For each admitted image, one bounded reader may decode the selected execute
body to build its direct CFG (LDDW16B), but output/analysis is limited to:

- exact function extent/hash and scoped nonzero validate/sweep symbol/direct
  call witnesses; symbol absence alone does not prove an inlining reason;
- actual R4 incoming-tag entry spill/copy provenance and validation reads
  whose last direct-FP writes are that derived spill; unsupported transport
  remains UNKNOWN instead of reusing an old displacement;
- shared data_is_empty return→inversion→actual spill/callee-saved register
  chain, including delayed spills, and actual test blocks;
- explicit fee-presence branch successors and Some/None direct-CFG paths to
  those shared heads. Name a common/private head only within that scope;
  source/ABI role review and actual instructions must support its label.

Failing/error branches may point physically outside the validation prefix;
do not inspect their full constructor/tail bodies or claim them cold. Do not
analyze unrelated tail/event/typed-target consumers, run generic full-CTO
similarity, recompute a metric, invoke an official scorer/compiler/VM, or create
a source variant. Context owns typed consumers; event owns the new Ebe metric;
root owns scoring and admission.

The conclusion can qualify current control structure and differences from
already sealed original/S1/S2/S3 facts. It does not establish source gain,
original Rust types, allocator/lifetime causes or automatic S4/retrial GO.
