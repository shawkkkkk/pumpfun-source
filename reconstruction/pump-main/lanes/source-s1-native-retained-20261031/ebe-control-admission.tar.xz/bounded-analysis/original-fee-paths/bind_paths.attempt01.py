"""Read bounded cached original paths only; never reopens or executes an ELF."""
from pathlib import Path
import hashlib,json,os,sys
assert os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode
HERE=Path(__file__).resolve().parent
CACHE=Path('/dev/shm/pump-cto-ecea702/work/fee-semantics-963d/ORIGINAL-PREFIX.json')
SHARED=Path('/dev/shm/pump-cto-option-c1/work/shared-boundary-query/ORIGINAL-SHARED-FLOW.json')
GUARDS=Path('/dev/shm/pump-cto-963d1ee/work/context963d/guard-precedence/RESULT.json')
inputs={}
def read(path):
    raw=path.read_bytes();inputs[str(path)]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};return json.loads(raw)
rows=read(CACHE);assert inputs[str(CACHE)]['sha256']=='adf469895c0c6962b312d3b9931c33b7bc63fc41a9f89b2e2de96771daea9789'
shared=read(SHARED);assert inputs[str(SHARED)]['sha256']=='05e4f56ad4280ae06df4eda4ae7296dd0bb3cadc8c6def1ee068ec1fdc0ae978'
guards=read(GUARDS);assert inputs[str(GUARDS)]['sha256']=='93c73ff4433065257ab8dec280ee053708189d12fcae1d76a79ce5b95a05d65c'
ins={int(r['offset'],16):r for r in rows};assert len(ins)==len(rows)
succ={};pred={p:[] for p in ins};outside=[]
for p,r in ins.items():
    op=r['opcode'];nxt=p+len(bytes.fromhex(r['raw']))
    if op==0x95:edges=[]
    elif op in (0x85,0x8d):edges=[nxt]
    elif op&7 in (5,6):
        target=p+8+8*r['displacement'];edges=[target] if op&0xf0==0 else [target,nxt]
    else:edges=[nxt]
    succ[p]=[q for q in edges if q in ins]
    outside.extend({'from':hex(p),'to':hex(q)} for q in edges if q not in ins)
    for q in succ[p]:pred[q].append(p)
def reach(start,graph):
    seen=set();todo=[start]
    while todo:
        p=todo.pop()
        if p not in seen:seen.add(p);todo.extend(graph[p])
    return seen
def paths(end):return reach(0,succ)&reach(end,pred)
def fp_writes(use,low,width):
    allowed=paths(use);seen=set();todo=list(pred[use]);found=set()
    while todo:
        p=todo.pop()
        if p not in allowed or p in seen:continue
        seen.add(p);r=ins[p]
        size={0:4,8:2,16:1,24:8}.get(r['opcode']&24)
        if r['opcode']&7 in (2,3) and r['dst']==10 and r['displacement']<low+width and low<r['displacement']+size:found.add(p)
        else:todo.extend(pred[p])
    return sorted(found)
def reg_writes(use,reg):
    allowed=paths(use);seen=set();todo=list(pred[use]);found=set()
    while todo:
        p=todo.pop()
        if p not in allowed or p in seen:continue
        seen.add(p);r=ins[p];op=r['opcode']
        writes=(op in (0x85,0x8d) and reg<=5) or ((op&7 in (1,4,7) or op==0x18) and r['dst']==reg)
        if writes:found.add(p)
        else:todo.extend(pred[p])
    return sorted(found)
checks={}
for name,pc,expected in [('holder-fee',0xaf0,0x8),('shared-nonholder-fee',0xe20,0x8),('nonshared-nonholder-fee',0x1500,0x8),('holder-raw-input',0x610,0x10),('new-presence-holder',0x900,0x4e0),('new-presence-nonholder',0x730,0x4e0)]:
    r=ins[pc];assert r['opcode']&7==1 and r['src']==10
    actual=fp_writes(pc,r['displacement'],8);assert actual==[expected],(name,actual)
    checks[name]={'load':r,'nearestOverlappingDirectFPWrites':[ins[x] for x in actual]}
assert reg_writes(0x640,8)==[0x618] and reg_writes(0x720,8)==[0x618]
assert ins[0x618]['opcode']==0x57 and ins[0x618]['immediate']==1
assert reg_writes(0x618,8)==[0x610]
assert reg_writes(0x4d8,7)==[0x1e0]
assert reg_writes(0xdc0,1)==[0xdb8]
assert ins[0xdb8]['opcode']==0x79 and ins[0xdb8]['src']==10 and ins[0xdb8]['displacement']==-2336
assert reg_writes(0x900,1)==[0x430]
checks['holder-bool-low-bit']={'rawLoad':ins[0x610],'mask':ins[0x618],'branches':[ins[x] for x in (0x640,0x720)]}
checks['nonholder-shared-branch']={'load':ins[0xdb8],'test':ins[0xdc0],'successors':[hex(x) for x in succ[0xdc0]],'savedRole':'Reuse sealed05e4f56a shared computation/storage/target selection proof.'}
checks['new-pointer-and-tag']={'pointerLoad':ins[0x1e0],'tagLoad':ins[0x4d8],'tagStore':ins[0x4e0],'holderTest':[ins[x] for x in (0x900,0x908)],'nonholderTest':[ins[x] for x in (0x730,0x738,0x740,0x748)]}
predicates=[
 {'site':'holder','feeLoad':'0xaf0','feeTest':'0xaf8','publicHolder':'Some(true)','publicNew':'None','shared':'either','selectedTarget':'K holder-rewards PDA','validationRoute':['0x610','0x618','0x640 OR 0x720/0x728','0x900','0x908->0xab8','0xaf0','0xaf8'],'notes':'Earlier mayhem/holder-reward/enabled guards must pass. newSome errors298 before this fee test, unless an earlier guard already errors.'},
 {'site':'shared-nonholder','feeLoad':'0xe20','feeTest':'0xe28','publicHolder':'None OR Some(false)','publicNew':'Some(N), validated nonzero/not holder-key/not sharing-key','shared':'true','selectedTarget':'C saved curve creator','validationRoute':['0x610','0x618','0x720->0x730','0x738/0x740->0x748','0xc08..0xd70 successful key checks','0xdb8/0xdc0->0xdc8','0xe20','0xe28'],'notes':'Nonholder requires holder_reward=false. Shared selection does not waive newSome/key validation.'},
 {'site':'nonshared-nonholder','feeLoad':'0x1500','feeTest':'0x1508','publicHolder':'None OR Some(false)','publicNew':'Some(N), validated nonzero/not holder-key/not sharing-key','shared':'false','selectedTarget':'N validated new creator','validationRoute':['0x610','0x618','0x720->0x730','0x738/0x740->0x748','0xc08..0xd70 successful key checks','0xdb8/0xdc0->0x1490','0x1500','0x1508'],'notes':'Nonholder requires holder_reward=false. Same newSome/key validation as shared nonholder.'}
]
result={'status':'BOUNDED_ORIGINAL_FEE_PATH_PREDICATES_BOUND_TO_CACHED_DIRECT_REACHING_WRITES','basis':'Three site/target selection partition already sealed05e4f56a; new supplement makes public-role distinction explicit, pending separate context-owned caller ABI conclusion.','predicates':predicates,'reachingChecks':checks,'prefixRows':len(rows),'outsidePrefixEdgesNotExplored':outside,'inputs':inputs,'limits':['Only original cached prefix0..17f8; no whole-function decompilation, new original-body decode, compiler, scorer, metrics, VM or source experiment.','Conditional on execution reaching the validation path and all earlier account/mayhem/holder/new-key guards succeeding.','Backward direct-FP/register facts treat calls using ordinary SBF caller-clobber/callee-save conventions. Arbitrary callee alias writes and indirect FP aliases are not proved absent.','No loop iteration bound, path termination or sufficiency of all runtime preconditions is proved. Outside-prefix edges are retained but not explored.','The holder low-bit partition only concerns these validation fee paths; no global equivalence of None and Some(false) is asserted.','The three sites do not prove three Rust fee functions, literal return arms, Result type, source aggregate, helper boundary or a new source trial.']}
with (HERE/'PREDICATES.json').open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps({'status':result['status'],'predicates':predicates,'checks':list(checks),'outsidePrefixEdgeCount':len(outside)},indent=2))
