"""Bounded static caller/ingress read; no project imports, scorer or VM."""
from pathlib import Path
import hashlib,json,os,re,struct,sys

assert os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode
ROOT=Path('/dev/shm/pump-cto-ebe5387')
HERE=Path(__file__).resolve().parent
ORIGINAL=Path('/dev/shm/pump-cto-faf9962/evidence/original/pump/deployed.so')
CURRENT=ROOT/'work/native-run/artifact/unstripped.so'
IDL=Path('/dev/shm/pump-cto-faf9962/evidence/upstream/pump.json')
CACHE=Path('/dev/shm/pump-cto-ecea702/work/fee-semantics-963d/ORIGINAL-PREFIX.json')
inputs={}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):
    raw=p.read_bytes();inputs[str(p)]={'bytes':len(raw),'sha256':sha(raw)};return raw
def js(p):return json.loads(read(p))
def elf(data):
    assert data[:7]==b'\x7fELF\x02\x01\x01'
    h=struct.unpack_from('<HHIQQQIHHHHHH',data,16);off,width,count,names=h[5],h[10],h[11],h[12]
    assert width==64 and off+width*count<=len(data)
    rows=[struct.unpack_from('<IIQQQQIIQQ',data,off+i*width) for i in range(count)]
    def payload(row):return data[row[4]:row[4]+row[5]]
    strings=payload(rows[names]);sections={}
    for row in rows:
        name=strings[row[0]:strings.index(b'\0',row[0])].decode();assert name not in sections;sections[name]=row
    symbols=[]
    if '.symtab' in sections:
        tab=sections['.symtab'];assert tab[9]==24;strings=payload(rows[tab[6]])
        for p in range(tab[4],tab[4]+tab[5],24):
            name,info,other,index,address,size=struct.unpack_from('<IBBHQQ',data,p)
            symbols.append({'name':strings[name:strings.index(b'\0',name)].decode(),'info':info,'other':other,'section':index,'address':address,'bytes':size})
    return sections,symbols
def body(data,sections,address,size):
    section=next(x for x in sections.values() if x[1]!=8 and x[3]<=address and address+size<=x[3]+x[5])
    off=section[4]+address-section[3];return data[off:off+size]
def decode(data,base):
    result=[];pc=0
    while pc<len(data):
        op,regs,disp,imm=struct.unpack_from('<BBhi',data,pc);width=16 if op==0x18 else 8
        x={'offset':hex(pc),'address':hex(base+pc),'opcode':op,'dst':regs&15,'src':regs>>4,'displacement':disp,'immediate':imm,'bytes':width,'raw':data[pc:pc+width].hex()}
        if op==0x18:x['wideImmediate']=(struct.unpack_from('<I',data,pc+12)[0]<<32)|(imm&0xffffffff)
        elif op==0x85:x['callTarget']=hex(base+pc+8+imm*8)
        elif op&7 in (5,6) and op not in (0x95,0x8d):x['branchTarget']=hex(pc+8+disp*8)
        result.append(x);pc+=width
    assert pc==len(data);return result
original,current=read(ORIGINAL),read(CURRENT)
assert sha(original)=='7a19affaa2c6187e04a5fe0ea298cee81fa5eb8c24cfcc30d85f615e89f7b02d'
assert sha(current)=='9ac11d9e5692d3ff91d45880d5e442347dac7a76bf7d62870f07fc53247b4fcf'
osections,_=elf(original);sections,symbols=elf(current)
caller=[s for s in symbols if s['info']&15==2 and re.fullmatch(r'_ZN14pump_recovered9__private8__global9admin_cto17h[0-9a-f]{16}E',s['name'])]
assert len(caller)==1;caller=caller[0]
saved=js(ROOT/'work/native-run/artifact/score.json')['windows'][str(caller['address'])]
assert saved['raw'] is True and saved['normalized'] is True and caller['name'] in saved['symbols'] and saved['bytes']==caller['bytes']
cb=body(current,sections,caller['address'],caller['bytes']);ob=body(original,osections,caller['address'],caller['bytes'])
assert cb==ob
rows=decode(ob,caller['address'])
calls=[r for r in rows if r.get('callTarget')==hex(0x22a10)]
assert len(calls)==1
call_index=rows.index(calls[0]);context=rows[max(0,call_index-28):call_index+2]
idl=js(IDL);instruction=[i for i in idl['instructions'] if i['name']=='admin_cto'];assert len(instruction)==1
assert instruction[0]['args']==[{'name':'is_holder_reward','type':{'option':'bool'}},{'name':'creator_fee_bps','type':{'option':'u64'}},{'name':'new_creator','type':{'option':'pubkey'}}]
assert instruction[0]['discriminator']==[125,126,214,134,77,229,188,89]
lib=read(ROOT/'programs/pump/src/lib.rs').decode();source=read(ROOT/'programs/pump/src/creator/admin_cto.rs').decode()
assert 'pub fn admin_cto(ctx:Context<AdminCto>,is_holder_reward:Option<bool>,creator_fee_bps:Option<u64>,new_creator:Option<Pubkey>)->Result<()>{admin_cto::execute(ctx,is_holder_reward,creator_fee_bps,new_creator)}' in lib
assert 'fn validate(st:&CtoState,hopt:Option<bool>,fee:Option<u64>,new:Option<Pubkey>,holder_key:&Pubkey,sharing:&Pubkey)->Result<Pubkey>{let holder=hopt==Some(true);' in source
cache=js(CACHE)
for row in cache:
    pc=int(row['offset'],16);assert body(original,osections,0x22a10+pc,len(bytes.fromhex(row['raw']))).hex()==row['raw']
result={'status':'RAW_MATCHED_PUBLIC_CALLER_AND_ABI_INPUTS_BOUND_FOR_MANUAL_PATH_REVIEW','caller':dict(caller,bodySha256=sha(cb),rawEqualOriginal=True),'executeCall':calls[0],'callArgumentContext':context,'logicalRows':rows,'publicIDL':instruction[0],'cachedOriginalPrefixRows':len(cache),'originalCTOBase':hex(0x22a10),'sourceHoptOptionRetained':True,'inputs':inputs,'limits':['Static bytes only; no compiler, source variant, scorer, metric or VM.','Public ABI and concrete caller transport are distinct from original private Result or source type guesses.','Original prefix path roles are reused from sealed reports; only ingress binding is newly inspected.']}
with (HERE/'CALLER.json').open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps({'caller':result['caller'],'executeCall':calls[0],'context':context,'idlSHA':inputs[str(IDL)]['sha256']},indent=2))
