#!/usr/bin/env python3
"""Bounded admitted Ebe line339 native producers, equality and gates only."""
import os, sys
os.environ['PYTHONDONTWRITEBYTECODE']='1'
sys.dont_write_bytecode=True
from pathlib import Path
import hashlib, json, struct
ROOT=Path('/dev/shm/pump-cto-ebe5387')
OUT=ROOT/'work/context-native-equality'
sys.path.insert(0,str(ROOT/'reconstruction/harness'))
from score import body, sections
from instruction_stream import instruction_offsets
from elf_symbols import function_symbols

def sha(b): return hashlib.sha256(b).hexdigest()
def load(p): return json.loads(p.read_text())
def seal(p): return {'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
elf=ROOT/'work/native-run/artifact/unstripped.so'
admp=ROOT/'work/root/CURRENT-ELF-ADMISSION.json'
indp=ROOT/'work/admission-reader/actual-review/REVIEW.json'
adm,ind=load(admp),load(indp)
assert sha(indp.read_bytes())=='5c30f7461c57f28183ed87f0f83e71a321550251ab65722cd9c9ae22af4fe653'
assert adm['base']=='ebe5387e12e948c2534618adf7a3cf0f27d9de51'
assert adm['sourceSha256']=='6b02f60a97777892b9cfb3b93ff40679226e08dca15b8313899df342c68e07e7'
b=elf.read_bytes();assert sha(b)==adm['images']['unstripped.so']=='9ac11d9e5692d3ff91d45880d5e442347dac7a76bf7d62870f07fc53247b4fcf'
assert len(b)==2665688
source=ROOT/'programs/pump/src/creator/admin_cto.rs'
assert sha(source.read_bytes())=='a1a0bb06a5a260e13f5824235bbd19b6fa43883f07e3073e1cbcba03ab16601a'
syms=function_symbols(b); matches=[s for s in syms if 'admin_cto7execute17h' in s[2]]
assert len(matches)==1
start,size,name=matches[0];raw=body(b,sections(b),start,size)
assert (start,size,sha(raw))==(141840,27400,adm['CTO']['bodySha256'])
assert sha(raw)=='c8039d904d1c31d837317bce16bc0e08ac1cebfefcb099756ecf8f719213520c'

def decode(raw,start):
    rows={}
    for o in instruction_offsets(raw):
        op,rs,disp,imm=struct.unpack_from('<BBhi',raw,o)
        width=16 if op==0x18 else 8
        row={'offset':hex(o),'va':hex(start+o),'raw':raw[o:o+width].hex(),'instruction_bytes':width,
             'opcode':op,'dst':rs&15,'src':rs>>4,'displacement':disp,'immediate':imm}
        if op==0x18: row['constant_u64']=(imm&0xffffffff)|(struct.unpack_from('<I',raw,o+12)[0]<<32)
        if op==0x85 and rs>>4==1 and imm!=-1:
            target=start+o+8+imm*8;row['direct_call_target']=hex(target)
            row['direct_call_symbols']=[s[2] for s in syms if s[0]==target]
        if op&7 in (5,6) and op not in (0x85,0x8d,0x95): row['branch_target_offset']=hex(o+8+disp*8)
        rows[o]=row
    return rows
ins=decode(raw,start)

def eq(o,op,d,s,disp,imm):
    r=ins[o]
    assert [r[k] for k in ['opcode','dst','src','displacement','immediate']]==[op,d,s,disp,imm],r

def select(lo,hi): return [r for o,r in ins.items() if lo<=o<hi]
for row in [(0x28,0x79,8,2,8,0),(0x80,0x79,7,8,144,0),(0x88,0x79,1,7,0,0),
            (0x90,0x79,2,1,24,0),(0x98,0x7b,10,2,-696,0),
            (0xa0,0x79,2,1,16,0),(0xa8,0x7b,10,2,-704,0),
            (0xb0,0x79,2,1,8,0),(0xb8,0x7b,10,2,-712,0),
            (0xc0,0x79,1,1,0,0),(0xc8,0x7b,10,1,-720,0),
            (0xd0,0x79,1,8,56,0),(0xd8,0x07,1,0,0,8),
            (0xe0,0xbf,2,10,0,0),(0xe8,0x07,2,0,0,-720),(0xf0,0xb7,3,0,0,32),
            (0x100,0xb7,6,0,0,0),(0x128,0x67,0,0,0,32),(0x130,0x77,0,0,0,32),
            (0x138,0x55,0,0,12,0),(0x140,0x79,1,7,24,0),(0x158,0xb7,3,0,0,32),
            (0x168,0x67,0,0,0,32),(0x170,0x77,0,0,0,32),(0x178,0x55,0,0,4,0),
            (0x180,0xbf,1,7,0,0),(0x190,0xbf,6,0,0,0),(0x198,0xa7,6,0,0,1),
            (0x1a0,0x7b,10,6,-2344,0),
            (0x17a0,0x79,1,10,-2344,0),(0x17a8,0x55,1,0,1,0),(0x17b0,0x05,0,0,37,0)]:eq(*row)
assert ins[0x138]['branch_target_offset']==ins[0x178]['branch_target_offset']=='0x1a0'
assert ins[0xf8]['direct_call_symbols']==ins[0x160]['direct_call_symbols']==['memcmp']
assert len(ins[0x188]['direct_call_symbols'])==1 and 'AccountInfo13data_is_empty' in ins[0x188]['direct_call_symbols'][0]
assert ins[0x148]['constant_u64']==0x1b7a61

# File-backed VA and dynamic syscall binding, never treating imm=-1 as a direct target.
shoff=struct.unpack_from('<Q',b,40)[0];shsize,shcount,namesi=struct.unpack_from('<HHH',b,58)
headers=[struct.unpack_from('<IIQQQQIIQQ',b,shoff+i*shsize) for i in range(shcount)]
strh=headers[namesi];sn=b[strh[4]:strh[4]+strh[5]]
def string(t,o):return t[o:t.index(b'\0',o)].decode()
secs={string(sn,h[0]):h for h in headers}
def va_bytes(addr,n):
    h=next(h for h in headers if h[1]!=8 and h[3]<=addr and addr+n<=h[3]+h[5])
    offset=h[4]+addr-h[3];return b[offset:offset+n]
const=va_bytes(ins[0x148]['constant_u64'],32)
pk='pfeeUxB6jkeY1Hxd7CsFCAjcbHA9rWtchMGdZ6VojVZ';alphabet='123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz'
v=0
for c in pk:v=v*58+alphabet.index(c)
base58decoded=b'\0'*(len(pk)-len(pk.lstrip('1')))+v.to_bytes((v.bit_length()+7)//8,'big')
assert const==base58decoded and len(const)==32
fees_source=ROOT/'programs/pump/src/creator/distribute_creator_fees.rs'
assert pk in fees_source.read_text()
helpers={}
for role,target in [('memcmp',ins[0xf8]['direct_call_target']),('data_is_empty',ins[0x188]['direct_call_target'])]:
    symbols=[s for s in syms if s[0]==int(target,16)];assert len(symbols)==1
    st,n,nm=symbols[0];rr=body(b,sections(b),st,n)
    helpers[role]={'symbol':nm,'start':hex(st),'bytes':n,'sha256':sha(rr),'instructions':list(decode(rr,st).values())}
assert helpers['memcmp']['bytes']==64 and helpers['data_is_empty']['bytes']==104
hr=secs['.rel.dyn'];dyn=secs['.dynsym'];ds=headers[dyn[6]];dst=b[ds[4]:ds[4]+ds[5]]
rels=[]
for off in range(hr[4],hr[4]+hr[5],16):
    addr,info=struct.unpack_from('<QQ',b,off)
    if addr!=int(helpers['memcmp']['start'],16)+0x18: continue
    index,kind=info>>32,info&0xffffffff;symbol=struct.unpack_from('<IBBHQQ',b,dyn[4]+index*24)
    rels.append({'va':hex(addr),'type':kind,'symbol_index':index,'symbol':string(dst,symbol[0])})
assert len(rels)==1 and rels[0]['type']==10 and rels[0]['symbol']=='sol_memcmp_'
helpers['memcmp']['syscall_relocation']=rels[0]
helpers['memcmp']['interpretation']='Passes existing r1/r2/r3 and r4=its own frame-4 to sol_memcmp_; returns the output i32. Execute compares its low32 bits with zero. This is a real dynamic relocation, not imm=-1 interpreted as a direct call.'
hdata=helpers['data_is_empty']['instructions']
assert hdata[0]['opcode']==0x79 and hdata[0]['dst']==hdata[0]['src']==1 and hdata[0]['displacement']==16
assert hdata[1]['opcode']==0x79 and hdata[1]['dst']==2 and hdata[1]['src']==1 and hdata[1]['displacement']==16
assert hdata[2]['constant_u64']==0x7ffffffffffffffe
assert hdata[3]['opcode']==0x2d and hdata[3]['branch_target_offset']=='0x50'
assert hdata[4]['opcode']==0x79 and hdata[4]['dst']==hdata[4]['src']==1 and hdata[4]['displacement']==32
helpers['data_is_empty']['interpretation']='Load AccountInfo+16 data representation pointer; load its+16 borrow state, branch to panic when unsigned value>0x7ffffffffffffffe; otherwise read its+32 length. Return1 when len==0, else0. Execute xor1 forms !empty. No source borrow lifetime or unique Rust aggregate type inferred.'
# Limited caller-frame checks only; later slot reuse is deliberately excluded.
widths={0x7b:8,0x63:4,0x6b:2,0x73:1,0x7a:8,0x62:4,0x6a:2,0x72:1}
store_census=[]
for o,row in ins.items():
    if o>=0x17a0:break
    if row['opcode'] in widths and row['dst']==10:
        a=row['displacement'];w=widths[row['opcode']]
        if a<-2336 and -2344<a+w:store_census.append(row)
assert [int(x['offset'],16) for x in store_census]==[0x1a0]
keywrites=[]
for o,row in ins.items():
    if o>=0xf8:break
    if row['opcode'] in widths and row['dst']==10:
        a=row['displacement'];w=widths[row['opcode']]
        if a<-688 and -720<a+w:keywrites.append(row)
assert [x['offset'] for x in keywrites]==['0x98','0xa8','0xb8','0xc8']
rawpacket={'coordinate_system':'Instruction offsets relative to actual execute VA0x22a10; va is absolute ELF virtual address; instruction_bytes includes16-byte LDDW. Helpers each have independent coordinate origin/frame.',
 'prefix':select(0,0x1a8),'direct_shared_use':select(0x17a0,0x17c8),'helpers':helpers,
 'limited_direct_fp_store_census':{'key_scratch_before_first_call':keywrites,'shared_slot_before_selected_gate17a0':store_census},
 'fees_constant':{'va':'0x1b7a61','bytes':32,'raw':const.hex(),'source_pubkey':pk,'sha256':sha(const)}}
(OUT/'NATIVE-WITNESSES.json').write_text(json.dumps(rawpacket,indent=2)+'\n')
result={
 'status':'ADMITTED_EBE339_NATIVE_CHAIN_BOUND_NO_METRIC_OR_SOURCE_GAIN_CLAIM',
 'source':{'commit':adm['base'],'leaf':str(source.relative_to(ROOT)),'leaf_sha256':sha(source.read_bytes()),'source141_aggregate':adm['sourceSha256'],'line':339},
 'native':{'path':str(elf),'bytes':len(b),'sha256':sha(b),'run':adm['run'],'operational_commit':adm['operationalCommit'],'cto':{'start':hex(start),'bytes':size,'symbol':name,'sha256':sha(raw)},'root_admission':{'path':str(admp),**seal(admp)},'independent_actual_review':{'path':str(indp),**seal(indp)}},
 'producers':{
  'accounts':{'at':ins[0x28],'expression':'r8=*(entry_r2+8); this is the actual execute accounts root for the selected native source mapping.'},
  'sharing_key':{'account_pointer_at':ins[0x80],'account_expression':'S=*(r8+144), kept in r7 across selected calls under SBF callee-saved ABI','key_pointer_at':ins[0x88],'key_expression':'P=*(S+0)','copy':'P[0,32) copied by four8-byte loads/stores into caller FP[-720,-688). Load/store pairs+90/+98,+a0/+a8,+b0/+b8,+c0/+c8; direct-overlap census before+f8 is exactly these four stores.','identity_qualification':'Source-pinned initial shared expression plus same S+24 owner compared with actual FEES and S passed to named AccountInfo::data_is_empty bind this sharing_config AccountInfo role. No Rust field-order/layout assumption establishes account offset144.'},
  'curve_creator':{'account_pointer_at':ins[0xd0],'address_at':ins[0xd8],'expression':'C=*(r8+56); equality reads C[8,40) directly through r1=C+8.','identity_qualification':'Source-pinned creator-vs-sharing initial equality, independently tagged sharing/owner/data side, and actual32-byte compare bind this creator read. This does not assert a general Rust layout theorem for BondingCurve/Account.'}},
 'equality':{'call':ins[0xf8],'r1':'curve pointer+8 (creator32)','r2':'caller FP-720 (copied sharing key32)','r3':32,'meaning':'actual native orientation is creator first, key second; result low32!=0 branches at+138 directly to+1a0. No intervening call occurs between the four key-copy stores and this first equality call.'},
 'owner_gate':{'entry':'Only equality low32==0 falls through+138 to+140','r1':'*(S+24), actual sharing owner pointer','r2':'file-backed FEES Pubkey bytes atVA1b7a61','r3':32,'call':ins[0x160],'false_successor':ins[0x178],'meaning':'owner mismatch jumps to+1a0; no data_is_empty call on either equality mismatch.'},
 'data_gate':{'entry':'Only both32-byte comparisons equal fall through+178 to+180','argument':'r1=S','call':ins[0x188],'native_helper':'actual104-byte AccountInfo::data_is_empty at1a2b38; borrow-state check and length==0, explicit panic successor retained','boolean':'r6 initialized0 at+100; on successful data helper return r6=r0 at+190, xor1 at+198. Both mismatch branches preserve0.'},
 'shared_result':{'store':ins[0x1a0],'expression':'callerFP[-2344,-2336) = (creator32==key32) && (owner32==FEES) && (data length!=0), conditioned on successful borrow check.','selected_direct_use':{'load':ins[0x17a0],'test':ins[0x17a8],'shared_true_successor':'0x17b8','shared_false_jump':ins[0x17b0],'shared_false_successor':'0x18e0'},'direct_store_limit':'Only direct r10-relative overlapping write before selected gate17a0 is+1a0. This is an instruction census, not a universal CFG/alias proof. Later frame-slot reuse is outside this receipt.'},
 'comparison_with_seals':{
  'original':'Retained w12a09 raw-derived cleanroom outline says memcmp(curve.creator,sharing_config.key) then owner then data, default0 with final !empty. Actual Ebe agrees with this reported argument and gate order. The historical note is not reopened raw proof, original source spelling/type, full prefix byte identity or matching metric.',
  'parent13fe':'Existing reference bindings seal parent image/body only; its native initial equality orientation/operand storage was not independently sealed in available inputs. Parent operand-order comparison remains UNKNOWN and its ELF was not read.',
  'source339':'Static source delta changes equality receiver/orientation and names a block-local key value. Actual Ebe creator-first argument is observed; no claim that this local caused a specific allocation/lifetime or any global improvement.',
  'line312':'Different restricted-key OR family; unchanged accepted source and historical measured-negative reversal remain closed.'},
 'limits':['No parent/original ELF analysis, full CTO/error/tail audit, metric, scorer, compiler, LLVM/IR proxy, VM, test or source variant.','Physical AccountInfo/key/owner and creator address roles are bound to the exact accepted source expression and actual matching consumers, not general Rust type/aggregate/layout claims.','SBF ABI register/caller-frame separation and documented readonly memcmp/syscall behavior are assumed. Private caller key buffer is not aliased by callees beyond the passed comparison pointers; no whole-program alias theorem.','Data helper panic path is retained; no equivalence claim for malformed/invalid raw pointers outside valid account/Rust state.','Recorded branch sequencing proves selected equality-owner-data short-circuit calls; unrelated ABI new/fee loads scheduled between comparison and gate do not change this predicate.','No source receiver-order-to-native-order guarantee beyond this actual admitted image.'],
 'input_seals':{str(p):seal(p) for p in [OUT/'PLAN.json',ROOT/'work/context-semantic-review/SEMANTIC-REVIEW.json',Path('/dev/shm/pump-cto-13fe453/work/native-run/control-review/REFERENCE-BINDINGS.json'),Path('/dev/shm/pump-cto-faf9962/reconstruction/pump-main/lanes/w12a09-cto-cleanroom/NOTES.md'),Path('/dev/shm/pump-cto-963d1ee/work/context963d/key-order/RESULT.json'),fees_source,ROOT/'reconstruction/harness/score.py',ROOT/'reconstruction/harness/instruction_stream.py',ROOT/'reconstruction/harness/elf_symbols.py']}
}
(OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS bounded actual Ebe339 equality/owner/data chain captured')
