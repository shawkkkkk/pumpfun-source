#!/usr/bin/env python3
"""One root-released Ebe target-token measurement; stdlib only."""
import argparse
import datetime
import difflib
import hashlib
import json
import os
import struct
import sys
from pathlib import Path

SOURCE = {
    "revision": "ebe5387e12e948c2534618adf7a3cf0f27d9de51",
    "tree": "196d24d8725ef08e0470c44de7bed95a797eb46a",
    "sourceAggregateSha256": "6b02f60a97777892b9cfb3b93ff40679226e08dca15b8313899df342c68e07e7",
    "adminCtoSha256": "a1a0bb06a5a260e13f5824235bbd19b6fa43883f07e3073e1cbcba03ab16601a",
}
METHOD = {
    "win.py": "658cd1b0b7d8fa615e8e986843d1bb597a48d3626e05e0508fba7e651eb50c71",
    "score.py": "5640d87864c6bc57005b8ada86f82dd1c944c92f5edf5181de4bb5e7568063f5",
    "score_admission.py": "2d79d738d3a5ec17b3affe1f3e49aa077752f45260dc8b758c915cae1c96d088",
    "instruction_stream.py": "288c9ceb3f0f177688501922ce56e6a72fe9c3fedcddf9ad1de474412f61ef9d",
    "elf_symbols.py": "7bae771bbc9039a595e84c956500268b2601d2f97a93b3edcc83fbc348a9a74c",
}
SYMBOL = "_ZN14pump_recovered9admin_cto7execute17h3bd6d7f34f2e30d7E"
ORIGINAL = "7a19affaa2c6187e04a5fe0ea298cee81fa5eb8c24cfcc30d85f615e89f7b02d"
SEALED_METRIC = "2ab39d249030560c5a2dc9bcc98d47c3f463ea3ed69e81b507394af73783c045"
QUALIFICATIONS = {
    "programSource141", "compiledStage142", "CORE236AndModes",
    "SDKRegistryLinkerUnchanged", "coldNormalBuild",
    "officialSavedScoreAdmission", "providerRunAndSourceBound",
}

def need(value, message):
    if not value:
        raise ValueError(message)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def pinned(record, label):
    need(isinstance(record, dict) and set(record) == {"path", "sha256"}, label + " pin")
    need(isinstance(record["sha256"], str) and len(record["sha256"]) == 64, label + " SHA256")
    raw = Path(record["path"]).read_bytes()
    need(sha(raw) == record["sha256"], label + " content identity")
    return raw

def logical(raw):
    position = 0
    while position < len(raw):
        width = 16 if raw[position] == 0x18 else 8
        need(position + width <= len(raw), "truncated logical instruction")
        yield position
        position += width

def elf(raw):
    need(raw[:7] == b"\x7fELF\x02\x01\x01" and len(raw) >= 64, "ELF64 little-endian header")
    offset = struct.unpack_from("<Q", raw, 40)[0]
    stride, count, names_index = struct.unpack_from("<HHH", raw, 58)
    need(stride == 64 and names_index < count and offset + stride * count <= len(raw), "section table")
    headers = [struct.unpack_from("<IIQQQQIIQQ", raw, offset + i * stride) for i in range(count)]
    def payload(header):
        need(header[4] + header[5] <= len(raw), "section file extent")
        return raw[header[4]:header[4] + header[5]]
    names = payload(headers[names_index])
    sections = {}
    for index, header in enumerate(headers):
        end = names.find(b"\0", header[0])
        need(header[0] < len(names) and end >= 0, "section name")
        name = names[header[0]:end].decode()
        need(name not in sections, "duplicate section name")
        sections[name] = (header, payload(header), index)
    symbols = []
    if ".symtab" in sections:
        header, data, _ = sections[".symtab"]
        need(header[9] == 24 and len(data) % 24 == 0 and header[6] < len(headers), "symbol table")
        strings = payload(headers[header[6]])
        for at in range(0, len(data), 24):
            name, info, _, section, address, size = struct.unpack_from("<IBBHQQ", data, at)
            end = strings.find(b"\0", name)
            need(name < len(strings) and end >= 0, "symbol name")
            symbols.append((strings[name:end].decode(), info, section, address, size))
    return sections, symbols

def body(sections, address, size):
    header, text, _ = sections[".text"]
    relative = address - header[3]
    need(size > 0 and relative >= 0 and relative + size <= len(text), "target within .text")
    boundaries = set(logical(text))
    need(relative in boundaries and (relative + size in boundaries or relative + size == len(text)),
         "target follows logical instruction boundaries")
    return text[relative:relative + size]

def normalized_tokens(raw, sections):
    # Literal score.normalize mask and win.insns/Cand.tokens logical slicing.
    masked = bytearray(raw)
    at = 0
    while at < len(raw):
        op, registers, _, immediate = struct.unpack_from("<BBhi", raw, at)
        if op == 0x18:
            need(at + 16 <= len(raw), "truncated LDDW")
            value = struct.unpack_from("<I", raw, at + 4)[0] | struct.unpack_from("<I", raw, at + 12)[0] << 32
            if any(h[3] > 0 and h[3] <= value < h[3] + h[5] for h, _, _ in sections.values()):
                masked[at + 4:at + 8] = bytes(4)
                masked[at + 12:at + 16] = bytes(4)
            at += 16
        else:
            if op == 0x85 and registers >> 4 == 1 and immediate != -1:
                masked[at + 4:at + 8] = bytes(4)
            at += 8
    return tuple(bytes(masked[at:at + (16 if raw[at] == 0x18 else 8)]) for at in logical(raw))

def write_exclusive(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")

def main():
    need(os.environ.get("PYTHONDONTWRITEBYTECODE") == "1" and sys.dont_write_bytecode,
         "use PYTHONDONTWRITEBYTECODE=1 python3 -B")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--release", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    gate_raw = args.release.read_bytes()
    gate = json.loads(gate_raw)
    need(gate["schema"] == "ebe-one-target-token-release-v1" and gate["rootCodeIdentityGO"] is True,
         "root actual-image admission and release required")
    need(gate["kind"] == "NORMAL_NATIVE_CURRENT_MAIN_CONTROL" and gate["source"] == SOURCE, "exact Ebe source")
    provider = gate["provider"]
    need(provider["repository"] == "shawkkkkk/pumpfun-source" and provider["runId"] == 41176417138
         and provider["operationalCommit"] == "1bb7326cbccd7773f9accba45b9b6379b76ceb12"
         and type(provider["attempt"]) is int and provider["attempt"] > 0, "exact normal provider run")
    need(set(gate["qualifications"]) == QUALIFICATIONS
         and all(value is True for value in gate["qualifications"].values()), "root normal provenance gates")
    for role in ("rootAdmission", "providerSourceCoreEvidence"):
        pinned(gate[role], role)
    repo = Path(gate["repo"])
    for name, digest in METHOD.items():
        need(sha((repo / "reconstruction/harness" / name).read_bytes()) == digest, "pinned CORE method " + name)
    need(sha((repo / "programs/pump/src/creator/admin_cto.rs").read_bytes()) == SOURCE["adminCtoSha256"],
         "current Ebe source leaf")
    baseline_raw = pinned(gate["sealed13feMetric"], "sealed13feMetric")
    need(sha(baseline_raw) == SEALED_METRIC, "already sealed baseline receipt")
    baseline = json.loads(baseline_raw)
    need(baseline["methodFiles"] == METHOD and baseline["candidates"]["13fe"]["normalizedMatchingLogicalInstructionsM"] == 2245,
         "sealed method and M2245; never recompute 13fe")
    original = pinned(gate["original"], "original")
    need(sha(original) == ORIGINAL, "captured original family")
    pinned(gate["nativeArchive"], "actual normal raw archive")
    candidate = pinned(gate["unstrippedELF"], "actual admitted Ebe image")
    args.out.mkdir(parents=True, exist_ok=True)
    write_exclusive(args.out / "STARTED.json", {
        "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "pid": os.getpid(), "releaseSha256": sha(gate_raw), "readerSha256": sha(Path(__file__).read_bytes()),
        "newEbeELFSha256": sha(candidate), "originalELFSha256": sha(original),
        "scope": "One new Ebe normalized target measurement; sealed 13fe M only, no 13fe ELF read.",
    })
    try:
        original_sections, _ = elf(original)
        prior_original = baseline["original"]
        original_body = body(original_sections, prior_original["start"], prior_original["bytes"])
        need(sha(original_body) == prior_original["bodySha256"], "sealed original CTO window")
        sections, symbols = elf(candidate)
        functions = [s for s in symbols if s[0] == SYMBOL and s[1] & 15 == 2]
        need(len(functions) == 1, "one same-family execute STT_FUNC")
        symbol = functions[0]
        need(symbol[2] == sections[".text"][2], "execute is defined in .text")
        candidate_body = body(sections, symbol[3], symbol[4])
        old_tokens = normalized_tokens(original_body, original_sections)
        new_tokens = normalized_tokens(candidate_body, sections)
        need(len(old_tokens) == prior_original["logicalInstructions"], "sealed original logical count")
        matcher = difflib.SequenceMatcher(None, old_tokens, new_tokens, autojunk=False)
        matching = sum(block.size for block in matcher.get_matching_blocks())
        result = {
            "status": "ONE_EBE_TARGET_TOKEN_MEASUREMENT_COMPLETE",
            "source": SOURCE, "provider": provider, "releaseSha256": sha(gate_raw),
            "method": "win.insns(score.normalize) / Cand.tokens / SequenceMatcher(None, original, newEbe, autojunk=False)",
            "methodFiles": METHOD,
            "rootQualificationEvidence": {role: gate[role] for role in ("rootAdmission", "providerSourceCoreEvidence")},
            "original": {**prior_original, "elfSha256": sha(original)},
            "Ebe": {"elfSha256": sha(candidate), "symbol": symbol[0], "start": symbol[3], "bytes": symbol[4],
                    "bodySha256": sha(candidate_body), "logicalInstructions": len(new_tokens),
                    "normalizedMatchingLogicalInstructionsM": matching, "maintainedWinNormalizedRatio": matcher.ratio()},
            "sealed13fe": {"receiptSha256": SEALED_METRIC, "M": 2245,
                           "ratio": baseline["candidates"]["13fe"]["maintainedWinNormalizedRatio"], "recomputed": False},
            "EbeMinusSealed13feM": matching - 2245,
            "reportedPlus2MConfirmed": matching - 2245 == 2,
            "limits": "Target token similarity only. Root's normal source/CORE/SDK/registry/cold/score admission is consumed, not rerun. No memberships/cmd_list/full scorer/objdump/compiler/VM, raw-token metric, source variant, original type/lifetime, whole-function cause or current-window equality claim.",
        }
        write_exclusive(args.out / "RESULT.json", result)
        print(json.dumps(result, indent=2))
    except BaseException as error:
        write_exclusive(args.out / "FAILURE.json", {"exception": type(error).__name__, "message": str(error),
                                                  "noRetryAuthorized": True, "releaseSha256": sha(gate_raw)})
        raise

if __name__ == "__main__":
    main()
