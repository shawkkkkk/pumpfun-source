# One admitted Ebe target-token measurement

Prepared only. The reader has not been imported, executed, syntax-tested or
used to calculate any tokens. The release template is false and has no native
image/archive or actual admission pins. Normal run 41176417138 is the sole
intended provider, operational revision 1bb7326cbccd7773f9accba45b9b6379b76ceb12.

The genuine source is Ebe5387e12e948c2534618adf7a3cf0f27d9de51, tree
196d24d8725ef08e0470c44de7bed95a797eb46a. Its prepared source141 aggregate is
6b02f60a97777892b9cfb3b93ff40679226e08dca15b8313899df342c68e07e7; the
772-line CTO leaf is a1a0bb06a5a260e13f5824235bbd19b6fa43883f07e3073e1cbcba03ab16601a.

Before release, root must admit the actual normal provider run/attempt and
source141/stage142/CORE236/modes, unchanged SDK/registry/linker inputs, cold
normal build and saved official score provenance. Root then binds the actual
raw ZIP, unstripped ELF and admission/evidence records by SHA256 and explicitly
sets rootCodeIdentityGO and every qualification to true in a separate RELEASE.json.
The reader consumes this qualified gate; it does not reproduce those build or
full-score checks. No pre-build copy or stale ELF can supply the image pin.

The five method-file hashes are exactly the previously sealed CORE methods.
The reader uses the reviewed stdlib ELF/mask/logical-token approach from the
S1-S3 packet verifier (ae7bdbf942bacc853c829e87d6ae92a72cc424f20fa48125c9f642d155253b23):
score.normalize masks only encoded internal-call immediates and section-pointer
LDDW words; win.insns/Cand.tokens split LDDW as16 bytes and other instructions
as8 bytes. Registers, FP offsets and jumps remain in tokens. It imports no
project module and invokes no external program.

The original ELF and original CTO body must match the sealed 7a19aff… and
6a7659fd… identities. Candidate selection requires the unique same-family
execute STT_FUNC symbol defined in .text. Its actual value/size and logical
instruction boundaries determine the Ebe extent/count. No 27,400-byte extent,
3,337-instruction count or M2247 is assumed for Ebe.

Exactly one new normalized SequenceMatcher(None, original_tokens, Ebe_tokens,
autojunk=False) is calculated. Its matching blocks provide M and its ratio
uses the actual token counts. The only 13fe input is the already sealed
TARGET-METRIC.json (SHA2ab39d249030560c5a2dc9bcc98d47c3f463ea3ed69e81b507394af73783c045),
which records M2245. No 13fe ELF is read or remeasured. The result reports the
observed delta and whether it equals the reported+2; disagreement is a result,
not a trigger for retry, alternative source, flag or matcher settings.

After root release, the intended one command is:

    PYTHONDONTWRITEBYTECODE=1 python3 -B read_target.py --release RELEASE.json --out measurement

The exclusive STARTED.json is created after identity/provenance-pin checks and
before ELF/token analysis. RESULT.json/stdout preserve the measurement; failures
retain FAILURE.json and do not authorize retries. Root chooses the actual
release/output paths. There is no execution at this preparation stage.

This measures target token similarity only. It calls no Cand.memberships,
cmd_list, full scorer, objdump, compiler or VM; computes no extra raw-token
metric; and creates no candidate/S4/source grid. A +2 result would confirm that
bounded metric on the qualified current normal build, not exact CTO equality,
runtime equivalence, a causal explanation or a new source lead.
