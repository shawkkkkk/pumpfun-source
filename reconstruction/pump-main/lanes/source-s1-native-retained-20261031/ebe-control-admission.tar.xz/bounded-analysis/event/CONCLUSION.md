The one admitted Ebe target measurement confirms the reported +2 normalized
matching instructions: M2247 versus already sealed 13fe M2245. The maintained
ratio is 0.6731575793888556. No 13fe ELF was read or remeasured.

Actual new native source is ebe5387e12e948c2534618adf7a3cf0f27d9de51, normal
run41176417138/attempt1, operational revision
1bb7326cbccd7773f9accba45b9b6379b76ceb12. The root release f81343b1… binds
the source-to-new-native provenance admitted by root47cd5913… and independent
review5c30f746…. Its GO is not original/13fe CTO byte identity.

The new unstripped ELF is SHA256
9ac11d9e5692d3ff91d45880d5e442347dac7a76bf7d62870f07fc53247b4fcf.
Its unique same-family execute symbol gives VA0x22a10,27,400 bytes and3,337
logical instructions. These were derived from the admitted ELF, not assumed.
The body SHA256 is
c8039d904d1c31d837317bce16bc0e08ac1cebfefcb099756ecf8f719213520c.
The original body remains the sealed7a19aff… ELF /6a7659fd… body,3,339 logical
instructions. All five pinned method files match the sealed CORE methods.

The sole reader execution took0.252432261 seconds, exited0 and emitted empty
stderr. All16 input files were byte/stat unchanged. stdout is byte-identical
to measurement/RESULT.json,2932 bytes/SHA256
e77fa54acbb9a9d90d80a1d2abc74c88a01d7872a70659fda26bd948406c731d.
STARTED, process/one-shot records, actual stdout/stderr, before/after inputs and
execution receipt are retained. There was no failure artifact or retry.

The new metric uses exactly one normalized SequenceMatcher with autojunk=False
on original/new-Ebe logical tokens. The 13fe reference is receipt
2ab39d249030560c5a2dc9bcc98d47c3f463ea3ed69e81b507394af73783c045,
consumed without its ELF or token calculation. No extra raw metric, membership
scan, cmd_list, full scorer, objdump, compiler, IR or VM was run in this lane.
The root's normal native score/provenance admission is consumed, not repeated.

The normal official membership result remains separately admitted at1034/1035,
with all saved rows/no-loss unchanged against13fe. This +2 token observation
does not close the CTO window, explain a whole-function cause, establish
runtime equivalence or authorize a new candidate/source variant. Standalone
VM executions in this metric lane remain0; no runtime result is claimed.

PLAN.md and RELEASE.template.json are immutable pre-release preparation
records, so their zero/not-released wording describes that earlier stage.
RELEASE.json and the actual execution/result records govern the final outcome.
No extra native ELF, raw ZIP, full CORE/source catalog or private material is
copied into this small analysis seal; those image/build inputs remain in the
separately owned normal-native retention package.
