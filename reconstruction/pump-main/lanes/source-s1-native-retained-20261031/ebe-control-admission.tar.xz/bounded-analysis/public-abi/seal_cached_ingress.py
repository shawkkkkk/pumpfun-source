#!/usr/bin/env python3
"""Cache-only public caller transport review; no ELF/IR/scorer/VM read or run."""
import os,sys
assert os.environ.get('PYTHONDONTWRITEBYTECODE')=='1'
sys.dont_write_bytecode=True
from pathlib import Path
import json,hashlib
ROOT=Path('/dev/shm/pump-cto-ebe5387');OUT=ROOT/'work/context-public-abi'
cache=ROOT/'work/original-fee-path-roles/CALLER.json'
def sha(b):return hashlib.sha256(b).hexdigest()
def binding(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
x=json.loads(cache.read_text());assert sha(cache.read_bytes())=='62447e297c9595733855d50c298308d942155607e46e68a1a30eab6de94d5e4d'
assert x['status']=='RAW_MATCHED_PUBLIC_CALLER_AND_ABI_INPUTS_BOUND_FOR_MANUAL_PATH_REVIEW'
caller=x['caller'];assert caller['address']==0x12da00 and caller['bytes']==2208 and caller['rawEqualOriginal'] is True
assert caller['bodySha256']=='7d0a74f04ad9aad2fb0a9e916e65b30e6118342d2036b2cfdf28119c053f2b14'
ins={int(r['offset'],16):r for r in x['logicalRows']}
def eq(o,op,d,s,disp,imm):
 r=ins[o];assert [r[k] for k in ['opcode','dst','src','displacement','immediate']]==[op,d,s,disp,imm],r
for a in [(0x48,0x79,3,8,-4088,0),(0x58,0x79,4,8,-4096,0),(0x60,0xb7,8,0,0,2),
          (0x68,0xbf,2,3,0,0),(0x70,0x07,2,0,0,-1),(0x78,0xbf,1,4,0,0),(0x80,0x07,1,0,0,1),
          (0x88,0x71,5,4,0,0),(0x98,0x15,5,0,43,0),(0xa0,0x15,5,0,1,1),
          (0xb8,0x71,8,1,0,0),(0xc8,0xa5,8,0,33,2),
          (0x1d8,0x07,4,0,0,2),(0x1e0,0x07,3,0,0,-2),(0x1e8,0xbf,1,4,0,0),(0x1f0,0xbf,2,3,0,0),
          (0x220,0x71,0,1,0,0),(0x230,0x15,0,0,9,0),(0x238,0x55,0,0,134,1),
          (0x248,0xb7,0,0,0,1),(0x250,0x79,3,1,1,0),(0x258,0x7b,10,3,-1016,0),
          (0x260,0x07,2,0,0,-9),(0x268,0x07,1,0,0,9),
          (0x288,0x71,1,3,0,0),(0x298,0x15,1,0,28,0),(0x2a0,0x15,1,0,1,1),
          (0x320,0xbf,5,0,0,0),(0x350,0xbf,0,5,0,0),(0x380,0x7b,10,0,-1024,0),
          (0x388,0x73,10,1,-113,0),(0x560,0x79,1,10,-1016,0),(0x568,0x7b,10,1,-4096,0),
          (0x570,0xbf,1,10,0,0),(0x578,0x07,1,0,0,-113),(0x580,0x7b,10,1,-4088,0),
          (0x5a8,0xbf,5,10,0,0),(0x5b0,0xbf,3,8,0,0),(0x5b8,0x79,4,10,-1024,0)]:eq(*a)
assert x['executeCall']==ins[0x5c0] and ins[0x5c0]['callTarget']=='0x22a10'
# Only this one already-bound wrapper is inventoried. No text-wide caller census.
calls=[r for r in ins.values() if r['opcode']==0x85 and r['src']==1 and r['immediate']!=-1 and r.get('callTarget')=='0x22a10']
assert len(calls)==1
r8defs=[r for r in ins.values() if r['dst']==8 and r['opcode']&7 in (1,4,7)]
assert [r['offset'] for r in r8defs]==['0x0','0x60','0xb8']
widths={0x7b:8,0x63:4,0x6b:2,0x73:1,0x7a:8,0x62:4,0x6a:2,0x72:1}
def overlap_writes(lo,hi,beg=0,end=0x5c0):
 return [r for o,r in ins.items() if beg<=o<end and r['opcode'] in widths and r['dst']==10 and r['displacement']<hi and lo<r['displacement']+widths[r['opcode']]]
tagwrites=overlap_writes(-1024,-1016);feevaluewrites=overlap_writes(-1016,-1008)
assert [r['offset'] for r in tagwrites]==['0x380'] and [r['offset'] for r in feevaluewrites]==['0x258']
new_late_writes=overlap_writes(-113,-80,0x3f0)
assert new_late_writes==[]
# Establish role names/types from the actual public IDL and admitted source, not widths.
idl=Path('/dev/shm/pump-cto-faf9962/evidence/upstream/pump.json')
lib=ROOT/'programs/pump/src/lib.rs';src=ROOT/'programs/pump/src/creator/admin_cto.rs'
for p in [idl,lib,src]:assert sha(p.read_bytes())==x['inputs'][str(p)]['sha256']
ix=[r for r in json.loads(idl.read_text())['instructions'] if r['name']=='admin_cto'];assert len(ix)==1
args=[{'name':'is_holder_reward','type':{'option':'bool'}},{'name':'creator_fee_bps','type':{'option':'u64'}},{'name':'new_creator','type':{'option':'pubkey'}}]
assert ix[0]['args']==x['publicIDL']['args']==args
assert ix[0]['discriminator']==[125,126,214,134,77,229,188,89]
public='pub fn admin_cto(ctx:Context<AdminCto>,is_holder_reward:Option<bool>,creator_fee_bps:Option<u64>,new_creator:Option<Pubkey>)->Result<()>{admin_cto::execute(ctx,is_holder_reward,creator_fee_bps,new_creator)}'
assert public in lib.read_text()
private='fn validate(st:&CtoState,hopt:Option<bool>,fee:Option<u64>,new:Option<Pubkey>,holder_key:&Pubkey,sharing:&Pubkey)->Result<Pubkey>{let holder=hopt==Some(true);'
assert private in src.read_text()
# Raw native bridges come from retained admitted records only.
originalp=Path('/dev/shm/pump-cto-ecea702/work/fee-semantics-963d/ORIGINAL-PREFIX.json')
assert sha(originalp.read_bytes())==x['inputs'][str(originalp)]['sha256']
orig={int(r['offset'],16):r for r in json.loads(originalp.read_text())}
for o,raw in [(0,'bf56000000000000'),(8,'7b4ad8f600000000'),(16,'7b3ae8f600000000'),(0x1e0,'796708f000000000'),(0x1e8,'796100f000000000')]:assert orig[o]['raw']==raw
native_resultp=ROOT/'work/context-native-equality/NATIVE-WITNESSES.json'
ebe={int(r['offset'],16):r for r in json.loads(native_resultp.read_text())['prefix']}
for o,raw in [(0,'bf59000000000000'),(8,'7b4af0f600000000'),(16,'7b3a18f700000000'),(0x108,'799108f000000000'),(0x118,'799100f000000000')]:assert ebe[o]['raw']==raw
new_ranges=[(1,0x2e0,0x2e8,0x390,0x398,-112,4),(5,0x2f0,0x2f8,0x3a0,0x3a8,-108,2),
 (7,0x2c8,0x338,0x378,0x3b8,-106,8),(15,0x2d0,0x2d8,0x370,0x3b0,-98,1),
 (16,0x330,0x340,0x3c0,0x3c8,-97,8),(24,0x328,0x348,0x3d0,0x3d8,-89,8),(32,0x310,0x360,0x3e0,0x3e8,-81,1)]
# Preserve rows for the split7/8 path, including the overlapping staging writes.
selected_ranges=[(0x48,0xd0),(0x1d8,0x3f0),(0x550,0x5c8)]
selected=[r for o,r in ins.items() if any(a<=o<z for a,z in selected_ranges)]
wits={'coordinate_system':'Caller offsets relative to actual public wrapper VA0x12da00, address fields absolute; LDDW bytes16. Callee offsets relative to their execute VA0x22a10. Caller FP and each callee FP are separate.','caller_rows':selected,'caller_r8_definition_census':r8defs,'direct_fp_overlapping_store_census':{'fee_presence':tagwrites,'fee_value':feevaluewrites,'new33_after_construction_before_call':new_late_writes},'original_execute_ingress':[orig[o] for o in [0,8,16,0x1e0,0x1e8]],'ebe_execute_ingress':[ebe[o] for o in [0,8,16,0x108,0x110,0x118,0x120]],'public_idl':{'name':'admin_cto','discriminator':ix[0]['discriminator'],'args':args},'public_forwarder':public,'private_validate_header':private}
(OUT/'INGRESS-WITNESSES.json').write_text(json.dumps(wits,indent=2)+'\n')
result={'status':'CACHED_RAW_MATCHED_PUBLIC_CALLER_ABI_CLOSED_UNDER_VALID_DECODE_AND_SBF_ABI_PREMISE','method':'No ELF/IR was reopened. Existing matched CALLER.json raw records and exact input hashes are reviewed; selected argument-decoder/setup and callee ingress rows only. Original fee-path role analysis remains owned by IRreview.','caller':caller,'direct_call':calls[0],'caller_count_scope':'Exactly one call to execute within this matched public wrapper; no claim of no other caller in the program. Only one caller is used in this proof.','source_and_idl':{'instruction':wits['public_idl'],'lib_rs_line':1071,'forwarder':public,'validate':'The admitted Ebe validate accepts hopt:Option<bool>, not an already collapsed holder bool, and computes holder=hopt==Some(true).','provenance':'IDL comes from retained pump-public-docs commit639b87fb45c3adeffa6f7c4a1bf0cb85e392bf22, SHA7616681ea557975f9f623ac211080f22a93060781eaf4765b0a488d980997207. This is a public schema, not original Rust source.'},
 'wire_to_execute_r3':{'decoder_slice':'Caller+48 loads input slice length from incoming saved_r5-4088; +58 loads input slice pointer P from saved_r5-4096. These incoming caller stack operands are not the outgoing fee/new operands later rewritten in its own frame.','wire':'First argument wire tag loaded P[0] at+88. Tag0 selects+1f8 after consuming1byte; tag1 selects+b0, checks available bool byte, loads P[1] at+b8 and accepts payload<2 at+c8→1d8, then consumes2bytes. Invalid/short-input error construction is outside the selected successful-decode proof.','representation_rows':[{'wire':'tag0; no bool payload','source':'None','execute_R3':2,'producer':'R8=2 at+60; tag0 branch+98 bypasses+b8'},{'wire':'tag1,bool0','source':'Some(false)','execute_R3':0,'producer':'R8=u8[P+1] at+b8; accepted bool<2 at+c8'},{'wire':'tag1,bool1','source':'Some(true)','execute_R3':1,'producer':'Same byte load and bound check'}],'transport':'R3=R8 at+5b0. R8 definition census has only entry+0(save incoming frame-base, then overwritten+60), default+60 and bool-load+b8. Across intervening calls, callee-saved R8 follows SBF ABI. None2 and Some(false)0 remain distinct at execute entry; this is not a pre-collapsed bool.','qualification':'The2/0/1 values are observed Rust-side native transport in this matched caller. They are distinct from Borsh wire tag+optional bool. No universal Rust Option niche/layout guarantee or malformed-ABI acceptance is asserted.'},
 'wire_to_execute_r4_and_fee_value':{'wire':'Second argument tag Q[0] is loaded at+220. Tag0 branches+230→280 retaining R0=0. Tag1 passes+238 and length check, sets R0=1 at+248 and loads u64Q[1,9) at+250→FP-1016+258. The Some-new path preserves/restores this fee tag via+320/+350.','presence':'R0 stored callerFP-1024 at+380, loaded R4 at+5b8. Thus execute incoming R4 is presence0/1, not fee magnitude.','value':'Caller+560 loads FP-1016; +568 writes callerFP-4096. At+5a8 R5=callerFP, so execute reads its extra operand at[R5-4096]. FeeNone payload is unspecified and not semantically asserted; Some(0) has presence1 and magnitude0, distinct from None.','preservation':'Only one direct overlapping callerFP write to presence slot(+380) and payload slot(+258) before execute call; hidden aliases/call preservation qualified below.'},
 'wire_to_new_extra_operand':{'wire':'Third argument tag at+288; tag0→380 or tag1→2b0 with33-byte availability check. The accepted Some path reads the following32 input bytes; None payload bytes are unspecified.','native_object':'callerFP[-113,-80) contains one actual tag byte+388 and32 payload bytes assembled+390..3e8. The7 payload range pieces are [1,5),[5,7),[7,15),[15,16),[16,24),[24,32),[32,33) relative to the serialized option start; overlapping staging at+300/+308/+338/+368/+370/+378 reconstructs the middle9 bytes without a width-to-type inference.','transport':'caller+570/+578 formsFP-113; +580 stores its pointer at callerFP-4088. R5=callerFP at+5a8. Execute extra operand[R5-4088] is this new Option object pointer, not the input wire pointer or fee value.','some_payload_segments':[{'wire_option_range':[a,a+w],'destination_caller_fp_range':[dest,dest+w],'source_or_staging_pc':hex(a1),'staging_store_pc':hex(a2),'final_load_or_shift_pc':hex(a3),'final_store_pc':hex(a4)} for a,a1,a2,a3,a4,dest,w in new_ranges],'preservation':'No direct callerFP overlapping write to[-113,-80) after construction through execute call; ordinary source/ABI private object nonalias premise still required.'},
 'callee_ingress_join':{'original':'At execute+0 save incomingR5→R6; +8 save incomingR4; +10 save incomingR3. +1e0 loads[R6-4088]→R7(new object pointer), +1e8 loads[R6-4096]→R1(fee magnitude). Exact rows are reused from sealed ORIGINAL-PREFIX.','ebe':'At execute+0 saveR5→R9; +8 saveR4; +10 saveR3. +108 loads[R9-4088](new), +118 loads[R9-4096](fee magnitude). Rows are reused from the existing admitted Ebe339 prefix seal.','distinct_frames':'Outgoing callerFP is the passed R5 value; execute own R10 is different. This proof does not conflate same numeric offsets in distinct frames.'},
 'bounds':['Valid public deserialization and ordinary valid account/Rust values are premises. Invalid wire error tails, dispatcher8-byte discriminator removal and arbitrary direct private-ABI callers are not exhaustively proved.','Public IDL types and exact admitted forwarding source assign role names; raw matched wrapper decode/setup assigns physical transport. Neither alone is used as a width guess.','SBF calling convention preserves R6-R9 across calls and separates caller/callee local frames. Caller-private fee/new objects are not aliased/mutated by account construction or memcpy beyond their specified passed ranges; direct FP census is not a universal alias theorem.','No original Rust private type, Result carrier, lifetime, full caller absence, later-main behavior, source gain or compiled metric is inferred.','No new binary/native/IR read, compiler/scorer/VM/test/metric/source variant/remote action was executed by this cache-only review.'],
 'input_bindings':[binding(cache),binding(ROOT/'work/original-fee-path-roles/read_ingress.py'),binding(originalp),binding(native_resultp),binding(idl),binding(lib),binding(src),binding(Path('/dev/shm/pump-cto-faf9962/evidence/upstream/provenance.json'))]}
(OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS cached matched public-caller wire/native operand binding')
