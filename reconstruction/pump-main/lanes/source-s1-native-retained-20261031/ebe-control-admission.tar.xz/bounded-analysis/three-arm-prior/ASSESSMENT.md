# Three selected-key arms: NO_CAUSAL_GO

The original's three fee-presence sites belong to **selected-key roles**:
holder K, shared nonholder C, and nonshared nonholder N. They are not the three
`Option<bool>` encodings. Cached original proof05e4f56a binds C selection at
+dc8..e18 before +e20/+e28 and N selection at +1490..14f0 before +1500/+1508;
the validated input N still supplies the separate later sharing payload.
Fresh cached13fe and Ebe receipts each report two native fee tests and a common
head. These are real native-flow constraints, not source-body counts.

Semantic arm specialization is possible without changing successful values:
preserve hopt, all common creator checks, holder's new-is-Some rejection, and
all supplied-N required/zero/invalid checks before splitting nonholders into
C and N. Fees must follow those checks, and sharing must retain original N.
The existing fee sequence is quote326, cashback330, first volatile read before
config334, range338, then second volatile read. None/quote/cashback error paths
perform zero reads; config/range errors perform one; successful Some performs
two. Moving or repeating this sequence can change observable volatile effects
or error precedence even though the resulting target key is unchanged.

There is a precise budget problem. Literal copies of the fee body in K/C/N
arms introduce six volatile source expressions, exceeding the required two.
A reusable helper/closure can keep two expressions and execute only one copy
per dynamic path, but its three call sites introduce a shared body and another
fallible boundary. Ordinary optimization can retain that helper or merge the
identical C/N fee work. This is not a prediction that either must occur.
Source branching alone cannot guarantee separate target storage, early
materialization, three in-function tag tests, the original private exits or
absence of the unwanted transport join.

| Exact prior | What it establishes |
| --- | --- |
| #3197 F1/F2/F3 | **Two nested-private fee_ok calls inside validate**, not public execute calls. F1 inserts a ResultUnit helper and calls it in holder/nonholder target arms; F2 passes scalar state fields; F3 adds a holder out-param. Notes report F1 26,288B/.48305 and a helper not inlined at its two call sites. Historical raw-IR oracle evidence, not a newly rebound ELF. |
| #3384 f1/f2/f3 | A private fee helper called from public execute after creator projection, or from an and_then closure. Different placement, already negative; helper visibility must not be called public. |
| w13a18 e1 | Pre-fee C selection with the private ResultKey and common private fees retained; caller late override removed. Reported 27,288B/.28580, two tests and eleven-instruction copy join. Does not test three fee call sites. |
| Actual S3 | Full settings Result6, different flags/carrier boundary, three native tests/private head but rejected target metric. It proves that the desired count/private head is insufficient for byte progress, not a universal rule about ResultKey. |

No exact three-arm ResultKey source collision was established in this bounded
retained F1/F2/F3/e1/feephi inspection. That absence is neither novelty nor
permission to regenerate it. #3197 supplies directly relevant negative
call-placement evidence; its source does not support labelling the proposed
private placement as a departure from two public calls.

No new favorable native prediction is justified. The original needs K/C/N
selection and fee-path separation while retaining a shared validation/error
structure. Neither that fact nor its separate incoming-N payload identifies a
Rust helper signature, three textual fee bodies/call sites or another Result
boundary. Calling three native tests the goal would repeat count tuning. A
new, independently bound ABI/value-transport constraint would be needed to
justify a particular ordinary source form and a measurable prediction beyond
the count. None emerged here.

Root's S4/source-generation gate therefore remains closed. No candidate,
macro/closure/helper implementation, tuple/permutation, take/nested296 form,
attribute, barrier, flag, compiler, scorer, metric or VM action was generated
or executed. Existing scripts and cached receipts were read as data only.
