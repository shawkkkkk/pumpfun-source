This reader is prepared and has not been executed. It has no native artifact to admit yet. Root owns acquisition and one independent official full rescore against the admitted actual13fe control. No compiler, SDK, scorer, metric, IR or VM operation belongs to this reader.

The starting implementation is the qualified33-check reader at `/dev/shm/pump-cto-13fe453/work/native-run/control-review/review_actual.py`. Its source/provenance/link/ELF/saved-row checks are retained. Ebe source is fixed at ebe5387e12e948c2534618adf7a3cf0f27d9de51, tree196d24d8725ef08e0470c44de7bed95a797eb46a, selected141 aggregate6b02f60a97777892b9cfb3b93ff40679226e08dca15b8313899df342c68e07e7, CORE236 and staged142. The seventeen lane research additions are nonselected. No program source is changed here.

Actual OP/run/job/artifact IDs, archive and image byte counts, full hashes, timing and CTO extent have not been supplied. The example release file deliberately has null values and cannot pass the reader's mandatory actual-pin admission. No +2M report is used as an expected result. Text and CTO geometry are derived from the actual raw link map and ELF symbol/section tables, compared across the actual stripped and unstripped images, and reported without running a similarity metric.

The parent standardized the following acquisition contract. Original provider wrappers must be preserved separately when normalized records are written.

| Path under `work/native-run` | Required schema and binding |
| --- | --- |
| `raw-artifact.zip`, `artifact/` | Root-acquired actual ZIP and exact regular extracted member bytes; all CRCs and membership recomputed. The normal43 member domain is taken from the qualified normal template, not predicted member contents. |
| `DOWNLOAD-VERIFIED.json` | Object with `artifactId`, `run`, `operationalCommit`, `bytes`, `sha256`, `members`, `CRC:"PASS"`, `files` **dictionary** mapping member to `{bytes,sha256}`. It is not the historical13fe files-list schema. |
| `ARTIFACT-METADATA.json` | Plain full provider artifact object; exact id, size, digest, expiration and membership in `artifacts-final` are checked. |
| `artifacts-final.json` | `{artifacts:[full provider objects]}`; selection is by released artifact id, not list position. |
| `run-final.json` | Plain full provider run; actual OP/head, id, attempt1, workflow_dispatch, workflow path and completed-success status. |
| `jobs-final.json` | `{jobs:[full provider objects]}`; one actual released job with matching run and all actual steps. |
| `steps-final.json` | `{steps: job0.steps}`; equality with that full job and successful completed steps. |
| `PUBLIC-OPERATIONAL.json` | The13fe-established public commit schema: `{sha,parents:[{sha}],files:[{filename,sha,status}],...}`. Sole Ebe parent and the three actual prepared Git blobs are required. Root provides this record. |

Local preparation contracts have been read directly rather than inferred from file names:

- `work/native-prep/FROZEN-MANIFEST.json` has `{status,files:[{path,bytes,sha256}]}`, paths relative to native-prep. It does **not** have `ops`. The reader authenticates its complete listed contents.
- `PREPARATION-RESULT.json.opsFiles` contains the three operational records, with base-only metadata too. Actual `operational-inputs.json.files` is compared after selecting `path,mode,bytes,sha256,gitBlob`; no base metadata is confused with native records.
- `program-source-inputs.json` and `toolchain-source-inputs.json` are typed `{base,files:[...]}`. Snapshot `source-inputs.json` and `preflight-builder-source-inputs.json` are `{schema,sha256,files}`. Stage inputs are a **bare dictionary** of142 paths to byte/hash/executable records. Source selection is a separate object.
- Native `PREFLIGHT.json` equals the local once-preflight evidence with only `preflightOnly:false`. Native program, CORE and stage records must equal the physically reviewed local preflight vectors.
- `REFERENCE-COPY-ADMISSION.json.files` is a **dictionary**. `REFERENCE-DOWNLOAD-VERIFIED.json.files` retains the original13fe **list**. The reader handles these two explicitly, authenticates all43 copied member bytes, and binds run41170683278/artifact13031166975 plus the full original ZIP and image hashes.
- `work/root/CURRENT-ELF-ADMISSION.json` uses the actual13fe normal-admission schema: base, operationalCommit, run, sourceSha256, sourceFiles, images, normalized, raw, total, independentOfficialScorer. Root's future Ebe record must retain these names or provide the explicit finalized schema before reader execution. No scorer is imported by this reader.

The original33 check families remain: ZIP/provider/membership/acquisition; public/prepared operational inputs and environment; program/CORE/stage and physical Git byte/blob/mode bindings; source archives; build/host/registry/tools/nativeLLD/cold source; pinned SDK archives/full guards and fresh flags; all retained link origins and555 selectors/private-script/map/ELF geometry; unique CTO; saved1035 rows and historical arithmetic; root one-off fullscore and released image pins; provider run/job/steps. Three additional named checks bind the Ebe freeze/native preflight, exact admitted13fe43 reference, and all1035 saved current-vs13fe normalized/raw no-loss rows. These are prepared checks, not results.

The reader retains the old target ELF format, exact profile/triple, two full SDK archive roles, documented five-command chain, published link grammar and current normal43 schema. An unexpected actual result or missing field must fail visibly; it must not be repaired by assuming a successful build or rewriting an original native failure. SDK/registry/private-temp bytes are not newly observed locally; limits must distinguish recorded native guards from local physical evidence.

After root explicitly supplies actual records and a non-null release file, the intended command is `PYTHONDONTWRITEBYTECODE=1 python3 -B work/admission-reader/review_actual.py --release work/admission-reader/ACTUAL-RELEASE.json` from the Ebe root. It has not been run. It writes a new `work/admission-reader/actual-review/` only after all admission predicates pass, and refuses to overwrite an earlier result. Preserve any failed execution stdout/stderr separately. No compiler/scorer/runtime or source experiment follows automatically.
