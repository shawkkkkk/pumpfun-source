"""Seal provider metadata and decoded public job log, without artifact download."""
from pathlib import Path
import datetime, hashlib, json, os, re, sys
assert os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode and sys.flags.optimize==0
R=Path('/dev/shm/pump-cto-ebe5387/work/native-run');sha=lambda b:hashlib.sha256(b).hexdigest()
run_id=41176417138;head='1bb7326cbccd7773f9accba45b9b6379b76ceb12';source='ebe5387e12e948c2534618adf7a3cf0f27d9de51'
run=json.loads((R/'run-final.json').read_text());jobs=json.loads((R/'jobs-final.json').read_text())['jobs'];steps=json.loads((R/'steps-final.json').read_text())['steps'];artifacts=json.loads((R/'artifacts-final.json').read_text())['artifacts']
assert run['id']==run_id and run['head_sha']==head and run['run_attempt']==1 and run['status']=='completed' and run['conclusion']=='success'
assert run['head_branch']=='work/cto-current-ebe5387-control-20261031' and len(jobs)==len(artifacts)==1
job=jobs[0];artifact=artifacts[0];assert job['id']==124464797685 and job['run_id']==run_id and job['conclusion']=='success' and steps==job['steps']
assert all(x['status']=='completed' and x['conclusion']=='success' for x in steps)
assert artifact==json.loads((R/'ARTIFACT-METADATA.json').read_text())
assert artifact['id']==13033007890 and artifact['size_in_bytes']==2539553 and artifact['digest']=='sha256:b9ad6f1bc76f9b8fdb01e06b65262e3725ded83d544e394c8f0f568da6bfcfe5'
assert artifact['workflow_run']['id']==run_id and artifact['workflow_run']['head_sha']==head and artifact['expired'] is False
polls=sorted(R.glob('poll-*'));assert len(polls)==9
parsed={}
for label in ['run','jobs','artifacts']:
    wrapper=json.loads((polls[-1]/(label+'-response.json')).read_text());assert wrapper['run_id']==run_id and not wrapper['result']['isError']
    parsed[label]=json.loads(wrapper['result']['structuredContent']['content'])
assert run==parsed['run'] and jobs==parsed['jobs']['jobs'] and artifacts==parsed['artifacts']['artifacts']
intervals=[];observed=[]
for folder in polls:
    w=json.loads((folder/'run-response.json').read_text());v=json.loads(w['result']['structuredContent']['content']);assert v['id']==run_id and v['head_sha']==head and v['run_attempt']==1
    observed.append(datetime.datetime.fromisoformat(w['observedUTC'].replace('Z','+00:00')))
for a,b in zip(observed,observed[1:]):intervals.append((b-a).total_seconds())
assert min(intervals)>=30
w=json.loads((R/'terminal/job-log-response.json').read_text());assert w['run_id']==run_id and w['job_id']==job['id'] and not w['result']['isError']
log=w['result']['structuredContent']['content'];assert isinstance(log,str);b=log.encode('utf-8')
assert not(R/'terminal/job.log').exists();(R/'terminal/job.log').write_bytes(b)
patterns=[rb'github_pat_[A-Za-z0-9_]{20,}',rb'gh[pousr]_[A-Za-z0-9]{20,}',rb'Bearer [A-Za-z0-9_.-]{20,}',rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
assert not any(re.search(p,b)for p in patterns),'Unexpected credential-shaped public log data; preserve privately and report'
mapping={'status':'CANONICAL_CONTRACT_REPRODUCED_FROM_FULL_PROVIDER_WRAPPERS','canonical':{'run-final.json':{'source':'poll-009/run-response.json','parse':'JSON.parse(result.structuredContent.content)','projection':'entire object'},'jobs-final.json':{'source':'poll-009/jobs-response.json','parse':'JSON.parse(result.structuredContent.content)','projection':'{jobs: provider.jobs}; every job/step field retained'},'steps-final.json':{'source':'poll-009/jobs-response.json','parse':'JSON.parse(result.structuredContent.content)','projection':'{steps: provider.jobs[0].steps}; exact complete raw steps'},'artifacts-final.json':{'source':'poll-009/artifacts-response.json','parse':'JSON.parse(result.structuredContent.content)','projection':'{artifacts: provider.artifacts}; every artifact field retained'},'ARTIFACT-METADATA.json':{'source':'poll-009/artifacts-response.json','parse':'JSON.parse(result.structuredContent.content)','projection':'provider.artifacts[0] bare full object'},'terminal/job.log':{'source':'terminal/job-log-response.json','parse':'result.structuredContent.content is decoded UTF8 text, not JSON','projection':'encode unchanged UTF8 content including any BOM; no redaction'}},'providerCollectionTotalCounts':{'jobs':parsed['jobs']['total_count'],'artifacts':parsed['artifacts']['total_count']},'wrappersPreserved':True,'allCanonicalFieldsReproduced':True,'rawPublicLogUnchanged':True,'credentialPatternMatchesInPublicLog':0,'privateTransferOrAuthRead':False}
(R/'CANONICAL-METADATA-MAP.json').write_text(json.dumps(mapping,indent=2)+'\n')
result={'status':'TERMINAL_SUCCESS_PROVIDER_METADATA_ONLY','repo':'shawkkkkk/pumpfun-source','runId':run_id,'attempt':1,'operationalHead':head,'operationalTree':'80c589377a42a4872b9b79609d339c742809433e','source':source,'workflowConclusion':run['conclusion'],'jobId':job['id'],'jobConclusion':job['conclusion'],'createdAt':run['created_at'],'updatedAt':run['updated_at'],'jobStartedAt':job['started_at'],'jobCompletedAt':job['completed_at'],'allStepsCompleteSuccess':True,'providerArtifact':artifact,'decodedJobLog':{'path':'terminal/job.log','bytes':len(b),'sha256':sha(b),'rawResponse':'terminal/job-log-response.json','unalteredDecodedPublicText':True},'polls':len(polls),'minimumObservedPollIntervalSeconds':min(intervals),'metadataContract':'CANONICAL-METADATA-MAP.json','limits':'Provider workflow SUCCESS and artifact declaration only; actual ZIP/source/SDK/ELF/score admission is root-owned and not inferred here. Plain unchanged Ebe control, not source variant/diagnostic/VM. No current-main/source-gain/byte-identity claim.','actions':{'dispatch':0,'retry':0,'cancel':0,'artifactZipDownloads':0,'compilerSDKScorerMetricVMTests':0},'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(R/'MONITOR-RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
handoff={'status':'READY_FOR_ROOT_ARTIFACT_ACQUISITION_AND_ADMISSION','runId':run_id,'operationalHead':head,'source':source,'artifactId':artifact['id'],'artifactName':artifact['name'],'providerBytes':artifact['size_in_bytes'],'providerDigest':artifact['digest'],'conclusion':run['conclusion'],'canonicalFiles':['run-final.json','jobs-final.json','steps-final.json','artifacts-final.json','ARTIFACT-METADATA.json'],'fullRawLog':'terminal/job.log','rawWrapperMap':'CANONICAL-METADATA-MAP.json','resultSha256':sha((R/'MONITOR-RESULT.json').read_bytes()),'artifactZipDownloadedHere':False,'rootOwnsDownloadAndOnceIndependentFullScore':True}
(R/'MONITOR-HANDOFF.json').write_text(json.dumps(handoff,indent=2)+'\n')
owned=[p for folder in polls for p in sorted(folder.glob('*.json'))]
owned += [R/x for x in ['MONITOR-PLAN.json','run-final.json','jobs-final.json','steps-final.json','artifacts-final.json','ARTIFACT-METADATA.json','terminal/job-log-response.json','terminal/job.log','CANONICAL-METADATA-MAP.json','MONITOR-RESULT.json','MONITOR-HANDOFF.json','seal_monitor.py']]
files=[]
for p in sorted(owned):
    b=p.read_bytes();files.append({'path':p.relative_to(R).as_posix(),'bytes':len(b),'sha256':sha(b)})
(R/'MONITOR-FROZEN-MANIFEST.json').write_text(json.dumps({'status':'FROZEN_TERMINAL_PROVIDER_METADATA_AND_RAW_LOG','files':files},indent=2)+'\n')
seal={'status':'SEALED_MONITOR_SUCCESS_NO_ZIP_DOWNLOAD','runId':run_id,'source':source,'providerArtifactId':artifact['id'],'providerArtifactBytes':artifact['size_in_bytes'],'providerArtifactDigest':artifact['digest'],'manifestSha256':sha((R/'MONITOR-FROZEN-MANIFEST.json').read_bytes()),'manifestFiles':len(files),'resultSha256':sha((R/'MONITOR-RESULT.json').read_bytes()),'handoffSha256':sha((R/'MONITOR-HANDOFF.json').read_bytes()),'canonicalMetadataMapSha256':sha((R/'CANONICAL-METADATA-MAP.json').read_bytes()),'runCanonicalSha256':sha((R/'run-final.json').read_bytes()),'jobCanonicalSha256':sha((R/'jobs-final.json').read_bytes()),'stepCanonicalSha256':sha((R/'steps-final.json').read_bytes()),'artifactCanonicalSha256':sha((R/'artifacts-final.json').read_bytes()),'rawWrappersAllRetained':True,'artifactDownload':False,'actions':result['actions']}
(R/'SEALED-MONITOR-RECEIPT.json').write_text(json.dumps(seal,indent=2)+'\n')
print(json.dumps({'sealSha256':sha((R/'SEALED-MONITOR-RECEIPT.json').read_bytes()),'manifestSha256':seal['manifestSha256'],'manifestFiles':len(files),'handoffSha256':seal['handoffSha256'],'rawLogBytes':result['decodedJobLog']['bytes'],'rawLogSha256':result['decodedJobLog']['sha256'],'allStepsSuccess':True,'artifactId':artifact['id'],'providerBytes':artifact['size_in_bytes'],'providerDigest':artifact['digest'],'minimumPollSeconds':min(intervals)}))
