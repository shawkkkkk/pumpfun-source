"""Independent Ebe normal-prep read/hash/AST/Git/archive review, no project calls."""
from pathlib import Path,PurePosixPath
import ast,copy,hashlib,json,os,re,subprocess,sys,tarfile,zipfile
assert os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode
ROOT=Path('/dev/shm/pump-cto-ebe5387');PREP=ROOT/'work/native-prep';OUT=ROOT/'work/capture-review';PARENT_ROOT=Path('/dev/shm/pump-cto-13fe453')
BASE='ebe5387e12e948c2534618adf7a3cf0f27d9de51';PARENT='13fe4536be64d8c5c10f8905e9d2236f423ac4f4';TREE='196d24d8725ef08e0470c44de7bed95a797eb46a';SOURCE='6b02f60a97777892b9cfb3b93ff40679226e08dca15b8313899df342c68e07e7';STAGE='d3a20e58a5ab6b40923700bf3ef97680a31675152c6d406d88eded4b12983e62'
CORE=('reconstruction/harness','reconstruction/toolchain','reconstruction/base','reconstruction/pump-main/baseline','evidence/original/pump');CHECKS=[]
ENV=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1',GIT_ALLOW_PROTOCOL='file')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());dump=lambda n:ast.dump(n,include_attributes=False)
def canonical(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
def check(name,value):assert value,name;CHECKS.append(name)
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,env=ENV,stderr=subprocess.PIPE)
def physical(prefixes):
 rows=[]
 for row in git('ls-tree','-rz',BASE,'--',*prefixes).split(b'\0'):
  if not row:continue
  meta,name=row.split(b'\t',1);mode,kind,oid=meta.decode().split();name=name.decode();p=ROOT/name
  assert kind=='blob' and mode in ('100644','100755','120000')
  if mode=='120000':assert p.is_symlink();data=os.fsencode(os.readlink(p))
  else:assert p.is_file() and not p.is_symlink() and bool(p.stat().st_mode&0o111)==(mode=='100755');data=p.read_bytes()
  assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid
  rows.append({'path':name,'mode':mode,'gitBlob':oid,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 actual={p.relative_to(ROOT).as_posix() for prefix in prefixes for p in (ROOT/prefix).rglob('*') if p.is_file() or p.is_symlink()}
 assert actual=={r['path'] for r in rows}
 return rows
def vector(folder):
 result={}
 for p in sorted(folder.rglob('*')):
  assert not p.is_symlink()
  if p.is_file():result[p.relative_to(folder).as_posix()]={'bytes':p.stat().st_size,'executable':bool(p.stat().st_mode&0o111),'sha256':sha(p)}
 return result

check('exact final55-file freeze and preparation summary',sha(PREP/'FROZEN-MANIFEST.json')=='3b3f86453f7f8efc2214a4da51f02c2e4ef9fff0088567d4150ec9bde700a5a3' and sha(PREP/'PREPARATION-RESULT.json')=='ee2190489b12b94775422203ddcc9f7ea53269c82c6d950a15ccdc0c6bba9caa')
freeze=load(PREP/'FROZEN-MANIFEST.json');prepared=load(PREP/'PREPARATION-RESULT.json');assert len(freeze['files'])==55
for row in freeze['files']:
 p=PREP/row['path'];name=PurePosixPath(row['path']);assert not name.is_absolute() and '..' not in name.parts and p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
check('all55 author-declared bytes unchanged',True)
check('genuine detached HEAD and exact tree',git('rev-parse','HEAD').decode().strip()==BASE and git('rev-parse','HEAD^{tree}').decode().strip()==TREE)
headers=git('cat-file','-p','HEAD').split(b'\n\n',1)[0].splitlines();check('sole13fe parent',[x[7:].decode() for x in headers if x.startswith(b'parent ')]==[PARENT])
program=physical(('programs/pump',));core=physical(CORE);check('typed physical Git141 source and236 CORE exact domains',len(program)==141 and len(core)==236)
for row in core:
 p=ROOT/row['path'];q=PARENT_ROOT/row['path'];assert p.is_symlink()==q.is_symlink()
 assert os.readlink(p)==os.readlink(q) if p.is_symlink() else p.read_bytes()==q.read_bytes()
check('all236 CORE bytes modes and blobs same actual13fe',core==load(PARENT_ROOT/'work/native-run/artifact/toolchain-source-inputs.json')['files'])
source_delta=git('diff','--no-ext-diff','--no-textconv','--no-renames','--name-only',PARENT,BASE,'--','programs/pump',*CORE).decode().splitlines();check('sole selected source delta',source_delta==['programs/pump/src/creator/admin_cto.rs'])
leaf=ROOT/source_delta[0];prior_leaf=PARENT_ROOT/source_delta[0];a,b=prior_leaf.read_text().splitlines(True),leaf.read_text().splitlines(True)
check('current accepted leaf a1a0 and single339 expression change',sha(leaf)=='a1a0bb06a5a260e13f5824235bbd19b6fa43883f07e3073e1cbcba03ab16601a' and len(a)==len(b)==772 and [i+1 for i,(x,y) in enumerate(zip(a,b)) if x!=y]==[339])
delta=load(PREP/'SOURCE-TREE-DELTA.json');full=git('diff','--no-ext-diff','--no-textconv','--no-renames','--name-status',PARENT,BASE).decode().splitlines();check('full18 Git paths correctly qualify17 nonselected research additions',len(full)==len(delta['files'])==18 and {tuple(x.split('\t',1)) for x in full}=={(x['status'],x['path']) for x in delta['files']})
for row in delta['files']:
 meta=git('ls-tree',BASE,'--',row['path']).decode().split('\t')[0].split();assert meta==[row['mode'],'blob',row['gitBlob']]
 if not row['selectedForBuild']:assert row['path'].startswith('reconstruction/pump-main/lanes/w14a108-cto-crlrepay/') and row['status']=='A' and not (ROOT/row['path']).exists() and not (ROOT/row['path']).is_symlink() and row['physicalMaterialized'] is row['executed'] is False
check('17 research metadata entries not materialized and absent from build input domains',len([x for x in delta['files'] if not x['selectedForBuild']])==17)
evidence=PREP/'preflight/evidence'
check('actual preflight program and CORE vectors exact physical Git',load(evidence/'program-source-inputs.json')==load(PREP/'program-source-inputs.json')=={'base':BASE,'files':program} and load(evidence/'toolchain-source-inputs.json')==load(PREP/'toolchain-source-inputs.json')=={'base':BASE,'files':core})
selected=[{'path':r['path'].removeprefix('programs/pump/'),'bytes':r['bytes'],'executable':r['mode']=='100755','sha256':r['sha256']} for r in program];snapshot=load(evidence/'preflight-builder-source-inputs.json')
check('selected141 canonical6b02 source snapshot exact',snapshot==load(PREP/'EXPECTED-SELECTED-SOURCE.json') and snapshot['files']==selected and snapshot['sha256']==canonical(selected)==SOURCE)
stage=PREP/'preflight/cold-work/ws';staged=vector(stage);check('actual maintained142 stage equals expected d3a20e58 projection',len(staged)==142 and staged==load(evidence/'compiled-workspace-inputs.json')==load(PREP/'EXPECTED-COMPILED-WORKSPACE.json') and canonical(staged)==STAGE)
toml=(ROOT/'programs/pump/Cargo.toml').read_text();ps=re.search(r'(?m)^\[profile\.release\]',toml).start();wi=re.search(r'(?m)^\[workspace\]',toml).start();projection={'programs/pump/'+r['path'].removeprefix('programs/pump/'):(ROOT/r['path']).read_bytes() for r in program if r['path'].removeprefix('programs/pump/') not in ('Cargo.toml','Cargo.lock')}
projection['programs/pump/Cargo.toml']=(toml[:ps].rstrip()+'\n').encode();projection['Cargo.toml']=('[workspace]\nmembers = ["programs/pump"]\nresolver = "2"\n\n'+toml[ps:wi].strip()+'\n').encode();projection['Cargo.lock']=(ROOT/'programs/pump/Cargo.lock').read_text().encode()
check('every142 staged byte equals immutable source and exact known manifest/lock projection',set(projection)==set(staged) and all((stage/name).read_bytes()==raw for name,raw in projection.items()))
archive_counts={}
for name,folder,rows in [('program-source.tar.gz',ROOT,{r['path']:r for r in program}),('compiled-workspace.tar.gz',stage,staged)]:
 with tarfile.open(evidence/name) as t:
  members=t.getmembers();assert len(members)==len({m.name for m in members})==len(rows) and {m.name for m in members}==set(rows)
  for m in members:
   assert m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts and t.extractfile(m).read()==(folder/m.name).read_bytes() and bool(m.mode&0o111)==bool((folder/m.name).stat().st_mode&0o111)
  archive_counts[name]=len(members)
check('all283 retained source/stage archive members exact bytes and modes',sum(archive_counts.values())==283)
lane='reconstruction/pump-main/lanes/current-native-control';controller=PREP/'ops'/lane/'pump_current_control.py';prior=PARENT_ROOT/'work/native-prep/ops'/lane/'pump_current_control.py';ct=ast.parse(controller.read_text());pt=ast.parse(prior.read_text());normalized=copy.deepcopy(ct)
for n in normalized.body:
 if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='BASE':n.value=ast.Constant(value=PARENT)
normalized.body[0]=copy.deepcopy(pt.body[0]);check('whole controller AST differs from qualified plain13fe only BASE/docstring',dump(normalized)==dump(pt))
helper_names=[n.name for n in ct.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name!='main'];check('all14 helpers class methods and main unchanged',len(helper_names)==14)
ops=('.github/workflows/qualify-pump-macos-v144.yml',lane+'/pump_current_control.py',lane+'/README.md');check('exact normal3 OPS domain',set(ops)=={x['path'] for x in prepared['opsFiles']} and len(prepared['opsFiles'])==3)
for row in prepared['opsFiles']:
 p=PREP/'ops'/row['path'];raw=p.read_bytes();assert p.is_file() and not p.is_symlink() and not p.stat().st_mode&0o111 and len(raw)==row['bytes'] and sha(p)==row['sha256'] and hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['gitBlob']
check('exact3 operational byte size mode SHA Gitblob pins',True)
workflow=(PREP/'ops'/ops[0]).read_text();old_workflow=(PARENT_ROOT/'work/native-prep/ops'/ops[0]).read_text();check('workflow only source pin and label strings changed',workflow.replace(BASE,PARENT).replace('ebe5387e','13fe4536')==old_workflow and workflow.count('run: python3 -B '+lane+'/pump_current_control.py')==1 and 'if: always()' in workflow and 'cancel-in-progress: false' in workflow and 'download-artifact' not in workflow and 'capture.py' not in workflow)
ref=ROOT/'work/current-13fe-reference';actual=PARENT_ROOT/'work/native-run/artifact';reference=load(PREP/'REFERENCE-COPY-ADMISSION.json');pins=reference['files'];check('actual13fe external-reference43 exact role and provenance',len(pins)==43 and reference['base']==PARENT and reference['run']==41170683278 and reference['artifactId']==13031166975 and reference['rawZipSha256']=='875edcd6e9ebb7e5b8fb2495d0008e723762b1f0251a02e038881fb56749fa92' and {p.relative_to(ref).as_posix() for p in ref.rglob('*') if p.is_file() or p.is_symlink()}==set(pins))
for name,row in pins.items():
 p=ref/name;q=actual/name;assert p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'] and p.read_bytes()==q.read_bytes()
with zipfile.ZipFile(actual.parent/'raw-artifact.zip') as z:
 assert z.testzip() is None and len(z.namelist())==43 and set(z.namelist())==set(pins)
 for name in z.namelist():assert z.read(name)==(ref/name).read_bytes()
check('all43 external reference bytes and root transport match actual13fe',sha(actual.parent/'raw-artifact.zip')==reference['rawZipSha256'] and (actual.parent/'raw-artifact.zip').stat().st_size==2539578 and (PREP/'REFERENCE-ROOT-ADMISSION.json').read_bytes()==(PARENT_ROOT/'work/root/CURRENT-ELF-ADMISSION.json').read_bytes())
score=load(ref/'score.json');check('actual reference source CORE cold and saved1035 arithmetic only',load(ref/'RESULT.json')['base']==PARENT and load(ref/'RESULT.json')['sourceUnchanged'] and load(ref/'RESULT.json')['coldTarget'] and load(ref/'toolchain-source-inputs.json')['files']==core and len(score['windows'])==score['summary']['total']==1035 and sum(x['raw'] for x in score['windows'].values())==sum(x['normalized'] for x in score['windows'].values())==1034)
before=load(PREP/'PREFLIGHT-INPUTS-BEFORE.json');after=load(PREP/'PREFLIGHT-INPUTS-AFTER.json');check('all424 original physical bindings unchanged during once preflight',before==after and len(before)==len({r['path'] for r in before})==424)
for row in after:
 p=Path(row['path']);assert p.is_relative_to(ROOT);raw=os.fsencode(os.readlink(p)) if p.is_symlink() else p.read_bytes();st=p.lstat();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'] and st.st_mode==row['mode'] and st.st_ino==row['inode'] and st.st_dev==row['device'] and st.st_mtime_ns==row['mtime_ns']
execution=load(PREP/'PREFLIGHT-EXECUTION.json');process=load(PREP/'PREFLIGHT-PROCESS.json');outcome=load(PREP/'PREFLIGHT-RESULT.json');check('actual PID726881 successful preflight authentic no SDK bootstrap Cargo compiler score VM',process['pid']==outcome['pid']==726881 and outcome['status']=='PASS' and outcome['exitCode']==execution['exitCode']==0 and execution['head']==BASE and execution['controllerSha256']==sha(controller) and outcome['sourceCoreReferenceOpsBoundFiles']==424 and not outcome['SDKBootstrapCargoCompilerScorerVMExecuted'] and not execution['fullNativeOperationalParentAdmissionExercised'])
for name in ('stdout','stderr'):
 p=PREP/('preflight.'+name);assert p.stat().st_size==outcome[name+'Bytes'] and sha(p)==outcome[name+'Sha256']
check('once process argv environment and raw zero-stderr logs bound',process['argv']==outcome['argv']==execution['command'] and process['environment']['PYTHONDONTWRITEBYTECODE']=='1' and process['argv'][1]=='-B' and outcome['stderrBytes']==0)
loader=ast.parse((PREP/'run_preflight.py').read_text());calls=[n for n in ast.walk(loader) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='main'];check('preflight loader binds ROOT EVIDENCE WORK only and exactly one preflight-only main',len(calls)==1 and len(calls[0].keywords)==1 and calls[0].keywords[0].arg=='preflight_only' and ast.literal_eval(calls[0].keywords[0].value) is True)
pf=load(evidence/'PREFLIGHT.json');link=load(evidence/'link-inputs.json');check('real staged/link preflight stops before all SDK/native operations',pf['preflightOnly'] and not pf['sdkInstalledByPreflight'] and not pf['bootstrapRunByPreflight'] and not pf['cargoRunByPreflight'] and not pf['compilerRunByPreflight'] and not link['configureExecutedByPreflight'] and link['selectors']=={'.text':555,'.rodata':0,'.data.rel.ro':0} and not (PREP/'preflight/cold-work/target-identity').exists())
all_rows={x['path']:x for x in program+core}
for name,row in {'ordered.ld':link['programScript'],**link['maintainedInputs']}.items():assert row==all_rows[row['path']] and sha(evidence/'pinned-link-inputs'/name)==row['sha256']
check('all5 pinned link input bytes/provenance exact',True)
for name in ('AGENTS.md','CONTRIBUTING.md','README.md','SECURITY.md','docs/SCOPE.md','docs/COMPLETION.md','docs/PARALLEL_WORK.md','programs/pump/Cargo.toml','programs/pump/Cargo.lock','programs/pump/pump-token-ext/Cargo.toml'):assert (ROOT/name).read_bytes()==(PARENT_ROOT/name).read_bytes()
check('guides manifests lock hooks unchanged reviewed13fe',True)
check('tracked source checkout remains clean',not git('status','--porcelain','--untracked-files=no').strip())
report={'status':'PASS','source':BASE,'tree':TREE,'parent':PARENT,'authorFreezeSha256':sha(PREP/'FROZEN-MANIFEST.json'),'authorFrozenFiles':55,'operationalFiles':prepared['opsFiles'],'sourceFiles':141,'coreFiles':236,'stageFiles':142,'selectedSourceSha256':SOURCE,'stageVectorSha256':STAGE,'fullDeltaPaths':18,'unmaterializedNonselectedResearchPaths':17,'referenceMembers':43,'referenceRun':41170683278,'referenceArtifact':13031166975,'checks':CHECKS,'normalUnchangedHelpers':helper_names,'actualPreflight':{'pid':726881,'seconds':outcome['elapsedSeconds'],'executionSha256':sha(PREP/'PREFLIGHT-EXECUTION.json')},'limits':['Independent read/hash/AST/Git/archive only; no project/preflight/test/SDK/compiler/scorer/VM/native/metric repeat or remote mutation.','External13fe reference is not a hosted candidate/diagnostic source overlay. Future normal job retains faithful historical score baseline; root alone compares actual full1035 rows/noLoss after artifact.','Native Ebe result and reported+2M remain unverified. No sourcegain, runtime/latest-source/whole-original identity or followup source authorization.']}
(OUT/'AUTHENTICATION.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','checks':len(CHECKS),'authenticationSha256':sha(OUT/'AUTHENTICATION.json'),'source':SOURCE,'stage':STAGE}))
