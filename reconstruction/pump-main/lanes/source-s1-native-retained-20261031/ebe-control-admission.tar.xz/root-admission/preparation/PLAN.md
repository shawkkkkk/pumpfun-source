# One root-owned official Ebe admission

Prepared only; neither this reader nor the scorer has been executed here.
Frozen source is ebe5387e12e948c2534618adf7a3cf0f27d9de51, operational
1bb7326cbccd7773f9accba45b9b6379b76ceb12, run41176417138/attempt1.

Root first acquires and safely admits the actual normal ZIP into
work/native-run/raw-artifact.zip and artifact/. Provider IDs, byte counts,
digests and image hashes remain unset until that acquisition. The release
schema is the existing admission-reader/ACTUAL-RELEASE.example.json contract,
with actual source/OP/run/job/artifact/ZIP/image pins. No second protocol.

Standard normalized metadata are ARTIFACT-METADATA.json, artifacts-final.json,
run-final.json, jobs-final.json, steps-final.json and PUBLIC-OPERATIONAL.json.
DOWNLOAD-VERIFIED.json.files is a dictionary. Preserve original provider
envelopes separately. No metadata endpoint or archive is fetched by this script.

The script reuses the qualified13fe root admission predicates, adapting only
the frozen Ebe preparation schemas and exact43 actual13fe external reference.
It derives ELF images, section geometry and the unique admin_cto execute
symbol extent from actual bytes. No 27,400-byte extent, match count or +2M
claim is used as an expected Ebe result.

After input admission, SCORE-STARTED.json is created exclusively **before**
the sole maintained score.py child. Exact argv, selected environment, input
hashes, PID, stdout, stderr and complete fresh JSON are retained in
work/root/admission/official-score/. The command uses actual13fe score.json
as baseline; Python -B/PYTHONDONTWRITEBYTECODE=1 and TMPDIR=/dev/shm persist.
No compiler, SDK, similarity metric or VM is called.

If SCORE-STARTED exists, no code path launches another scorer. --resume
requires the completed process receipt and unchanged scorer/image/reference
inputs, and reparses the existing official-score/score.json. A missing JSON,
nonzero child, interrupted/unknown child or input drift fails visibly without
retry. Admission/parser errors are retained as separate attempt records.
Parser-only corrections can use --resume; reader text is recorded separately
from the immutable score input binding and does not force another child.

All1035 fresh rows must equal the native saved rows. Every fresh row is then
compared with actual13fe, preserving changed rows plus raw/normalized gains,
losses and no-loss booleans. CURRENT-ELF-ADMISSION.json retains the agreed
base/operationalCommit/run/sourceSha256/sourceFiles/images/normalized/raw/
total/independentOfficialScorer keys. A loss remains a recorded negative and
does not become source acceptance. Full JSON/streams are never regenerated.

Root must review the prepared script before invoking it with an actual release.
This preparation authorizes no execution, native retry or new source form.
