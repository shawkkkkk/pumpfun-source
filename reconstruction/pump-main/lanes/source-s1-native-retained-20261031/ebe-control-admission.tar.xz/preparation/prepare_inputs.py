"""Authenticate Ebe Git inputs and prepare only the unchanged normal-control recipe."""
from pathlib import Path
import ast, datetime, hashlib, json, os, shutil, stat, subprocess, sys
assert os.environ.get('PYTHONDONTWRITEBYTECODE') == '1' and sys.dont_write_bytecode and sys.flags.optimize == 0
R=Path('/dev/shm/pump-cto-ebe5387'); O=R/'work/native-prep'; OLD=Path('/dev/shm/pump-cto-13fe453')
S='ebe5387e12e948c2534618adf7a3cf0f27d9de51'; P='13fe4536be64d8c5c10f8905e9d2236f423ac4f4'; T='196d24d8725ef08e0470c44de7bed95a797eb46a'
CORE=('reconstruction/harness','reconstruction/toolchain','reconstruction/base','reconstruction/pump-main/baseline','evidence/original/pump')
GUIDES=['AGENTS.md','CONTRIBUTING.md','README.md','SECURITY.md','docs/SCOPE.md','docs/COMPLETION.md','docs/PARALLEL_WORK.md']
OPS=['.github/workflows/qualify-pump-macos-v144.yml','reconstruction/pump-main/lanes/current-native-control/pump_current_control.py','reconstruction/pump-main/lanes/current-native-control/README.md']
sha=lambda b:hashlib.sha256(b).hexdigest()
env={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_ALLOW_PROTOCOL':'file','PYTHONDONTWRITEBYTECODE':'1'}
def git(*args):
    return subprocess.run(['git',*args],cwd=R,env=env,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout
assert git('rev-parse','HEAD').decode().strip()==S and git('rev-parse','HEAD^{tree}').decode().strip()==T
assert [x[7:].decode() for x in git('cat-file','-p',S).split(b'\n\n',1)[0].splitlines() if x.startswith(b'parent ')]==[P]
def entries(commit,prefixes,physical=True):
    rows=[]
    for raw in git('ls-tree','-rz',commit,'--',*prefixes).split(b'\0'):
        if not raw:continue
        meta,name=raw.split(b'\t',1); mode,kind,oid=meta.decode().split(); name=name.decode(); assert kind=='blob' and mode in ['100644','100755','120000']
        b=git('cat-file','blob',oid)
        if physical:
            p=R/name
            if mode=='120000':assert p.is_symlink(); actual=os.fsencode(os.readlink(p))
            else:
                assert p.is_file() and not p.is_symlink(); actual=p.read_bytes(); assert bool(p.stat().st_mode&0o111)==(mode=='100755')
            assert actual==b
        rows.append({'path':name,'mode':mode,'gitBlob':oid,'bytes':len(b),'sha256':sha(b)})
    return rows
source=entries(S,('programs/pump',)); core=entries(S,CORE); assert(len(source),len(core))==(141,236)
assert core==entries(P,CORE,False)
full_delta=git('diff','--no-ext-diff','--no-textconv','--no-renames','--name-only',P,S).decode().splitlines()
assert [n for n in full_delta if n.startswith(('programs/pump/',*(x+'/' for x in CORE)))]==['programs/pump/src/creator/admin_cto.rs']
assert all(n=='programs/pump/src/creator/admin_cto.rs' or n.startswith('reconstruction/pump-main/lanes/w14a108-cto-crlrepay/') for n in full_delta)
(O/'SOURCE-TREE-DELTA.json').write_text(json.dumps({'paths':full_delta,'programCoreDelta':['programs/pump/src/creator/admin_cto.rs'],'unselectedResearchRecordsMaterializedOrExecuted':False},indent=2)+'\n')
leaf=next(x for x in source if x['path']=='programs/pump/src/creator/admin_cto.rs')
assert leaf['gitBlob']=='861112a0ea90265bc8886f06e9c0ea9dd0c73abe' and leaf['sha256']=='a1a0bb06a5a260e13f5824235bbd19b6fa43883f07e3073e1cbcba03ab16601a'
selected=[{'path':x['path'].removeprefix('programs/pump/'),'bytes':x['bytes'],'executable':x['mode']=='100755','sha256':x['sha256']} for x in source]
selected.sort(key=lambda x:x['path'])
encoded=json.dumps(selected,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
snapshot={'schema':'pump-source-inputs-v1','sha256':sha(encoded),'files':selected}
staged=json.loads((OLD/'work/native-prep/preflight/evidence/compiled-workspace-inputs.json').read_text())
stageleaf='programs/pump/src/creator/admin_cto.rs'; assert stageleaf in staged
staged[stageleaf]={'bytes':leaf['bytes'],'executable':False,'sha256':leaf['sha256']}
stage_sha=sha(json.dumps(staged,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
guides={}
for name in GUIDES+['programs/pump/Cargo.toml','programs/pump/Cargo.lock','programs/pump/pump-token-ext/Cargo.toml']:
    b=(R/name).read_bytes(); assert b==git('cat-file','blob',S+':'+name)==git('cat-file','blob',P+':'+name)==(OLD/name).read_bytes()
    guides[name]={'bytes':len(b),'sha256':sha(b),'byteEqualReviewed13fe':True}
hooks=['source_inputs.py','fastbuild.py','build_process.py','link_order.py','pump_physical_source_wrapper.py','pump_link_rustc.py','pump_link_lld.py','sbf_default.ld']
hookmeta={}
for name in hooks:
    b=(R/'reconstruction/harness'/name).read_bytes(); assert b==(OLD/'reconstruction/harness'/name).read_bytes()
    hookmeta[name]={'bytes':len(b),'sha256':sha(b),'byteEqualReviewed13fe':True}
assert not any(x['path'].endswith('/build.rs') for x in source)
rsync=Path('/workspace/pumpfun-source-workers/pump-lifecycle/work/host-tools/rsync-debian-13/extracted/usr/bin/rsync')
assert sha(rsync.read_bytes())=='a56c05b960beb734169619d5760b43ff495e84f85a93eb1f54fe58118262fb20'
(O/'INPUT-REVIEW.json').write_text(json.dumps({'status':'PASS_BEFORE_PROJECT_EXECUTION','guidesAndManifests':guides,'hooks':hookmeta,'coreAll236ByteModeBlobEqual13fe':True,'manifestBuildScript':False,'observedFlaggedHook':False,'reviewBasis':'Current genuine AGENTS/CONTRIBUTING/manifests and source-input/physical wrapper read; full source/CORE Git vectors and unchanged reviewed hooks/lockfile authenticated against admitted13fe. Exact repository delta is one program leaf; no instruction/build-input change. Stopped lanes remain stopped. No install/bootstrap/compiler/scorer/VM authorized.','rsyncSha256':sha(rsync.read_bytes())},indent=2)+'\n')
for name,value in [('program-source-inputs.json',{'base':S,'files':source}),('toolchain-source-inputs.json',{'base':S,'files':core}),('EXPECTED-SELECTED-SOURCE.json',snapshot),('EXPECTED-COMPILED-WORKSPACE.json',staged)]:
    (O/name).write_text(json.dumps(value,indent=2)+'\n')

REF=OLD/'work/native-run/artifact'; DEST=R/'work/current-13fe-reference'
admit=json.loads((OLD/'work/root/CURRENT-ELF-ADMISSION.json').read_text()); download=json.loads((OLD/'work/native-run/DOWNLOAD-VERIFIED.json').read_text())
assert admit['base']==P and admit['run']==41170683278 and admit['sourceAndArchiveAdmission']==admit['independentOfficialScorer']=='PASS' and (admit['total'],admit['raw'],admit['normalized'])==(1035,1034,1034)
assert download['sha256']=='875edcd6e9ebb7e5b8fb2495d0008e723762b1f0251a02e038881fb56749fa92' and download['actualBytes']==2539578 and download['artifact']==13031166975 and download['members']==43
table={}
for p in sorted(REF.rglob('*')):
    if p.is_file():
        assert not p.is_symlink(); b=p.read_bytes(); table[p.relative_to(REF).as_posix()]={'bytes':len(b),'sha256':sha(b)}
assert len(table)==43 and table=={x['path']:{'bytes':x['bytes'],'sha256':x['sha256']}for x in download['files']}
assert json.loads((REF/'toolchain-source-inputs.json').read_text())['files']==core
score=json.loads((REF/'score.json').read_text()); assert len(score['windows'])==1035 and score['summary']['candidate_sha256']==admit['images']['unstripped.so']
assert(sum(x['raw']for x in score['windows'].values()),sum(x['normalized']for x in score['windows'].values()))==(1034,1034)
DEST.mkdir(exist_ok=False)
for name,value in table.items():
    p=DEST/name; p.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(REF/name,p); assert len(p.read_bytes())==value['bytes'] and sha(p.read_bytes())==value['sha256']
for name,value in table.items():assert sha((REF/name).read_bytes())==value['sha256']
for target,path in [('REFERENCE-ROOT-ADMISSION.json',OLD/'work/root/CURRENT-ELF-ADMISSION.json'),('REFERENCE-DOWNLOAD-VERIFIED.json',OLD/'work/native-run/DOWNLOAD-VERIFIED.json')]: (O/target).write_bytes(path.read_bytes())
(O/'REFERENCE-COPY-ADMISSION.json').write_text(json.dumps({'status':'PASS_ACTUAL_ADMITTED13FE43_LOCAL_REFERENCE','base':P,'sourceAggregate':'ba203d5c8b0cda5ab3bb6eec65266a992331b7a8a361b9977a3d2ab474b11fe2','run':41170683278,'artifactId':13031166975,'rawZipSha256':download['sha256'],'rawZipBytes':download['actualBytes'],'originalReference':str(REF),'copiedReference':str(DEST),'files':table,'savedRows':1035,'raw':1034,'normalized':1034,'scoreRerun':False,'role':'Root-admitted actual13fe cohort retained for subsequent exact source/native comparison. Plain normal controller is unchanged and independently records all1035 actual Ebe rows against its explicit official historical scorer input; no candidate/no-loss/experimental controller is substituted.'},indent=2)+'\n')

template=OLD/'work/native-prep/ops';old=(template/OPS[1]).read_text();new=old.replace('One faithful cold build of the exact frozen 13fe4536 source checkpoint.','One faithful cold build of the exact frozen ebe5387e source checkpoint.').replace("BASE = '"+P+"'","BASE = '"+S+"'")
assert old!=new
old_ast=ast.parse(old);new_ast=ast.parse(new)
for tree in [old_ast,new_ast]:
    assert isinstance(tree.body[0],ast.Expr) and isinstance(tree.body[0].value,ast.Constant);tree.body[0].value.value='DESCRIPTION'
    assigns=[n for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='BASE'];assert len(assigns)==1;assigns[0].value.value='BASE'
assert ast.dump(old_ast,include_attributes=False)==ast.dump(new_ast,include_attributes=False)
wf=(template/OPS[0]).read_text();newwf=wf.replace(P,S).replace('13fe4536','ebe5387e'); assert newwf!=wf
for name,text in [(OPS[1],new),(OPS[0],newwf)]:
    p=O/'ops'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
readme=f'''# Frozen ebe5387e native identity control

Measure one unchanged Pump source commit `{S}`, tree
`{T}`, sole source parent `{P}`.
The genuine detached sparse Git checkout supplies all program bytes; the only
source delta from the admitted13fe parent is the existing CTO line339 expression.
The leaf is Git blob `{leaf['gitBlob']}`, SHA256 `{leaf['sha256']}`.

Only the registered workflow, this README and `pump_current_control.py` may
differ in the future operational checkout, which must be one direct child of
this frozen source. This is the qualified plain13fe normal control, changed only
in BASE and its first descriptive string. Every function, LinkAudit method and
main AST is unchanged. The workflow changes only frozen source and label strings.
There is no S3 candidate/diagnostic controller, new flag, source overlay or variant.

Physical/Git inventories bind141 selected source files, aggregate
`{snapshot['sha256']}`, and236 CORE files byte/mode/blob equal13fe.
Maintained staging must produce142 files, canonical vector `{stage_sha}`.
Current genuine instruction files, crate manifests/lockfile and executed staging
and link helpers equal the previously reviewed13fe bytes. No source cache files
are excluded from admission beyond the maintained source selection rules.

One local actual `--preflight-only` invocation admits the current physical/Git
source and CORE, executes maintained snapshot/staging with qualified real rsync,
and validates the ordered linker script. Its immutable process/log receipt records
actual PID, argv, environment, time and exit. It returns before SDK acquisition,
bootstrap, Cargo, compiler, linker, scorer or VM. Hosted direct-operational-parent
qualification remains exclusive to future full mode. All input hashes are checked
before and after this one preflight.

Full mode retains the normal macOS26 ARM64 recipe: fresh work, SDK/cache/target
paths; exact pinned v1.44 and analysis-only v1.52 archives; full native SDK and
Linux target-library inventories; authenticated native LLD; locked acquisition
followed by one offline cold compile; local-crate fingerprints and unchanged
flags; before/after source/CORE/staging/registry/tool checks. The linker validates
program/default scripts, uses a private checked copy and removes it after linking;
the controller retains source scripts, real nativeLLD, link receipt/map and all
compiler output. Raw ELF outputs and all1,035 official saved score rows are retained
even on partial failure. No old native hash, reported +2M or score predicts Ebe.

The admitted13fe reference is run41170683278/artifact13031166975, actual43 members,
ZIP SHA256 `875edcd6e9ebb7e5b8fb2495d0008e723762b1f0251a02e038881fb56749fa92`.
Its complete local reference evidence, image/member hashes and root admission are
bound separately in `REFERENCE-COPY-ADMISSION.json`, with actual1034raw/1034norm
of1035. Those results belong to13fe. They are reference evidence for root's later
Ebe comparison and do not replace this normal controller's explicit historical
official scorer baseline or supply a transferred runtime/native result.

Root owns publication and one native dispatch after independent review. This
preparation provides no native result, source gain, runtime equivalence, security
clearance, whole-original ELF identity or qualification of later main. S3 remains
rejected and its VM remains held. No source proposal or followup variant is authorized.
'''
(O/'ops'/OPS[2]).write_text(readme)
adapt={'status':'PASS_ONLY_NORMAL_CONTROL_BASE_AND_DESCRIPTION_CHANGED','template':str(template/OPS[1]),'templateSha256':sha(old.encode()),'controllerSha256':sha(new.encode()),'wholeModuleASTIdenticalExceptBaseAndFirstDocstring':True,'allFunctionsMethodsMainUnchanged':True,'workflowLabelsAndSourcePinOnly':True,'candidateOrDiagnosticControllerUsed':False,'source':S,'projectExecutions':0}
(O/'CONTROLLER-ADAPTATION.json').write_text(json.dumps(adapt,indent=2)+'\n')
derive={'sourceCommit':S,'sourceTree':T,'sourceParent':P,'sourceFiles':141,'coreFiles':236,'expectedStageFiles':142,'selectedSourceSha256':snapshot['sha256'],'expectedStageVectorSha256':stage_sha,'stageExpectedFromQualified13feProjectionWithExactGitLeaf':True,'actualMaintainedStageDeferredToOncePreflight':True,'leaf':leaf,'allCoreEqual13fe':True,'onlySourceDelta':['programs/pump/src/creator/admin_cto.rs'],'SDKCompilerScorerVMExecutions':0}
(O/'DERIVATION.json').write_text(json.dumps(derive,indent=2)+'\n')
print(json.dumps({'status':'INPUTS_AUTHENTICATED_OPS_PREPARED_NO_PREFLIGHT_YET','source':S,'sourceSha256':snapshot['sha256'],'expectedStageVectorSha256':stage_sha,'referenceMembers':len(table),'controllerSha256':sha(new.encode())}))
