"""Seal the exact Ebe plain normal-control preparation; no build/test execution."""
from pathlib import Path
import ast, datetime, difflib, hashlib, json, os, subprocess, sys, tarfile
assert os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode and sys.flags.optimize==0
R=Path('/dev/shm/pump-cto-ebe5387'); O=R/'work/native-prep'; OLD=Path('/dev/shm/pump-cto-13fe453')
S='ebe5387e12e948c2534618adf7a3cf0f27d9de51'; P='13fe4536be64d8c5c10f8905e9d2236f423ac4f4'; T='196d24d8725ef08e0470c44de7bed95a797eb46a'
sha=lambda b:hashlib.sha256(b).hexdigest()
env={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_ALLOW_PROTOCOL':'file','PYTHONDONTWRITEBYTECODE':'1'}
def git(*args):return subprocess.run(['git',*args],cwd=R,env=env,capture_output=True,check=True).stdout
assert git('rev-parse','HEAD').decode().strip()==S and git('rev-parse','HEAD^{tree}').decode().strip()==T
assert not git('status','--porcelain','--untracked-files=no').strip()
result=json.loads((O/'PREFLIGHT-RESULT.json').read_text()); assert result['status']=='PASS' and result['exitCode']==0 and result['inputsUnchanged'] and result['sourceCoreReferenceOpsBoundFiles']==424
assert json.loads((O/'PREFLIGHT-INPUTS-BEFORE.json').read_text())==json.loads((O/'PREFLIGHT-INPUTS-AFTER.json').read_text())
assert result['SDKBootstrapCargoCompilerScorerVMExecuted'] is False
pre=json.loads((O/'preflight/evidence/PREFLIGHT.json').read_text());d=json.loads((O/'DERIVATION.json').read_text())
assert (pre['programGitFiles'],pre['selectedSourceFiles'],pre['workspaceFiles'],pre['coreFiles'])==(141,141,142,236) and pre['preflightOnly']
assert pre['sourceSha256']==d['selectedSourceSha256']=='6b02f60a97777892b9cfb3b93ff40679226e08dca15b8313899df342c68e07e7'
assert pre['linkInputs']['selectors']=={'.text':555,'.rodata':0,'.data.rel.ro':0}
expected=json.loads((O/'EXPECTED-SELECTED-SOURCE.json').read_text()); actual=json.loads((O/'preflight/evidence/preflight-builder-source-inputs.json').read_text()); assert expected==actual
assert json.loads((O/'preflight/evidence/program-source-inputs.json').read_text())==json.loads((O/'program-source-inputs.json').read_text())
assert json.loads((O/'preflight/evidence/toolchain-source-inputs.json').read_text())==json.loads((O/'toolchain-source-inputs.json').read_text())
staged=json.loads((O/'preflight/evidence/compiled-workspace-inputs.json').read_text()); assert staged==json.loads((O/'EXPECTED-COMPILED-WORKSPACE.json').read_text())
stage_sha=sha(json.dumps(staged,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()); assert stage_sha==d['expectedStageVectorSha256']=='d3a20e58a5ab6b40923700bf3ef97680a31675152c6d406d88eded4b12983e62'
for name,rows in [('program-source.tar.gz',{x['path']:{'bytes':x['bytes'],'sha256':x['sha256'],'executable':x['mode']=='100755'} for x in json.loads((O/'program-source-inputs.json').read_text())['files']}),('compiled-workspace.tar.gz',staged)]:
    with tarfile.open(O/'preflight/evidence'/name) as tar:
        mm=tar.getmembers(); assert len(mm)==len(rows) and {m.name for m in mm}==set(rows)
        for m in mm:
            assert m.isfile() and bool(m.mode&0o111)==rows[m.name]['executable']; b=tar.extractfile(m).read(); assert len(b)==rows[m.name]['bytes'] and sha(b)==rows[m.name]['sha256']
delta=json.loads((O/'SOURCE-TREE-DELTA.json').read_text()); assert len(delta['files'])==delta['fullDeltaCount']==18 and delta['nonselectedResearchAdditionsCount']==17 and delta['selectedProgramDeltaCount']==1
assert {x['path']for x in delta['files']}==set(git('diff','--no-ext-diff','--no-textconv','--no-renames','--name-only',P,S).decode().splitlines())
for row in delta['files']:
    assert git('ls-tree',S,'--',row['path']).decode().strip()==row['mode']+' blob '+row['gitBlob']+'\t'+row['path']
    if not row['selectedForBuild']:assert not(R/row['path']).exists() and not row['physicalMaterialized'] and not row['executed']
adapt=json.loads((O/'CONTROLLER-ADAPTATION.json').read_text()); assert adapt['wholeModuleASTIdenticalExceptBaseAndFirstDocstring'] and adapt['allFunctionsMethodsMainUnchanged']
ops=['.github/workflows/qualify-pump-macos-v144.yml','reconstruction/pump-main/lanes/current-native-control/pump_current_control.py','reconstruction/pump-main/lanes/current-native-control/README.md']
controller=(O/'ops'/ops[1]).read_bytes(); assert sha(controller)==adapt['controllerSha256']
for before in json.loads((O/'PREFLIGHT-INPUTS-BEFORE.json').read_text()):
    p=Path(before['path']); b=os.fsencode(os.readlink(p))if p.is_symlink()else p.read_bytes(); assert sha(b)==before['sha256'] and len(b)==before['bytes']
reference=json.loads((O/'REFERENCE-COPY-ADMISSION.json').read_text()); assert len(reference['files'])==43 and reference['base']==P and reference['run']==41170683278 and reference['artifactId']==13031166975
for name,row in reference['files'].items():
    b=(R/'work/current-13fe-reference'/name).read_bytes(); assert len(b)==row['bytes'] and sha(b)==row['sha256']
meta={}
for raw in git('ls-tree','-rz',S,'--',*ops).split(b'\0'):
    if raw:
        m,n=raw.split(b'\t',1); mode,kind,oid=m.decode().split(); assert kind=='blob';meta[n.decode()]=(mode,oid)
patch=[];changes=[]
for name in ops:
    b=(O/'ops'/name).read_bytes(); nb=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(); old=git('cat-file','blob',S+':'+name) if name in meta else b''; ob=meta[name][1] if name in meta else '0'*40
    patch.append('diff --git a/'+name+' b/'+name+'\n')
    if name not in meta:patch.append('new file mode 100644\n')
    elif meta[name][0]!='100644':patch.extend(['old mode '+meta[name][0]+'\n','new mode 100644\n'])
    patch.append('index '+ob+'..'+nb+(' 100644'if name in meta and meta[name][0]=='100644'else'')+'\n')
    patch.extend(difflib.unified_diff(old.decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile='a/'+name if name in meta else '/dev/null',tofile='b/'+name))
    changes.append({'path':name,'mode':'100644','bytes':len(b),'sha256':sha(b),'gitBlob':nb,'baseGitBlob':ob if name in meta else None,'baseMode':meta[name][0] if name in meta else None})
(O/'OPS.patch').write_text(''.join(patch))
argv=['git','apply','--cached','--check','--whitespace=error',str(O/'OPS.patch')];p=subprocess.run(argv,cwd=R,env=env,capture_output=True)
(O/'GIT-PATCH-CHECK.json').write_text(json.dumps({'argv':argv,'exitCode':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode(),'indexMutation':False},indent=2)+'\n'); assert p.returncode==0
(O/'RECEIPT-SCHEMAS.json').write_text(json.dumps({'root':str(R),'folder':'work/native-prep','sourceAndCore':{'program-source-inputs.json':'object {base, files:[{path,mode,gitBlob,bytes,sha256}]}','toolchain-source-inputs.json':'same schema, exactly236 tracked entries including typed symlink','SOURCE-TREE-DELTA.json':'object {source,parent,sourceTree,files:[18 exact Git old/new mode/blob/status/path plus selected/materialized/executed flags]}','EXPECTED-SELECTED-SOURCE.json':'maintained snapshot-compatible {schema,sha256,files:[141 selected records]}'},'stage':{'preflight/evidence/compiled-workspace-inputs.json':'bare path→{bytes,executable,sha256} dictionary,142 entries','preflight/evidence/preflight-builder-source-inputs.json':'actual maintained snapshot {schema,sha256,files}'},'preflight':{'run_preflight.py':'ordinary13fe wrapper; overrides only ROOT/EVIDENCE/WORK paths and invokes real controller.main(preflight_only=True)','PREFLIGHT-PROCESS.json':'actual {pid,ppid,argv,cwd,startUtc,environment}','PREFLIGHT-RESULT.json':'actual {status,pid,argv,startUtc,endUtc,exitCode,elapsedSeconds,stdout/stderrBytes,SHA256,inputsUnchanged,...}','PREFLIGHT-INPUTS-BEFORE.json':'424 typed physical identity records, byteequal AFTER','preflight.stdout':'raw stdout','preflight.stderr':'raw stderr (zero bytes)'},'reference':{'REFERENCE-COPY-ADMISSION.json':'object files is path→{bytes,sha256} dictionary,43 entries; actual reference folder work/current-13fe-reference','REFERENCE-DOWNLOAD-VERIFIED.json':'root original download receipt; files is list of path/bytes/sha256 records','REFERENCE-ROOT-ADMISSION.json':'root original actual13fe ELF/source/fullscore admission; no re-execution'},'freeze':'FROZEN-MANIFEST.json object {status,files:[{path,bytes,sha256}]}; paths relative native-prep. PREPARATION-RESULT.json holds3OPS hashes/blobs and whole-reference/source/actualpreflight summary.','noAdapterOrRunnerSubstitution':True},indent=2)+'\n')
freeze=[]
for p in sorted(O.rglob('*')):
    if not p.is_file():continue
    name=p.relative_to(O).as_posix()
    if name.startswith('preflight/cold-work/') or name in ['FROZEN-MANIFEST.json','PREPARATION-RESULT.json']:continue
    b=p.read_bytes();freeze.append({'path':name,'bytes':len(b),'sha256':sha(b)})
assert not(O/'FROZEN-MANIFEST.json').exists()
(O/'FROZEN-MANIFEST.json').write_text(json.dumps({'status':'FROZEN_EBE_PLAIN_NORMAL_CONTROL_PREPARATION_ONLY','files':freeze},indent=2)+'\n')
summary={'status':'READY_FOR_ROOT_AND_INDEPENDENT_REVIEW_NO_NATIVE_RELEASE','sourceCommit':S,'sourceTree':T,'sourceParent':P,'leafGitBlob':'861112a0ea90265bc8886f06e9c0ea9dd0c73abe','leafSha256':'a1a0bb06a5a260e13f5824235bbd19b6fa43883f07e3073e1cbcba03ab16601a','sourceFiles':141,'coreFiles':236,'stageFiles':142,'selectedSourceSha256':expected['sha256'],'projectedWorkspaceVectorSha256':stage_sha,'fullCommitDeltaPaths':18,'selectedProgramDeltaPaths':1,'nonselectedResearchAdditions':17,'nonselectedResearchMaterializedOrExecuted':False,'fullDeltaReceiptSha256':sha((O/'SOURCE-TREE-DELTA.json').read_bytes()),'opsFiles':changes,'opsPatchSha256':sha((O/'OPS.patch').read_bytes()),'frozenManifestSha256':sha((O/'FROZEN-MANIFEST.json').read_bytes()),'frozenFileCount':len(freeze),'actualPreflight':result,'actualReference':{'source':P,'sourceAggregate':'ba203d5c8b0cda5ab3bb6eec65266a992331b7a8a361b9977a3d2ab474b11fe2','run':41170683278,'artifactId':13031166975,'rawZipSha256':reference['rawZipSha256'],'members':43,'folder':'work/current-13fe-reference','role':'External root-admission/current-vs-reference comparison only; plain hosted normal controller still retains faithful historical baseline.'},'wholeNormalControllerASTUnchangedExceptBaseAndDescription':True,'SDKCompilerScorerVmDispatchRemoteWrites':0,'trackedGitStatusClean':not git('status','--porcelain','--untracked-files=no').strip(),'CORECacheFilesAbsent':not any((R/prefix).rglob('__pycache__')for prefix in []) if False else not any(p.name=='__pycache__' for prefix in ['reconstruction/harness','reconstruction/toolchain']for p in (R/prefix).rglob('*')),'preservedFailures':['GIT-ACQUISITION-ATTEMPT01.json','GIT-ACQUISITION-ATTEMPT02.json','INPUT-PREPARATION-ATTEMPT01.json','DELTA-METADATA-ATTEMPT01.json'],'limits':'Frozen accepted Ebe source normal-control preparation only. No candidate/diagnostic/S4 source, no new flags, no native result/+2M/source-gain prediction, no transferred13fe runtime/native result, no latest-main or whole-original identity claim. Root alone publishes/dispatches after independent review.','utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
assert summary['CORECacheFilesAbsent']
(O/'PREPARATION-RESULT.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'status':summary['status'],'freezeSha256':summary['frozenManifestSha256'],'frozenFiles':len(freeze),'resultSha256':sha((O/'PREPARATION-RESULT.json').read_bytes()),'patchSha256':summary['opsPatchSha256'],'ops':changes,'sourceSha256':expected['sha256'],'stageVectorSha256':stage_sha}))
