"""Package existing Ebe control receipts after all named seals; no measurement."""
from pathlib import Path, PurePosixPath
import datetime, hashlib, io, json, os, re, sys, tarfile
assert os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode and sys.flags.optimize==0
R=Path('/dev/shm/pump-cto-ebe5387'); O=R/'work/retention-prep'; sha=lambda b:hashlib.sha256(b).hexdigest(); blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
members={};inputs={};omissions=[]
release=json.loads((O/'FINAL-RELEASE.json').read_text())
assert release['status']=='ALL_EXISTING_REQUIRED_SEALS_READY_NO_MEASUREMENTS'
assert set(release['analysisSeals'])=={'context','event','sweep'}
plan=json.loads((O/'PLAN.json').read_text()); S=plan['source']['commit']
def add(name,path,expected=None):
    n=PurePosixPath(name);p=Path(path)
    assert not n.is_absolute() and '..'not in n.parts and str(n)==name and name not in members
    assert p.is_file() and not p.is_symlink() and not any(x in p.parts for x in ['private-transfer','private-slop'])
    assert not any(x in p.name.lower() for x in ['client-version','client_version','auth-state','auth_state','cookie','credential'])
    b=p.read_bytes(); assert not b.startswith((b'\x7fELF',b'!<arch>\n')) and p.suffix.lower()not in ['.so','.rlib','.a','.dylib','.ll']
    if expected:assert len(b)==expected['bytes'] and sha(b)==expected['sha256'],name
    members[name]=b;inputs[name]={'source':str(p),'bytes':len(b),'sha256':sha(b)}
def add_manifest(folder,name,prefix,expected_sha=None,skip=()):
    folder=Path(folder);p=folder/name;b=p.read_bytes()
    if expected_sha:assert sha(b)==expected_sha
    d=json.loads(b);rows=d['files'] if isinstance(d,dict) and 'files'in d else d
    rows=[dict(path=n,**v)for n,v in rows.items()]if isinstance(rows,dict)else rows
    for row in rows:
        n=row['path']
        if n in skip:
            omissions.append({'source':str(folder/n),'bytes':row['bytes'],'sha256':row['sha256'],'reason':'Duplicate source/workspace payload remains represented by immutable preflight manifest and actual native ZIP; no extra payload copy.'});continue
        add(prefix+'/'+n,folder/n,row)
    add(prefix+'/'+name,p)
def add_sealed_allowlist(name,desc):
    folder=Path(desc['folder']);m=folder/desc['manifest'];assert sha(m.read_bytes())==desc['sha256']
    # Explicit final selection supplied by owner; never infer working inputs.
    rows={x['path']:x for x in desc['retentionFiles']}
    assert desc['manifest'] in rows
    for n,row in rows.items():add('bounded-analysis/'+name+'/'+n,folder/n,row)

add_manifest(R/'work/native-prep','FROZEN-MANIFEST.json','preparation','3b3f86453f7f8efc2214a4da51f02c2e4ef9fff0088567d4150ec9bde700a5a3',skip=['preflight/evidence/program-source.tar.gz','preflight/evidence/compiled-workspace.tar.gz'])
for n in ['PREPARATION-RESULT.json','ROOT-PREPARATION-REVIEW.json']:add('preparation/'+n,R/'work/native-prep'/n)
add_manifest(R/'work/capture-review','MANIFEST.json','preparation-independent-review',release['preparationReviewManifestSha256'])
add_manifest(R/'work/context-semantic-review','MANIFEST.json','accepted-source-semantic-review','0a2cd9a15716012516c479907ba7ec509e04952bae190355685d831963626719')
add_manifest(R/'work/native-run','MONITOR-FROZEN-MANIFEST.json','monitoring','ea111573a3f6bdcaa48f79da6ea9414700fe348dff4901dc1ed2d2e97baacdb3')
for n in ['SEALED-MONITOR-RECEIPT.json','DISPATCH.json','DOWNLOAD-VERIFIED.json','PUBLIC-OPERATIONAL.json']:
    add('monitoring/'+n,R/'work/native-run'/n)
for row in release['rootSafeRecords']:add('root-safe-records/'+row['archiveName'],R/row['path'],row)
add('root-admission/CURRENT-ELF-ADMISSION.json',R/'work/root/CURRENT-ELF-ADMISSION.json',release['rootAdmission'])
for p in sorted((R/'work/official-admission-prep').iterdir()):
    if p.is_file():add('root-admission/preparation/'+p.name,p)
for p in sorted((R/'work/root/admission/official-score').iterdir()):
    if p.is_file():add('root-admission/official-score/'+p.name,p)
add_manifest(R/'work/admission-reader','FINAL-MANIFEST.json','independent-actual-admission','6da13eda1fb1363fce3f295ba30c4bde2de955f390d86404191f93e4641b5708')
download=json.loads((R/'work/native-run/DOWNLOAD-VERIFIED.json').read_text())
assert download['sha256']==plan['additions'][0]['sha256'] and download['bytes']==2539553 and download['members']==43
skip={'candidate.so','unstripped.so','program-source.tar.gz','compiled-workspace.tar.gz','registry-source-inputs.json','registry-source-inputs-after.json','link.map'}
for name,row in download['files'].items():
    if name in skip:
        omissions.append({'source':'rawZIP:'+name,'bytes':row['bytes'],'sha256':row['sha256'],'reason':'Full native payload retained only in untouched rawZIP; no duplicate binary/source archive/large registry catalog/link map.'});continue
    add('actual-native-metadata/'+name,R/'work/native-run/artifact'/name,row)
for name,desc in release['analysisSeals'].items():add_sealed_allowlist(name,desc)
root=json.loads((R/'work/root/CURRENT-ELF-ADMISSION.json').read_text())
assert root['base']==S and(root['total'],root['raw'],root['normalized'])==(1035,1034,1034)
assert root['comparison']['allRowsEqual'] is True and root['comparison']['changedRows']=={} and root['comparison']['noRawLosses'] is True and root['comparison']['noNormalizedLosses'] is True
assert sha((R/'work/root/admission/official-score/score.json').read_bytes())=='eb31f3f8bac9ae9a31f3f932dd99a952ee57e6c46c876c901bb778c00ab6def5'
rawzip=R/'work/native-run/raw-artifact.zip';b=rawzip.read_bytes();assert len(b)==2539553 and sha(b)==plan['additions'][0]['sha256'];rawmeta={'path':str(rawzip),'bytes':len(b),'sha256':sha(b),'gitBlob':blob(b)}
safe_patterns=[rb'github_pat_[A-Za-z0-9_]{20,}',rb'gh[pousr]_[A-Za-z0-9]{20,}',rb'Bearer [A-Za-z0-9_.-]{20,}',rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
for name,b in members.items():
    assert not any(re.search(p,b)for p in safe_patterns),('Unexpected credential-shaped data',name)
    assert not any(x in name.lower()for x in ['private-transfer','private-slop','client-version','client_version'])
archive_receipt={'status':'SAFE_EXISTING_EBE_ADMISSION_AND_BOUNDED_ANALYSIS_RECORDS','source':S,'run':41176417138,'rawZIP':rawmeta,'seals':release['analysisSeals'],'rootAdmissionSha256':release['rootAdmission']['sha256'],'independentFinalManifestSha256':'6da13eda1fb1363fce3f295ba30c4bde2de955f390d86404191f93e4641b5708','omissions':omissions,'fullRawPublicLogPreserved':True,'maskedStaticLogLabelsAllowed':True,'actions':{'remoteWrites':0,'compilerNativeSDKScorerMetricVMTests':0,'analysisProducerExecutions':0},'scope':'Existing accepted historical Ebe normal control only; source141/CORE236/stage142,1034raw/norm and all1035 saved rows equal13fe. VM0; no whole-original/current-later-main/runtime/source-variant claim.'}
members['ARCHIVE-RECEIPT.json']=(json.dumps(archive_receipt,indent=2)+'\n').encode()
mm={n:{'bytes':len(b),'sha256':sha(b)}for n,b in sorted(members.items())};members['MANIFEST.json']=(json.dumps(mm,indent=2)+'\n').encode()
archive=O/'ebe-control-admission.tar.xz';assert not archive.exists()
with tarfile.open(archive,'w:xz',preset=6)as t:
    for n,b in sorted(members.items()):
        m=tarfile.TarInfo(n);m.size=len(b);m.mode=0o644;m.uid=m.gid=m.mtime=0;m.uname=m.gname='';t.addfile(m,io.BytesIO(b))
with tarfile.open(archive,'r:xz')as t:
    entries=t.getmembers();assert len(entries)==len(members)==len({x.name for x in entries})
    for m in entries:assert m.isfile() and t.extractfile(m).read()==members[m.name]
b=archive.read_bytes();archive_meta={'path':str(archive),'bytes':len(b),'sha256':sha(b),'gitBlob':blob(b),'members':len(members)}
receipt={'schema':'ebe-actual-normal-control-retention-receipt-v1','status':'ADMITTED_NATIVE_SUCCESS_NO_LOSS_VM0','source':plan['source'],'native':plan['native'],'rawZIP':rawmeta,'admissionArchive':archive_meta,'sourceNativeImages':root['images'],'official':{'total':1035,'raw':1034,'normalized':1034,'unmatched':['0x22a10'],'fullReferenceRows':1035,'allRowsEqual13fe':True,'changedRows':{},'rawLosses':0,'normalizedLosses':0,'rootScoreSha256':'eb31f3f8bac9ae9a31f3f932dd99a952ee57e6c46c876c901bb778c00ab6def5','rootAdmissionSha256':release['rootAdmission']['sha256'],'onceIndependentOfficialScorerRun':True,'independentAdmission':'PASS37_FIRST_ONLY_READER'},'targetMetric':release['targetMetric'],'boundedAnalysisConclusions':release['analysisConclusions'],'analysisSeals':{k:{'manifest':v['manifest'],'sha256':v['sha256']}for k,v in release['analysisSeals'].items()},'VM':{'executions':0,'resultTransferFrom13fe':False,'finiteRuntimeEquivalenceClaim':False},'preservation':{'allPreparationFailures':True,'ARTMETAExistingBeforeWriteFailurePreserved':True,'allRawProviderWrappersAndCanonicalMappings':True,'rawPublicMaskedLogUnchanged':True,'independentReleaseAndReaderRecords':True,'privateAuthTransferSlopClientVersionExcluded':True,'extraNativeCopiesOutsideZIP':0},'retentionAnchor':{k:plan[k]for k in ['repository','branch','expectedParent','expectedBaseTree']},'limits':['One exact accepted Ebe source normal control; no new source variant or diagnostic.','Full official window no-loss is distinct from target similarity and whole-original ELF identity.','Target metric, if present, comes only from separately sealed existing measurement; no measurement ran here.','No VM run, later-main qualification, security acceptance or followup candidate authorization.'],'actions':{'remoteWrites':0,'compilerNativeSDKScorerMetricVMTests':0,'analysisProducerExecutions':0},'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
p=O/'EBE-RECEIPT.json';assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n');b=p.read_bytes();receipt_meta={'path':str(p),'bytes':len(b),'sha256':sha(b),'gitBlob':blob(b)}
additions=[]
for dest,row in zip(plan['additions'],[rawmeta,archive_meta,receipt_meta]):additions.append({'path':plan['destinationPrefix']+dest['name'],'mode':'100644','type':'blob',**row})
freeze={'schema':'ebe-three-path-retention-append-freeze-v1','status':'FROZEN_READY_FOR_ROOT_REVIEW_NO_UPLOAD','repository':plan['repository'],'branch':plan['branch'],'expectedParent':plan['expectedParent'],'expectedBaseTree':plan['expectedBaseTree'],'remoteLeaseMustBeFetchedByRoot':True,'additions':additions,'exactNewPaths':3,'replaceOrDelete':False,'allInputFiles':inputs,'analysisSeals':receipt['analysisSeals'],'localPlanSha256':sha((O/'PLAN.json').read_bytes()),'finalReleaseSha256':sha((O/'FINAL-RELEASE.json').read_bytes()),'packagerSha256':sha(Path(__file__).read_bytes()),'rawPublicLogUnaltered':True,'archiveMembersVerified':len(members),'credentialPatternMatches':0,'actions':receipt['actions']}
p=O/'FROZEN-APPEND.json';assert not p.exists();p.write_text(json.dumps(freeze,indent=2)+'\n')
print(json.dumps({'freeze':str(p),'freezeSha256':sha(p.read_bytes()),'archiveMembers':len(members),'additions':additions}))
